/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.config;

import java.io.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.DocumentImpl;
import org.w3c.dom.Document;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.apache.xerces.parsers.DOMParser;
import gistoolkit.display.*;
import gistoolkit.server.*;

/**
 * Class for reading and writing configuration files.
 *
 * The GISToolkit configuration files are XML files that describe what to use to generate a map.
 * @author  ithaqua
 */
public class Configurator extends Object {
    
    /** Creates new Configurator */
    public Configurator() {
    }
    
    /** Write the configuration file for the GISDisplay */
    public static void writeConfig(GISDisplay inDisplay, String inFileName) throws Exception{
        
        // retrieve the node from the display
        gistoolkit.common.Node tempRootNode = inDisplay.getNode();
        
        // Convert the Node elements to an XML DOM representation
        Document tempDocument = new DocumentImpl();
        Element tempRootElement = tempDocument.createElement("GISToolkit");     // Create Root Element
        addNode(tempDocument, tempRootElement, tempRootNode);
        tempDocument.appendChild(tempRootElement);
        
        // write the XML Document
        File tempFile = new File(inFileName);
        OutputFormat    format  = new OutputFormat( tempDocument );   //Serialize DOM
        format.setIndenting(true);
        format.setLineSeparator("\n");
        FileWriter  fout = new FileWriter(tempFile);        //Writer will be a String
        XMLSerializer    serial = new XMLSerializer( fout, format );
        serial.asDOMSerializer();                            // As a DOM Serializer
        serial.serialize( tempDocument.getDocumentElement() );
        fout.close();
    }
    
    /** Set up the GISDisplay with the given configuration file */
    public static void readConfig(GISDisplay inDisplay, String inFileName) throws Exception{
        // read the XML document
        DOMParser parser = new DOMParser();
        parser.parse("file:///"+inFileName);
        Document tempDocument= parser.getDocument();
        Element tempRootElement = tempDocument.getDocumentElement();
        if (tempRootElement.getTagName().equals("GISToolkit")){
            gistoolkit.common.Node tempNode = getNode(tempRootElement);
            gistoolkit.common.Node tempDisplayNode = tempNode.getChild("GISDisplay");
            inDisplay.setNode(tempDisplayNode);
        }
        else throw new Exception("XML Error, can not find node GISToolkit");
    }
    
    /** Write the configuration file for the GISServer */
    public static void writeConfig(Server inServer, String inFileName) throws Exception{
        
        // retrieve the node from the display
        gistoolkit.common.Node tempRootNode = inServer.getNode();
        
        // Convert the Node elements to an XML DOM representation
        Document tempDocument = new DocumentImpl();
        Element tempRootElement = tempDocument.createElement("GISToolkit");     // Create Root Element
        addNode(tempDocument, tempRootElement, tempRootNode);
        tempDocument.appendChild(tempRootElement);
        
        // write the XML Document
        File tempFile = new File(inFileName);
        OutputFormat    format  = new OutputFormat( tempDocument );   //Serialize DOM
        format.setIndenting(true);
        format.setLineSeparator("\n");
        FileWriter  fout = new FileWriter(tempFile);        //Writer will be a String
        XMLSerializer    serial = new XMLSerializer( fout, format );
        serial.asDOMSerializer();                            // As a DOM Serializer
        serial.serialize( tempDocument.getDocumentElement() );
        fout.close();
    }

    /** Set up the Server with the given configuration file. */
    public static void readConfig(Server inServer, String inFileName) throws Exception {
        // read the XML document
        DOMParser parser = new DOMParser();
        parser.parse(inFileName);
        Document tempDocument= parser.getDocument();
        Element tempRootElement = tempDocument.getDocumentElement();
        if (tempRootElement.getTagName().equals("GISToolkit")){
            gistoolkit.common.Node tempNode = getNode(tempRootElement);
            gistoolkit.common.Node tempServerNode = tempNode.getChild("GISServer");
            inServer.setNode(tempServerNode);
        }
        else throw new Exception("XML Error, can not find node GISToolkit");        
    }

    /** Write the configuration file for the GISServer */
    public static void writeConfig(gistoolkit.common.Node inNode, String inFileName) throws Exception{
        
        // retrieve the node
        gistoolkit.common.Node tempRootNode = inNode;
        
        // Convert the Node elements to an XML DOM representation
        Document tempDocument = new DocumentImpl();
        Element tempRootElement = tempDocument.createElement("GISToolkit");     // Create Root Element
        addNode(tempDocument, tempRootElement, tempRootNode);
        tempDocument.appendChild(tempRootElement);
        
        // write the XML Document
        File tempFile = new File(inFileName);
        OutputFormat    format  = new OutputFormat( tempDocument );   //Serialize DOM
        format.setIndenting(true);
        format.setLineSeparator("\n");
        FileWriter  fout = new FileWriter(tempFile);        //Writer will be a String
        XMLSerializer    serial = new XMLSerializer( fout, format );
        serial.asDOMSerializer();                            // As a DOM Serializer
        serial.serialize( tempDocument.getDocumentElement() );
        fout.close();
    }

    /** Reads configuration information from the given file. */
    public static gistoolkit.common.Node readConfig( String inFileName) throws Exception {
        // read the XML document
        DOMParser parser = new DOMParser();
        parser.parse(inFileName);
        Document tempDocument= parser.getDocument();
        Element tempRootElement = tempDocument.getDocumentElement();
        if (tempRootElement.getTagName().equals("GISToolkit")){
            gistoolkit.common.Node tempNode = getNode(tempRootElement);
            gistoolkit.common.Node[] tempNodes = tempNode.getChildren();
            if (tempNodes.length > 0){
                return tempNodes[0];
            }
            return null;
        }
        else throw new Exception("XML Error, can not find node GISToolkit");        
    }
    
    /** Create a node tree from the element tree */
    private static gistoolkit.common.Node getNode(Element inElement){
        gistoolkit.common.Node tempRoot = new gistoolkit.common.Node(inElement.getTagName());
        NamedNodeMap tempMap = inElement.getAttributes();
        for (int i=0; i<tempMap.getLength(); i++){
            org.w3c.dom.Node tempNode = tempMap.item(i);
            tempRoot.addAttribute(tempNode.getNodeName(), tempNode.getNodeValue());
        }
        NodeList tempList = inElement.getChildNodes();
        String tempValue = "";
        for (int i=0; i<tempList.getLength(); i++){
            org.w3c.dom.Node tempNode = tempList.item(i);
            if (tempNode instanceof Text){
                tempValue = tempValue + tempNode.getNodeValue();
            }
            if (tempNode instanceof Element){
                gistoolkit.common.Node tempChildNode = getNode((Element) tempList.item(i));
                tempRoot.addChild(tempChildNode);
            }
        }
        tempRoot.setValue(tempValue);
        return tempRoot;
    }
    
    /** Add the node to the element, and all of it's sub nodes as well */
    private static void addNode(Document inDocument, Element inElement, gistoolkit.common.Node inNode){
        // add the node to the element
        try{
            Element tempElement = inDocument.createElement(inNode.getName());

            // add the attributes to the element
            String[] tempNames = inNode.getAttributeNames();
            for (int i=0; i<tempNames.length; i++){
                tempElement.setAttribute(tempNames[i], inNode.getAttribute(tempNames[i]));
            }

            // add the child nodes to the element
            gistoolkit.common.Node[] tempNodes = inNode.getChildren();
            for (int i=0; i<tempNodes.length; i++){
                addNode(inDocument, tempElement, tempNodes[i]);
            }

            // add this element to the element sent in
            inElement.appendChild(tempElement);
        }
        catch (Throwable e){
            System.out.println(inNode.getName());
            System.out.println(e);
            e.printStackTrace();
        }
        return;
    }
    
    /** Print the contents of a node to the standard output stream */
    public void print(gistoolkit.common.Node inNode){
        System.out.println(inNode.getName()+"="+inNode.getValue());
        String[] tempNames = inNode.getAttributeNames();
        for (int i=0; i<tempNames.length; i++){
            System.out.println(tempNames[i] + "="+inNode.getAttribute(tempNames[i]));
        }
        gistoolkit.common.Node[] tempNodes = inNode.getChildren();
        for (int i=0; i<tempNodes.length; i++){
            print(tempNodes[i]);
        }
    }
    
    /** Read an XML document from the given location, and parse it into a node tree */
    public static gistoolkit.common.Node getXML(String inLocation) throws Exception{
        // read the XML document
        DOMParser parser = new DOMParser();
        parser.setFeature("http://xml.org/sax/features/validation", false); 
        parser.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        parser.parse(inLocation);
        Document tempDocument= parser.getDocument();
        Element tempRootElement = tempDocument.getDocumentElement();
        gistoolkit.common.Node tempNode = getNode(tempRootElement);
        return tempNode;
    }
}
