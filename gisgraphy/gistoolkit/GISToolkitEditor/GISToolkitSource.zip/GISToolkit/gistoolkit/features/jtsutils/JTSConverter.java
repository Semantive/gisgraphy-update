/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */
package gistoolkit.features.jtsutils;

import com.vividsolutions.jts.geom.*;

/**
 * Class to use to convert a GISToolkit shape to a JTS shape and back.
 */
public class JTSConverter {
    /** Create a precision model. */
    private com.vividsolutions.jts.geom.PrecisionModel myPrecisionModel = new com.vividsolutions.jts.geom.PrecisionModel(gistoolkit.features.Shape.EQUAL_LIMIT);

    /** The default SRID. */
    private int mySRID = 0;
    
    /** Creates a new instance of JTSConverter */
    public JTSConverter() {
    }
        
    /** Convert a GISToolkit Point to a JTS Point. */
    public com.vividsolutions.jts.geom.Point convertPoint(gistoolkit.features.Point inPoint){
        if (inPoint == null) return null;
        com.vividsolutions.jts.geom.Coordinate tempCoordinate = new com.vividsolutions.jts.geom.Coordinate(inPoint.getX(), inPoint.getY(), 0);
        com.vividsolutions.jts.geom.Point tempPoint = new com.vividsolutions.jts.geom.Point(tempCoordinate, myPrecisionModel, mySRID);
        return tempPoint;
    }
    
    /** Converts a JTS Point to a GISToolkit Point. */
    public gistoolkit.features.Point convertPoint(com.vividsolutions.jts.geom.Point inPoint){
        if (inPoint == null) return null;
        gistoolkit.features.Point tempPoint = new gistoolkit.features.Point(inPoint.getX(), inPoint.getY());
        return tempPoint;
    }
    
    /** Converts a GISToolkit MultiPoint to a JTS MultiPoint. */
    public com.vividsolutions.jts.geom.MultiPoint convertMultiPoint(gistoolkit.features.MultiPoint inMultiPoint){
        if (inMultiPoint == null) return null;

        // I am not using getPoints() to attempt to make this faster.  getPoints() creates the array of points.
        double[] tempXs = inMultiPoint.getXCoordinates();
        double[] tempYs = inMultiPoint.getYCoordinates();
        
        com.vividsolutions.jts.geom.Point[] tempPoints = new com.vividsolutions.jts.geom.Point[inMultiPoint.getNumPoints()];
        for (int i=0; i<tempPoints.length; i++){
            com.vividsolutions.jts.geom.Coordinate tempCoordinate = new com.vividsolutions.jts.geom.Coordinate(tempXs[i], tempYs[i], 0);
            tempPoints[i] = new com.vividsolutions.jts.geom.Point(tempCoordinate, myPrecisionModel, mySRID);
        }
        com.vividsolutions.jts.geom.MultiPoint tempMultiPoint = new MultiPoint(tempPoints, myPrecisionModel, mySRID);
        return tempMultiPoint;
    }
    
    /** Converts a JTS MultiPoint to a GISToolkit MultiPoint. */
    public gistoolkit.features.MultiPoint convertMultiPoint(com.vividsolutions.jts.geom.MultiPoint inMultiPoint){
        if (inMultiPoint == null) return null;

        com.vividsolutions.jts.geom.Coordinate[] tempCoordinates = inMultiPoint.getCoordinates();
        double[] tempXs = new double[tempCoordinates.length];
        double[] tempYs = new double[tempCoordinates.length];
        for (int i=0; i<tempCoordinates.length; i++){
            tempXs[i] = tempCoordinates[i].x;
            tempYs[i] = tempCoordinates[i].y;
        }
        return new gistoolkit.features.MultiPoint(tempXs, tempYs);
    }
    
    /** Converts a GISToolkit LineString to a JTS LineString. */
    public com.vividsolutions.jts.geom.LineString convertLineString(gistoolkit.features.LineString inLineString){
        if (inLineString == null) return null;
        // I am not using getPoints() to attempt to make this faster.  getPoints() creates the array of points.
        double[] tempXs = inLineString.getXCoordinates();
        double[] tempYs = inLineString.getYCoordinates();
        
        com.vividsolutions.jts.geom.Coordinate[] tempPoints = new com.vividsolutions.jts.geom.Coordinate[inLineString.getNumPoints()];
        for (int i=0; i<tempPoints.length; i++){
            tempPoints[i] = new com.vividsolutions.jts.geom.Coordinate(tempXs[i], tempYs[i], 0);
        }
        com.vividsolutions.jts.geom.LineString tempLineString = new com.vividsolutions.jts.geom.LineString(tempPoints, myPrecisionModel, mySRID);
        return tempLineString;
    }
    
    /** Converts a JTS LineString to a GISToolkit LineString. */
    public gistoolkit.features.LineString convertLineString(com.vividsolutions.jts.geom.LineString inLineString){
        if (inLineString == null) return null;

        com.vividsolutions.jts.geom.Coordinate[] tempCoordinates = inLineString.getCoordinates();
        double[] tempXs = new double[tempCoordinates.length];
        double[] tempYs = new double[tempCoordinates.length];
        for (int i=0; i<tempCoordinates.length; i++){
            tempXs[i] = tempCoordinates[i].x;
            tempYs[i] = tempCoordinates[i].y;
        }
        return new gistoolkit.features.LineString(tempXs, tempYs);   
    }
    
    /** Converts a GISToolkit MultiLineString to a JTS MultiLineString. */
    public com.vividsolutions.jts.geom.MultiLineString convertMultiLineString(gistoolkit.features.MultiLineString inMultiLineString){
        if (inMultiLineString == null) return null;

        gistoolkit.features.LineString[] tempGISLineStrings = inMultiLineString.getLines();
        com.vividsolutions.jts.geom.LineString[] tempJTSLineStrings = new com.vividsolutions.jts.geom.LineString[tempGISLineStrings.length];
        for (int i=0; i<tempGISLineStrings.length; i++){
            tempJTSLineStrings[i] = convertLineString(tempGISLineStrings[i]);
        }
        com.vividsolutions.jts.geom.MultiLineString tempMultiLineString = new com.vividsolutions.jts.geom.MultiLineString(tempJTSLineStrings, myPrecisionModel, mySRID);
        return tempMultiLineString;
    }
    
    /** Converts a JTS MultiLineString to a GISToolkit MultiLineString. */
    public gistoolkit.features.MultiLineString convertMultiLineString(com.vividsolutions.jts.geom.MultiLineString inMultiLineString){
        if (inMultiLineString == null) return null;
        
        gistoolkit.features.LineString[] tempGISLineStrings = new gistoolkit.features.LineString[inMultiLineString.getNumGeometries()];
        for (int i=0; i<tempGISLineStrings.length; i++){
            tempGISLineStrings[i] = convertLineString( (com.vividsolutions.jts.geom.LineString) inMultiLineString.getGeometryN(i));
        }
        return new gistoolkit.features.MultiLineString(tempGISLineStrings);
    }    

    /** Converts a GISToolkit LinearRing to a JTS LinearRing. */
    public com.vividsolutions.jts.geom.LinearRing convertLinearRing(gistoolkit.features.LinearRing inLinearRing){
        if (inLinearRing == null) return null;
        // I am not using getPoints() to attempt to make this faster.  getPoints() creates the array of points.
        double[] tempXs = inLinearRing.getXCoordinates();
        double[] tempYs = inLinearRing.getYCoordinates();
        
        com.vividsolutions.jts.geom.Coordinate[] tempPoints = new com.vividsolutions.jts.geom.Coordinate[inLinearRing.getNumPoints()];
        for (int i=0; i<tempPoints.length; i++){
            tempPoints[i] = new com.vividsolutions.jts.geom.Coordinate(tempXs[i], tempYs[i], 0);
        }
        com.vividsolutions.jts.geom.LinearRing tempLinearRing = new com.vividsolutions.jts.geom.LinearRing(tempPoints, myPrecisionModel, mySRID);
        return tempLinearRing;
    }
    
    /** Converts a JTS LinearRing to a GISToolkit LinearRing. */
    public gistoolkit.features.LinearRing convertLinearRing(com.vividsolutions.jts.geom.LinearRing inLinearRing){
        if (inLinearRing == null) return null;

        com.vividsolutions.jts.geom.Coordinate[] tempCoordinates = inLinearRing.getCoordinates();
        double[] tempXs = new double[tempCoordinates.length];
        double[] tempYs = new double[tempCoordinates.length];
        for (int i=0; i<tempCoordinates.length; i++){
            tempXs[i] = tempCoordinates[i].x;
            tempYs[i] = tempCoordinates[i].y;
        }
        return new gistoolkit.features.LinearRing(tempXs, tempYs);   
    }
    
    /** Converts a GISToolkit Polygon to a JTS Polygon. */
    public com.vividsolutions.jts.geom.Polygon convertPolygon(gistoolkit.features.Polygon inPolygon){
        if (inPolygon == null) return null;
        
        // convert the posative (exterior) ring.
        com.vividsolutions.jts.geom.LinearRing tempPosativeRing = convertLinearRing(inPolygon.getPosativeRing());
        
        // convert the holes.
        gistoolkit.features.LinearRing[] tempGISHoles = inPolygon.getHoles();
        com.vividsolutions.jts.geom.LinearRing[] tempJTSHoles = null;
        if (tempGISHoles == null){
            tempJTSHoles = new com.vividsolutions.jts.geom.LinearRing[0];
        }
        else{
            tempJTSHoles = new com.vividsolutions.jts.geom.LinearRing[tempGISHoles.length];
            for (int i=0; i<tempGISHoles.length; i++){
                tempJTSHoles[i] = convertLinearRing(tempGISHoles[i]);
            }
        }
        
        com.vividsolutions.jts.geom.Polygon tempPolygon = new  com.vividsolutions.jts.geom.Polygon(tempPosativeRing, tempJTSHoles, myPrecisionModel, mySRID);
        return tempPolygon;
    }
            
    /** Converts a JTS Polygon to a GISToolkit Polygon. */
    public gistoolkit.features.Polygon convertPolygon(com.vividsolutions.jts.geom.Polygon inPolygon){
        if (inPolygon == null) return null;

        // convert the posative (exterior) ring.
        gistoolkit.features.LinearRing tempPosativeRing = convertLinearRing((com.vividsolutions.jts.geom.LinearRing) inPolygon.getExteriorRing());
        
        // convert the holes (interior ring.
        gistoolkit.features.LinearRing[] tempHoles = new gistoolkit.features.LinearRing[inPolygon.getNumInteriorRing()];
        for (int i=0; i<tempHoles.length; i++){
            tempHoles[i] = convertLinearRing((com.vividsolutions.jts.geom.LinearRing) inPolygon.getInteriorRingN(i));
        }
        
        gistoolkit.features.Polygon tempPolygon = new  gistoolkit.features.Polygon(tempPosativeRing, tempHoles);
        return tempPolygon;        
    }

    /** Converts a GISToolkit MultiPolygon to a JTS Polygon. */
    public com.vividsolutions.jts.geom.MultiPolygon convertMultiPolygon(gistoolkit.features.MultiPolygon inMultiPolygon){
        if (inMultiPolygon == null) return null;
        
        gistoolkit.features.Polygon[] tempGISPolygons = inMultiPolygon.getPolygons();
        com.vividsolutions.jts.geom.Polygon[] tempJTSPolygons = new com.vividsolutions.jts.geom.Polygon[tempGISPolygons.length];
        for (int i=0; i<tempGISPolygons.length; i++){
            tempJTSPolygons[i] = convertPolygon(tempGISPolygons[i]);
        }
        
        return new com.vividsolutions.jts.geom.MultiPolygon(tempJTSPolygons, myPrecisionModel, mySRID);
    }

    /** Converts a JTS MultiPolygon to a GISToolkit Polygon. */
    public gistoolkit.features.MultiPolygon convertMultiPolygon(com.vividsolutions.jts.geom.MultiPolygon inMultiPolygon){
        if (inMultiPolygon == null) return null;
        
        gistoolkit.features.Polygon[] tempGISPolygons = new gistoolkit.features.Polygon[inMultiPolygon.getNumGeometries()];
        for (int i=0; i<tempGISPolygons.length; i++){
            tempGISPolygons[i] = convertPolygon((com.vividsolutions.jts.geom.Polygon) inMultiPolygon.getGeometryN(i));
        }
        
        return new gistoolkit.features.MultiPolygon(tempGISPolygons);
    }
    
    /** Converts a GISToolkit shape to a JTS Geomethry. */
    public com.vividsolutions.jts.geom.Geometry convertShape(gistoolkit.features.Shape inShape){
        if (inShape instanceof gistoolkit.features.Point) return convertPoint((gistoolkit.features.Point) inShape);
        if (inShape instanceof gistoolkit.features.MultiPoint) return convertMultiPoint((gistoolkit.features.MultiPoint) inShape);
        if (inShape instanceof gistoolkit.features.LineString) return convertLineString((gistoolkit.features.LineString) inShape);
        if (inShape instanceof gistoolkit.features.MultiLineString) return convertMultiLineString((gistoolkit.features.MultiLineString) inShape);
        if (inShape instanceof gistoolkit.features.LinearRing) return convertLinearRing((gistoolkit.features.LinearRing) inShape);
        if (inShape instanceof gistoolkit.features.Polygon) return convertPolygon((gistoolkit.features.Polygon) inShape);
        if (inShape instanceof gistoolkit.features.MultiPolygon) return convertMultiPolygon((gistoolkit.features.MultiPolygon) inShape);
        return null;
    }
    
    /** Converts a JTS Geometry to a GISToolkit shape. */
    public gistoolkit.features.Shape convertShape(com.vividsolutions.jts.geom.Geometry inGeometry){
        if (inGeometry instanceof com.vividsolutions.jts.geom.Point) return convertPoint((com.vividsolutions.jts.geom.Point) inGeometry);
        if (inGeometry instanceof com.vividsolutions.jts.geom.MultiPoint) return convertMultiPoint((com.vividsolutions.jts.geom.MultiPoint) inGeometry);
        if (inGeometry instanceof com.vividsolutions.jts.geom.LinearRing) return convertLinearRing((com.vividsolutions.jts.geom.LinearRing) inGeometry);
        if (inGeometry instanceof com.vividsolutions.jts.geom.LineString) return convertLineString((com.vividsolutions.jts.geom.LineString) inGeometry);
        if (inGeometry instanceof com.vividsolutions.jts.geom.MultiLineString) return convertMultiLineString((com.vividsolutions.jts.geom.MultiLineString) inGeometry);
        if (inGeometry instanceof com.vividsolutions.jts.geom.Polygon) return convertPolygon((com.vividsolutions.jts.geom.Polygon) inGeometry);
        if (inGeometry instanceof com.vividsolutions.jts.geom.MultiPolygon) return convertMultiPolygon((com.vividsolutions.jts.geom.MultiPolygon) inGeometry);
        return null;
    }
}
