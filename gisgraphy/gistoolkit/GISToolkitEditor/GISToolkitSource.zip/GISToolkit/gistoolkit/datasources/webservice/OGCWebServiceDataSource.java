/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.datasources.webservice;

import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;
/**
 * Data source for reading images from an OGC WebMapService.
 */
public class OGCWebServiceDataSource extends SimpleDataSource implements RasterDatasource {
    
    /** Holds the base URL for reading information from this datasource */
    private String myURLBase = "";
    /** Set the base URL for reading information from this datasource */
    public void setURLBase(String inURLBase){myURLBase = inURLBase;}
    /** Retrieve the base URL for reading information from this datasource */
    public String getURLBase(){return myURLBase;}
    
    /** Holds the name of the service.  This is only required for the ESRI services, the bastards*/
    private String myService = null;
    /** set the service name of the service when connecting to an ESRI service */
    public void setService(String inService){myService = inService;}
    /** Retrive the name of the service */
    public String getService(){return myService;}
    
    /** The client to use for connecting with the web service */
    private OGCClient myOGCClient = null;
    
    /** Creates new OGCWebServiceDataSource */
    public OGCWebServiceDataSource() {
    }
        
    /** The name of this data source */
    private String myName = "OGC Web Service";
    /**Sets an identifier string for the datasource.*/
    public void setName(String inName) { myName = inName;}
    /**Returns the identifier string for the datasource.*/
    public String getName() {return myName;}
    
    /** The list of layers in the order they are to be drawn */
    private Layer[] myLayers = new Layer[0];
    /** Retrieve the list of layers */
    public Layer[] getLayers(){return myLayers;}
    /** Set the list of layers */
    public void setLayers(Layer[] inLayers){myLayers = inLayers;}
                
    /**
     * Determines if this datasource is updateable.
     */
    public boolean isUpdateable() {
        return false;
    }
    
    /** Connect to the data source */
    public void connect() throws Exception{
        // Attempt to connect with the 1.1 client
        
        // Attempt to connect with the 1.0 client
        OGCClient tempClient = new Client100();
        tempClient.setURLBase(getURLBase());
        tempClient.setService(getService());
        try{
            tempClient.connect();
            myOGCClient = tempClient;
        }
        catch (Exception e){
            System.out.println(""+e);
            throw e;
        }
    }
        
    private static final String DATASOURCE_NAME = "DataSourceName";
    private static final String URLBASE = "URLBase";
    
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("OGCWebServiceDataSource");
        tempRoot.addAttribute(DATASOURCE_NAME, myName);
        tempRoot.addAttribute(URLBASE, myURLBase);
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        if (inNode == null) throw new Exception("Error reading configuration information for OGCWebServcieDataSource");
        super.setNode(inNode);
        String tempString = inNode.getAttribute(DATASOURCE_NAME);
        if (tempString != null) myName = tempString;
        tempString = inNode.getAttribute(URLBASE);
        if (tempString != null)myURLBase = tempString;
    }
    
    /** Retrieve the available layers */
    public Layer[] getAvailableLayers(){
        return myOGCClient.getLayers();
    }
    
    /**
     * Set the width of the image to retrieve.
     * The data source can use this information to generate the appropriate rastor shapes.
     * Several shapes may be generated or just one that cover this area.  This is just a
     * suggestion.
     */
    public void setImageWidth(int inWidth) {
        myOGCClient.setWidth(inWidth);
    }
    
    /**
     * Set the height of the image to retrieve.
     * The data source can use this information to generate the appropriate rastor shapes.
     * Several shapes may be generated or just one that cover this area.  This is just a
     * suggestion.
     */
    public void setImageHeight(int inHeight) {
        myOGCClient.setHeight(inHeight);
    }
    
    /** Retrieve the available map formats */
    public String[] getAvailableMapFormats(){
        if (myOGCClient != null) return myOGCClient.getMapFormats();
        return new String[0];
    }
    
    /** Set the Selected map format */
    public void setSelectedMapFormat(String inFormat){
        if (myOGCClient != null) myOGCClient.setSelectedMapFormat(inFormat);
    }
        
    /** Returns the bounding rectangle of all the shapes in the Data Source. */
    public Envelope readEnvelope() throws Exception {
        return null;
    }
    
    /** This method should return the shapes from the data source  */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception {
        // send the request to the server
        myOGCClient.setSelectedLayers(myLayers);
        GISDataset tempDataset = myOGCClient.read(inEnvelope);
        
        return tempDataset;
    }    
}