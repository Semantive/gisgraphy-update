/*
 * JAIImageReader.java
 *
 */

package gistoolkit.datasources.imagefile;

import java.io.*;
import java.awt.image.*;

/**
 * Class to protect from Instantiation exceptions if JAI is not installed.
 */
public class JAIImageReader {
    private File myFile = null;
    
    /** The width of the image. */
    private int myWidth = -1;
    public int getWidth(){return myWidth;}
    
    /** The height of the image*/
    private int myHeight = -1;
    public int getHeight(){return myHeight;}
    
    /** The Rendered Image in case it should be needed. */
    private RenderedImage myImage = null;
    public RenderedImage getImage(){return myImage;}
   
    
    /** Creates a new instance of JAIImageReader */
    public JAIImageReader(String inFile) throws Exception{
        myFile = new File(inFile);
        RenderedImage image = javax.media.jai.JAI.create("fileload", inFile);
        myImage = image;
        myWidth = image.getWidth();
        myHeight = image.getHeight();        
    }
}
