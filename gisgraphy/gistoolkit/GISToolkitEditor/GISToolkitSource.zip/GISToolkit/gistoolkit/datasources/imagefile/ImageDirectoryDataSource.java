/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile;

import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.io.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.projection.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.imagefile.imagereaders.*;

/**
 * The idea is that there will be a directory on disk that will contain mayn Tif/tfw files.  These files
 * will be indexed by this data source, and only the images that need to be read will be.
 */
public class ImageDirectoryDataSource extends SimpleDataSource implements ImageObserver{
    /** Vector of envelopes for the files. */
    private Vector myEnvelopeVect = new Vector();
    
    /** Vector of filenames for the files. */
    private Vector myFileVect = new Vector();
    
    /** An envelope of all envelopes to check first to see if we should even bother. */
    private Envelope myImageEnvelope = null;
    
    /** The name of the directory where the images are stored. */
    private File myImageDirectory = null;
    /** Set the name of the directory where the images are stored. */
    public void setImageDirectory(String inImageDirectory)throws FileNotFoundException{
        File tempFile = new File(inImageDirectory);
        if (!tempFile.exists()) throw new FileNotFoundException("File "+inImageDirectory+" does not exist");
        if (!tempFile.isDirectory()) throw new FileNotFoundException("File "+inImageDirectory+" Is not a directory");
        myImageDirectory = tempFile;
        loadIndex();
    };
    /** Get the name of the directory where the images are stored. */
    public String getImageDirectory(){
        if (myImageDirectory == null) return null;
        return myImageDirectory.getAbsolutePath();
    }
    
    /** Creates new ImageDirectoryDataSource */
    public ImageDirectoryDataSource() {
        super();
    }
    /** Creates new ImageDirectoryDataSource with the given file.*/
    public ImageDirectoryDataSource(File inDirectory) throws Exception{
        super();
        
        // set the directory
        setImageDirectory(inDirectory.getAbsolutePath());
        setName(inDirectory.getName());
    }
    
    /** Set the projection from which this data should be projected. */
    public void setFromProjection(Projection inProjection)throws Exception{
        super.setFromProjection(inProjection);
        myGISDataset = null;
    }
    
    /** Constants for the configuration information*/
    private static final String IMAGE_DIRECTORY_TAG = "ImageFileName";
    
    /** Get the configuration information for this layer. */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("ImageDirectoryDataSource");
        tempRoot.addAttribute(IMAGE_DIRECTORY_TAG, myImageDirectory.getAbsolutePath());
        return tempRoot;
    }
    
    /** Set the configuration information for this layer. */
    public void setNode(Node inNode) throws Exception{
        if (inNode != null){
            
            // construct the file
            String tempString = inNode.getAttribute(IMAGE_DIRECTORY_TAG);
            if (tempString != null){
                try{
                    setImageDirectory(tempString);
                }
                catch (FileNotFoundException e){
                    System.out.println("ImageFile "+tempString+" does not exist");
                }
            }
        }
        super.setNode(inNode);
    }
    
    /**
     * Returns the bounding rectangle of all the shapes in the Data Source.
     */
    public Envelope readEnvelope() throws Exception {
        // envelope are not immutable, make a defensive copy.
        if (myImageEnvelope != null) return (Envelope) myImageEnvelope.clone();
        else return null;
    }
    
    /** Only read the image the once. */
    private GISDataset myGISDataset = null;
    
    /**
     * Reads only the objects from the data source that intersect these envelope.
     */
    public synchronized GISDataset readDataset(Envelope inEnvelope) throws Exception {
        if (inEnvelope == null) return readDataset();
        boolean blewCache = false;
        if (getCached()){
            blewCache = !isCachedProjected();
        }
        
        // all the things that can blow a cache.
        if ((getFromProjection() == null) || (getToProjection() == null)||(blewCache)||(getFromProjection() instanceof NoProjection)||(getToProjection() instanceof NoProjection)){
            return super.readDataset(inEnvelope);
        }
        else{
            
            // this is a very specific case to try to increase the resolution of reprojected images.
            // If there is a from and a to projection, chances are they are from and two similar projections
            // It is much more efficient to project these once than to do it many times.
            
            Envelope tempEnvelope = inEnvelope;
            if (getCacheEnvelope() != null){
                if (getCacheEnvelope().contains(tempEnvelope)){
                    return queryFromCache(tempEnvelope);
                }
            }
            tempEnvelope = ShapeProjector.projectBackward(getToProjection(), inEnvelope);
            // I have some concerns about this because the shape is not really a square at this point.
            // would be more efficient to convert to a polygon and then query from that.
            GISDataset tempDataset = readShapes(ShapeProjector.projectForward(getFromProjection(), tempEnvelope));
            if (tempDataset != null){
                tempDataset = filterDataset(tempDataset);
                tempDataset = (GISDataset) tempDataset.clone();
                for (int i=0; i<tempDataset.size(); i++){
                    gistoolkit.features.Shape tempShape = tempDataset.getShape(i);
                    if ((tempShape != null) && (tempShape instanceof RasterShape)){
                        ImageProjector.reProject(getFromProjection(), getToProjection(), (RasterShape) tempShape);
                    }
                }
                setCache(tempDataset, (Envelope) inEnvelope.clone());
            }
            return tempDataset;
        }
    }
    
    
    /**
     * Reads all the objects from the data source.
     */
    public GISDataset readDataset() throws Exception {
        if ((getFromProjection() == null) || (getToProjection() == null)||(!isCachedProjected())||(getFromProjection() instanceof NoProjection)||(getToProjection() instanceof NoProjection)){
            return super.readDataset(null);
        }
        else{
            
            // this is a very specific case to try to increase the resolution of reprojected images.
            // If there is a from and a to projection, chances are they are from and two similar projections
            // It is much more efficient to project these once than to do it many times.
            GISDataset tempDataset = readShapes(null);
            if (tempDataset != null){
                tempDataset = filterDataset(tempDataset);
                for (int i=0; i<tempDataset.size(); i++){
                    gistoolkit.features.Shape tempShape = tempDataset.getShape(i);
                    if ((tempShape != null) && (tempShape instanceof RasterShape)){
                        ImageProjector.reProject(getFromProjection(), getToProjection(), (RasterShape) tempShape);
                    }
                }
                setCache(tempDataset, (Envelope) tempDataset.getEnvelope().clone());
            }
            return tempDataset;
        }
    }
    
    /** This method should return the shapes from the data source  */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception {
        // if this envelope is no where near the one that I have, then just return nothing.
        if (inEnvelope != null){
            if (!inEnvelope.overlaps(myImageEnvelope)){
                return new GISDataset();
            }
        }
        
        // create the index should it not exist.
        loadIndex();
        
        // create the dataset
        String[] tempAttributeNames = {"FileName"};
        AttributeType[] tempAttributeTypes = {new AttributeType(AttributeType.STRING)};
        GISDataset tempGISDataset = new GISDataset(tempAttributeNames, tempAttributeTypes);
        for (int i=0; i<myEnvelopeVect.size(); i++){
            // check for envelope overlap.
            String tempFileName = (String) myFileVect.elementAt(i);
            Envelope tempEnvelope = (Envelope) myEnvelopeVect.elementAt(i);
            if (tempEnvelope.overlaps(inEnvelope)){
                RasterShape tempShape = readImage(tempFileName, tempEnvelope);
                
                // create the record
                Object[] tempAttributes = {tempFileName};
                tempGISDataset.add(tempAttributes, tempShape);
            }
        }
        
        // return the dataset
        return tempGISDataset;
    }
    
    /** Read the RasterShape from the file system. */
    private RasterShape readImage(String inFilename, Envelope inEnvelope){
        try{
            File tempImageFile = new File(myImageDirectory.getAbsolutePath() + File.separatorChar + inFilename);
            // read the image from a file.
            Image tempImage = null;
            BufferedImage tempBufferedImage = null;

            // If you have the JAI package (yippie!)
            ImageInformation tempInfo = ImageReader.readImage(tempImageFile.getAbsolutePath());
            if (tempInfo.getImage() != null){
                int tempWidth = tempInfo.getImageWidth();
                int tempHeight = tempInfo.getImageHeight();
                tempBufferedImage = new BufferedImage(tempWidth, tempHeight, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = (Graphics2D) tempBufferedImage.getGraphics();
                if (tempInfo.getImage() instanceof RenderedImage){
                    g2d.drawRenderedImage((RenderedImage)tempInfo.getImage(), AffineTransform.getTranslateInstance(0,0));
                }
                else{
                    // track the image
                    Panel tempPanel = new Panel();
                    tempImage = tempInfo.getImage();
                    MediaTracker mt = new MediaTracker(tempPanel);
                    mt.addImage(tempImage, 0);
                    mt.waitForAll();

                    // grab the pixels
                    int[] pixels = new int[tempWidth * tempHeight];
                    PixelGrabber pg = new PixelGrabber(tempImage, 0, 0, tempWidth, tempHeight, pixels, 0, tempWidth);
                    pg.grabPixels();

                    // create a buffered image from this image.
                    tempBufferedImage = new BufferedImage(tempImage.getWidth(this), tempImage.getHeight(this), BufferedImage.TYPE_INT_ARGB);
                    Graphics g = tempBufferedImage.getGraphics();
                    g.drawImage(tempImage,0,0, this);
                }
            }
            
            // in this case, there is only one shape, and it is the image.
            RasterShape tempRasterShape = new RasterShape(inEnvelope, tempBufferedImage);
            return tempRasterShape;
        }
        catch (Exception e){
            System.out.println("Could not read image "+inFilename+" "+e);
        }
        return null;
    }
    
    
    
    /** The name of the index file. */
    private String myIndexFileName = "Index.idx";
    /** Set the name of the index file. */
    public void setIndexFileName(String inIndexFileName){if (inIndexFileName != null) myIndexFileName = inIndexFileName;}
    /** Get the name of the index file. */
    public String getIndexFileName(){return myIndexFileName;}
    
    /** Create the index should it not exist. */
    public void loadIndex(){
        
        /** Check for the existence of the index file. */
        File tempIndexFile = new File(myImageDirectory.getAbsolutePath() + File.separatorChar + getIndexFileName());
        if ((tempIndexFile.exists()) && (myImageEnvelope != null)) return;
        
        // if the index file exists, then use it.
        boolean tempReadIndex = false;
        if (tempIndexFile.exists()){
            try{
                FileReader fread = new FileReader(tempIndexFile);
                BufferedReader bread = new BufferedReader(fread);
                String tempLine = bread.readLine();
                while (tempLine != null){
                    tempLine = tempLine.trim();
                    if ((tempLine.length() > 0)&&(!tempLine.startsWith("#"))){
                        // read the input line
                        StringTokenizer st = new StringTokenizer(tempLine);
                        try{
                            // read the file name
                            String tempFileName = st.nextToken("|");
                            tempFileName = tempFileName.trim();
                            File tempFile = new File(myImageDirectory.getAbsolutePath() + File.separatorChar + tempFileName);
                            
                            // if the file exists, then read it's coordinates.
                            if (tempFile.exists()){
                                
                                String tempMinXS = st.nextToken("|");
                                double tempMinX = Double.parseDouble(tempMinXS);
                                String tempMinYS = st.nextToken("|");
                                double tempMinY = Double.parseDouble(tempMinYS);
                                String tempMaxXS = st.nextToken("|");
                                double tempMaxX = Double.parseDouble(tempMaxXS);
                                String tempMaxYS = st.nextToken("|");
                                double tempMaxY = Double.parseDouble(tempMaxYS);
                                
                                // Create the index
                                Envelope tempEnvelope = new Envelope(tempMinX, tempMinY, tempMaxX, tempMaxY);
                                
                                // add the envelope to the index.
                                myEnvelopeVect.addElement(tempEnvelope);
                                myFileVect.addElement(tempFileName);
                                
                            }
                        }
                        catch (Exception e){
                        }
                    }
                    tempLine = bread.readLine();
                }
                tempReadIndex = true;
            }
            catch (IOException e){
                System.out.println("Error reading Index "+e);
            }
        }
        
        // if the index was not read for some reason, then build it.
        if (!tempReadIndex){
            System.out.println("Building Image Index File "+tempIndexFile.getAbsolutePath());
            String[] tempExtensions = {".tif",".tiff",".jpg",".gif",".png"};
            try{
                // read all the files in the directory.
                File[] tempFiles = myImageDirectory.listFiles();
                for (int i=0; i<tempFiles.length; i++){
                    // look for tfw files.
                    String tempName = tempFiles[i].getName();
                    if ((tempName.toUpperCase().endsWith(".TFW"))||(tempName.toUpperCase().endsWith(".JGW"))||(tempName.toUpperCase().endsWith(".TIFW"))){
                        int tempExtensionLength = 0;
                        if (tempName.toUpperCase().endsWith(".TFW")) tempExtensionLength = 4;
                        if (tempName.toUpperCase().endsWith(".JGW")) tempExtensionLength = 4;
                        if (tempName.toUpperCase().endsWith(".TIFW")) tempExtensionLength = 5;
                        
                        // look for the image file for this TFw
                        String tempBase = myImageDirectory.getAbsolutePath() + File.separatorChar + tempName.substring(0, tempName.length()-tempExtensionLength);
                        String tempFileName = null;
                        
                        // Is it a file we know about? (could be faster to query this way).
                        for (int j=0; j<tempExtensions.length; j++){
                            File tempTestFile  = new File(tempBase + tempExtensions[j]);
                            if (tempTestFile.exists()){
                                tempFileName = tempTestFile.getName();
                                break;
                            }
                        }
                        
                        // if it was not found, then look for all others.
                        if (tempFileName == null){
                            String tempBaseName = tempName.substring(0, tempName.length()-tempExtensionLength);
                            for (int j=0; j<tempFiles.length; j++){
                                String tempImageName = tempFiles[j].getName();
                                tempImageName = tempImageName.toUpperCase();
                                if ((!tempImageName.endsWith(".TFW"))&&(!tempImageName.endsWith(".TIFW"))){
                                    if (tempImageName.toUpperCase().startsWith(tempBaseName)){
                                        tempFileName = tempImageName;
                                        break;
                                    }
                                }
                            }
                        }
                        
                        // if it was found, then read the world file.
                        if (tempFileName != null){
                            Envelope tempEnvelope = loadEnvelope(new File(myImageDirectory.getAbsolutePath() + File.separatorChar + tempFileName));
                            if (tempEnvelope != null){
                                myEnvelopeVect.addElement(tempEnvelope);
                                myFileVect.addElement(tempFileName);
                            }
                        }
                    }
                }
                saveIndex();
                
            }
            catch (Exception e){
            }
        }
        // build the image Envelope.
        if (myEnvelopeVect.size() > 0){
            gistoolkit.features.featureutils.EnvelopeBuffer tempBuffer = new gistoolkit.features.featureutils.EnvelopeBuffer();
            for (int i=0; i<myEnvelopeVect.size(); i++){
                tempBuffer.expandToInclude((Envelope) myEnvelopeVect.elementAt(0));
            }
            
            // set the envelope.
            myImageEnvelope = tempBuffer.getEnvelope();
        }
        
    }
    
    /** Check for a world file from which to load the Envelope. */
    public Envelope loadEnvelope(File inImageFile){
        /** Check for World file. */
        Envelope tempEnvelope = null;
        String tempLocation = inImageFile.getAbsolutePath();
        if ((tempLocation != null) && (tempLocation.length() > 0)){
            // try to find the extension
            int tempIndex = tempLocation.lastIndexOf(".");
            if (tempIndex != -1){
                String tempFileBase = tempLocation.substring(0, tempIndex);
                
                // try to find the file
                boolean tempFound = false;
                File tempFile = new File(tempFileBase+".tfw");
                if (tempFile.exists()){
                    tempFound = true;
                }
                if (!tempFound){
                    tempFile = new File(tempFileBase + ".tifw");
                    if (tempFile.exists()){
                        tempFound = true;
                    }
                }
                if (!tempFound) return tempEnvelope;
                
                try{
                    // read the contents
                    FileReader fread = new FileReader(tempFile);
                    BufferedReader bread = new BufferedReader(fread);
                    String tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The dimension of a pixel in map units in the x-direction) is not available");
                    double tempXScale = Double.parseDouble(tempLine);
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The rotation factor in the x-direction (generally 0)) is not available");
                    double  tempXRot = 0;
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The rotation factor in the y-direction (generally 0)) is not available");
                    double  tempYRot = 0;
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The negative of the dimension of a pixel in map units in the y-direction) is not available");
                    double  tempYScale = Double.parseDouble(tempLine);
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The x-coordinate of the center of the upper left pixel) is not available");
                    double  tempXStart = Double.parseDouble(tempLine);
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The y-coordinate of the center of the upper left pixel) is not available");
                    double  tempYStart = Double.parseDouble(tempLine);
                    
                    // how many pixels are there in the image
                    String tempImageLocation = inImageFile.getAbsolutePath();
                    
                    // read the image from a file.
                    int tempWidth = 0;
                    int tempHeight = 0;
                    try{
                        JAIImageReader tempImageReader = new JAIImageReader(tempImageLocation);
                        tempWidth = tempImageReader.getWidth();
                        tempHeight = tempImageReader.getHeight();
                    }
                    catch (Exception e){
                        Image tempImage = Toolkit.getDefaultToolkit().createImage(tempImageLocation);
                        System.out.println(tempImage);
                        
                        // track the image
                        MediaTracker mt = new MediaTracker(new Panel());
                        mt.addImage(tempImage, 0);
                        mt.waitForAll();
                        
                        // get the height.
                        tempWidth = tempImage.getWidth(this);
                        tempHeight = tempImage.getHeight(this);
                    }
                    
                    if ((tempWidth == 0) || (tempHeight == 0)) throw new Exception("Can not read the image file "+tempImageLocation);
                    
                    // calculate the bounds.
                    double tempTopX = tempXStart;
                    double tempBottomX = tempWidth*tempXScale + tempXStart;
                    double tempTopY = tempYStart;
                    double tempBottomY = tempHeight*tempYScale + tempYStart;
                    tempEnvelope = new Envelope(tempTopX, tempTopY, tempBottomX, tempBottomY);
                    
                }
                catch (Exception e){
                    System.out.println("Error parsing world file "+e);
                }
            }
        }
        return tempEnvelope;
    }
    
    /** Save the index to a file.
     *  <p>The format of the file will be:<p>
     *  <code>FileNameOfImageFile (relative to directory)|minX|minY|maxX|maxY<code>
     *  <p> All lines beginning with a # are ignored.
     */
    public void saveIndex()throws IOException{
        if (myEnvelopeVect.size()>0){
            File tempIndexFile = new File(myImageDirectory.getAbsolutePath() + File.separatorChar + getIndexFileName());
            FileWriter fwrite = new FileWriter(tempIndexFile);
            fwrite.write("#Filename|minX|minY|maxX|maxY\n");
            
            for (int i=0; i<myEnvelopeVect.size(); i++){
                String tempFileName = (String) myFileVect.elementAt(i);
                Envelope tempEnvelope = (Envelope) myEnvelopeVect.elementAt(i);
                fwrite.write(tempFileName);
                fwrite.write("|"+tempEnvelope.getMinX());
                fwrite.write("|"+tempEnvelope.getMinY());
                fwrite.write("|"+tempEnvelope.getMaxX());
                fwrite.write("|"+tempEnvelope.getMaxY());
                fwrite.write("\n");
            }
            fwrite.close();
        }
    }
    
    
    public boolean imageUpdate(java.awt.Image image, int param, int param2, int param3, int param4, int param5) {
        return true;
    }
    
    /** Get the style to use with this datasource.  */
    public gistoolkit.display.Style getStyle() {
        return null;
    }
    
}
