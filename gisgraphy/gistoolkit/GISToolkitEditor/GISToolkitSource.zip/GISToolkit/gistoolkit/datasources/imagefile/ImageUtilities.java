/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile;

import java.io.*;
import gistoolkit.features.Envelope;
import gistoolkit.datasources.imagefile.imagereaders.*;

/**
 * Class to contain code common to image files their reading/writing and manipulation.
 */
public class ImageUtilities {
    
    /** Creates a new instance of ImageUtilities */
    public ImageUtilities() {
    }
    
    /** Read the image information for this image. */
    public static ImageInformation readImageInformation(File inFile){
        // how many pixels are there in the image
        String tempImageLocation = inFile.getAbsolutePath();
        return ImageReader.readImage(tempImageLocation);
    }
    
    /** Calculate the envelope given the TFWFile. */
    public static Envelope calculateEnvelope(File inTFWFile, ImageInformation inImageInformation)throws Exception{
        if (inTFWFile == null) throw new Exception("Unable to read world coordinates, The World file is null");
        if (inImageInformation == null) throw new Exception("Unable to read Image Information for "+inTFWFile);
        
        /** Check for World file. */
        Envelope tempEnvelope = null;
        if (inTFWFile.length() > 0){
            
            // read the contents
            FileReader fread = new FileReader(inTFWFile);
            BufferedReader bread = new BufferedReader(fread);
            String tempLine = bread.readLine();
            if (tempLine == null) throw new Exception("First line of tfw (The dimension of a pixel in map units in the x-direction) is not available");
            double tempXScale = Double.parseDouble(tempLine);
            tempLine = bread.readLine();
            if (tempLine == null) throw new Exception("Second line of tfw (The rotation factor in the x-direction (generally 0)) is not available");
            double  tempXRot = 0;
            tempLine = bread.readLine();
            if (tempLine == null) throw new Exception("Third line of tfw (The rotation factor in the y-direction (generally 0)) is not available");
            double  tempYRot = 0;
            tempLine = bread.readLine();
            if (tempLine == null) throw new Exception("Fourth line of tfw (The negative of the dimension of a pixel in map units in the y-direction) is not available");
            double  tempYScale = Double.parseDouble(tempLine);
            tempLine = bread.readLine();
            if (tempLine == null) throw new Exception("Fifth line of tfw (The x-coordinate of the center of the upper left pixel) is not available");
            double  tempXStart = Double.parseDouble(tempLine);
            tempLine = bread.readLine();
            if (tempLine == null) throw new Exception("Sixth line of tfw (The y-coordinate of the center of the upper left pixel) is not available");
            double  tempYStart = Double.parseDouble(tempLine);
            
            int tempWidth = inImageInformation.getImageWidth();
            int tempHeight = inImageInformation.getImageHeight();
            if ((tempWidth == 0) || (tempHeight == 0)) throw new Exception("Can not read the image file for "+inTFWFile);
            
            // calculate the bounds.
            double tempTopX = tempXStart - tempXScale/2;
            double tempBottomX = tempWidth*tempXScale + tempXStart;
            double tempTopY = tempYStart - tempYScale/2;
            double tempBottomY = tempHeight*tempYScale + tempYStart;
            tempEnvelope = new Envelope(tempTopX, tempTopY, tempBottomX, tempBottomY);
        }
        return tempEnvelope;
    }

    /** Calculate the envelope given the TFWFile. */
    public static void writeWorldFile(File inOutputFile, Envelope inEnvelope, double inXDimen, double inYDimen) throws Exception{
        if (inOutputFile == null) throw new Exception("Unable to write world coordinates, The file is null");
        if (inEnvelope == null) throw new Exception("Envelope is null ");
        
        /** Check for World file. */
        Envelope tempEnvelope = null;
        FileWriter tempFileWriter = new FileWriter(inOutputFile);
        
        // The First line of the file is the dimension of a pixel in map units in the X direction.
        tempFileWriter.write(""+inXDimen);
        tempFileWriter.write("\n");
        
        // The Second line of the file is the rotation factor in the x direction.
        tempFileWriter.write(""+0.0);
        tempFileWriter.write("\n");
        
        // The Third line of the file is the rotation factor in the y direction
        tempFileWriter.write(""+0.0);
        tempFileWriter.write("\n");

        // The Fourth line of the file is the negative of the dimension of a pixel in map units in the Y direction.
        if (inYDimen > 0){
            inYDimen = -inYDimen;
        }
        tempFileWriter.write(""+inYDimen);
        tempFileWriter.write("\n");
        
        // The Fifth line of the file is the x coordinate of the center of the upper left pixel.
        tempFileWriter.write(""+(inEnvelope.getMinX()+(inXDimen/2)));
        tempFileWriter.write("\n");
        
        // The Sixth line of the file is the y coordinate of the center of the upper left pixel.
        tempFileWriter.write(""+(inEnvelope.getMaxY()+(inYDimen/2)));
        tempFileWriter.write("\n");
        tempFileWriter.close();
    }
    
    /** Check for a world file from which to load the Envelope. */
    public static Envelope loadEnvelope(File inTFWFile, File inImageFile) throws Exception{
        if ((inTFWFile == null) && (inImageFile == null)) throw new Exception("Unable to read world coordinates.  Both the World and image files are null");
        if (inTFWFile == null) throw new Exception("Unable to read world coordinates for "+inImageFile.getAbsolutePath()+".  The World file is null");
        if (inImageFile == null) throw new Exception("Unable to read world coordinates for "+inTFWFile.getAbsolutePath()+".  The Image file is null");
        
        ImageInformation tempImageInformation = readImageInformation(inImageFile);
        if (tempImageInformation == null) throw new Exception("Can not read the image file "+inImageFile);
        return calculateEnvelope(inTFWFile, tempImageInformation);
    }
}
