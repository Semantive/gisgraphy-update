/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import gistoolkit.features.*;
import gistoolkit.datasources.imagefile.imagereaders.*;
import javax.imageio.*;

/**
 * Class to cut georeferenced images into 1/4 of their orrigional size.
 */
public class ImageChopper {
    
    /** The location of the source directory of images. */
    private File mySourceImageDirectory = null;
    /** Get the location of the source directory containing the images to convert. */
    public String getSourceImageDirectory(){if (mySourceImageDirectory == null) return null; return mySourceImageDirectory.getAbsolutePath();}
    /** Set the location of the source directory containing the images to convert. */
    public void setSourceImageDirectory(String inSourceImageDirectory) throws FileNotFoundException{
        if (inSourceImageDirectory == null) throw new FileNotFoundException("Input file is null");
        File tempFile = new File(inSourceImageDirectory);
        if (!tempFile.exists()) throw new FileNotFoundException("File "+inSourceImageDirectory+" can not be found.");
        if (!tempFile.isDirectory()) throw new FileNotFoundException("File "+inSourceImageDirectory+" is not a directory.");
        mySourceImageDirectory = tempFile;
    }
    
    /** The location of the destination directory of images. */
    private File myDestinationImageDirectory = null;
    /** Get the location of the source directory containing the images to convert. */
    public String getDestinationImageDirectory(){if (myDestinationImageDirectory == null) return null; return myDestinationImageDirectory.getAbsolutePath();}
    /** Set the location of the source directory containing the images to convert. */
    public void setDestinationImageDirectory(String inDestinationImageDirectory) throws FileNotFoundException{
        if (inDestinationImageDirectory == null) throw new FileNotFoundException("Input file is null");
        File tempFile = new File(inDestinationImageDirectory);
        if (!tempFile.exists()){
            // create the destination folder should it not exist.
            tempFile.mkdirs();
            if (!tempFile.exists())throw new FileNotFoundException("File "+inDestinationImageDirectory+" can not be found.");
        }
        if (!tempFile.isDirectory()) throw new FileNotFoundException("File "+inDestinationImageDirectory+" is not a directory.");
        myDestinationImageDirectory = tempFile;
    }
    
    /** The type to write.*/
    private String myOutputType = "JPG";
    /** Set the type to write. */
    public void setOutputType(String inOutputType){myOutputType = inOutputType;}
    /** Get the type to write. */
    public String getOutputType(){return myOutputType;}

    /** Tells this thread to stop processing. */
    private boolean myStopProcessing = false;
    /** Set the status of the stop processing. */
    public void setStopProcessing(boolean inStopProcessing){myStopProcessing = inStopProcessing;}
    
    /** The world file extensions to check for. */
    private String[] myWorldFileExtensions = {".TFW",".TIFW",".JGW"};
    
    /** The image file extensions to check for. */
    private String[] myImageFileExtensions = {".jpg",".png",".gif",".tif",".tiff"};
    
    /** Creates a new instance of ImageChopper */
    public ImageChopper() {
    }
    
    
    /** Cut georeferenced images into 1/4 of their orrigional size. */
    public void doChop(){
        // get the directory listing.
        File[] tempFiles = mySourceImageDirectory.listFiles();
        for (int i=0; i<tempFiles.length; i++){
            if (myStopProcessing) return;
            String tempName = tempFiles[i].getName();
            String tempUCName = tempName.toUpperCase();
            int tempWorldExtensionLength = 0;
            String tempWorldExtension = "";
            boolean tempIsWorld = false;
            for (int j=0; j<myWorldFileExtensions.length; j++){
                if (tempUCName.endsWith(myWorldFileExtensions[j])){
                    tempWorldExtension = myWorldFileExtensions[j].toLowerCase();
                    tempWorldExtensionLength = myWorldFileExtensions[j].length();
                    tempIsWorld = true;
                    break;
                }
            }
            if (tempIsWorld){
                // look for the corrisponding Image File
                String tempImageName = tempName.substring(0, tempName.length()-tempWorldExtensionLength);
                String tempImageExtension = ".jpg";
                File tempImageFile = null;
                
                for (int j=0; j<myImageFileExtensions.length; j++){
                    String tempFileName = mySourceImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+myImageFileExtensions[j];
                    File tempFile = new File(tempFileName);
                    if (tempFile.exists()){
                        tempImageExtension = myImageFileExtensions[j];
                        tempImageFile = tempFile;
                        break;
                    }
                }
                
                // if the image file was found then calculate the Envelope for this image.
                if (tempImageFile != null){
                    // read the image file
                    fireImageChopperEvent(ImageChopperEvent.READING_FILE, tempImageFile.getAbsolutePath());
                    System.out.println("Reading "+tempImageFile.getAbsolutePath());
                    ImageInformation tempInformation = ImageUtilities.readImageInformation(tempImageFile);
                    if (tempInformation != null){
                        
                        try{
                            // calculate the envelope for this file.
                            Envelope tempImgEnvelope = ImageUtilities.calculateEnvelope(tempFiles[i], tempInformation);
                            double tempXScale = tempImgEnvelope.getWidth()/tempInformation.getImageWidth();
                            double tempYScale = tempImgEnvelope.getHeight()/tempInformation.getImageHeight();

                            //TILE A Upper Left ******************************************************************************
                            // Calculate the coordinates of the first tile.
                            int tempAWidth = tempInformation.getImageWidth()/2;
                            int tempAHeight = tempInformation.getImageHeight()/2;
                            double tempAMinX = tempImgEnvelope.getMinX();
                            double tempAMinY = tempImgEnvelope.getMaxY() - (tempAHeight/((double)tempInformation.getImageHeight()))*tempImgEnvelope.getHeight();
                            double tempAMaxX = tempAMinX + (tempAWidth/((double)tempInformation.getImageWidth()))*tempImgEnvelope.getWidth();
                            double tempAMaxY = tempImgEnvelope.getMaxY();
                            Envelope tempAEnvelope = new Envelope(tempAMinX, tempAMinY, tempAMaxX, tempAMaxY);

                            // write the image file for the first tile.
                            File tempImageOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"A."+myOutputType.toLowerCase());
                            fireImageChopperEvent(ImageChopperEvent.WRITING_FILE, tempImageOutputFile.getAbsolutePath());
                            BufferedImage tempImage = new BufferedImage(tempAWidth, tempAHeight, BufferedImage.TYPE_INT_BGR);
                            Graphics2D g2d = (Graphics2D) tempImage.getGraphics();
                            g2d.setColor(new Color(255,255,255,255));
                            g2d.fillRect(0, 0, tempAWidth, tempAHeight);
                            g2d.drawImage(tempInformation.getImage(),
                            0,
                            0,
                            tempAWidth,
                            tempAHeight,
                            0,
                            0,
                            tempAWidth,
                            tempAHeight,
                            null);
                            System.out.println("Writing A");
                            myDestinationImageDirectory.mkdirs();
                            ImageIO.write(tempImage, myOutputType.toLowerCase(), tempImageOutputFile);
                            
                            // write the world file for the first tile.
                            File tempWorldOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"A"+tempWorldExtension);
                            ImageUtilities.writeWorldFile(tempWorldOutputFile, tempAEnvelope, tempXScale, tempYScale);

                            //TILE B Upper Right ******************************************************************************
                            // Calculate the coordinates of the second tile.
                            int tempBWidth = tempInformation.getImageWidth()-tempAWidth;
                            int tempBHeight = tempAHeight;
                            double tempBMinX = tempAMaxX;
                            double tempBMinY = tempAMinY;
                            double tempBMaxX = tempImgEnvelope.getMaxX();
                            double tempBMaxY = tempAMaxY;
                            Envelope tempBEnvelope = new Envelope(tempBMinX, tempBMinY, tempBMaxX, tempBMaxY);

                            // write the image file for the second tile.
                            tempImageOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"B."+myOutputType.toLowerCase());
                            fireImageChopperEvent(ImageChopperEvent.WRITING_FILE, tempImageOutputFile.getAbsolutePath());
                            tempImage = new BufferedImage(tempBWidth, tempBHeight, BufferedImage.TYPE_INT_BGR);
                            g2d = (Graphics2D) tempImage.getGraphics();
                            g2d.setColor(new Color(255,255,255,255));
                            g2d.fillRect(0, 0, tempAWidth, tempAHeight);
                            g2d.drawImage(tempInformation.getImage(),
                            0,
                            0,
                            tempBWidth,
                            tempBHeight,
                            tempAWidth,
                            0,
                            tempInformation.getImageWidth(),
                            tempBHeight,
                            null);
                            System.out.println("Writing B");
                            ImageIO.write(tempImage, myOutputType.toLowerCase(), tempImageOutputFile);
                            
                            // write the world file for the second tile.
                            tempWorldOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"B"+tempWorldExtension);
                            ImageUtilities.writeWorldFile(tempWorldOutputFile, tempBEnvelope, tempXScale, tempYScale);

                            //TILE C Lower Left ******************************************************************************
                            // Calculate the coordinates of the third tile.
                            int tempCWidth = tempAWidth;
                            int tempCHeight = tempInformation.getImageHeight()-tempAHeight;
                            double tempCMinX = tempAMinX;
                            double tempCMinY = tempImgEnvelope.getMinY();
                            double tempCMaxX = tempAMaxX;
                            double tempCMaxY = tempAMinY;
                            Envelope tempCEnvelope = new Envelope(tempCMinX, tempCMinY, tempCMaxX, tempCMaxY);

                            // write the image file for the second tile.
                            tempImageOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"C."+myOutputType.toLowerCase());
                            fireImageChopperEvent(ImageChopperEvent.WRITING_FILE, tempImageOutputFile.getAbsolutePath());
                            tempImage = new BufferedImage(tempCWidth, tempCHeight, BufferedImage.TYPE_INT_BGR);
                            g2d = (Graphics2D) tempImage.getGraphics();
                            g2d.setColor(new Color(255,255,255,255));
                            g2d.fillRect(0, 0, tempAWidth, tempAHeight);
                            g2d.drawImage(tempInformation.getImage(),
                            0,
                            0,
                            tempCWidth,
                            tempCHeight,
                            0,
                            tempAHeight,
                            tempCWidth,
                            tempInformation.getImageHeight(),
                            null);
                            System.out.println("Writing C");
                            ImageIO.write(tempImage, myOutputType.toLowerCase(), tempImageOutputFile);
                            
                            // write the world file for the second tile.
                            tempWorldOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"C"+tempWorldExtension);
                            ImageUtilities.writeWorldFile(tempWorldOutputFile, tempCEnvelope, tempXScale, tempYScale);

                            //TILE D Lower Left ******************************************************************************
                            // Calculate the coordinates of the fourth tile.
                            int tempDWidth = tempBWidth;
                            int tempDHeight = tempCHeight;
                            double tempDMinX = tempBMinX;
                            double tempDMinY = tempCMinY;
                            double tempDMaxX = tempBMaxX;
                            double tempDMaxY = tempCMaxY;
                            Envelope tempDEnvelope = new Envelope(tempDMinX, tempDMinY, tempDMaxX, tempDMaxY);

                            // write the image file for the second tile.
                            tempWorldOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"D"+tempWorldExtension);
                            fireImageChopperEvent(ImageChopperEvent.WRITING_FILE, tempImageOutputFile.getAbsolutePath());
                            tempImage = new BufferedImage(tempDWidth, tempDHeight, BufferedImage.TYPE_INT_BGR);
                            g2d = (Graphics2D) tempImage.getGraphics();
                            g2d.setColor(new Color(255,255,255,255));
                            g2d.fillRect(0, 0, tempAWidth, tempAHeight);
                            g2d.drawImage(tempInformation.getImage(),
                            0,
                            0,
                            tempDWidth,
                            tempDHeight,
                            tempCWidth,
                            tempAHeight,
                            tempInformation.getImageWidth(),
                            tempInformation.getImageHeight(),
                            null);
                            System.out.println("Writing D");
                            tempImageOutputFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+"D."+myOutputType.toLowerCase());
                            ImageIO.write(tempImage, myOutputType.toLowerCase(), tempImageOutputFile);
                            
                            // write the world file for the second tile.
                            ImageUtilities.writeWorldFile(tempWorldOutputFile, tempDEnvelope, tempXScale, tempYScale);
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
    /** Event notification stuff. */
    private Vector myVectListeners = new Vector();
    /** Add a listener to the list of registered listeners. */
    public void addImageChopperListener(ImageChopperListener inListener){
        if (inListener != null){
            if (!myVectListeners.contains(inListener)){
                myVectListeners.addElement(inListener);
            }
        }
    }
    /** Remove a listener from the list of registered listeners. */
    public void removeImageChopperListener(ImageChopperListener inListener){
        if (inListener != null){
            myVectListeners.removeElement(inListener);
        }
    }
    /** Fire an ImageChopper Event. */
    private void fireImageChopperEvent(int inAction, String inFilename){
        ImageChopperEvent tempEvent = new ImageChopperEvent(inAction, inFilename);
        for (int i=0; i<myVectListeners.size(); i++){
            ImageChopperListener tempListener = (ImageChopperListener) myVectListeners.elementAt(i);
            try{
                tempListener.imageChopped(tempEvent);
            }
            catch (Exception e){
                System.out.println("Error on event dispatch ");
                e.printStackTrace();
            }
        }
    }
    
    
    /** Main entry point for the program. */
    public static void main(String[] inArgs){
        try{
            ImageChopper tempImageChopper = new ImageChopper();
            tempImageChopper.setSourceImageDirectory("/disk3/imagery/hawaii/Hawaii");
            tempImageChopper.setDestinationImageDirectory("/disk3/imagery/hawaii/Hawaii2");
            tempImageChopper.doChop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
    
}
