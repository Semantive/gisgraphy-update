/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Class to provide a user interface to the RasterCatalogCreator.
 */
public class RasterCatalogCreatorApplication extends JPanel {
    /** Text field for selecting the source directory. */
    private JTextField myTextFieldSourceDirectory = new JTextField();
    /** Button for displaying the file chooser for the source directory. */
    private JButton myButtonSourceDirectory = new JButton("...");
    
    /** Text field for selecting the destination directory. */
    private JTextField myTextFieldDestinationDirectory = new JTextField();
    /** Button for displaying the file chooser for the destination directory. */
    private JButton myButtonDestinationDirectory = new JButton("...");
    
    /** TextField for entering the width of the tiles. */
    private JTextField myTextFieldTileWidth = new JTextField("500");
    
    /** Combo box for entering the output type of the images. */
    private JComboBox myComboOutputType = new JComboBox();
    
    /** Status line for the current Resolution. */
    private JLabel myLabelResolution = new JLabel("Resolution");

    /** Status line for the current x coordinate. */
    private JLabel myLabelXCoordinate = new JLabel("X Coordinate");
    
    /** Status line for the current y coordinate. */
    private JLabel myLabelYCoordinate = new JLabel("Y Coordinate");
    
    /** Status line for the current File. */
    private JLabel myLabelCurrentFile = new JLabel("Current File");
    
    /** Button for performing this action. */
    private JButton myButtonOK = new JButton("OK");
    
    /** Button for canceling this action. */
    private JButton myButtonCancel = new JButton("Close");
    
    /** The current parent frame. */
    private Component myFrame = null;
    /** Set the curent parent frame. */
    public void setFrame(Component inFrame){myFrame = inFrame;}
    
    /** Return the parent panel for this frame. */
    public Component getFrame(){return myFrame;}
    
    /** The class that actually does the work. */
    RasterCatalogCreator myRasterCatalogCreater = new RasterCatalogCreator();
    
    /** Thread for running the raster catalog creator. */
    private Thread myThread = null;
    
    /** The action listener for this application to listen to the buttons. */
    private class MyActionListener implements ActionListener, Runnable{
        
        /** Invoked when an action occurs.*/
        public void actionPerformed(ActionEvent e) {
            // check for the source button.
            if (e.getSource() == myButtonSourceDirectory){
                myFileChooser.setDialogTitle("Select Source Directory");
                String tempFile = myTextFieldSourceDirectory.getText();
                if ((tempFile == null)||(tempFile.length() == 0)){
                    tempFile = ".";
                }
                myFileChooser.setCurrentDirectory(new File(tempFile));
                myFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                if (myFileChooser.showOpenDialog(getFrame()) == JFileChooser.APPROVE_OPTION) {
                    File tempResultFile = myFileChooser.getSelectedFile();
                    if (tempResultFile != null){
                        myTextFieldSourceDirectory.setText(tempResultFile.getAbsolutePath());
                    }
                }
            }
            if (e.getSource() == myButtonDestinationDirectory){
                myFileChooser.setDialogTitle("Select Destination Directory");
                String tempFile = myTextFieldDestinationDirectory.getText();
                myFileChooser.setCurrentDirectory(new File(tempFile));
                myFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                if (myFileChooser.showOpenDialog(getFrame()) == JFileChooser.APPROVE_OPTION) {
                    File tempResultFile = myFileChooser.getSelectedFile();
                    if (tempResultFile != null){
                        myTextFieldDestinationDirectory.setText(tempResultFile.getAbsolutePath());
                    }
                }
            }
            if (e.getSource() == myButtonCancel){
                myRasterCatalogCreater.setStopProcessing(true);
                if (getFrame() instanceof Window){
                    ((Window) getFrame()).dispose();
                }
            }
            if (e.getSource() == myButtonOK){
                try{
                    // look for the input directory.
                    myRasterCatalogCreater.setSourceImageDirectory(myTextFieldSourceDirectory.getText());
                    myRasterCatalogCreater.setDestinationImageDirectory(myTextFieldDestinationDirectory.getText());
                    try{
                        int tempMaxWidth = Integer.parseInt(myTextFieldTileWidth.getText());
                        myRasterCatalogCreater.setMaxWidth(tempMaxWidth);
                    }
                    catch (Exception ex){
                        throw new Exception("Tile width is not an integer: "+myTextFieldTileWidth.getText());
                    }
                    
                    // retrieve the out put type
                    myRasterCatalogCreater.setOutputType((String) myComboOutputType.getSelectedItem());
                    
                    myButtonOK.setEnabled(false);
                    myThread = new Thread(this);
                    myThread.start();
                }
                catch (Exception ex){
                    JOptionPane.showMessageDialog(getFrame(), ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    myButtonOK.setEnabled(true);
                }
            }
        }
        /** The run method for runnign the create action. */
        public void run(){
            try{
                myRasterCatalogCreater.doConvert();
            }
            catch (Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(getFrame(), e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            myButtonOK.setEnabled(true);
        }
    }
    private MyActionListener myActionListener = new MyActionListener();
    
    /** File Chooser dialog for selecting the source and destination directories. */
    private JFileChooser myFileChooser = new JFileChooser();
    
    /** Creates a new instance of RasterCatalogCreatorApplication */
    public RasterCatalogCreatorApplication() {
        initPanel();
    }
    
    /** Initialize the user interface for this appliction. */
    private void initPanel(){
        
        // create a panel for displaying controls
        JPanel tempPanel = this;
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 0;
        
        // add a description of what this application will do.
        c.gridx = 0;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(new JLabel("This application converts a series of large georeferenced images"), c );
        c.gridy++;
        tempPanel.add(new JLabel("into a catalog of raster images that can be more quickly displayed."), c);
        c.gridwidth = 1;
        
        // add a prompt for the user so they know what a source directory is.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(new JLabel("Enter the directory containing the images and world files."), c);
        c.gridwidth = 1;
        
        // add a text field for selecting the source directory.
        c.weightx = 1;
        c.gridy++;
        tempPanel.add(myTextFieldSourceDirectory, c);
        c.weightx = 0;
        c.gridx++;
        tempPanel.add(myButtonSourceDirectory, c);
        myButtonSourceDirectory.addActionListener(myActionListener);
        
        // add a prompt for the user so they know what a destination directory is.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(new JLabel("Enter the directory where the catalog should be written."), c);
        c.gridwidth = 1;
        
        // add a text field for selecting the destination directory.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myTextFieldDestinationDirectory, c);
        c.weightx = 0;
        c.gridx++;
        tempPanel.add(myButtonDestinationDirectory, c);
        myButtonDestinationDirectory.addActionListener(myActionListener);
        
        // add a prompt for the user so they know what the tile resolution is.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(new JLabel("Enter the width in pixels of each tile."), c);
        c.gridwidth = 1;
        
        // add a text field for selecting the tile width.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myTextFieldTileWidth, c);
        
        // add a combo box for selecting the output type.
        c.gridx = 0;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridy++;
        tempPanel.add(new JLabel("Select the type of file to be written"), c);
        c.weightx = 0;
        c.gridy++;
        tempPanel.add(myComboOutputType, c);
        // Get list of unique supported write formats
        String[] tempFormats = myRasterCatalogCreater.getSupportedOutputTypes();
        if (tempFormats != null){
            for (int i=0; i<tempFormats.length; i++){
                myComboOutputType.addItem(tempFormats[i]);
            }
        }
        
        // add the label for displaying the current Resolution
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myLabelResolution, c);
        
        // add the label for displaying the current X Coordinate.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myLabelXCoordinate, c);
        
        // add the label for displaying the current Y Coordinate.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myLabelYCoordinate, c);
        
        // add the label for displaying the current File.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myLabelCurrentFile, c);
        
        // add some space.
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);
        
        // add the OK and Cancel buttons.
        c.gridx = 0;
        c.gridy++;
        c.weighty = 0;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        JPanel tempGridPanel = new JPanel(new GridLayout(1,2,2,2));
        tempGridPanel.add(myButtonOK);
        myButtonOK.addActionListener(myActionListener);
        tempGridPanel.add(myButtonCancel);
        myButtonCancel.addActionListener(myActionListener);
        JPanel tempButtonPanel = new JPanel(new BorderLayout());
        tempButtonPanel.add(tempGridPanel, BorderLayout.EAST);
        tempPanel.add(tempButtonPanel, c);
        
        // set the primitive notification.
        myRasterCatalogCreater.setRasterCatalogCreatorApplication(this);
    }
    
    /** set the status of the application. */
    public void setStatus(String inFile, int inResolution, int inX, int inY){
        myLabelCurrentFile.setText(inFile);
        myLabelResolution.setText("R="+inResolution);
        myLabelXCoordinate.setText("X="+inX);
        myLabelYCoordinate.setText("Y="+inY);
    }
    
    /* Main entry point for the application. */
    public static void main(String inArgs[]){
        RasterCatalogCreatorApplication tempApplication = new RasterCatalogCreatorApplication();
        JFrame tempFrame = new JFrame();
        tempApplication.setFrame(tempFrame);
        // add a listener to the frame.
        tempFrame.addWindowListener( new WindowAdapter(){
            public void windowClosing(WindowEvent inWE){
                System.exit(0);
            }
        }
        );
        
        // use some nice title.
        tempFrame.setTitle("Creates a Raster Catalog!");
        tempFrame.setContentPane(tempApplication);
        tempFrame.pack();
        tempFrame.setVisible(true);
        
    }
}
