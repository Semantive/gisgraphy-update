/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Class to provide a user interface to the RasterCatalogCreator.
 */
public class ImageChopperApplication extends JPanel implements ImageChopperListener{
    /** Text field for selecting the source directory. */
    private JTextField myTextFieldSourceDirectory = new JTextField();
    /** Button for displaying the file chooser for the source directory. */
    private JButton myButtonSourceDirectory = new JButton("...");
    
    /** Text field for selecting the destination directory. */
    private JTextField myTextFieldDestinationDirectory = new JTextField();
    /** Button for displaying the file chooser for the destination directory. */
    private JButton myButtonDestinationDirectory = new JButton("...");
        
    /** Status line for the current File. */
    private JLabel myLabelCurrentFile = new JLabel("Current File");
    
    /** Button for performing this action. */
    private JButton myButtonOK = new JButton("OK");
    
    /** Button for canceling this action. */
    private JButton myButtonCancel = new JButton("Cancel");
    
    /** The current parent frame. */
    private Component myFrame = null;
    /** Set the curent parent frame. */
    public void setFrame(Component inFrame){myFrame = inFrame;}
    
    /** Return the parent panel for this frame. */
    public Component getFrame(){return myFrame;}
    
    /** The class that actually does the work. */
    ImageChopper myImageChopper = new ImageChopper();
    
    /** Thread for running the ImageChopper. */
    private Thread myThread = null;
    
    /** The action listener for this application to listen to the buttons. */
    private class MyActionListener implements ActionListener, Runnable{
        
        /** Invoked when an action occurs.*/
        public void actionPerformed(ActionEvent e) {
            // check for the source button.
            if (e.getSource() == myButtonSourceDirectory){
                myFileChooser.setDialogTitle("Select Source Directory");
                String tempFile = myTextFieldSourceDirectory.getText();
                if ((tempFile == null)||(tempFile.length() == 0)){
                    tempFile = ".";
                }
                myFileChooser.setCurrentDirectory(new File(tempFile));
                myFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                if (myFileChooser.showOpenDialog(getFrame()) == JFileChooser.APPROVE_OPTION) {
                    File tempResultFile = myFileChooser.getSelectedFile();
                    if (tempResultFile != null){
                        myTextFieldSourceDirectory.setText(tempResultFile.getAbsolutePath());
                    }
                }
            }
            if (e.getSource() == myButtonDestinationDirectory){
                myFileChooser.setDialogTitle("Select Destination Directory");
                String tempFile = myTextFieldDestinationDirectory.getText();
                myFileChooser.setCurrentDirectory(new File(tempFile));
                myFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                if (myFileChooser.showOpenDialog(getFrame()) == JFileChooser.APPROVE_OPTION) {
                    File tempResultFile = myFileChooser.getSelectedFile();
                    if (tempResultFile != null){
                        myTextFieldDestinationDirectory.setText(tempResultFile.getAbsolutePath());
                    }
                }
            }
            if (e.getSource() == myButtonCancel){
                myImageChopper.setStopProcessing(true);
                if (getFrame() instanceof Window){
                    ((Window) getFrame()).dispose();
                }
            }
            if (e.getSource() == myButtonOK){
                try{
                    // look for the input directory.
                    myImageChopper.setSourceImageDirectory(myTextFieldSourceDirectory.getText());
                    myImageChopper.setDestinationImageDirectory(myTextFieldDestinationDirectory.getText());
                    
                    myImageChopper.setStopProcessing(false);
                    myButtonOK.setEnabled(false);
                    myThread = new Thread(this);
                    myThread.start();
                }
                catch (Exception ex){
                    JOptionPane.showMessageDialog(getFrame(), ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    myButtonOK.setEnabled(true);
                }
            }
        }
        /** The run method for runnign the create action. */
        public void run(){
            try{
                myImageChopper.doChop();
            }
            catch (Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(getFrame(), e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            myButtonOK.setEnabled(true);
        }
    }
    private MyActionListener myActionListener = new MyActionListener();
    
    /** File Chooser dialog for selecting the source and destination directories. */
    private JFileChooser myFileChooser = new JFileChooser();
    
    /** Creates a new instance of RasterCatalogCreatorApplication */
    public ImageChopperApplication() {
        initPanel();
        myImageChopper.addImageChopperListener(this);
    }
    
    /** Initialize the user interface for this appliction. */
    private void initPanel(){
        
        // create a panel for displaying controls
        JPanel tempPanel = this;
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 0;
        
        // add a description of what this application will do.
        c.gridx = 0;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(new JLabel("This application converts a series of large georeferenced images"), c );
        c.gridy++;
        tempPanel.add(new JLabel("into a series of georeferenced images 1/4 the size of the orrigionals."), c);
        c.gridwidth = 1;
        
        // add a prompt for the user so they know what a source directory is.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(new JLabel("Enter the directory containing the images and world files."), c);
        c.gridwidth = 1;
        
        // add a text field for selecting the source directory.
        c.weightx = 1;
        c.gridy++;
        tempPanel.add(myTextFieldSourceDirectory, c);
        c.weightx = 0;
        c.gridx++;
        tempPanel.add(myButtonSourceDirectory, c);
        myButtonSourceDirectory.addActionListener(myActionListener);
        
        // add a prompt for the user so they know what a destination directory is.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(new JLabel("Enter the directory where the new files should be written."), c);
        c.gridwidth = 1;
        
        // add a text field for selecting the destination directory.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myTextFieldDestinationDirectory, c);
        c.weightx = 0;
        c.gridx++;
        tempPanel.add(myButtonDestinationDirectory, c);
        myButtonDestinationDirectory.addActionListener(myActionListener);        
                        
        // add the label for displaying the current File.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myLabelCurrentFile, c);
        
        // add some space.
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);
        
        // add the OK and Cancel buttons.
        c.gridx = 0;
        c.gridy++;
        c.weighty = 0;
        c.weightx = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        JPanel tempGridPanel = new JPanel(new GridLayout(1,2,2,2));
        tempGridPanel.add(myButtonOK);
        myButtonOK.addActionListener(myActionListener);
        tempGridPanel.add(myButtonCancel);
        myButtonCancel.addActionListener(myActionListener);
        JPanel tempButtonPanel = new JPanel(new BorderLayout());
        tempButtonPanel.add(tempGridPanel, BorderLayout.EAST);
        tempPanel.add(tempButtonPanel, c);        
    }
    
    /** set the status of the application. */
    public void setStatus(String inFile){
        myLabelCurrentFile.setText(inFile);
    }
    
    /* Main entry point for the application. */
    public static void main(String inArgs[]){
        ImageChopperApplication tempApplication = new ImageChopperApplication();
        JFrame tempFrame = new JFrame();
        tempApplication.setFrame(tempFrame);
        // add a listener to the frame.
        tempFrame.addWindowListener( new WindowAdapter(){
            public void windowClosing(WindowEvent inWE){
                System.exit(0);
            }
        }
        );
        
        // use some nice title.
        tempFrame.setTitle("Chops all images to 1/4 their orrigional size.");
        tempFrame.setContentPane(tempApplication);
        tempFrame.pack();
        tempFrame.setVisible(true);
        
    }
    
    /** Gets called when an image is being read, or written.  */
    public void imageChopped(ImageChopperEvent inEvent) {
        myLabelCurrentFile.setText(""+inEvent);
    }
    
}
