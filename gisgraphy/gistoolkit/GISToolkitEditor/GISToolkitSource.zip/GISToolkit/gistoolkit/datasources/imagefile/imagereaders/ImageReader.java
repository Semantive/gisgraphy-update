/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile.imagereaders;

/**
 * Class to try all the available means for reading an image and using the best one.
 */
public class ImageReader {
    
    /** Creates a new instance of JAIImageReader */
    public ImageReader() throws Exception{
    }
    
    /** Read the images with the javax.imageio packages. */
    public static String METHOD_JAVAIO = "JAVAIO";
    
    /** Read the images with the Java Advanced Imaging Software. */
    public static String METHOD_JAI = "JAI";
    
    /** Read the images with the javax.swing packages. */
    public static String METHOD_ICON = "SWING_ICON";
    
    /** Read the imates with the Standard AWT toolkit. */
    public static String METHOD_AWT = "AWT";

    /** A variable to keep track of which method works. */
    public static String myMethod = null;
    
    /** This method will attempt to use the available methods to read images. */
    public static ImageInformation readImage(String inFilename){
        /** Place to keep the image information. */
        ImageInformation tempReturnImageInformation = null;
        
        /** If the best method has been determined, then use it. */
        if ((myMethod == null)||(myMethod==METHOD_JAVAIO)){
            // first try the javaio api.
            try{
                ImageIOImageReader tempReader = new ImageIOImageReader(inFilename);
                ImageInformation tempInformation = tempReader.readImage(inFilename);
                if ((tempInformation.getImage() != null) && 
                   (tempInformation.getImageWidth() > 0) &&
                   (tempInformation.getImageHeight() > 0)){
                       setMethod(METHOD_JAVAIO);
                       tempReturnImageInformation = tempInformation;
                }                
            }
            catch (Exception e){
            }
        }
        
        /** Next try the advanced imaging API */
        if ((myMethod == null)||(myMethod==METHOD_JAI)){
            
            try{
                JAIImageReader tempReader = new JAIImageReader(inFilename);
                ImageInformation tempInformation = tempReader.readImage(inFilename);
                if ((tempInformation.getImage() != null) && 
                   (tempInformation.getImageWidth() > 0) &&
                   (tempInformation.getImageHeight() > 0)){
                       setMethod(METHOD_JAI);
                       tempReturnImageInformation = tempInformation;
                }                
            }
            catch (Exception e){
            }
        }        
        /** Next try the Swing Icon API */
        if ((myMethod == null)||(myMethod==METHOD_ICON)){
            
            try{
                IconImageReader tempReader = new IconImageReader(inFilename);
                ImageInformation tempInformation = tempReader.readImage(inFilename);
                if ((tempInformation.getImage() != null) && 
                   (tempInformation.getImageWidth() > 0) &&
                   (tempInformation.getImageHeight() > 0)){
                       setMethod(METHOD_ICON);
                       tempReturnImageInformation = tempInformation;
                }                
            }
            catch (Exception e){
            }
        }
        
        /** Fall back to the AWT api. */
        if ((myMethod == null)||(myMethod==METHOD_AWT)){
            
            try{
                AWTImageReader tempReader = new AWTImageReader(inFilename);
                ImageInformation tempInformation = tempReader.readImage(inFilename);
                if ((tempInformation.getImage() != null) && 
                   (tempInformation.getImageWidth() > 0) &&
                   (tempInformation.getImageHeight() > 0)){
                       setMethod(METHOD_AWT);
                       tempReturnImageInformation = tempInformation;
                }                
            }
            catch (Exception e){
            }
        }

        return tempReturnImageInformation;
    }
    
    /** Method to tell when the method has been selected. */
    public static void setMethod(String inMethod){
        if (myMethod == null){
            System.out.println("Reading Images by the "+inMethod+" Method");
        }
        myMethod = inMethod;
    }
}
