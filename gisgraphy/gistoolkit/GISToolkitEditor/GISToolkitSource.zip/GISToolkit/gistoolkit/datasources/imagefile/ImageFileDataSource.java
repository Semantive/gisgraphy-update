/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile;

import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.io.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.projection.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.imagefile.imagereaders.*;
import gistoolkit.datasources.filter.*;

/**
 * Provides the ability to display an image file as part of the map.
 */
public class ImageFileDataSource extends SimpleDataSource implements ImageObserver{
    
    /** The envelope of the map. */
    private Envelope myImageEnvelope = null;
    /** Return the envelope in world coordinates of the map. */
    public Envelope getImageEnvelope(){return myImageEnvelope;}
    /** Set the enxtents of the image in world coordinates. */
    public void setImageEnvelope(Envelope inEnvelope){myImageEnvelope = inEnvelope;}
    
    /** The file name of the map. */
    private File myImageFile = null;
    /** Return the file representing the image. */
    public File getImageFile(){return myImageFile;}
    /** Set the name of the file. */
    public void setImageFile(File inImageFile) throws Exception{
        if (inImageFile != null){
            if (!inImageFile.exists()) throw new Exception("Error File "+inImageFile.getAbsolutePath() + " does not exist");
        }
        myImageFile = inImageFile;
        setName(myImageFile.getName());
    }
    
    /** Creates new ImageFileDataSource */
    public ImageFileDataSource() {
    }
    
    /** Set the projection from which this data should be projected. */
    public void setFromProjection(Projection inProjection)throws Exception{
        super.setFromProjection(inProjection);
        myGISDataset = null;
    }
    
    /** Constants for the configuration information*/
    private static final String TOPX_TAG = "TopX";
    private static final String BOTTOMX_TAG = "BottomX";
    private static final String TOPY_TAG = "TopY";
    private static final String BOTTOMY_TAG = "BottomY";
    private static final String MINX_TAG = "MinX";
    private static final String MAXX_TAG = "MaxX";
    private static final String MINY_TAG = "MinY";
    private static final String MAXY_TAG = "MaxY";
    private static final String IMAGE_FILENAME_TAG = "ImageFileName";
    
    /** Get the configuration information for this layer. */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("ImageFileDataSource");
        tempRoot.addAttribute(MINX_TAG, ""+myImageEnvelope.getMinX());
        tempRoot.addAttribute(MAXX_TAG, ""+myImageEnvelope.getMaxX());
        tempRoot.addAttribute(MINY_TAG, ""+myImageEnvelope.getMinY());
        tempRoot.addAttribute(MAXY_TAG, ""+myImageEnvelope.getMaxY());
        tempRoot.addAttribute(IMAGE_FILENAME_TAG, myImageFile.getAbsolutePath());
        return tempRoot;
    }
    
    /** Set the configuration information for this layer. */
    public void setNode(Node inNode) throws Exception{
        if (inNode != null){
            
            // construct the Envelope.
            // Minimum X
            double tempMinX = 0;
            String tempString = inNode.getAttribute(MINX_TAG);
            if (tempString != null){
                try{tempMinX = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(MINX_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
            }
            else{
                tempString = inNode.getAttribute(TOPX_TAG);
                if (tempString != null){
                    try{tempMinX = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(TOPX_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
                }
            }
            
            // Minimum Y
            double tempMinY = 0;
            tempString = inNode.getAttribute(MINY_TAG);
            if (tempString != null){
                try{tempMinY = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(MINY_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
            }
            else{
                tempString = inNode.getAttribute(BOTTOMY_TAG);
                if (tempString != null){
                    try{tempMinY = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(BOTTOMY_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
                }
            }
            
            // Maximum X
            double tempMaxX = 0;
            tempString = inNode.getAttribute(MAXX_TAG);
            if (tempString != null){
                try{tempMaxX = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(MAXX_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
            }
            else{
                tempString = inNode.getAttribute(BOTTOMX_TAG);
                if (tempString != null){
                    try{tempMaxX = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(BOTTOMX_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
                }
            }
            
            // Minimum Y
            double tempMaxY = 0;
            tempString = inNode.getAttribute(MAXY_TAG);
            if (tempString != null){
                try{tempMaxY = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(MAXY_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
            }
            else{
                tempString = inNode.getAttribute(TOPY_TAG);
                if (tempString != null){
                    try{tempMaxY = Double.parseDouble(tempString);}catch(NumberFormatException e){System.out.println(TOPY_TAG+" for ImageDataSource is "+tempString+" which is not a double");}
                }
            }
            
            
            myImageEnvelope = new Envelope(tempMinX, tempMinY, tempMaxX, tempMaxY);
            
            // construct the file
            tempString = inNode.getAttribute(IMAGE_FILENAME_TAG);
            if (tempString != null){
                myImageFile = new File(tempString);
                if (!myImageFile.exists()){ System.out.println("ImageFile "+tempString+" does not exist");}
            }
            super.setNode(inNode);
        }
        
    }
    /**
     * Returns the bounding rectangle of all the shapes in the Data Source.
     */
    public Envelope readEnvelope() throws Exception {
        // envelope are not immutable, make a defensive copy.
        return (Envelope) myImageEnvelope.clone();
    }
    
    /** Only read the image the once. */
    private GISDataset myGISDataset = null;
    
    /**
     * Reads only the objects from the data source that intersect these envelope.
     */
    public synchronized GISDataset readDataset(Envelope inEnvelope) throws Exception {
        if (inEnvelope == null) return readDataset();
        boolean blewCache = false;
        if (getCached()){
            blewCache = !isCachedProjected();
        }
        if ((getFromProjection() == null) || (getToProjection() == null)||(blewCache)||(getFromProjection() instanceof NoProjection)||(getToProjection() instanceof NoProjection)){
            return super.readDataset(inEnvelope);
        }
        else{
            
            // this is a very specific case to try to increase the resolution of reprojected images.
            // If there is a from and a to projection, chances are they are from and two similar projections
            // It is much more efficient to project these once than to do it many times.
            
            Envelope tempEnvelope = inEnvelope;
            if (getCacheEnvelope() != null){
                if (getCacheEnvelope().contains(tempEnvelope)){
                    return queryFromCache(tempEnvelope);
                }
            }
            tempEnvelope = ShapeProjector.projectBackward(getToProjection(), inEnvelope);
            // I have some concerns about this because the shape is not really a square at this point.
            // would be more efficient to convert to a polygon and then query from that.
            GISDataset tempDataset = readShapes(ShapeProjector.projectForward(getFromProjection(), tempEnvelope));
            if (tempDataset != null){
                tempDataset = filterDataset(tempDataset);
                tempDataset = (GISDataset) tempDataset.clone();
                for (int i=0; i<tempDataset.size(); i++){
                    gistoolkit.features.Shape tempShape = tempDataset.getShape(i);
                    if ((tempShape != null) && (tempShape instanceof RasterShape)){
                        ImageProjector.reProject(getFromProjection(), getToProjection(), (RasterShape) tempShape);
                    }
                }
                setCache(tempDataset, (Envelope) inEnvelope.clone());
            }
            return tempDataset;
        }
    }
    
    
    /**
     * Reads all the objects from the data source.
     */
    public GISDataset readDataset() throws Exception {
        if ((getFromProjection() == null) || (getToProjection() == null)||(!isCachedProjected())||(getFromProjection() instanceof NoProjection)||(getToProjection() instanceof NoProjection)){
            return super.readDataset(null);
        }
        else{
            
            // this is a very specific case to try to increase the resolution of reprojected images.
            // If there is a from and a to projection, chances are they are from and two similar projections
            // It is much more efficient to project these once than to do it many times.
            GISDataset tempDataset = readShapes(null);
            if (tempDataset != null){
                tempDataset = filterDataset(tempDataset);
                for (int i=0; i<tempDataset.size(); i++){
                    gistoolkit.features.Shape tempShape = tempDataset.getShape(i);
                    if ((tempShape != null) && (tempShape instanceof RasterShape)){
                        ImageProjector.reProject(getFromProjection(), getToProjection(), (RasterShape) tempShape);
                    }
                }
                setCache(tempDataset, (Envelope) tempDataset.getEnvelope().clone());
            }
            return tempDataset;
        }
    }
    
    
    /** This method should return the shapes from the data source  */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception {
        if (inEnvelope != null){
            if (!inEnvelope.overlaps(myImageEnvelope)){
                return new GISDataset();
            }
        }
        
        File tempImageFile = null;
        String tempFileName = null;
        
        // check the filter
        Filter tempFilter = getFilter();
        if (tempFilter != null){
            if (tempFilter instanceof AttributeFilter){
                AttributeFilter tempAFilter = (AttributeFilter) tempFilter;
                String tempName = tempAFilter.getAttributeName();
                System.out.println("ImageFileDataSource Found Filter "+tempAFilter.getFilterName()+" Name="+tempAFilter.getAttributeName()+" Value="+tempAFilter.getAttributeValue());
                if (tempName.equalsIgnoreCase("FileName")){
                    try{
                        String tempString = (String) ((AttributeFilter) tempFilter).getAttributeValue();
                        if ((tempString != null) && (tempString.length() > 0)){
                            // find the new file.
                            File tempFile = new File(tempString);
                            if (tempFile.exists()){
                                tempImageFile = tempFile;
                                tempFileName = tempString;
                                myGISDataset = null;
                            }
                            else{
                                // look for it in the same directory as the last one.
                                File tempDirectory = myImageFile.getParentFile();
                                if (tempDirectory.isDirectory()){
                                    tempFile = new File(tempDirectory.getAbsolutePath() + File.separatorChar + tempString);
                                    if (tempFile.exists()){
                                        tempImageFile = tempFile;
                                        tempFileName = tempString;
                                        myGISDataset = null;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception e){
                        System.out.println("Exception reading filter \"FileName\" "+e);
                    }
                }
                else{
                    System.out.println("ImageFileDataSource Found Filter "+tempAFilter.getFilterName()+" Name="+tempAFilter.getAttributeName()+" Value="+tempAFilter.getAttributeValue());
                }
            }
        }
        
        if (myGISDataset != null) return myGISDataset;
        Envelope tempEnvelope = myImageEnvelope;
        if (tempImageFile == null){
            tempImageFile = myImageFile;
            tempFileName = myImageFile.getAbsolutePath();
        }
        else tempEnvelope = loadEnvelope(tempImageFile);
        
        // read the image from a file.
        Image tempImage = null;
        BufferedImage tempBufferedImage = null;
        // If you have the JAI package (yippie!)
        ImageInformation tempInfo = ImageReader.readImage(tempImageFile.getAbsolutePath());
        if (tempInfo.getImage() != null){
            int tempWidth = tempInfo.getImageWidth();
            int tempHeight = tempInfo.getImageHeight();
            tempBufferedImage = new BufferedImage(tempWidth, tempHeight, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = (Graphics2D) tempBufferedImage.getGraphics();
            if (tempInfo.getImage() instanceof RenderedImage){
                g2d.drawRenderedImage((RenderedImage)tempInfo.getImage(), AffineTransform.getTranslateInstance(0,0));
            }
            else{
                // track the image
                Panel tempPanel = new Panel();
                tempImage = tempInfo.getImage();
                MediaTracker mt = new MediaTracker(tempPanel);
                mt.addImage(tempImage, 0);
                mt.waitForAll();
                
                // grab the pixels
                int[] pixels = new int[tempWidth * tempHeight];
                PixelGrabber pg = new PixelGrabber(tempImage, 0, 0, tempWidth, tempHeight, pixels, 0, tempWidth);
                pg.grabPixels();
                
                // create a buffered image from this image.
                tempBufferedImage = new BufferedImage(tempImage.getWidth(this), tempImage.getHeight(this), BufferedImage.TYPE_INT_ARGB);
                Graphics g = tempBufferedImage.getGraphics();
                g.drawImage(tempImage,0,0, this);
            }
        }
        
        // in this case, there is only one shape, and it is the image.
        RasterShape tempRasterShape = new RasterShape((Envelope) myImageEnvelope.clone(), tempBufferedImage);
        
        // create the dataset
        String[] tempAttributeNames = {"FileName"};
        AttributeType[] tempAttributeTypes = {new AttributeType(AttributeType.STRING)};
        myGISDataset = new GISDataset(tempAttributeNames, tempAttributeTypes);
        
        // create the record
        Object[] tempAttributes = {tempFileName};
        myGISDataset.add(tempAttributes, tempRasterShape);
        return myGISDataset;
    }

    /** The world file extensions to check for. */
    private String[] myWorldFileExtensions = {".TFW",".TIFW",".JGW"};
    
    /** Check for a world file from which to load the Envelope. */
    public Envelope loadEnvelope(File inImageFile){
        if (inImageFile == null) return null;
        String tempDirectory = inImageFile.getParent();
        
        /** Check for World file. */
        Envelope tempEnvelope = myImageEnvelope;
        String tempLocation = inImageFile.getAbsolutePath();
        if ((tempLocation != null) && (tempLocation.length() > 0)){
            String tempName = inImageFile.getName();
            String tempUCName = tempName.toUpperCase();
            File tempWorldFile = null;
            for (int i=0; i<myWorldFileExtensions.length; i++){
                int tempIndex = tempUCName.indexOf(myWorldFileExtensions[i]);
                if (tempIndex > -1){
                    String tempWorldFileName = tempName.substring(0, tempIndex);
                    // check for the world file with lower case extension
                    File tempFile = new File(tempDirectory + File.separatorChar+tempWorldFileName+myWorldFileExtensions[i].toLowerCase());
                    if (tempFile.exists()){
                        tempWorldFile = tempFile;
                        break;
                    }
                    // check for the world file with upper case extension
                    tempFile = new File(tempDirectory + File.separatorChar+tempWorldFileName+myWorldFileExtensions[i]);
                    if (tempFile.exists()){
                        tempWorldFile = tempFile;
                        break;
                    }
                }
            }
            if (tempWorldFile != null){
                try{
                    tempEnvelope = ImageUtilities.loadEnvelope(tempWorldFile, inImageFile);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        return tempEnvelope;
    }
    
    public boolean imageUpdate(java.awt.Image image, int param, int param2, int param3, int param4, int param5) {
        return true;
    }
    
    /** Get the style to use with this datasource.  */
    public gistoolkit.display.Style getStyle() {
        return null;
    }
    
}
