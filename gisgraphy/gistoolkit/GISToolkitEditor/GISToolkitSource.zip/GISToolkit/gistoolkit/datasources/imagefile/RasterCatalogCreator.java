/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.imagefile;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import gistoolkit.common.Node;
import gistoolkit.features.Envelope;
import gistoolkit.features.featureutils.EnvelopeBuffer;
import gistoolkit.datasources.imagefile.imagereaders.ImageInformation;

/**
 * Class to take a directory of images and tfw files and create a RasterCatalog from them.
 */
public class RasterCatalogCreator {
    
    /** The location of the source directory of images. */
    private File mySourceImageDirectory = null;
    /** Get the location of the source directory containing the images to convert. */
    public String getSourceImageDirectory(){if (mySourceImageDirectory == null) return null; return mySourceImageDirectory.getAbsolutePath();}
    /** Set the location of the source directory containing the images to convert. */
    public void setSourceImageDirectory(String inSourceImageDirectory) throws FileNotFoundException{
        if (inSourceImageDirectory == null) throw new FileNotFoundException("Input file is null");
        File tempFile = new File(inSourceImageDirectory);
        if (!tempFile.exists()) throw new FileNotFoundException("File "+inSourceImageDirectory+" can not be found.");
        if (!tempFile.isDirectory()) throw new FileNotFoundException("File "+inSourceImageDirectory+" is not a directory.");
        mySourceImageDirectory = tempFile;
    }
    
    /** The location of the destination directory of images. */
    private File myDestinationImageDirectory = null;
    /** Get the location of the source directory containing the images to convert. */
    public String getDestinationImageDirectory(){if (myDestinationImageDirectory == null) return null; return myDestinationImageDirectory.getAbsolutePath();}
    /** Set the location of the source directory containing the images to convert. */
    public void setDestinationImageDirectory(String inDestinationImageDirectory) throws FileNotFoundException{
        if (inDestinationImageDirectory == null) throw new FileNotFoundException("Input file is null");
        File tempFile = new File(inDestinationImageDirectory);
        if (!tempFile.exists()){
            // create the destination folder should it not exist.
            tempFile.mkdirs();
            if (!tempFile.exists())throw new FileNotFoundException("File "+inDestinationImageDirectory+" can not be found.");
        }
        if (!tempFile.isDirectory()) throw new FileNotFoundException("File "+inDestinationImageDirectory+" is not a directory.");
        myDestinationImageDirectory = tempFile;
    }
    
    /** The maximum width of an image. */
    private int myMaxWidth = 500;
    /** Set the maximum width of an image. */
    public void setMaxWidth(int inMaxWidth){myMaxWidth = inMaxWidth;}
    /** Get the maximum width of an image. */
    public int getMaxWidth(){return myMaxWidth;}
    
    /** The resolutions to break the images into. */
    int[] myResolutions = {1,2,4,8,16,32,64,128};
    /** Set the resolutions to break the images into. */
    public void setResolutions(int[] inResolutions){myResolutions = inResolutions;}
    /** Get the resolutions to break the images into. */
    public int[] getResolutions(){return myResolutions;}
    
    /** The type to write.*/
    private String myOutputType = "JPG";
    /** Set the type to write. */
    public void setOutputType(String inOutputType){myOutputType = inOutputType;}
    /** Get the type to write. */
    public String getOutputType(){return myOutputType;}
    
    /** list array for each of the resoltuions. */
    private ArrayList[] myLists = null;
    
    /** Image file types to search for. */
    private String[] myExtensions = {".jpg",".png",".gif",".tif",".tiff"};
    
    /** The buffer to use to aggregate the envelopes. */
    public EnvelopeBuffer myEnvelopeBuffer = new EnvelopeBuffer();
    
    /** Tells this thread to stop processing. */
    private boolean myStopProcessing = false;
    /** Set the status of the stop processing. */
    public void setStopProcessing(boolean inStopProcessing){myStopProcessing = inStopProcessing;}
    
    
    /** Class to hold information about an image. */
    private class ImageTile{
        private String myFileName;
        public void setFileName(String inFileName){myFileName = inFileName;}
        public String getfileName(){return myFileName;}
        
        /** width of the image. */
        private int myWidth = 0;
        /** Set the width of the image. */
        public void setWidth(int inWidth){myWidth = inWidth;}
        /** Get the width of the image. */
        public int getWidth(){return myWidth;}
        
        /** height of the image. */
        private int myHeight = 0;
        /** Set the height of the image. */
        public void setHeight(int inHeight){myHeight = inHeight;}
        /** Get the height of the image. */
        public int getHeight(){return myHeight;}
        
        /** Envelope to hold the extents of the tile. */
        private Envelope myEnvelope = null;
        /** Get the envelope. */
        public Envelope getEnvelope(){return myEnvelope;}
        /** Set the envelope. */
        public void setEnvelope(Envelope inEnvelope){
            myEnvelope = inEnvelope;
        }
        
        /** Create a new ImageTile. */
        public ImageTile(String inFileName, Envelope inEnvelope, int inWidth, int inHeight){
            myFileName = inFileName;
            myEnvelope = inEnvelope;
            setWidth(inWidth);
            setHeight(inHeight);
        }
    }
    
    /** The list of images and the corrisponding envelopes. */
    private ArrayList mySourceList = new ArrayList();
    
    /** Creates a new instance of RasterCatalogCreator */
    public RasterCatalogCreator() {
    }
    
    /** Creates a new instance of RasterCatalogCreator */
    public RasterCatalogCreator(String inFileLocation) throws FileNotFoundException{
        super();
        setSourceImageDirectory(inFileLocation);
    }
    
    /** Return the supported output types. */
    public String[] getSupportedOutputTypes(){
        // Get list of unique supported write formats
        String[] tempFormatNames = ImageIO.getWriterFormatNames();
        Set set = new HashSet();
        for (int i=0; i<tempFormatNames.length; i++) {
            String name = tempFormatNames[i].toLowerCase();
            set.add(name);
        }
        
        tempFormatNames = new String[set.size()];
        Iterator tempIterator = set.iterator();
        int i=0;
        while (tempIterator.hasNext()){
            tempFormatNames[i] = (String) tempIterator.next();
            
            // make sure jpg is first - cause I like them best.
            if (tempFormatNames[i].equalsIgnoreCase("jpg")){
                String tempString = tempFormatNames[0];
                tempFormatNames[0] = tempFormatNames[i];
                tempFormatNames[i] = tempString;
            }
            i++;
        }
        
        return tempFormatNames;
    }
    
    /** Some Array Lists for optimization. */
    private ArrayList myCacheImages = new ArrayList();
    private ArrayList myCacheFileNames = new ArrayList();
    
    /** Convert the images. */
    public void doConvert() throws Exception{
        setStopProcessing(false);
        
        // loop through the files to get the minimum bounding rectangle.
        if (mySourceImageDirectory == null) throw new Exception("Source Image Directory is null, no conversion can occur.");
        
        // look for the index file.
        Envelope tempEnvelope = null;
        tempEnvelope = readIndex();
        
        if (tempEnvelope == null){
            mySourceList.clear();
            
            // Find the envelope of all the files.
            EnvelopeBuffer tempEnvelopeBuffer = new EnvelopeBuffer();
            notify("Reading World Files", -1, 0,0);
            
            // get the directory listing.
            File[] tempFiles = mySourceImageDirectory.listFiles();
            for (int i=0; i<tempFiles.length; i++){
                if (myStopProcessing) return;
                String tempName = tempFiles[i].getName();
                String tempUCName = tempName.toUpperCase();
                if ((tempUCName.endsWith(".TFW")) || (tempUCName.endsWith(".JGW")) || (tempUCName.endsWith(".TIFW"))){
                    int tempExtensionLength = 0;
                    if (tempUCName.endsWith(".TFW")) tempExtensionLength = 4;
                    if (tempUCName.endsWith(".JGW")) tempExtensionLength = 4;
                    if (tempUCName.endsWith(".TIFW")) tempExtensionLength = 5;
                    
                    // look for the corrisponding Image File
                    String tempImageName = tempName.substring(0, tempName.length()-tempExtensionLength);
                    File tempImageFile = null;
                    for (int j=0; j<myExtensions.length; j++){
                        String tempFileName = mySourceImageDirectory.getAbsolutePath()+File.separatorChar+tempImageName+myExtensions[j];
                        File tempFile = new File(tempFileName);
                        if (tempFile.exists()){
                            tempImageFile = tempFile;
                            break;
                        }
                    }
                    
                    // if the image file was found then calculate the Envelope for this image.
                    notify("Reading World File "+tempImageFile.getAbsolutePath(), -1, 0,0);
                    if (tempImageFile != null){
                        // read the image file
                        ImageInformation tempInformation = ImageUtilities.readImageInformation(tempImageFile);
                        if (tempInformation != null){
                            
                            // calculate the envelope for this file.
                            Envelope tempImgEnvelope = ImageUtilities.calculateEnvelope(tempFiles[i], tempInformation);
                            tempEnvelopeBuffer.expandToInclude(tempImgEnvelope);
                            
                            // save in the source list
                            ImageTile tempImageTile = new ImageTile(tempImageFile.getAbsolutePath(), tempImgEnvelope, tempInformation.getImageWidth(), tempInformation.getImageHeight());
                            mySourceList.add(tempImageTile);
                        }
                    }
                }
            }
            
            // loop through the envelope.
            tempEnvelope = tempEnvelopeBuffer.getEnvelope();
            // write the XML file for these nodes.
            writeIndex(tempEnvelope);
        }
        if (tempEnvelope != null){
            
            // create the tiles for the first resolution.
            int tempCurrentResolution = myResolutions[0];
            
            // create the directory
            File tempResolutionDirectory = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+"r"+tempCurrentResolution);
            tempResolutionDirectory.mkdirs();
            
            // how big are the tiles in world coordinates.
            double tempWorldWidth = tempCurrentResolution * myMaxWidth;
            double tempWorldHeight = tempCurrentResolution * myMaxWidth;
            
            // how many tiles is it going to take at this resolution
            int tempXItter = (int) tempEnvelope.getWidth()/(tempCurrentResolution*myMaxWidth) + 1;
            int tempYItter = (int) tempEnvelope.getHeight()/(tempCurrentResolution*myMaxWidth) + 1;
            
            // loop through the tiles generating each one.
            for (int j=0; j<tempXItter; j++){
                for (int k=0; k<tempYItter; k++){
                    if (myStopProcessing) return;
                    notify(null, tempCurrentResolution, j, k);
                    // the file name
                    String tempFileName = "X"+j+"Y"+k+"."+myOutputType.toLowerCase();;
                    File tempFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+"r"+tempCurrentResolution+File.separatorChar+tempFileName);
                    if (!tempFile.exists()){
                        
                        // determine the world coordinates of the tile.
                        double tempWorldStartX = tempEnvelope.getMinX() + j*tempWorldWidth;
                        double tempWorldStartY = tempEnvelope.getMinY() + k*tempWorldHeight;
                        double tempWorldEndX = tempWorldStartX+tempWorldWidth;
                        double tempWorldEndY = tempWorldStartY+tempWorldHeight;
                        Envelope tempTileEnvelope = new Envelope(tempWorldStartX, tempWorldStartY, tempWorldEndX, tempWorldEndY);
                        System.out.println("TileEnvelope = "+tempTileEnvelope);
                        
                        // create the buffer.
                        BufferedImage tempImage = null;
                        Graphics2D g2d = null;
                        boolean tempFound = false;
                        
                        // loop through the images attempting to find the right one.
                        for (int l=0; l<mySourceList.size(); l++){
                            if (myStopProcessing) return;
                            ImageTile tempTile = (ImageTile) mySourceList.get(l);
                            if (tempTileEnvelope.intersects(tempTile.getEnvelope())){
                                System.out.println("ImageEnvelope = "+tempTile.getEnvelope());
                                
                                // draw this tile on the buffer.
                                Envelope tempNewEnvelope = tempTileEnvelope.getOverlap(tempTile.getEnvelope());
                                
                                // determine the image coordinates of the source image.
                                int tempSourceStartX = (int) (((tempNewEnvelope.getMinX()-tempTile.getEnvelope().getMinX())/(tempTile.getEnvelope().getWidth())) * tempTile.getWidth());
                                int tempSourceStartY = tempTile.getHeight() - (int) (((tempNewEnvelope.getMinY()-tempTile.getEnvelope().getMinY())/(tempTile.getEnvelope().getHeight())) * tempTile.getHeight());
                                int tempSourceEndX = (int) (((tempNewEnvelope.getMaxX()-tempTile.getEnvelope().getMinX())/(tempTile.getEnvelope().getWidth())) * tempTile.getWidth());
                                int tempSourceEndY = tempTile.getHeight() - (int) (((tempNewEnvelope.getMaxY()-tempTile.getEnvelope().getMinY())/(tempTile.getEnvelope().getHeight())) * tempTile.getHeight());
                                
                                // determine the image coordinates of the destination image.
                                int tempDestinationStartX = (int) (((tempNewEnvelope.getMinX()-tempWorldStartX)/(tempWorldWidth)) * myMaxWidth);
                                int tempDestinationStartY = myMaxWidth - (int) (((tempNewEnvelope.getMinY()-tempWorldStartY)/(tempWorldHeight)) * myMaxWidth);
                                int tempDestinationEndX = (int) (((tempNewEnvelope.getMaxX()-tempWorldStartX)/(tempWorldWidth)) * myMaxWidth);
                                int tempDestinationEndY = myMaxWidth - (int) (((tempNewEnvelope.getMaxY()-tempWorldStartY)/(tempWorldHeight)) * myMaxWidth);
                                
                                // read the image
                                ImageInformation tempInformation = null;
                                for (int m=0; m<myCacheFileNames.size(); m++){
                                    String tempTestFileName = (String) myCacheFileNames.get(m);
                                    if (tempTestFileName.equals(tempTile.getfileName())){
                                        tempInformation = (ImageInformation) myCacheImages.get(m);
                                    }
                                }
                                if (tempInformation == null){
                                    System.out.println("Reading "+tempTile.getfileName());
                                    notify(tempTile.getfileName(), tempCurrentResolution, j, k);
                                    
                                    tempInformation = ImageUtilities.readImageInformation(new File(tempTile.getfileName()));
                                    if (tempInformation != null){
                                        myCacheFileNames.add(0,  tempTile.getfileName());
                                        myCacheImages.add(0, tempInformation);
                                        
                                        if (myCacheFileNames.size() > 2){
                                            myCacheFileNames.remove(2);
                                            myCacheImages.remove(2);
                                        }
                                    }
                                }
                                if (tempInformation != null){
                                    if (!tempFound){
                                        tempImage = new BufferedImage(myMaxWidth, myMaxWidth, BufferedImage.TYPE_INT_BGR);
                                        g2d = (Graphics2D) tempImage.getGraphics();
                                        g2d.setColor(new Color(255,255,255,255));
                                        g2d.fillRect(0, 0, myMaxWidth, myMaxWidth);
                                        tempFound = true;
                                    }
                                    
                                    // draw the image
                                    g2d.drawImage(tempInformation.getImage(),
                                    tempDestinationStartX,
                                    tempDestinationStartY,
                                    tempDestinationEndX,
                                    tempDestinationEndY,
                                    tempSourceStartX,
                                    tempSourceStartY,
                                    tempSourceEndX,
                                    tempSourceEndY,
                                    null);
                                }
                            }
                        }
                        
                        // write the immage.
                        if (tempFound){
                            ImageIO.write(tempImage, myOutputType.toLowerCase(), tempFile);
                        }
                    }
                }
            }
            
            // After doing the first resolution, do all the next ones based on the first one.
            for (int i=1; i<myResolutions.length; i++){
                // create the tiles for the first resolution.
                tempCurrentResolution = myResolutions[i];
                
                // create the directory
                tempResolutionDirectory = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+"r"+tempCurrentResolution);
                tempResolutionDirectory.mkdirs();
                
                // how big are the tiles in world coordinates.
                tempWorldWidth = tempCurrentResolution * myMaxWidth;
                tempWorldHeight = tempCurrentResolution * myMaxWidth;
                
                // how many tiles is it going to take at this resolution
                tempXItter = (int) tempEnvelope.getWidth()/(tempCurrentResolution*myMaxWidth) + 1;
                tempYItter = (int) tempEnvelope.getHeight()/(tempCurrentResolution*myMaxWidth) + 1;
                
                // loop through the tiles generating each one.
                for (int j=0; j<tempXItter; j++){
                    for (int k=0; k<tempYItter; k++){
                        if (myStopProcessing) return;
                        notify(null, tempCurrentResolution, j, k);
                        // the file name
                        String tempFileName = "X"+j+"Y"+k+"."+myOutputType.toLowerCase();;
                        File tempFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+"r"+tempCurrentResolution+File.separatorChar+tempFileName);
                        if (!tempFile.exists()){
                            
                            // determine the world coordinates of the tile.
                            double tempWorldStartX = tempEnvelope.getMinX() + j*tempWorldWidth;
                            double tempWorldStartY = tempEnvelope.getMinY() + k*tempWorldHeight;
                            double tempWorldEndX = tempWorldStartX+tempWorldWidth;
                            double tempWorldEndY = tempWorldStartY+tempWorldHeight;
                            Envelope tempTileEnvelope = new Envelope(tempWorldStartX, tempWorldStartY, tempWorldEndX, tempWorldEndY);
                            System.out.println("TileEnvelope = "+tempTileEnvelope);
                            
                            // create the buffer.
                            BufferedImage tempImage = null;
                            Graphics2D g2d = null;
                            boolean tempFound = false;
                            
                            // find the tiles from the previous resolution for this resoltuion.
                            int tempPreviousResolution = myResolutions[i-1];
                            double tempPreviousWorldWidth = myMaxWidth*tempPreviousResolution;
                            double tempPreviousWorldHeight = myMaxWidth*tempPreviousResolution;
                            int tempPreviousResolutionStartX = (int) ((tempWorldStartX - tempEnvelope.getMinX())/(tempPreviousWorldWidth));
                            int tempPreviousResolutionEndX = (int) ((tempWorldEndX - tempEnvelope.getMinX())/(tempPreviousWorldWidth));
                            int tempPreviousResolutionStartY = (int) ((tempWorldStartY - tempEnvelope.getMinY())/(tempPreviousWorldHeight));
                            int tempPreviousResolutionEndY = (int) ((tempWorldEndY - tempEnvelope.getMinY())/(tempPreviousWorldHeight));
                            
                            // loop through the x and y tiles drawing them on the current set
                            for (int tx = tempPreviousResolutionStartX; tx<tempPreviousResolutionEndX+1; tx++){
                                for (int ty = tempPreviousResolutionStartY; ty<tempPreviousResolutionEndY+1; ty++){
                                    if (myStopProcessing) return;
                                    
                                    // Does this tile exist.
                                    String tempPreviousTileFileName = "X"+tx+"Y"+ty+"."+myOutputType.toLowerCase();;
                                    File tempPreviousFile = new File(myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+"r"+tempPreviousResolution+File.separatorChar+tempPreviousTileFileName);
                                    if (tempPreviousFile.exists()){
                                        
                                        // determine the world coordinates of the source tile.
                                        double tempTileMinX = tempEnvelope.getMinX() + (tx * tempPreviousWorldWidth);
                                        double tempTileMaxX = tempEnvelope.getMinX() + ((tx+1) * tempPreviousWorldWidth);
                                        double tempTileMinY = tempEnvelope.getMinY() + (ty * tempPreviousWorldHeight);
                                        double tempTileMaxY = tempEnvelope.getMinY() + ((ty+1) * tempPreviousWorldHeight);
                                        Envelope tempPreviousTileEnvelope = new Envelope(tempTileMinX, tempTileMinY, tempTileMaxX, tempTileMaxY);
                                        Envelope tempNewEnvelope = tempTileEnvelope.getOverlap(tempPreviousTileEnvelope);
                                        
                                        // determine the image coordinates of the source image.
                                        if (tempNewEnvelope != null){
                                            int tempSourceStartX = (int) (((tempNewEnvelope.getMinX()-tempPreviousTileEnvelope.getMinX())/(tempPreviousTileEnvelope.getWidth())) * myMaxWidth);
                                            int tempSourceStartY = myMaxWidth - (int) (((tempNewEnvelope.getMinY()-tempPreviousTileEnvelope.getMinY())/(tempPreviousTileEnvelope.getHeight())) * myMaxWidth);
                                            int tempSourceEndX = (int) (((tempNewEnvelope.getMaxX()-tempPreviousTileEnvelope.getMinX())/(tempPreviousTileEnvelope.getWidth())) * myMaxWidth);
                                            int tempSourceEndY = myMaxWidth - (int) (((tempNewEnvelope.getMaxY()-tempPreviousTileEnvelope.getMinY())/(tempPreviousTileEnvelope.getHeight())) * myMaxWidth);

                                            // determine the image coordinates of the destination image.
                                            int tempDestinationStartX = (int) (((tempNewEnvelope.getMinX()-tempWorldStartX)/(tempWorldWidth)) * myMaxWidth);
                                            int tempDestinationStartY = myMaxWidth - (int) (((tempNewEnvelope.getMinY()-tempWorldStartY)/(tempWorldHeight)) * myMaxWidth);
                                            int tempDestinationEndX = (int) (((tempNewEnvelope.getMaxX()-tempWorldStartX)/(tempWorldWidth)) * myMaxWidth);
                                            int tempDestinationEndY = myMaxWidth - (int) (((tempNewEnvelope.getMaxY()-tempWorldStartY)/(tempWorldHeight)) * myMaxWidth);

                                            // read the image
                                            ImageInformation tempInformation = null;
                                            System.out.println("Reading "+tempPreviousFile.getAbsolutePath());
                                            notify(tempPreviousFile.getAbsolutePath(), tempCurrentResolution, j, k);
                                            tempInformation = ImageUtilities.readImageInformation(tempPreviousFile);
                                            if (tempInformation != null){
                                                if (!tempFound){
                                                    tempImage = new BufferedImage(myMaxWidth, myMaxWidth, BufferedImage.TYPE_INT_BGR);
                                                    g2d = (Graphics2D) tempImage.getGraphics();
                                                    g2d.setColor(new Color(255,255,255,255));
                                                    g2d.fillRect(0, 0, myMaxWidth, myMaxWidth);
                                                    tempFound = true;
                                                }

                                                // draw the image
                                                g2d.drawImage(tempInformation.getImage(),
                                                tempDestinationStartX,
                                                tempDestinationStartY,
                                                tempDestinationEndX,
                                                tempDestinationEndY,
                                                tempSourceStartX,
                                                tempSourceStartY,
                                                tempSourceEndX,
                                                tempSourceEndY,
                                                null);
                                            }
                                        }
                                    }
                                }
                            }
                            // write the immage.
                            if (tempFound){
                                ImageIO.write(tempImage, myOutputType.toLowerCase(), tempFile);
                            }
                        }
                    }
                }
            }
            // write the XML file for these nodes.
            writeIndex(tempEnvelope);
        }
        notify("Finished", -1, 0,0);
    }
    
    /** Read the envelope from the index file.  This prevents multiple reads in the case of restarting the process. */
    private Envelope readIndex(){
        /** Check for the existence of the index file. */
        File tempIndexFile = new File(myDestinationImageDirectory.getAbsolutePath() + File.separatorChar + "Index.xml");
        if (!tempIndexFile.exists()) return null;
        
        try{
            // if the index file exists, then use it.
            boolean tempReadIndex = false;
            if (tempIndexFile.exists()){
                Node tempRoot = gistoolkit.config.Configurator.readConfig(tempIndexFile.getAbsolutePath());
                if (tempRoot == null) throw new Exception("Can not read configuration file.");
                
                // read the envelope.
                double tempMinX = 0;
                if (tempRoot != null){
                    try{
                        String tempString = tempRoot.getAttribute("MinX");
                        tempMinX = Double.parseDouble(tempString);
                    }
                    catch (Exception e){
                        throw new Exception("Error parsing MinX from RasterCatalog Index File");
                    }
                }
                double tempMinY = 0;
                if (tempRoot != null){
                    try{
                        String tempString = tempRoot.getAttribute("MinY");
                        tempMinY = Double.parseDouble(tempString);
                    }
                    catch (Exception e){
                        throw new Exception("Error parsing MinY from RasterCatalog Index File");
                    }
                }
                double tempMaxX = 0;
                if (tempRoot != null){
                    try{
                        String tempString = tempRoot.getAttribute("MaxX");
                        tempMaxX = Double.parseDouble(tempString);
                    }
                    catch (Exception e){
                        throw new Exception("Error parsing MaxX from RasterCatalog Index File");
                    }
                }
                double tempMaxY = 0;
                if (tempRoot != null){
                    try{
                        String tempString = tempRoot.getAttribute("MaxY");
                        tempMaxY = Double.parseDouble(tempString);
                    }
                    catch (Exception e){
                        throw new Exception("Error parsing MaxY from RasterCatalog Index File");
                    }
                }
                // Create the envelope
                Envelope tempEnvelope = new Envelope(tempMinX, tempMinY, tempMaxX, tempMaxY);
                
                // read the resolutions.
                int[] tempResolutions = null;
                String[] tempResolutionNames = null;
                try{
                    String tempString = tempRoot.getAttribute("Resolutions");
                    if (tempString == null) throw new Exception("Unable to read Resolutions configuration information.");
                    ArrayList tempList = new ArrayList();
                    StringTokenizer st = new StringTokenizer(tempString);
                    while (st.hasMoreElements()){
                        tempList.add(st.nextToken(","));
                    }
                    
                    tempResolutions = new int[tempList.size()];
                    tempResolutionNames = new String[tempList.size()];
                    for (int i=0; i<tempList.size(); i++){
                        tempResolutionNames[i] = (String) tempList.get(i);
                        tempResolutions[i] = Integer.parseInt(tempResolutionNames[i]);
                    }
                    if (tempResolutions.length == 0) throw new Exception("No Resolutions found in Index File!");
                    myResolutions = tempResolutions;
                }
                catch (Exception e){
                    e.printStackTrace();
                    throw new Exception("Error parsing Resolutions from index file.");
                }
                
                // Read the file extension of the tiles.
                String tempExtension = tempRoot.getAttribute("Extension");
                if (tempExtension == null) tempExtension = "jpg";
                
                // read the source information.
                Node[] tempSourceNodes = tempRoot.getChildren("SourceImage");
                for (int i=0; i<tempSourceNodes.length; i++){
                    // read the envelope.
                    String tempString = tempSourceNodes[i].getAttribute("MinX");
                    tempMinX = Double.parseDouble(tempString);
                    tempString = tempSourceNodes[i].getAttribute("MinY");
                    tempMinY = Double.parseDouble(tempString);
                    tempString = tempSourceNodes[i].getAttribute("MaxX");
                    tempMaxX = Double.parseDouble(tempString);
                    tempString = tempSourceNodes[i].getAttribute("MaxY");
                    tempMaxY = Double.parseDouble(tempString);
                    Envelope tempSourceEnvelope = new Envelope(tempMinX, tempMinY, tempMaxX, tempMaxY);
                    
                    // read the width and height
                    int tempWidth = Integer.parseInt(tempSourceNodes[i].getAttribute("ImageWidth"));
                    int tempHeight = Integer.parseInt(tempSourceNodes[i].getAttribute("ImageHeight"));
                    
                    // read the file name
                    String tempFileName = tempSourceNodes[i].getAttribute("ImageFileName");
                    
                    // create the tile
                    ImageTile tempImageTile = new ImageTile(tempFileName, tempSourceEnvelope, tempWidth, tempHeight);
                    mySourceList.add(tempImageTile);
                }
                
                // create the index
                return tempEnvelope;
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    /** write the index file. */
    private void writeIndex(Envelope tempEnvelope) throws Exception{
        // write the XML file for these nodes.
        Node tempRoot = new Node("TilesColection");
        tempRoot.addAttribute("MinX", ""+tempEnvelope.getMinX());
        tempRoot.addAttribute("MinY", ""+tempEnvelope.getMinY());
        tempRoot.addAttribute("MaxX", ""+tempEnvelope.getMaxX());
        tempRoot.addAttribute("MaxY", ""+tempEnvelope.getMaxY());
        tempRoot.addAttribute("TileWidth", ""+myMaxWidth);
        tempRoot.addAttribute("Extension", ""+myOutputType.toLowerCase());
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<myResolutions.length; i++){
            if (i>0) sb.append(",");
            sb.append(""+myResolutions[i]);
        }
        tempRoot.addAttribute("Resolutions", sb.toString());
        
        /** Save the source information. */
        for (int i=0; i<mySourceList.size(); i++){
            ImageTile tempImageTile = (ImageTile) mySourceList.get(i);
            Node tempImageNode = new Node("SourceImage");
            Envelope tempImageEnvelope = tempImageTile.getEnvelope();
            tempImageNode.addAttribute("MinX", ""+tempImageEnvelope.getMinX());
            tempImageNode.addAttribute("MinY", ""+tempImageEnvelope.getMinY());
            tempImageNode.addAttribute("MaxX", ""+tempImageEnvelope.getMaxX());
            tempImageNode.addAttribute("MaxY", ""+tempImageEnvelope.getMaxY());
            tempImageNode.addAttribute("ImageWidth", ""+tempImageTile.getWidth());
            tempImageNode.addAttribute("ImageHeight", ""+tempImageTile.getHeight());
            tempImageNode.addAttribute("ImageFileName", ""+tempImageTile.getfileName());
            tempRoot.addChild(tempImageNode);
        }
        
        // write the index file
        gistoolkit.config.Configurator.writeConfig(tempRoot, myDestinationImageDirectory.getAbsolutePath()+File.separatorChar+"Index.xml");
        
    }
    
    /** For status in the application (I know I should use events, but it seems pointless at this point. ) */
    private RasterCatalogCreatorApplication myRasterCatalogCreatorApplication = null;
    /** Set the application for notification. */
    public void setRasterCatalogCreatorApplication(RasterCatalogCreatorApplication inRasterCatalogCreatorApplication){myRasterCatalogCreatorApplication = inRasterCatalogCreatorApplication;}
    
    private String lastFile = "";
    /** Notify the application of a status change. */
    public void notify(String inFile, int inResolution, int inX, int inY){
        String tempFile = inFile;
        if (tempFile == null) tempFile = lastFile;
        else lastFile = tempFile;
        
        if (myRasterCatalogCreatorApplication != null){
            myRasterCatalogCreatorApplication.setStatus(tempFile, inResolution, inX, inY);
        }
    }
}