/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.mysql;
import java.util.*;
import java.io.*;
import java.sql.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;

/**
 * Allows for any sql query to be sent to the database, and returns the data set.
 */
public class ReadOnlyMySQLDataSource extends MySQLDataSource {
    
    /** This Data Source relies on a pre constructed SQL Query */
    private String myDatabaseQuery = null;
    /** Set the SQL Query to use when accessing the data source */
    public void setDatabaseQuery(String inQuery){myDatabaseQuery = inQuery;}
    /** return the SQLQuery to use when accessing the data source */
    public String getDatabaseQuery(){return myDatabaseQuery;}
    
    /** Indicates whether to preread this data source, keeping the contents in memory until the data source is disposed. */
    private boolean myPreread = false;
    /** Sets the preread flag to tell this data source to preread the entire contents of the layer, and keep them in memory, essentially caching them, until the data source is disposed. */
    public void setPreread(boolean inPreread){ myPreread = inPreread;}
    /** Returns the preread flag.  This flag tells the data source to preread the entire contents of the layer, and to cach that information in memory until the data source is disposed. */
    public boolean getPreread(){return myPreread;}
    
    /** Creates new ReadOnlyMySQLDataSource */
    public ReadOnlyMySQLDataSource() {
    }
    
    /** This method returns the shapes from the data source  */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception{
        // check for cached information
        if (inEnvelope != null){
            if (getPreread()){
                return queryFromCache(getCacheEnvelope());
            }
        }
        
        // construct the SQL statement
        String tempSQLStatement = null;
        if (inEnvelope == null){
            tempSQLStatement = myDatabaseQuery;
        }
        else{
            tempSQLStatement = myDatabaseQuery;
            if (tempSQLStatement.toUpperCase().indexOf("WHERE") ==-1){
                tempSQLStatement = tempSQLStatement + " WHERE ";
            }
            else {
                tempSQLStatement = tempSQLStatement + " AND ";
            }
            tempSQLStatement = tempSQLStatement
            + "MBRIntersects("+getDatabaseShapeColumn()+",GeomFromText('POLYGON(("
            + inEnvelope.getMinX() + " " + inEnvelope.getMaxY() + ", "
            + inEnvelope.getMaxX() + " " + inEnvelope.getMaxY() + ", "
            + inEnvelope.getMaxX() + " " + inEnvelope.getMinY() + ", "
            + inEnvelope.getMinX() + " " + inEnvelope.getMinY() + ", "
            + inEnvelope.getMinX() + " " + inEnvelope.getMaxY() + "))'))";
        }
        
        // connect to the data source
        Connection tempConnection = connect();
        SQLConverter tempConverter = getSQLConverter();
        
        // Send the sql Query to the database
        Statement tempStatement = tempConnection.createStatement();
        ResultSet tempResultSet = null;
        try{
            tempResultSet = tempStatement.executeQuery(tempSQLStatement);
        }
        catch (Exception e){
            System.out.println(tempSQLStatement);
            throw (e);
        }
        
        // construct the attribute names and types
        int tempShapeColumnNum = -1;
        ResultSetMetaData tempResultSetMetaData = tempResultSet.getMetaData();
        int tempColumnNum = tempResultSetMetaData.getColumnCount();
        ArrayList tempAttributeNamesList = new ArrayList(tempColumnNum-1);
        ArrayList tempAttributeTypesList = new ArrayList(tempColumnNum-1);
        for (int i=0; i<tempColumnNum; i++){
            String tempColumnName = tempResultSetMetaData.getColumnName(i+1);
            AttributeType tempAttributeType = tempConverter.getAttributeType(tempResultSetMetaData, i);
            if (!tempColumnName.equalsIgnoreCase(getDatabaseShapeColumn())){
                tempAttributeNamesList.add(tempColumnName);
                tempAttributeTypesList.add(tempAttributeType);
            }
            else{
                tempShapeColumnNum = i;
            }
        }
        String[] tempAttributeNames = new String[tempAttributeNamesList.size()];
        tempAttributeNamesList.toArray(tempAttributeNames);
        AttributeType[] tempAttributeTypes = new AttributeType[tempAttributeTypesList.size()];
        tempAttributeTypesList.toArray(tempAttributeTypes);
        if (tempShapeColumnNum == -1) throw new Exception("Shape column not found in resulting Data set");
        
        // Create the new GISDataset
        GISDataset tempGISDataset = new GISDataset(tempAttributeNames);
        while(tempResultSet.next()){
            // retrieve the columns
            Shape tempShape = null;
            Object[] tempAttributes = new Object[tempAttributeNames.length];
            for (int i=0; i<tempColumnNum; i++){
                if (i == tempShapeColumnNum){
                    // parse out the shape
                    InputStream in = tempResultSet.getBinaryStream(i + 1);
                    tempShape = WKBFactory.parseShape(in);
                }
                else {
                    // add the attribute
                    if (i<tempShapeColumnNum){
                        tempAttributes[i] = tempResultSet.getObject(i+1);
                    }
                    else if (i>tempShapeColumnNum){
                        tempAttributes[i-1] = tempResultSet.getObject(i+1);
                        System.out.print(""+tempAttributes[i-1]);
                    }
                }
            }
            tempGISDataset.add(tempAttributes, tempShape);
        }
        return tempGISDataset;
    }
    
    /** Static final for the name of the query */
    private static final String DATABASE_QUERY = "DatabaseQuery";
    private static final String PREREAD = "Preread";
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("ReadOnlyMySQLDataSource");
        tempRoot.addAttribute(DATABASE_QUERY, getDatabaseQuery());
        tempRoot.addAttribute(PREREAD, ""+getPreread());
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        super.setNode(inNode);
        setDatabaseQuery(inNode.getAttribute(DATABASE_QUERY));
        String tempPrereadString = inNode.getAttribute(PREREAD);
        if (tempPrereadString == null) setPreread(false);
        else{
            if (tempPrereadString.toUpperCase().trim().startsWith("T")){
                setPreread(true);
            }
        }
        if (getPreread()){
            this.readDataset();
        }
    }
    
    /** Testing only */
    public static void main(String[] inArgs){
        if (inArgs.length == 0) {
            System.out.println("Program DatabaseName DatabaseUsername [Database Password]");
            return;
        }
        ReadOnlyMySQLDataSource tempDataSource = new ReadOnlyMySQLDataSource();
        tempDataSource.setDatabaseName(inArgs[0]);
        tempDataSource.setDatabaseUsername(inArgs[1]);
        if (inArgs.length > 2){
            tempDataSource.setDatabasePassword(inArgs[2]);
        }
        try{
            tempDataSource.connect();
            tempDataSource.setDatabaseQuery("Select state_name, state_abbr, AsWKB(Shape) as Shape from states");
            tempDataSource.readDataset();
            tempDataSource.closeConnection();
        }
        catch (Exception e){
            System.out.println("Exception in main " + e);
            e.printStackTrace();
        }
    }
    /** Get the style to use with this datasource.  */
    public gistoolkit.display.Style getStyle() {
        return null;
    }
}
