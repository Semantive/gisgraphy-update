/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package gistoolkit.datasources.mysql;

import java.io.*;
import gistoolkit.datasources.shapefile.*;

/**
 * Class to import a shape file into the MYSQL Database.
 */
public class MySQLImporter {
    
    /** The shape file data source for reading data. */
    private ShapeFileReader myShapeFileReader = null;
    
    /** The MySQL data source for inserting data. */
    private UpdateableMySQLDataSource mySQLDataSource = null;
    
    /** Creates a new instance of MySQLImporter */
    public MySQLImporter() {
    }

    /** Set the shape file to use for this importer. */
    public void setShapeFile(String inShapeFileName) throws Exception{
        ShapeFileReader tempShapeFileReader = new ShapeFileReader(inShapeFileName);
        myShapeFileReader = tempShapeFileReader;
    }
    
    /** Set the requirements for connecting to the server. */
    public void setDBConnection(String inServer, String inPort, String inDatabaseName, String inTableName, String inColumnName, String inUsername, String inPassword) throws Exception{
        UpdateableMySQLDataSource tempMySQLDataSource = new UpdateableMySQLDataSource();
        tempMySQLDataSource.setDatabaseServername(inServer);
        tempMySQLDataSource.setDatabasePort(Integer.parseInt(inPort));
        tempMySQLDataSource.setDatabaseName(inDatabaseName);
        tempMySQLDataSource.setDatabaseTablename(inTableName);
        tempMySQLDataSource.setDatabaseUsername(inUsername);
        tempMySQLDataSource.setDatabasePassword(inPassword);
        tempMySQLDataSource.setDatabaseShapeColumn(inColumnName);
        tempMySQLDataSource.connect();
        mySQLDataSource = tempMySQLDataSource;
    }
    
    /** read the records from the shape file and insert them into the database. */
    public void doImport() throws Exception{
        // determine how many attributes the shape file has.
        ShapeFileRecord tempRecord = myShapeFileReader.read();
        int tempIndex = 0;
        while (tempRecord != null){
            tempIndex++;
            mySQLDataSource.insert(tempRecord);
            
            // commit every 100 records
            if ((tempIndex % 100) == 0){
                System.out.println(tempIndex);
                mySQLDataSource.commit();
                tempIndex = 0;
            }
            tempRecord = myShapeFileReader.read();
        }
        myShapeFileReader = null;
        mySQLDataSource.commit();
    }
    
    /** The main routine when run as an executable. */
    public static void main(String[] inArgs){
        // the first argument is the shape file to use.
        if (inArgs.length <= 0) {
            showHelp();
            return;
        }
        
        try{
            // find the shape file
            String tempShapeFileName = inArgs[0];
            File tempShapeFile = new File(tempShapeFileName);
            if (!tempShapeFile.exists()){
                System.out.println("Can not find shape file "+tempShapeFile.getAbsolutePath());
            }
            MySQLImporter tempImporter = new MySQLImporter();
            tempImporter.setShapeFile(tempShapeFileName);

            String tempServername = null;
            String tempPort = "3306";
            String tempDatabaseName = null;
            String tempTableName = null;
            String tempColumnName = null;
            String tempUsername = null;
            String tempPassword = null;

            // Database Connection parameters.
            for (int i=0; i<inArgs.length; i++){
                if (inArgs[i].equals("-s"))if (inArgs.length > i+1) tempServername = inArgs[i+1];
                if (inArgs[i].equals("-pt"))if (inArgs.length > i+1) tempPort = inArgs[i+1];
                if (inArgs[i].equals("-d"))if (inArgs.length > i+1) tempDatabaseName = inArgs[i+1];
                if (inArgs[i].equals("-t"))if (inArgs.length > i+1) tempTableName = inArgs[i+1];
                if (inArgs[i].equals("-c"))if (inArgs.length > i+1) tempColumnName = inArgs[i+1];
                if (inArgs[i].equals("-u"))if (inArgs.length > i+1) tempUsername = inArgs[i+1];
                if (inArgs[i].equals("-p"))if (inArgs.length > i+1) tempPassword = inArgs[i+1];
            }

            boolean tempHelp = false;
            if (tempServername == null) {System.out.println("Can not find servername -s option"); tempHelp = true;}
            if (tempPort == null) {System.out.println("Can not find port -pt option"); tempHelp = true;}
            if (tempDatabaseName == null) {System.out.println("Can not find database -d option"); tempHelp = true;}
            if (tempTableName == null) {System.out.println("Can not find tablename -t option"); tempHelp = true;}
            if (tempColumnName == null) {System.out.println("Can not find columnname -c option"); tempHelp = true;}
            if (tempUsername == null) {System.out.println("Can not find username -u option"); tempHelp = true;}
            if (tempPassword == null) {System.out.println("Can not find password -p option"); tempHelp = true;}
            if (tempHelp){showHelp(); return;}
            
            tempImporter.setDBConnection(tempServername, tempPort, tempDatabaseName, tempTableName, tempColumnName, tempUsername, tempPassword);            
            tempImporter.doImport();
        }
        catch (Exception e){
            e.printStackTrace();
            System.out.println(e);
        }
    }
    
    /** Show the help page. */
    public static void showHelp(){
        System.out.println("MySQLImporter shapefilename -s servername [-pt port] -d databasename -t tablename -u username -p password");
    }
}
