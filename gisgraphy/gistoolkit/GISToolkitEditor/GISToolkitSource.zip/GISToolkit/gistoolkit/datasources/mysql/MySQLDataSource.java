/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.datasources.mysql;

import java.util.*;
import java.sql.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;

/**
 * MySQL has recently added support for spatial objects within their databases.  They did this in a way which
 * complies with the recomendation from OGC.
 */
public abstract class MySQLDataSource extends SimpleDBDataSource{
    
    // Things that need to be known in order to connect to the database.
    /** The string to prepend to the url in orde to construct it.  This is usually a constant like "jdbc:mysql://".*/
    private String myDatabaseURLBase = "jdbc:mysql://";
    /** Get the string to prepend to the url used to locate the database.  This is usally a constant like  "jdbc:mysql://".*/
    public String getDatabaseURLBase(){return myDatabaseURLBase;}
    /** Set the string to prepend to the url used to locate the database.  This is usally a constant like  "jdbc:mysql://".*/
    public void setDatabaseURLBase(String inURLBase){myDatabaseURLBase = inURLBase;}
    
    /** The hostname/servername of the target computer.  This usually changes with each installation or application. The default is "localhost" for the local computer*/
    private String myDatabaseServername = "localhost";
    /** Get thehostname/servername of the target computer.  This usually changes with each installation or application. The default is "localhost" for the local computer*/
    public String getDatabaseServername(){return myDatabaseServername;}
    /** Set thehostname/servername of the target computer.  This usually changes with each installation or application. The default is "localhost" for the local computer*/
    public void setDatabaseServername(String inDatabaseServername){myDatabaseServername = inDatabaseServername;}
    
    /** The TCP-IP port number on which the postmaster is listening.  The default is 3306, but it could be changed to a different port, depending on configuration. */
    private int myDatabasePort = 3306;
    /** Get the TCP-IP port number on which the postmaster is listening.  The default is 3306, but it could be changed to a different port, depending on configuration. */
    public int getDatabasePort(){return myDatabasePort;}
    /** Set the TCP-IP port number on which the postmaster is listening.  The default is 3306, but it could be changed to a different port, depending on configuration. */
    public void setDatabasePort(int inPortNumber){myDatabasePort = inPortNumber;}
    
    /** The database name the postmaster should access for servicing this request.  The default is "database", which is most likely inappropriate.*/
    private String myDatabaseName = "database";
    /** Get the database name the postmaster should access for servicing this request.  The default is "database", which is most likely inappropriate.*/
    public String getDatabaseName(){return myDatabaseName;}
    /** Set the database name the postmaster should access for servicing this request.  The default is "database", which is most likely inappropriate.*/
    public void setDatabaseName(String inDatabaseName){myDatabaseName = inDatabaseName;}
    
    /** The name of the column that contains the shapes.  This column will be translated into a shape and rendered. */
    private String myDatabaseShapeColumn = "Shape";
    /** Get the name of the column containing shapes. */
    public String getDatabaseShapeColumn(){return myDatabaseShapeColumn;}
    /** Set the name of the column containing shapes. */
    public void setDatabaseShapeColumn(String inShapeColumn){myDatabaseShapeColumn = inShapeColumn;}
    
    /** The username with permission to connect to the database. */
    private String myDatabaseUsername = "mysql";
    /** Get the username with permission to connect to the database. These are defined in the database.*/
    public String getDatabaseUsername(){return myDatabaseUsername;}
    /** Set the username with permission to connect to the database.  These are defined in the database.*/
    public void setDatabaseUsername(String inDatabaseUsername){myDatabaseUsername = inDatabaseUsername;}
    
    /** The password of the user with permission to access the database.  The password is used to validate that the user is actually who they say they are. */
    private String myDatabasePassword = "";
    /** Get the password that validates the username. */
    public String getDatabasePassword(){return myDatabasePassword;}
    /** Set the password that validates the username. */
    public void setDatabasePassword(String inDatabasePassword){myDatabasePassword = inDatabasePassword;}

    /**Spatial Reference ID needed for accessing shape information.*/
    private int myDatabaseSpatialReferenceID = 1;
    /** Returns the spatial reference id to use for converting shapes to and from database format.*/
    public int getDatabaseSpatialReferenceID() {return myDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(int inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = inDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(String inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = Integer.parseInt(inDatabaseSpatialReferenceID);}

    /** Indicates whether a transaction is in progress or not */
    private boolean myInTransaction = false;
    
    /** Creates new MySQLDataSource */
    public MySQLDataSource() {
    }
    
    /** Connection to the database.*/
    private Connection myConnection = null;
    
    /** Connect this datasource to the database */
    public Connection connect() throws Exception{
        if (myConnection != null) return myConnection;
        
        //Load the JDBC driver and establish a connection.
        try{
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (Exception e){
            System.out.println("Error Loading Driver org.postgresql.Driver \n" +e);
            throw new Exception("Error Loading Driver org.postgresql.Driver "+e);
        }
        String tempURL = myDatabaseURLBase+myDatabaseServername+":"+myDatabasePort+"/"+myDatabaseName;
        // Construct the URL jdbc:mysql://[hostname][,failoverhost...][:port]/[dbname][?param1=value1][&param2=value2]
        myConnection = DriverManager.getConnection(tempURL, myDatabaseUsername, myDatabasePassword);
        
        //Create a statement and execute a select query.
        Statement s = myConnection.createStatement();
        ResultSet r = s.executeQuery("show databases");

        // close the statement and return
        s.close();
        return myConnection;
    }
    
    /** Close the connection to the database. */
    protected void closeConnection() throws Exception{
        if (myConnection != null){
            myConnection.close();
            myConnection = null;
        }
    }
    
    /** Close any open connections */
    public void finalize(){
        try{
            closeConnection();
        }
        catch(Exception e){
            // do nothing here, nothing much that I know of that I can do
        }
    }
    
    // Static finals for the node tags.
    private static final String DATASOURCE_NAME = "DataSourceName";
    private static final String SERVER_NAME = "Servername";
    private static final String PORT_NUMBER = "PortNumber";
    private static final String USERNAME = "Username";
    private static final String PASSWORD = "Password";
    private static final String DATABASE_NAME = "DatabaseName";
    private static final String SHAPE_COLUMN = "ShapeColumn";
    private static final String URLBASE = "URLBase";
    private static final String SRID = "SRID";
    
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("MySQLDataSource");
        
        // connection parameters
        tempRoot.addAttribute(SERVER_NAME, getDatabaseServername());
        tempRoot.addAttribute(PORT_NUMBER, ""+getDatabasePort());
        tempRoot.addAttribute(USERNAME, getDatabaseUsername());
        tempRoot.addAttribute(PASSWORD, getDatabasePassword());
        tempRoot.addAttribute(DATABASE_NAME, getDatabaseName());
        tempRoot.addAttribute(SHAPE_COLUMN, getDatabaseShapeColumn());
        tempRoot.addAttribute(URLBASE, getDatabaseURLBase());
        tempRoot.addAttribute(SRID, ""+getDatabaseSpatialReferenceID());
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        super.setNode(inNode);
        setDatabaseServername(inNode.getAttribute(SERVER_NAME));
        setDatabaseName(inNode.getAttribute(DATABASE_NAME));
        setDatabasePort(Integer.parseInt(inNode.getAttribute(PORT_NUMBER)));
        setDatabaseUsername(inNode.getAttribute(USERNAME));
        setDatabasePassword(inNode.getAttribute(PASSWORD));
        setDatabaseName(inNode.getAttribute(DATABASE_NAME));
        setDatabaseShapeColumn(inNode.getAttribute(SHAPE_COLUMN));
        setDatabaseURLBase(inNode.getAttribute(URLBASE));
        setDatabaseSpatialReferenceID(inNode.getAttribute(SRID));
    }
    
    /**Initialize the data source from the properties.*/
    public void load(Properties inProperties) {
    }    
  
    /**Returns the bounding rectangle of all the shapes in the Data Source.*/
    public Envelope readEnvelope() throws Exception {
        readDataset();
        return getCacheEnvelope();
    }

    /** Returns the converter for this Database. */
    public SQLConverter getSQLConverter(){return new MySQLConverter();}  
}
