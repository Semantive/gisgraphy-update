/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.datasources.mysql;

import gistoolkit.features.*;

/**
 * A record designed for use with the UpdateableMySQLDataSource to allow updates.  It keeps the old Attributes, and shape.
 */
public class MySQLRecord extends Record{

    /** Creates new PostGISRecord */
    public MySQLRecord() {
    }

    /** Keep a separate array of all of the old values of the data for this record.*/
    protected Object[] myOldAttributes = null;
    /** return the old attributes of this record */
    public Object[] getOldAttributes(){return myOldAttributes;}
    
    /** Keep a separate entry for the old shape */
    protected Shape myOldShape = null;
    /** return the old shape of this record */
    public Shape getOldShape(){return myOldShape;}
    
    /** handle the clone method as the record will be cloned before it is modified.*/
    public Object clone(){
        MySQLRecord tempRecord = new MySQLRecord();
        // set the old values
        if (myOldShape == null) tempRecord.myOldShape = (Shape) getShape().clone();
        else tempRecord.myOldShape = myOldShape;
        
        if (myOldAttributes == null) {
            Object[] tempAttributes = new Object[getAttributes().length];
            for (int i=0; i<tempAttributes.length; i++){
                tempAttributes[i] = getAttributes()[i];
            }
            tempRecord.myOldAttributes = tempAttributes;
        }
        else tempRecord.myOldAttributes = myOldAttributes;
        
        // set the actual values.
        tempRecord.setAttributeNames(getAttributeNames());
        tempRecord.setAttributeTypes(getAttributeTypes());
        tempRecord.setAttributes(getAttributes());
        tempRecord.setShape((Shape) getShape().clone());
        return tempRecord;
    }
}
