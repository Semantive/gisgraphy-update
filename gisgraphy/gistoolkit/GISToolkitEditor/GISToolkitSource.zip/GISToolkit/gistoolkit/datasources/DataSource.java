/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.datasources;

import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.display.Style;
import gistoolkit.projection.Projection;
import gistoolkit.datasources.filter.Filter;
public interface DataSource {
    public static final String STRING = "String";
    public static final String DOUBLE = "Double";
    public static final String INTEGER = "Integer";
    public static final String DATETIME = "Date";
    public static final String BOOLEAN = "Boolean";
    
    /**
     * Returns the bounding rectangle of all the shapes in the Data Source.
     */
    public Envelope getEnvelope() throws Exception;
    
    /**
     * Sets an identifier string for the datasource.
     */
    public void setName(String inName);
    
    /**
     * Returns the identifier string for the datasource.
     */
    public String getName();
    
    /**
     * Update the data source with the changed record.
     */
    public void update(Record inRecord) throws Exception;
    
    /**
     * Commit all changes since the last commit.
     */
    public void commit() throws Exception;
    
    /**
     * Delete this record from the database.
     */
    public void delete(Record inRecord) throws Exception;
    
    /**
     * Inserts the given record into the datasource.
     */
    public void insert(Record inRecord)throws Exception;
    
    /**
     * Reads all the objects from the data source.
     */
    public GISDataset readDataset() throws Exception;
    
    /**
     * Reads only the objects from the data source that intersect these extents.
     */
    public GISDataset readDataset(Envelope inEnvelope) throws Exception;
    
    /**
     * Rollback any changes to this datasource since the last commit.
     */
    public void rollback() throws Exception;
    
    /**
     * Determines if this datasource is updateable.
     */
    public boolean isUpdateable();
    
    /**
     * Adds a datasource listener to this datasource.
     */
    public void addDataSourceListener(DataSourceListener inDataSourceListener);
    
    /**
     * Removes the datasource lisener from this datasource.
     */
    public void removeDataSourceListener(DataSourceListener inDataSourceListener);
    
    /**
     * Sets the projection to use to convert from the storage media, source projection. 
     * It is expected that this projection will be run in reverse, to reverse project already projected data,
     * and that it will not change often so it is OK for this to be done just once.
     */
    public void setFromProjection(Projection inProjection) throws Exception;
    /**
     * Gets the projection to use to convert from the storage media, source projection. 
     * It is expected that this projection will be run in reverse, to reverse project already projected data,
     * and that it will not change often so it is OK for this to be done just once.
     */
    public Projection getFromProjection();
    
    /**
     * Allows another projection to be used to convert to the screen projection.  The CacheProjected flag indicates to the
     * Data source that the to projection will not be changing often, and it is OK to project once and cache it.  Setting this
     * flag to false indicates to the DataSource that the toProjection will be changing often.
     */
    public void setToProjection(Projection inProjection, boolean inCacheProjected) throws Exception;
    /**
     * Allows another projection to be used to convert to the screen projection.  The CacheProjected flag indicates to the
     * Data source that the to projection will not be changing often, and it is OK to project once and cache it.  Setting this
     * flag to false indicates to the DataSource that the toProjection will be changing often.
     */
    public Projection getToProjection();

    /** Get the configuration information for this data source */
    public Node getNode();
    
    /** Set the configuration information for this data source */
    public void setNode(Node inNode) throws Exception;
    
    /** Set the filter to use with this datasource. */
    public void setFilter(Filter inFilter);
    
    /** Get the filter to use with this datasource. */
    public Filter getFilter();
    
    /** Get the style to use with this datasource. */
    public Style getStyle();
    
}