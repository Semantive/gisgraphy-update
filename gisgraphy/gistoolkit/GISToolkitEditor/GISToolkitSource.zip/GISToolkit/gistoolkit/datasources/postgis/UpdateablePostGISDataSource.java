/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.datasources.postgis;
import java.util.*;
import java.sql.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;

/**
 * Reads the shapes from a single table.  This allows the shapes to be updated along with the attribute data without the confusion of adding additonal joins.
 * @author  bitterstorm
 */
public class UpdateablePostGISDataSource extends PostGISDataSource {
    
    /** This Data Source relies on a pre constructed SQL Query */
    private String myDatabaseTablename = null;
    /** Set the table name to use when accessing the data source */
    public void setDatabaseTablename(String inDatabaseTablename){myDatabaseTablename = inDatabaseTablename;}
    /** return the tablename to use when accessing the data source */
    public String getDatabaseTablename(){return myDatabaseTablename;}
    
    /** The names of the none shape columns. */
    private String[] myColumnNames = null;
    
    /** The types of the various columns. */
    private AttributeType[] myColumnTypes = null;
    
    /** The JDBC Types of the vearious columns. */
    private Integer[] myJDBCColumnTypes = null;
    
    /** The type of the shape */
    private String myShapeType = null;
    
    /** Creates new ReadOnlyPostGISDataSource */
    public UpdateablePostGISDataSource() {
    }
    
    /** The valid shapes for this data source */
    private String[] myShapeTypes = null;
    /** Return the valid shapes for this data source */
    public String[] getValidShapeTypes(){return myShapeTypes;}
    
    public Connection connect() throws Exception{
        Connection tempConnection = super.connect();
        SQLConverter tempConverter = getSQLConverter();
        
        if (myColumnNames == null){
            // retrieve the names of the geometry columns
            String tempQuery = "select type from geometry_columns where f_table_name = '"+myDatabaseTablename+"' and f_geometry_column = '"+getDatabaseShapeColumn()+"'";
            System.out.println(tempQuery);
            Statement tempStatement = tempConnection.createStatement();
            ResultSet tempResultSet = tempStatement.executeQuery(tempQuery);
            if (tempResultSet.next()){
                myShapeType = tempResultSet.getString(1);
                if (myShapeType.equalsIgnoreCase("POINT")) myShapeType = Shape.POINT;
                if (myShapeType.equalsIgnoreCase("MULTIPOINT")) myShapeType = Shape.MULTIPOINT;
                if (myShapeType.equalsIgnoreCase("LINESTRING")) myShapeType = Shape.LINESTRING;
                if (myShapeType.equalsIgnoreCase("MULTILINESTRING")) myShapeType = Shape.MULTILINESTRING;
                if (myShapeType.equalsIgnoreCase("POLYGON")) myShapeType = Shape.POLYGON;
                if (myShapeType.equalsIgnoreCase("MULTIPOLYGON")) myShapeType = Shape.MULTIPOLYGON;
            }
            String[] tempValidShapeTypes = {myShapeType};
            myShapeTypes = tempValidShapeTypes;
            System.out.println("My Shape Type = "+myShapeType);
            
            // retrieve the column names from the table
            tempQuery = "select * from "+myDatabaseTablename+" where 0=1";
            
            // Send the sql Query to the database
            tempResultSet = tempStatement.executeQuery(tempQuery);
            
            // construct the attribute names and types
            ResultSetMetaData tempResultSetMetaData = tempResultSet.getMetaData();
            int tempColumnNum = tempResultSetMetaData.getColumnCount();
            ArrayList tempNameList = new ArrayList(tempColumnNum-1);
            ArrayList tempTypeList = new ArrayList(tempColumnNum-1);
            ArrayList tempJDBCList = new ArrayList(tempColumnNum-1);
            for (int i=0; i<tempColumnNum; i++){
                String tempColumnName = tempResultSetMetaData.getColumnName(i+1);
                AttributeType tempColumnType = tempConverter.getAttributeType(tempResultSetMetaData, i);
                String tempTypeName = tempResultSetMetaData.getColumnTypeName(i+1);
                int tempJDBCType = tempResultSetMetaData.getColumnType(i+1);
                if (!tempTypeName.equalsIgnoreCase("geometry")){
                    tempNameList.add(tempColumnName);
                    tempTypeList.add(tempColumnType);
                    tempJDBCList.add(new Integer(tempJDBCType));
                }
            }
            myColumnNames = new String[tempNameList.size()];
            tempNameList.toArray(myColumnNames);
            myColumnTypes = new AttributeType[tempTypeList.size()];
            tempTypeList.toArray(myColumnTypes);
            myJDBCColumnTypes = new Integer[tempJDBCList.size()];
            tempJDBCList.toArray(myJDBCColumnTypes);
        }
        return tempConnection;
    }
    
    
    /** This method returns the shapes from the data source  */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception{
        // connect to the database
        connect();
        SQLConverter tempConverter = getSQLConverter();
        
        // construct the SQL statement
        StringBuffer sb = new StringBuffer();
        sb.append("select ");
        for (int i=0; i<myColumnNames.length; i++){
            if (i > 0) sb.append(", ");
            sb.append(myColumnNames[i]);
        }
        if (myColumnNames.length > 0) sb.append(", ");
        sb.append("AsText("+getDatabaseShapeColumn()+") as "+getDatabaseShapeColumn());
        sb.append(" from ");
        sb.append(myDatabaseTablename);
        if (inEnvelope != null){
            sb.append(" WHERE "
            + getDatabaseShapeColumn() +" && GeometryFromText('POLYGON(("
            +inEnvelope.getMinX() + " " + inEnvelope.getMaxY() + ", "
            +inEnvelope.getMaxX() + " " + inEnvelope.getMaxY() + ", "
            +inEnvelope.getMaxX() + " " + inEnvelope.getMinY() + ", "
            +inEnvelope.getMinX() + " " + inEnvelope.getMinY() + ", "
            +inEnvelope.getMinX() + " " + inEnvelope.getMaxY()
            +"))',"+getDatabaseSpatialReferenceID()+")");
        }
        String tempSQLStatement = sb.toString();
        
        // connect to the data source
        Connection tempConnection = connect();
        
        // Send the sql Query to the database
        Statement tempStatement = tempConnection.createStatement();
        ResultSet tempResultSet = tempStatement.executeQuery(tempSQLStatement);
        
        // construct the attribute names and types
        int tempShapeColumnNum = -1;
        ResultSetMetaData tempResultSetMetaData = tempResultSet.getMetaData();
        int tempColumnNum = tempResultSetMetaData.getColumnCount();
        ArrayList tempListNames = new ArrayList(tempColumnNum-1);
        ArrayList tempListTypes = new ArrayList(tempColumnNum-1);
        for (int i=0; i<tempColumnNum; i++){
            String tempColumnName = tempResultSetMetaData.getColumnName(i+1);
            if (!tempColumnName.equalsIgnoreCase(getDatabaseShapeColumn())){
                AttributeType tempAttributeType = tempConverter.getAttributeType(tempResultSetMetaData, i);
                tempListNames.add(tempColumnName);
                tempListTypes.add(tempAttributeType);
            }
            else{
                tempShapeColumnNum = i;
            }
        }
        String[] tempAttributeNames = new String[tempListNames.size()];
        tempListNames.toArray(tempAttributeNames);
        AttributeType[] tempAttributeTypes = new AttributeType[tempListTypes.size()];
        tempListTypes.toArray(tempAttributeTypes);
        
        if (tempShapeColumnNum == -1) throw new Exception("Shape column not found in resulting Data set");
        
        // Create the new GISDataset
        GISDataset tempGISDataset = new GISDataset(tempAttributeNames);
        while(tempResultSet.next()){
            // retrieve the columns
            Shape tempShape = null;
            Object[] tempAttributes = new Object[tempAttributeNames.length];
            for (int i=0; i<tempColumnNum; i++){
                if (i == tempShapeColumnNum){
                    // parse out the shape
                    String tempWKT = tempResultSet.getString(i+1);
                    tempShape = WKTFactory.parseShape(tempWKT);
                    if (myShapeType == null){
                        myShapeType = tempShape.getShapeType();
                        String[] tempValidShapeTypes = {myShapeType};
                        myShapeTypes = tempValidShapeTypes;
                        System.out.println("My Shape Type = "+myShapeType);
                        
                    }
                }
                else {
                    // add the attribute
                    if (i<tempShapeColumnNum){
                        tempAttributes[i] = tempResultSet.getObject(i+1);
                        if (tempAttributeTypes[i].getType() == AttributeType.STRING){
                            if (tempAttributes[i] instanceof String){
                                String tempString = (String) tempAttributes[i];
                                if (tempString.length() > tempAttributeTypes[i].getLength()){
                                    tempAttributeTypes[i] = new AttributeType(AttributeType.STRING, tempString.length(), -1);
                                }
                            }
                        }
                    }
                    else if (i>tempShapeColumnNum){
                        tempAttributes[i-1] = tempResultSet.getObject(i+1);
                        if (tempAttributeTypes[i-1].getType() == AttributeType.STRING){
                            if (tempAttributes[i-1] instanceof String){
                                String tempString = (String) tempAttributes[i-1];
                                if (tempString.length() > tempAttributeTypes[i-1].getLength()){
                                    tempAttributeTypes[i-1] = new AttributeType(AttributeType.STRING, tempString.length(), -1);
                                }
                            }
                        }
                    }
                }
            }
            PostGISRecord tempRecord = new PostGISRecord();
            tempRecord.setAttributeNames(tempAttributeNames);
            tempRecord.setAttributeTypes(tempAttributeTypes);
            tempRecord.setAttributes(tempAttributes);
            tempRecord.setShape(tempShape);
            tempGISDataset.add(tempRecord);
        }
        return tempGISDataset;
    }
    
    /** Static final for the name of the query */
    private static final String DATABASE_TABLENAME = "DatabaseTableName";
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("UpdateablePostGISDataSource");
        tempRoot.addAttribute(DATABASE_TABLENAME, getDatabaseTablename());
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        super.setNode(inNode);
        setDatabaseTablename(inNode.getAttribute(DATABASE_TABLENAME));
    }
    
    /** Determines if this datasource is updateable. By default it is not, so this method always returns false.*/
    public boolean isUpdateable() {return true;}
    
    /** Keep track of the state of a transaction.  Do not start another transaction if there is already one pending. */
    private boolean myInTransaction = false;
        
    /**Inserts the given record into the datasource.*/
    public void doInsert(Record inRecord) throws Exception {
        
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        SQLConverter tempConverter = getSQLConverter();
        
        //Is there a transaction active.
        if (!myInTransaction){
            // start a new Transaction
            String tempQuery = "BEGIN TRANSACTION";
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.execute(tempQuery);
            tempStatement.close();
            myInTransaction = true;
        }
        
        // construct the SQL for the statement.
        StringBuffer sb = new StringBuffer();
        sb.append("Insert into ");
        sb.append(myDatabaseTablename);
        sb.append(" (\n");
        for (int i=0; i<myColumnNames.length; i++){
            if (i>0) sb.append(",\n");
            sb.append("\t");
            sb.append(myColumnNames[i]);
        }
        if (myColumnNames.length > 0) sb.append(",\n");
        sb.append(getDatabaseShapeColumn());
        sb.append(") VALUES (\n");
        
        // insert as many attributes as will match
        String[] tempAttributeNames = inRecord.getAttributeNames();
        Object[] tempAttributes = inRecord.getAttributes();
        AttributeType[] tempAttributeTypes = inRecord.getAttributeTypes();
        for (int i=0; i<myColumnNames.length; i++){
            if (i > 0) sb.append(",\n");
            String tempValue = "";
            if (tempAttributeNames != null){
                for (int j=0; j<tempAttributeNames.length; j++){
                    if (myColumnNames[i].equalsIgnoreCase(tempAttributeNames[j])){
                        tempValue = tempConverter.toSQL(tempAttributes[j], tempAttributeTypes[j], myJDBCColumnTypes[i].intValue());
                    }
                }
            }
            sb.append("\t");
            sb.append(tempValue);
        }
        // insert the shape column
        if (myColumnNames.length > 0) sb.append(",\n");
        Shape tempShape = inRecord.getShape();
        if (tempShape != null){
            sb.append("\tGeometryFromText('");
            sb.append(tempShape.getWKT());
            sb.append("', "+getDatabaseSpatialReferenceID()+")");
        }
        sb.append("\n)");
        
        // Send the SQL to the database
        String tempSQL = sb.toString();
        System.out.println(tempSQL);
        Statement tempStatement = tempConnection.createStatement();
        tempStatement.execute(tempSQL);
        tempStatement.close();
        fireInsert(inRecord);
        setCache(null, null);
    }
    
    /** Update the data source with the changed record. By default this is a read only data source, so this method does nothing. */
    public void doUpdate(Record inRecord) throws Exception {
        if (inRecord instanceof PostGISRecord){
            PostGISRecord tempRecord = (PostGISRecord) inRecord;
            SQLConverter tempConverter = getSQLConverter();
            
            // Retrieve the connection to the database
            Connection tempConnection = connect();
            
            //Is there a transaction active.
            if (!myInTransaction){
                // start a new Transaction
                String tempQuery = "BEGIN TRANSACTION";
                Statement tempStatement = tempConnection.createStatement();
                tempStatement.execute(tempQuery);
                tempStatement.close();
                myInTransaction = true;
            }
            
            // create the sql statement
            StringBuffer sb = new StringBuffer();
            sb.append("UPDATE "+myDatabaseTablename+" SET \n");
            String[] tempColumnNames = inRecord.getAttributeNames();
            Object[] tempAttributes = inRecord.getAttributes();
            for (int i=0; i<tempColumnNames.length; i++){
                if (i>0) sb.append(",\n");
                sb.append("\t"+tempColumnNames[i]+"="+tempConverter.toSQL(tempAttributes[i], myColumnTypes[i], myJDBCColumnTypes[i].intValue()));
            }
            
            // the geometry column
            if (tempColumnNames.length > 0) sb.append(",\n");
            Shape tempShape = inRecord.getShape();
            if (tempShape != null){
                sb.append("\t"+getDatabaseShapeColumn()+" = GeometryFromText('");
                sb.append(tempShape.getWKT());
                sb.append("', "+getDatabaseSpatialReferenceID()+")\n");
            }
            else{
                sb.append("\tnull\n");
            }
            
            // the where clause
            sb.append("WHERE\n");
            Object[] tempOldAttributes = tempRecord.getOldAttributes();
            for (int i=0; i<tempColumnNames.length; i++){
                if (i>0) sb.append(" AND\n");
                sb.append("\t"+tempColumnNames[i]+"="+tempConverter.toSQL(tempAttributes[i], myColumnTypes[i], myJDBCColumnTypes[i].intValue()));
            }
            
            // send the statement to the database
            String tempSQL = sb.toString();
            System.out.println(tempSQL);
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.execute(tempSQL);
            tempStatement.close();
            fireUpdate(inRecord);
        }
        else {
            throw new Exception("Record can not be updated, it did not come from this data source");
        }
        setCache(null, null);
    }
    
    /**Delete this record from the database. By default this is a read only data source, so this method does nothing.*/
    public void doDelete(Record inRecord) throws Exception {
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        SQLConverter tempConverter = getSQLConverter();
        
        //Is there a transaction active.
        if (!myInTransaction){
            // start a new Transaction
            String tempQuery = "BEGIN TRANSACTION";
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.execute(tempQuery);
            tempStatement.close();
            myInTransaction = true;
        }
        
        // create the statement
        StringBuffer sb = new StringBuffer();
        sb.append("DELETE FROM ");
        sb.append(myDatabaseTablename);
        // the where clause
        sb.append(" WHERE\n");
        String[] tempColumnNames = inRecord.getAttributeNames();
        Object[] tempAttributes = inRecord.getAttributes();
        for (int i=0; i<tempColumnNames.length; i++){
            if (i>0) sb.append(" AND\n");
            sb.append("\t"+tempColumnNames[i]+"="+tempConverter.toSQL(tempAttributes[i], myColumnTypes[i], myJDBCColumnTypes[i].intValue()));
        }
        // send the statement to the database
        String tempSQL = sb.toString();
        System.out.println(tempSQL);
        Statement tempStatement = tempConnection.createStatement();
        tempStatement.execute(tempSQL);
        tempStatement.close();
        fireDelete(inRecord);
        setCache(null, null);
    }
    
    /**Commit all changes since the last commit. This is a read only data source by default, so this method does nothing. */
    public void commit() throws Exception {
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        
        //Is there a transaction active.
        if (myInTransaction){
            // commit the transaction
            String tempQuery = "COMMIT";
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.execute(tempQuery);
            tempStatement.close();
            myInTransaction = false;
        }
        fireCommit();
        setCache(null, null);
    }
    
    /**Rollback any changes to this datasource since the last commit.*/
    public void rollback() throws Exception {
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        
        //Is there a transaction active.
        if (myInTransaction){
            // commit the transaction
            String tempQuery = "ROLLBACK";
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.execute(tempQuery);
            tempStatement.close();
            myInTransaction = false;
        }
        fireRollBack();
        setCache(null, null);
    }   
    /** Get the style to use with this datasource.  */
    public gistoolkit.display.Style getStyle() {
        return null;
    }  
}