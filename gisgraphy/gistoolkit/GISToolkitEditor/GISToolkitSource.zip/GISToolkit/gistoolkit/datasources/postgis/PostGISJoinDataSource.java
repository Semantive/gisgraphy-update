/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.postgis;

import java.sql.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;

/**
 *
 * Class to join a PostGIS Datatable to another data source.
 *
 * Set the column from the source data that is to be used with the setDatasourceJoinColumn method, and
 * set the column for this data source with the setTableJoinColumn method.
 *
 * The data source first reads the data from the source datasource, then it compares the data from the
 * join data source to that of the source data source, and throws away any that do not have a match.  It 
 * also trims the source data source to the envelope.  This results in a standard inner join between the
 * source data, and the join data.
 *
 */
public class PostGISJoinDataSource extends SimpleJoinDBDataSource{
    
    // Things that need to be known in order to connect to the database.
    /** The string to prepend to the url in orde to construct it.  This is usually a constant like "jdbc:postgresql://".*/
    private String myDatabaseURLBase = "jdbc:postgresql://";
    /** Get the string to prepend to the url used to locate the database.  This is usally a constant like  "jdbc:postgresql://".*/
    public String getDatabaseURLBase(){return myDatabaseURLBase;}
    /** Set the string to prepend to the url used to locate the database.  This is usally a constant like  "jdbc:postgresql://".*/
    public void setDatabaseURLBase(String inURLBase){myDatabaseURLBase = inURLBase;}
    
    /** The hostname/servername of the target computer.  This usually changes with each installation or application. The default is "localhost" for the local computer*/
    private String myDatabaseServername = "localhost";
    /** Get thehostname/servername of the target computer.  This usually changes with each installation or application. The default is "localhost" for the local computer*/
    public String getDatabaseServername(){return myDatabaseServername;}
    /** Set thehostname/servername of the target computer.  This usually changes with each installation or application. The default is "localhost" for the local computer*/
    public void setDatabaseServername(String inDatabaseServername){myDatabaseServername = inDatabaseServername;}
    
    /** The driver to use when accessing the database.  If the POSGRES team ever changes this, it will need to be updated.*/
    private String myDatabaseDriver = "org.postgresql.Driver";
    /** Get The driver to use when accessing the database.  If the POSGRES team ever changes this, it will need to be updated.*/
    public String getDatabaseDriver(){return myDatabaseDriver;}
    /** Set The driver to use when accessing the database.  If the POSGRES team ever changes this, it will need to be updated.*/
    public void setDatabaseDriver(String inDatabaseDriver){myDatabaseDriver = inDatabaseDriver;}

    /** The TCP-IP port number on which the postmaster is listening.  The default is 5432, but it could be changed to a different port, depending on configuration. */
    private int myDatabasePort = 5432;
    /** Get the TCP-IP port number on which the postmaster is listening.  The default is 5432, but it could be changed to a different port, depending on configuration. */
    public int getDatabasePort(){return myDatabasePort;}
    /** Set the TCP-IP port number on which the postmaster is listening.  The default is 5432, but it could be changed to a different port, depending on configuration. */
    public void setDatabasePort(int inPortNumber){myDatabasePort = inPortNumber;}
    
    /** The database name the postmaster should access for servicing this request.  The default is "database", which is most likely inappropriate.*/
    private String myDatabaseName = "database";
    /** Get the database name the postmaster should access for servicing this request.  The default is "database", which is most likely inappropriate.*/
    public String getDatabaseName(){return myDatabaseName;}
    /** Set the database name the postmaster should access for servicing this request.  The default is "database", which is most likely inappropriate.*/
    public void setDatabaseName(String inDatabaseName){myDatabaseName = inDatabaseName;}
        
    /** The username with permission to connect to the database. */
    private String myDatabaseUsername = "postgres";
    /** Get the username with permission to connect to the database. These are defined in the database.*/
    public String getDatabaseUsername(){return myDatabaseUsername;}
    /** Set the username with permission to connect to the database.  These are defined in the database.*/
    public void setDatabaseUsername(String inDatabaseUsername){myDatabaseUsername = inDatabaseUsername;}
    
    /** The password of the user with permission to access the database.  The password is used to validate that the user is actually who they say they are. */
    private String myDatabasePassword = "";
    /** Get the password that validates the username. */
    public String getDatabasePassword(){return myDatabasePassword;}
    /** Set the password that validates the username. */
    public void setDatabasePassword(String inDatabasePassword){myDatabasePassword = inDatabasePassword;}

    /**Spatial Reference ID needed for accessing shape information.*/
    private int myDatabaseSpatialReferenceID = 1;
    /** Returns the spatial reference id to use for converting shapes to and from database format.*/
    public int getDatabaseSpatialReferenceID() {return myDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(int inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = inDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(String inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = Integer.parseInt(inDatabaseSpatialReferenceID);}
    
    /** SQL Query to use to retrieve data from the database. */
    private String myDatabaseQuery = null;
    /** SQL Query to use to retrieve data from the database. */
    public void setDatabaseQuery(String inQuery){myDatabaseQuery = inQuery;}
    /** SQL Query to use in retrieving data from the database. */
    public String getDatabaseQuery(){return myDatabaseQuery;}    

    /** Indicates whether a transaction is in progress or not */
    private boolean myInTransaction = false;
    
    /**
     * For use with configuration only where the source data source is to be set with the setNode() function.
     */
    public PostGISJoinDataSource(){};
    
    /**
     * Create a new DB2JoinDataSource with this data source as the source node.
     */
    public PostGISJoinDataSource(DataSource inSourceDataSource){
        super(inSourceDataSource);
    }
    
    /** Connection to the database.*/
    private Connection myCon = null;
    
    /** Connect this datasource to the database */
    public Connection connect() throws Exception{
        if (myCon != null) return myCon;
        
        //Load the JDBC driver and establish a connection.
        try{
            Class.forName(getDatabaseDriver());
        }
        catch (Exception e){
            System.out.println("Error Loading Driver org.postgresql.Driver \n" +e);
            throw new Exception("Error Loading Driver org.postgresql.Driver "+e);
        }
        String tempURL = myDatabaseURLBase+myDatabaseServername+":"+myDatabasePort+"/"+myDatabaseName;
        //String url = "jdbc:postgresql://localhost:5432/database";
        myCon = DriverManager.getConnection(tempURL, myDatabaseUsername, myDatabasePassword);
        
        //Create a statement and execute a select query.
        Statement s = myCon.createStatement();
        ResultSet r = s.executeQuery("select * from pg_tables");

        // close the statement and return
        s.close();
        return myCon;
    }
    
    /** Close the connection to the database. */
    protected void closeConnection() throws Exception{
        if (myCon != null){
            myCon.close();
            myCon = null;
        }
    }
    
    /** Close any open connections */
    public void finalize(){
        try{
            closeConnection();
        }
        catch(Exception e){
            // do nothing here, nothing much that I know of that I can do
        }
    }

    /**
     * Reads the objects from the database that fall within the given Envelope.
     * If a null is sent in for the Envelope, all the objects in the shape file are read.
     */
    public synchronized GISDataset readShapes(Envelope inEnvelope) throws Exception {
        
        // retrieve the dataset from the source
        readDataSource(inEnvelope);
        
        // retrieve the connection
        connect();
        
        // create the statement
        Statement tempStatement = myCon.createStatement();
        
        // add the where clause to include the filters.
        StringBuffer sb = new StringBuffer(myDatabaseQuery);
        String tempUpper = myDatabaseQuery.toUpperCase();
        if (inEnvelope != null){
            // create the where clause
            String tempFilterSQL = getFilterSQL();
            System.out.println("FilterSQL = "+tempFilterSQL);
            String tempWhere = "";
            if ((tempFilterSQL != null) && (tempFilterSQL.length() > 0)){
                tempWhere =  tempFilterSQL;
                // check for joinwhere
                int tempIndex = tempUpper.indexOf("JOINWHERE");
                if (tempIndex == -1){
                    // check for where.
                    tempIndex = tempUpper.indexOf("WHERE");
                    if ( tempIndex == -1){
                        // check for group by
                        tempIndex = tempUpper.indexOf("GROUP BY");
                        if (tempIndex == -1){
                            // check for order by
                            tempIndex = tempUpper.indexOf("ORDER BY");
                            if (tempIndex == -1){
                                // just append the where clause.
                                sb.append(" WHERE "+tempWhere);
                            }
                            else{
                                // insert before the ORDER BY
                                sb.insert(tempIndex, " WHERE "+tempWhere);
                            }
                        }
                        else{
                            // insert before the Group By clause
                            sb.insert(tempIndex, " WHERE "+tempWhere);
                        }
                    }
                    else{
                        // insert after the where clause
                        sb.insert(tempIndex+5, " "+tempWhere+" AND ");
                    }
                }
                else{
                    // replace SHAPEWHERE with the shape where clause
                    sb.replace(tempIndex, tempIndex+10, tempWhere);
                }
            }
        }
        String tempQuery = sb.toString();
        System.out.println(tempQuery);
        
        // send the SQLString to the database
        ResultSet tempResultSet = tempStatement.executeQuery(tempQuery);
        
        // read the attribute headers
        ResultSetMetaData tempMetaData = tempResultSet.getMetaData();
        int tempShapeCol = Integer.MAX_VALUE;
        
        // add the joined data to the array.
        int tempCount = tempMetaData.getColumnCount();
        
        String[] tempDatasourceAttributeNames = getJoinDataSourceAttributeNames();
        AttributeType[] tempDatasourceAttributeTypes = getJoinDataSourceAttributeTypes();
        int tempDatasourceCount =tempDatasourceAttributeNames.length;
        
        String[] tempNames = new String[tempCount + tempDatasourceCount];
        AttributeType[] tempTypes = new AttributeType[tempCount+tempDatasourceCount];
        for (int i=0; i<tempDatasourceCount; i++){
            tempNames[i] = tempDatasourceAttributeNames[i];
            tempTypes[i] = tempDatasourceAttributeTypes[i];
        }
        
        // add the db2 data to the array and find the shape column
        SQLConverter tempSQLConverter = getSQLConverter();
        int tempJoinIndex = -1;
        for (int i = 0; i < tempCount; i++) {
            String tempName = tempMetaData.getColumnName(i + 1);
            if (tempName.equalsIgnoreCase(getTableJoinColumn())){
                tempJoinIndex = i;
            }
            tempNames[tempDatasourceCount+i] = tempName;
            AttributeType tempType = tempSQLConverter.getAttributeType(tempMetaData, i);
            tempTypes[tempDatasourceCount+i] = tempType;
        }
        if (tempJoinIndex == -1){
            tempResultSet.close();
            tempStatement.close();
            throw new Exception("Did not find Table Join Column "+getTableJoinColumn());
        }
        
        
        // create the dataset
        GISDataset tempDataset = new GISDataset(tempNames, tempTypes);
        
        try{
            // add the records to the dataset.
            boolean tempContinue = true;
            Object[] tempObjects = new Object[tempNames.length];
            while (tempContinue) {
                try{
                    tempContinue = tempResultSet.next();
                }
                catch (Exception e){
                    System.out.println("The ResultSet.next() threw "+e);
                    tempContinue = false;
                }
                
                if (tempContinue){
                    // create the attributes
                    for (int i = 0; i < tempCount; i++) {
                        Object tempObject = tempResultSet.getObject(i+1);
                        if (i == tempJoinIndex) {
                            // locate this row.
                            Record tempRecord = getDatasourceRecord(tempObject);
                            // If the record is not found, then do not continue.
                            if (tempRecord == null) continue;
                            Object[] tempAttributes = tempRecord.getAttributes();
                            for (int j=0; j<tempAttributes.length; j++){
                                tempObjects[j] = tempAttributes[j];
                            }
                            tempDataset.add(tempObjects, tempRecord.getShape());
                        }
                        tempObjects[tempDatasourceCount+i] = tempObject;
                    }
                    tempObjects = new Object[tempNames.length];
//                    fireRead(tempDataset.getRecord(tempDataset.getNumShapes()-1));
                }
            }// end while
        }
        catch (Exception e){
            System.out.println("Outer Loop "+e);
            e.printStackTrace();
        }
        catch (Throwable t){
            System.out.println("Outer Loop "+t);
            t.printStackTrace();
        }
        
        // close the connection to the database.
        tempStatement.close();
        myCon.close();
        myCon = null;
        
        // return the completed dataset.
        System.out.println("Read "+tempDataset.size()+" Records");
        return tempDataset;
    }
    
    
    // Static finals for the node tags.
    private static final String DATASOURCE_NAME = "DataSourceName";
    private static final String SERVER_NAME = "Servername";
    private static final String PORT_NUMBER = "PortNumber";
    private static final String USERNAME = "Username";
    private static final String PASSWORD = "Password";
    private static final String DATABASE_NAME = "DatabaseName";
    private static final String URLBASE = "URLBase";
    private static final String QUERY = "QUERY";
    
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("PostGISDataSource");
        
        // connection parameters
        tempRoot.addAttribute(SERVER_NAME, getDatabaseServername());
        tempRoot.addAttribute(PORT_NUMBER, ""+getDatabasePort());
        tempRoot.addAttribute(USERNAME, getDatabaseUsername());
        tempRoot.addAttribute(PASSWORD, getDatabasePassword());
        tempRoot.addAttribute(DATABASE_NAME, getDatabaseName());
        tempRoot.addAttribute(URLBASE, getDatabaseURLBase());
        tempRoot.addAttribute(QUERY, getDatabaseQuery());
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        super.setNode(inNode);
        setDatabaseServername(inNode.getAttribute(SERVER_NAME));
        setDatabaseName(inNode.getAttribute(DATABASE_NAME));
        setDatabasePort(Integer.parseInt(inNode.getAttribute(PORT_NUMBER)));
        setDatabaseUsername(inNode.getAttribute(USERNAME));
        setDatabasePassword(inNode.getAttribute(PASSWORD));
        setDatabaseName(inNode.getAttribute(DATABASE_NAME));
        setDatabaseURLBase(inNode.getAttribute(URLBASE));
        setDatabaseQuery(inNode.getAttribute(QUERY));
    }
    
    /** Returns the converter for this Database. */
    public SQLConverter getSQLConverter(){return new PostGISSQLConverter();}     
    
    /** Get the style to use with this datasource.  */
    public gistoolkit.display.Style getStyle() {
        return null;
    }      
}
