/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.datasources.db2spatialextender;

import java.util.*;
import java.sql.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;

/**
 *
 * Super class for the Spatial Extender DataSources.  Handles connecting to the database
 * retrieving the valid range of x and y values, and serialization of the connection parameters common to
 * SpatialExtenderDataSources.
 *
 */
public abstract class SpatialExtenderDataSource extends SimpleDBDataSource{
    
    /**Name of this datasource.*/
    private String myName = "None";
    /** Return the name of this datasource for display to the user. */
    public String getName(){return myName;}
    /** Set the name of this datasource for display purposes. */
    public void setName(String inName){myName = inName;}
    
    /**When connecting with the driver, a specific urlbase is required.*/
    private String myDatabaseURLBase = "jdbc:db2";
    /** Returns the url base to use when connecting through the JDBC driver. */
    public String getDatabaseURLBase() {return myDatabaseURLBase;}
    /** Sets the url base to use when connecting through the JDBC driver.*/
    public void setDatabaseURLBase(String inDatabaseURLBase){myDatabaseURLBase = inDatabaseURLBase;}
    
    /**
     * This driver must be present in the class path of this application as
     * it is required for connecting to DB2.
     */
    private String myDatabaseDriver = "COM.ibm.db2.jdbc.net.DB2Driver";
    /** Returns the jdbc driver class used for connection to the database. */
    public String getDatabaseDriver() {return myDatabaseDriver;}
    /** Sets the name of the jdbc driver class used for connection to the database. */
    public void setDatabaseDriver(String inDatabaseDriver){myDatabaseDriver = inDatabaseDriver;}
    
    /**The server name of the server to connect to.*/
    private String myDatabaseServername="Servername";
    /** Returns the computer name of the DB2 server. */
    public String getDatabaseServername() {return myDatabaseServername;}
    /** Sets the name of the DB2 Server computer. */
    public void setDatabaseServername(String inDatabaseServername){myDatabaseServername = inDatabaseServername;}
    
    /**The name of the database on the DB2 server to connect to.*/
    public String myDatabaseName = "Databasename";
    /** Returns the name of the DB2 Database. */
    public String getDatabaseName() {return myDatabaseName;}
    /** Sets the name of the DB2 Database. */
    public void setDatabaseName(String inDatabaseName){myDatabaseName = inDatabaseName;}
    
    /**DB2 supports Schemas, and this is the schema under which the data will reside.*/
    private String myDatabaseSchema = "Schemaname";
    /** Returns the name of the schema within the DB2 database where the data resides. */
    public String getDatabaseSchema() {return myDatabaseSchema;}
    /** Sets the name of the schema within the DB2 database where the data resides. */
    public void setDatabaseSchema(String inDatabaseSchema){myDatabaseSchema = inDatabaseSchema;}
    
    /**The username used to connect to the database.*/
    private String myDatabaseUsername = "Username";
    /** Returns the username to use when connecting to the DB2 server. */
    public String getDatabaseUsername() {return myDatabaseUsername;}
    /** Sets the username to use when connecting to the DB2 server. */
    public void setDatabaseUsername(String inDatabaseUsername){myDatabaseUsername = inDatabaseUsername;}
    
    /**Password for connecting to the database.*/
    private String myDatabasePassword = "Password";
    /** Returns the password to use when connecting to the DB2 server. */
    public String getDatabasePassword() {return myDatabasePassword;}
    /** Sets the password to use when connecting to the DB2 server. */
    public void setDatabasePassword(String inDatabasePassword){myDatabasePassword = inDatabasePassword;}
    
    /**Port needed for connecting to the database.*/
    private int myDatabasePort = 1150;
    /** Returns the tcpip port to use when connecting to the DB2 server */
    public int getDatabasePort() {return myDatabasePort;}
    /** Sets the tcpip port to use when connecting to the DB2 server*/
    public void setDatabasePort(int inDatabasePort){myDatabasePort = inDatabasePort;}
    
    /**Column Name of the shape column, since the records can only handle a single shape column, this one is used.*/
    private String myDatabaseShapeColumn = "Shape";
    /** Returns the name of the shape column. */
    public String getDatabaseShapeColumn() {return myDatabaseShapeColumn;}
    /** Sets the name of the shape column. The contents of this column will be parsed as a shape. */
    public void setDatabaseShapeColumn(String inDatabaseShapeColumn){myDatabaseShapeColumn = inDatabaseShapeColumn;}
    
    /**Spatial Reference ID needed for accessing shape information.*/
    private int myDatabaseSpatialReferenceID = 1;
    /** Returns the spatial reference id to use for converting shapes to and from database format.*/
    public int getDatabaseSpatialReferenceID() {return myDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(int inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = inDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(String inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = Integer.parseInt(inDatabaseSpatialReferenceID);}
        
    /** Creates new SpatialExtenderDataSource */
    public SpatialExtenderDataSource() {
    }
    
    /**
     * DB2 stores all of these features as posative integers between 0 and the MAX_DB2_INT.
     * DB2 throws a nasty exception if the value is out of range, so this number is used
     * to move the bounds such that they can be represented within this range.
     * The maximum is an signed posative 32 bit integer = 2,147,483,647
     */
    public static long MAX_DB2_INT = Long.parseLong("2147483647");
    
    /** Only find the X and Y maximums once. */
    private boolean myFoundMaxMins = false;
    /** The maximum X value that DB2 can represent */
    private double myXMax = 1000000;
    /** The minimum X value that DB2 can represent */
    private double myXMin = 0;
    /** The maximum Y value that DB2 can represent */
    private double myYMax = 1000000;
    /** the minimum Y value that DB2 can represent */
    private double myYMin = 0;    
    
    /** Function to ensure that the X and Y of the point are within the allowable limits */
    protected Point checkMaxPoint(Point inPoint){
        if (inPoint.getX() > myXMax) inPoint.setX(myXMax);
        if (inPoint.getY() > myYMax) inPoint.setY(myYMax);
        if (inPoint.getX() < myXMin) inPoint.setX(myXMin);
        if (inPoint.getY() < myYMin) inPoint.setY(myYMin);
        return inPoint;
    }
    
    /**The Envelope of the dataset.*/
    protected Envelope myEnvelope = null;
        
    /**Connection to the DB2 datasource used for maintaining persistent connections.*/
    protected Connection myCon = null;
    
    /**Statment used to maintain distributed transactions.*/
    protected Statement myStmt = null;
    
    
    /**
     * Initializes the connection to the database.
     */
    public void connect() throws Exception{
        if (myCon != null) return;
        if (myDatabaseDriver == null)
            throw new Exception("No Database Driver Class defined");
        if (myDatabasePassword == null)
            throw new Exception("No Database Password defined");
        if (myDatabaseSchema == null)
            throw new Exception("No Database Schema defined");
        if (myDatabaseName == null)
            throw new Exception("No Database Name defined");
        if (myDatabaseServername == null)
            throw new Exception("No Database Servername defined");
        if (myDatabaseURLBase == null)
            throw new Exception("No Database URL Base defined");
        if (myDatabaseUsername == null)
            throw new Exception("No Database Username defined");
        
        // load the driver
        try {
            Class.forName(getDatabaseDriver()).newInstance();
        }
        catch (Exception e) {
            System.out.println("Error Loading DBDriver Class " + e);
            throw new Exception("Error Loading Database Driver " + e);
        }
        
        // URL is jdbc:db2:dbname
        String url = "jdbc:db2://"+getDatabaseServername()+":"+myDatabasePort+"/"+getDatabaseName();
        try {
            myCon = DriverManager.getConnection(url, getDatabaseUsername(), getDatabasePassword());
            myStmt = myCon.createStatement();
            
            if (!myFoundMaxMins){
                // try using the 7.2 view.
                try{
                    // if the max and min have not already been found, determine them
                    String tempQuery = "SELECT falsex, falsey, xyunits FROM db2gse.spatial_ref_sys WHERE srid = "+myDatabaseSpatialReferenceID;
                    ResultSet rset = myStmt.executeQuery(tempQuery);
                    rset.next();
                    double tempXOffset = rset.getDouble(1);
                    double tempYOffset = rset.getDouble(2);
                    double tempScale = rset.getDouble(3);
                    myXMax = (tempXOffset + MAX_DB2_INT/tempScale)-1;
                    myXMin = (tempXOffset);
                    myYMax = (tempYOffset + MAX_DB2_INT/tempScale)-1;
                    myYMin = (tempYOffset);
                    myFoundMaxMins = true;
                    rset.close();
                    myStmt.close();
                    myStmt = null;
                }
                catch (Exception e){
                
                    // try using the 8.0 view.
                    String tempQuery = "SELECT x_offset, y_offset, x_scale, y_scale FROM db2gse.ST_spatial_reference_systems WHERE srs_id "+myDatabaseSpatialReferenceID;
//                    String tempQuery = "SELECT falsex, falsey, xyunits FROM db2gse.gse_spatial_ref WHERE srid = "+myDatabaseSpatialReferenceID;
                    ResultSet rset = myStmt.executeQuery(tempQuery);
                    rset.next();
                    double tempXOffset = rset.getDouble(1);
                    double tempYOffset = rset.getDouble(2);
                    double tempXScale = rset.getDouble(3);
                    double tempYScale = rset.getDouble(4);
                    myXMax = (tempXOffset + MAX_DB2_INT/tempXScale)-1;
                    myXMin = (tempXOffset);
                    myYMax = (tempYOffset + MAX_DB2_INT/tempYScale)-1;
                    myYMin = (tempYOffset);
                    myFoundMaxMins = true;
                    rset.close();
                    myStmt.close();
                    myStmt = null;
                }
            }            
        }
        catch (Exception e) {
            throw new Exception("Error Connecting " + e);
        }
    }
    
    /**Returns the bounding rectangle of all the shapes in the Data Source.*/
    public Envelope readEnvelope() throws Exception {
        readDataset();
        return getCacheEnvelope();
    }    
    
    /**
     * set the properties of this datasource.
     */
    public void load(Properties inProperties) {
        if (inProperties == null) return;
        String tempName = this.getClass().getName();
        
        String tempString = inProperties.getProperty(tempName+".Driver");
        if (tempString != null) {myDatabaseDriver = tempString;}
        
        tempString = inProperties.getProperty(tempName+".Servername");
        if (tempString != null) {myDatabaseServername = tempString;}
        
        tempString = inProperties.getProperty(tempName+".URLBase");
        if (tempString != null) {myDatabaseURLBase = tempString;}
        
        tempString = inProperties.getProperty(tempName+".DatabaseName");
        if (tempString != null) {myDatabaseName = tempString;}
        
        tempString = inProperties.getProperty(tempName+".Schema");
        if (tempString != null) {myDatabaseSchema = tempString;}
        
        tempString = inProperties.getProperty(tempName+".Port");
        if (tempString != null) {myDatabasePort = Integer.parseInt(tempString);}
        
        tempString = inProperties.getProperty(tempName+".Username");
        if (tempString != null) {myDatabaseUsername = tempString;}
        
        tempString = inProperties.getProperty(tempName+".Password");
        if (tempString != null) {myDatabasePassword = tempString;}
        
        tempString = inProperties.getProperty(tempName+".ShapeColumn");
        if (tempString != null) {myDatabaseShapeColumn = tempString;}
        
        tempString = inProperties.getProperty(tempName+".SpatialReferenceID");
        if (tempString != null) {myDatabaseSpatialReferenceID = Integer.parseInt(tempString);}
        
    }
    
    
    /** Get the where clause based on the Envelope */
    protected String getWhereString(Envelope inEnvelope){
        // if the Envelope form a point, then construct the point.
        if (inEnvelope.getMinX() == inEnvelope.getMaxX()){
            Point tempPoint = new Point(inEnvelope.getMinX(), inEnvelope.getMaxY());
            return "db2gse.ST_Intersects("+getDatabaseShapeColumn()+", db2gse.ST_PointFromText('"+tempPoint.getWKT()+"', db2gse.coordref()..srid("+getDatabaseSpatialReferenceID()+"))) = 1";
        }
        else{
            Point tempTopLeft = checkMaxPoint(new Point(inEnvelope.getMinX(), inEnvelope.getMaxY()));
            Point tempTopRight = checkMaxPoint(new Point(inEnvelope.getMaxX(), inEnvelope.getMaxY()));
            Point tempBottomLeft = checkMaxPoint(new Point(inEnvelope.getMinX(), inEnvelope.getMinY()));
            Point tempBottomRight = checkMaxPoint(new Point(inEnvelope.getMaxX(), inEnvelope.getMinY()));
            
            String tempWhereString = "\tdb2gse.ST_Intersects("+getDatabaseShapeColumn()+", "
            +"db2gse.ST_PolyFromText('polygon(("
            +tempTopLeft.getX()+" "+tempTopLeft.getY()+", "
            +tempTopRight.getX()+" "+tempTopRight.getY()+", "
            +tempBottomRight.getX()+" "+tempBottomRight.getY()+", "
            +tempBottomLeft.getX()+" "+tempBottomLeft.getY()+", "
            +tempTopLeft.getX()+" "+tempTopLeft.getY()+""
            +"))', db2gse.coordref()..srid("+getDatabaseSpatialReferenceID()+"))) = 1";
            return tempWhereString;
        }
    }
    
    private static final String SERVER_NAME = "Servername";
    private static final String PORT_NUMBER = "PortNumber";
    private static final String USERNAME = "Username";
    private static final String PASSWORD = "Password";
    private static final String DATABASE_NAME = "DatabaseName";
    private static final String SCHEMA = "Schema";
    private static final String SHAPE_COLUMN = "ShapeColumn";
    private static final String DRIVER = "Driver";
    private static final String URLBASE = "URLBase";
    private static final String SPATIAL_REFERENCE_ID = "SpatialReferenceID";
    
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("DB2SpatialExtenderDataSource");
        
        // connection parameters
        tempRoot.addAttribute(SERVER_NAME, getDatabaseServername());
        tempRoot.addAttribute(PORT_NUMBER, ""+getDatabasePort());
        tempRoot.addAttribute(USERNAME, getDatabaseUsername());
        tempRoot.addAttribute(PASSWORD, getDatabasePassword());
        tempRoot.addAttribute(DATABASE_NAME, getDatabaseName());
        tempRoot.addAttribute(SCHEMA, getDatabaseSchema());
        tempRoot.addAttribute(SHAPE_COLUMN, getDatabaseShapeColumn());
        tempRoot.addAttribute(DRIVER, getDatabaseDriver());
        tempRoot.addAttribute(URLBASE, getDatabaseURLBase());
        tempRoot.addAttribute(SPATIAL_REFERENCE_ID, ""+getDatabaseSpatialReferenceID());
        return tempRoot;
    }            
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        if (inNode == null) throw new Exception("Can not set up DB2 Datasource configuration information is null");
        super.setNode(inNode);
        String tempName = null;
        String tempValue = null;
        try{
            // connection parameters
            tempName = SERVER_NAME;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseServername(tempValue);
            tempName = PORT_NUMBER;
            tempValue = inNode.getAttribute(tempName);
            setDatabasePort(Integer.parseInt(tempValue));
            tempName = USERNAME;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseUsername(tempValue);
            tempName = PASSWORD;
            tempValue = inNode.getAttribute(tempName);
            setDatabasePassword(tempValue);
            tempName = DATABASE_NAME;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseName(tempValue);
            tempName = SCHEMA;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseSchema(tempValue);
            tempName = DRIVER;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseDriver(tempValue);
            tempName = SHAPE_COLUMN;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseShapeColumn(tempValue);
            tempName = URLBASE;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseURLBase(tempValue);
            tempName = SPATIAL_REFERENCE_ID;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseSpatialReferenceID(tempValue);
        }
        catch (Exception e){
            throw new Exception("Can not read value for "+tempName+" to configure "+getName()+ " Arc SDE Datasource");
        }
    }    
    /** Returns the converter for this Database. */
    public SQLConverter getSQLConverter(){return new DB2SQLConverter();}  
}
