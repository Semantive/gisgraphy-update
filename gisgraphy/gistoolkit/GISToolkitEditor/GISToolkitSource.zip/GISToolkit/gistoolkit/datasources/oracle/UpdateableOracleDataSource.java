/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.datasources.oracle;
import java.util.*;
import java.sql.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;

/**
 * Class used to allow selects as well as inserts, updates and deletes from an oracle table.
 *
 * This class uses the Oracle Locator features that are shipped with oracle databases 8i and above.
 */
public class UpdateableOracleDataSource extends OracleDataSource {
    
    /** This Data Source constructs sql queries based on a table name. */
    private String myDatabaseTablename = null;
    /** Set the table name to use when accessing the data source */
    public void setDatabaseTablename(String inDatabaseTablename){myDatabaseTablename = inDatabaseTablename;}
    /** return the tablename to use when accessing the data source */
    public String getDatabaseTablename(){return myDatabaseTablename;}
    
    /** The names of the none shape columns. */
    private String[] myColumnNames = null;
    
    /** The types of the various non shape columns. */
    private AttributeType[] myColumnTypes = null;
    
    /** The JDBC Types of the vearious columns. */
    private Integer[] myJDBCColumnTypes = null;
    
    /** The valid shapes for this data source */
    private String[] myShapeTypes = {Shape.POINT,Shape.MULTIPOINT,Shape.LINESTRING,Shape.MULTILINESTRING,Shape.POLYGON,Shape.MULTIPOLYGON};
    /** Return the valid shapes for this data source */
    public String[] getValidShapeTypes(){return myShapeTypes;}
    
    /**
     * Creates new UpdateableOracleDataSource.
     *
     * <p>
     * This is the zero parameter constructor used for creating the datasource from configuration information.
     * <p>
     */
    public UpdateableOracleDataSource() {
    }
    
    public Connection connect() throws Exception{
        Connection tempConnection = super.connect();
        SQLConverter tempConverter = getSQLConverter();
        
        if (myColumnNames == null){
            tempConnection.setAutoCommit(false);
            String tempTableName = myDatabaseTablename.trim().toUpperCase();
            // retrieve the names of the geometry columns
            String tempQuery = "SELECT column_name, data_type FROM user_tab_columns WHERE table_name = '"+tempTableName+"'";
            Statement tempStatement = tempConnection.createStatement();
            ResultSet tempResultSet = tempStatement.executeQuery(tempQuery);
            boolean tempFound = false;
            while (tempResultSet.next()){
                String tempColumnName = tempResultSet.getString(1);
                if (tempColumnName.equalsIgnoreCase(getDatabaseShapeColumn())){
                    tempFound = true;
                }
            }
            if (!tempFound) throw new Exception("Can not find shape column "+getDatabaseShapeColumn()+" in Table "+getDatabaseTablename());
            
            // retrieve the column names from the table
            tempQuery = "SELECT * FROM "+myDatabaseTablename+" WHERE 0=1";
            
            // Send the sql Query to the database
            tempResultSet = tempStatement.executeQuery(tempQuery);
            
            // construct the attribute names and types
            ResultSetMetaData tempResultSetMetaData = tempResultSet.getMetaData();
            int tempColumnNum = tempResultSetMetaData.getColumnCount();
            ArrayList tempNameList = new ArrayList(tempColumnNum-1);
            ArrayList tempTypeList = new ArrayList(tempColumnNum-1);
            ArrayList tempJDBCList = new ArrayList(tempColumnNum-1);
            for (int i=0; i<tempColumnNum; i++){
                String tempColumnName = tempResultSetMetaData.getColumnName(i+1);
                if (!tempColumnName.equalsIgnoreCase(getDatabaseShapeColumn())){
                    AttributeType tempColumnType = tempConverter.getAttributeType(tempResultSetMetaData, i);
                    String tempTypeName = tempResultSetMetaData.getColumnTypeName(i+1);
                    int tempJDBCType = tempResultSetMetaData.getColumnType(i+1);
                    tempNameList.add(tempColumnName);
                    tempTypeList.add(tempColumnType);
                    tempJDBCList.add(new Integer(tempJDBCType));
                }
            }
            myColumnNames = new String[tempNameList.size()];
            tempNameList.toArray(myColumnNames);
            myColumnTypes = new AttributeType[tempTypeList.size()];
            tempTypeList.toArray(myColumnTypes);
            myJDBCColumnTypes = new Integer[tempJDBCList.size()];
            tempJDBCList.toArray(myJDBCColumnTypes);
        }
        return tempConnection;
    }
        
    /** This method returns the shapes from the data source  */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception{
        // connect to the database
        Connection tempConnection = connect();
        SQLConverter tempConverter = getSQLConverter();
        
        // construct the SQL statement
        StringBuffer sb = new StringBuffer();
        sb.append("SELECT ");
        for (int i=0; i<myColumnNames.length; i++){
            if (i > 0) sb.append(", ");
            sb.append(myColumnNames[i]);
        }
        if (myColumnNames.length > 0) sb.append(", ");
        sb.append(getDatabaseShapeColumn()+" as "+getDatabaseShapeColumn());
        sb.append(" FROM ");
        sb.append(myDatabaseTablename);
        if (inEnvelope != null){
            sb.append(" WHERE " + getWhereString(inEnvelope));
        }
        String tempSQLStatement = sb.toString();
        
        // Send the sql Query to the database
        Statement tempStatement = tempConnection.createStatement();
        ResultSet tempResultSet = null;
        try{
            tempResultSet = tempStatement.executeQuery(tempSQLStatement);
        }
        catch (Exception e){
            System.out.println(tempSQLStatement);
        }
        
        // construct the attribute names and types
        int tempShapeColumnNum = -1;
        ResultSetMetaData tempResultSetMetaData = tempResultSet.getMetaData();
        int tempColumnNum = tempResultSetMetaData.getColumnCount();
        ArrayList tempListNames = new ArrayList(tempColumnNum-1);
        ArrayList tempListTypes = new ArrayList(tempColumnNum-1);
        for (int i=0; i<tempColumnNum; i++){
            String tempColumnName = tempResultSetMetaData.getColumnName(i+1);
            if (!tempColumnName.equalsIgnoreCase(getDatabaseShapeColumn())){
                AttributeType tempAttributeType = tempConverter.getAttributeType(tempResultSetMetaData, i);
                tempListNames.add(tempColumnName);
                tempListTypes.add(tempAttributeType);
            }
            else{
                tempShapeColumnNum = i;
            }
        }
        String[] tempAttributeNames = new String[tempListNames.size()];
        tempListNames.toArray(tempAttributeNames);
        AttributeType[] tempAttributeTypes = new AttributeType[tempListTypes.size()];
        tempListTypes.toArray(tempAttributeTypes);
        
        if (tempShapeColumnNum == -1) throw new Exception("Shape column not found in resulting Data set");
        
        // Create the new GISDataset
        GISDataset tempGISDataset = new GISDataset(tempAttributeNames);
        while(tempResultSet.next()){
            // retrieve the columns
            Shape tempShape = null;
            Object[] tempAttributes = new Object[tempAttributeNames.length];
            for (int i=0; i<tempColumnNum; i++){
                if (i == tempShapeColumnNum){
                    // parse out the shape
                    tempShape = parseSDOStruct(tempResultSet.getObject(i + 1));
                }
                else {
                    // add the attribute
                    if (i<tempShapeColumnNum){
                        tempAttributes[i] = tempResultSet.getObject(i+1);
                        if (tempAttributeTypes[i].getType() == AttributeType.STRING){
                            if (tempAttributes[i] instanceof String){
                                String tempString = (String) tempAttributes[i];
                                if (tempString.length() > tempAttributeTypes[i].getLength()){
                                    tempAttributeTypes[i] = new AttributeType(AttributeType.STRING, tempString.length(), -1);
                                }
                            }
                        }
                    }
                    else if (i>tempShapeColumnNum){
                        tempAttributes[i-1] = tempResultSet.getObject(i+1);
                        if (tempAttributeTypes[i-1].getType() == AttributeType.STRING){
                            if (tempAttributes[i-1] instanceof String){
                                String tempString = (String) tempAttributes[i-1];
                                if (tempString.length() > tempAttributeTypes[i-1].getLength()){
                                    tempAttributeTypes[i-1] = new AttributeType(AttributeType.STRING, tempString.length(), -1);
                                }
                            }
                        }
                    }
                }
            }
            OracleRecord tempRecord = new OracleRecord();
            tempRecord.setAttributeNames(tempAttributeNames);
            tempRecord.setAttributeTypes(tempAttributeTypes);
            tempRecord.setAttributes(tempAttributes);
            tempRecord.setShape(tempShape);
            tempGISDataset.add(tempRecord);
        }
        if (inEnvelope == null) myEnvelope = tempGISDataset.getEnvelope();
        return tempGISDataset;
    }
    
    /** Static final for the name of the query */
    private static final String DATABASE_TABLENAME = "DatabaseTableName";
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("UpdateableOracleDataSource");
        tempRoot.addAttribute(DATABASE_TABLENAME, getDatabaseTablename());
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        super.setNode(inNode);
        setDatabaseTablename(inNode.getAttribute(DATABASE_TABLENAME));
    }
    
    /** Determines if this datasource is updateable. By default it is not, so this method always returns true to override the super class.*/
    public boolean isUpdateable() {return true;}
    
    /** statement for entering a bunch of insert statements. */
    private PreparedStatement myInsertPreparedStatement = null;

    /**Inserts the given record into the datasource.*/
    public void doInsert(Record inRecord) throws Exception {
        
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        SQLConverter tempConverter = getSQLConverter();
    
        if (myInsertPreparedStatement == null){
            // construct the SQL for the statement.
            StringBuffer sb = new StringBuffer();
            sb.append("INSERT INTO ");
            sb.append(myDatabaseTablename);
            sb.append(" (\n");
            for (int i=0; i<myColumnNames.length; i++){
                if (i>0) sb.append(",\n");
                sb.append("\t");
                sb.append(myColumnNames[i]);
            }
            if (myColumnNames.length > 0) sb.append(",\n");
            sb.append("\t");
            sb.append(getDatabaseShapeColumn());
            sb.append("\n) VALUES (\n");

            // insert all attributes
            for (int i=0; i<myColumnNames.length; i++){
                if (i > 0) sb.append(",\n");
                sb.append("\t");
                sb.append("?");
            }

            // insert the shape column
            if (myColumnNames.length > 0) sb.append(",\n");
            sb.append("\t");
            sb.append(" ? ");
            sb.append("\n)");
            String tempSQL = sb.toString();
            myInsertPreparedStatement =  tempConnection.prepareStatement(tempSQL);
        }
        else{
            myInsertPreparedStatement.clearParameters();
        }
        
        // insert as many attributes as will match
        String[] tempAttributeNames = inRecord.getAttributeNames();
        Object[] tempAttributes = inRecord.getAttributes();
        AttributeType[] tempAttributeTypes = inRecord.getAttributeTypes();
        for (int i=0; i<myColumnNames.length; i++){
            Object tempValue = "";
            if (tempAttributeNames != null){
                for (int j=0; j<tempAttributeNames.length; j++){
                    if (myColumnNames[i].equalsIgnoreCase(tempAttributeNames[j])){
                        tempValue = tempAttributes[j];
                    }
                }
            }
            myInsertPreparedStatement.setObject(i+1, tempValue);
        }
        
        // insert the shape.
        Shape tempShape = inRecord.getShape();
        myInsertPreparedStatement.setObject(myColumnNames.length+1, parseGISToolkitShape(tempShape));
        
        // Send the SQL to the database
        try{
            myInsertPreparedStatement.executeUpdate();
        }catch (Exception e){
            throw(e);
        }
        fireInsert(inRecord);
        clearCache();
    }
    
    /** Update the data source with the changed record. By default this is a read only data source, so this method does nothing. */
    public void doUpdate(Record inRecord) throws Exception {
        if (inRecord instanceof OracleRecord){
            OracleRecord tempRecord = (OracleRecord) inRecord;
            SQLConverter tempConverter = getSQLConverter();
            
            // Retrieve the connection to the database
            Connection tempConnection = connect();
            
            // create the sql statement
            StringBuffer sb = new StringBuffer();
            sb.append("UPDATE "+myDatabaseTablename+" SET \n");
            String[] tempColumnNames = inRecord.getAttributeNames();
            Object[] tempAttributes = inRecord.getAttributes();
            for (int i=0; i<tempColumnNames.length; i++){
                if (i>0) sb.append(",\n");
                sb.append("\t"+tempColumnNames[i]+"="+tempConverter.toSQL(tempAttributes[i], myColumnTypes[i], myJDBCColumnTypes[i].intValue()));
            }
            
            // the geometry column
            if (tempColumnNames.length > 0) sb.append(",\n");
            Shape tempShape = inRecord.getShape();
            if (tempShape != null){
                sb.append("\t");
                sb.append(getDatabaseShapeColumn());
                sb.append("=");
                sb.append("? ");
            }
            else{
                sb.append("\tnull\n");
            }
            
            // the where clause
            sb.append("WHERE\n");
            Object[] tempOldAttributes = tempRecord.getOldAttributes();
            for (int i=0; i<tempColumnNames.length; i++){
                if (i>0) sb.append(" AND\n");
                sb.append("\t"+tempColumnNames[i]+"="+tempConverter.toSQL(tempAttributes[i], myColumnTypes[i], myJDBCColumnTypes[i].intValue()));
            }
            
            // Send the SQL to the database
            String tempSQL = sb.toString();
            PreparedStatement tempStmt = tempConnection.prepareStatement(tempSQL);
            Object tempObject = parseGISToolkitShape(tempShape);
            tempStmt.setObject(1, tempObject);
            try{
                tempStmt.executeUpdate();
            }catch(Exception e){
                System.out.println(tempSQL);
                e.printStackTrace();
            }
            tempStmt.close();
            fireUpdate(inRecord);
        }
        else {
            throw new Exception("Record can not be updated, it did not come from this data source");
        }
        setCache(null, null);
    }
    
    /**Delete this record from the database. By default this is a read only data source, so this method does nothing.*/
    public void doDelete(Record inRecord) throws Exception {
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        SQLConverter tempConverter = getSQLConverter();
        
        // create the statement
        StringBuffer sb = new StringBuffer();
        sb.append("DELETE FROM ");
        sb.append(myDatabaseTablename);
        // the where clause
        sb.append(" WHERE\n");
        String[] tempColumnNames = inRecord.getAttributeNames();
        Object[] tempAttributes = inRecord.getAttributes();
        for (int i=0; i<tempColumnNames.length; i++){
            if (i>0) sb.append(" AND\n");
            sb.append("\t"+tempColumnNames[i]+"="+tempConverter.toSQL(tempAttributes[i], myColumnTypes[i], myJDBCColumnTypes[i].intValue()));
        }
        // send the statement to the database
        String tempSQL = sb.toString();
        try{
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.executeUpdate(tempSQL);
            tempStatement.close();
        }
        catch (Exception e){
            System.out.println(tempSQL);
            e.printStackTrace();
        }
        fireDelete(inRecord);
        setCache(null, null);
    }
    
    /**Commit all changes since the last commit. This is a read only data source by default, so this method does nothing. */
    public void commit() throws Exception {
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        
        // clear the insert prepared statement
        if (myInsertPreparedStatement != null){
            myInsertPreparedStatement.close();
            myInsertPreparedStatement = null;
        }

        // commit the transaction
        tempConnection.commit();
        
        fireCommit();
        setCache(null, null);
    }
    
    /**Rollback any changes to this datasource since the last commit.*/
    public void rollback() throws Exception {
        // Retrieve the connection to the database
        Connection tempConnection = connect();
        
        // clear the insert prepared statement
        if (myInsertPreparedStatement != null){
            myInsertPreparedStatement.close();
            myInsertPreparedStatement = null;
        }

        // rollback the transaction
        String tempQuery = "ROLLBACK";
        Statement tempStatement = tempConnection.createStatement();
        tempStatement.execute(tempQuery);
        tempStatement.close();
        
        fireRollBack();
        setCache(null, null);
    }
    /** Get the style to use with this datasource.  */
    public gistoolkit.display.Style getStyle() {
        return null;
    }
}