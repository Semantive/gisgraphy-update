/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.datasources.oracle;

import java.sql.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;

/**
 * Abstract class for handling information common to both the read only, and the updateable Oracle datasources.
 *
 * This class connects to an Oracle Database with the OracleLocator option.  The OracleLocator is shipped with every
 * Oracle database from 8.1 and up.  It is not a part of OracleSpatial, so OracleSpatial is not required for
 * this data source to work.
 */
public abstract class OracleDataSource extends SimpleDBDataSource{
    
    /**Name of this datasource.*/
    private String myName = "Oracle";
    /** Return the name of this datasource for display to the user. */
    public String getName(){return myName;}
    /** Set the name of this datasource for display purposes. */
    public void setName(String inName){myName = inName;}
    
    /**When connecting with the driver, a specific urlbase is required.*/
    private String myDatabaseURLBase = "jdbc:oracle:thin:";
    /** Returns the url base to use when connecting through the JDBC driver. */
    public String getDatabaseURLBase() {return myDatabaseURLBase;}
    /** Sets the url base to use when connecting through the JDBC driver.*/
    public void setDatabaseURLBase(String inDatabaseURLBase){myDatabaseURLBase = inDatabaseURLBase;}
    
    /**
     * This driver must be present in the class path of this application as
     * it is required for connecting to Oracle.
     */
    private String myDatabaseDriver = "oracle.jdbc.driver.OracleDriver";
    /** Returns the jdbc driver class used for connection to the database. */
    public String getDatabaseDriver() {return myDatabaseDriver;}
    /** Sets the name of the jdbc driver class used for connection to the database. */
    public void setDatabaseDriver(String inDatabaseDriver){myDatabaseDriver = inDatabaseDriver;}
    
    /**The server name of the server to connect to.*/
    private String myDatabaseServername="Servername";
    /** Returns the computer name of the Oracle server. */
    public String getDatabaseServername() {return myDatabaseServername;}
    /** Sets the name of the Oracle Server computer. */
    public void setDatabaseServername(String inDatabaseServername){myDatabaseServername = inDatabaseServername;}
    
    /**The name of the database on the DB2 server to connect to.*/
    public String myDatabaseName = "Databasename";
    /** Returns the name of the Oracle Database. */
    public String getDatabaseName() {return myDatabaseName;}
    /** Sets the name of the Oracle Database. */
    public void setDatabaseName(String inDatabaseName){myDatabaseName = inDatabaseName;}
    
    /**Oracle supports Schemas, and this is the schema under which the data will reside.*/
    private String myDatabaseSchema = "Schemaname";
    /** Returns the name of the schema within the Oracle database where the data resides. */
    public String getDatabaseSchema() {return myDatabaseSchema;}
    /** Sets the name of the schema within the Oracle database where the data resides. */
    public void setDatabaseSchema(String inDatabaseSchema){myDatabaseSchema = inDatabaseSchema;}
    
    /**The username used to connect to the database.*/
    private String myDatabaseUsername = "Username";
    /** Returns the username to use when connecting to the Oracle server. */
    public String getDatabaseUsername() {return myDatabaseUsername;}
    /** Sets the username to use when connecting to the Oracle server. */
    public void setDatabaseUsername(String inDatabaseUsername){myDatabaseUsername = inDatabaseUsername;}
    
    /**Password for connecting to the database.*/
    private String myDatabasePassword = "Password";
    /** Returns the password to use when connecting to the Oracle server. */
    public String getDatabasePassword() {return myDatabasePassword;}
    /** Sets the password to use when connecting to the Oracle server. */
    public void setDatabasePassword(String inDatabasePassword){myDatabasePassword = inDatabasePassword;}
    
    /**Port needed for connecting to the database.*/
    private int myDatabasePort = 1521;
    /** Returns the tcpip port to use when connecting to the Oracle server */
    public int getDatabasePort() {return myDatabasePort;}
    /** Sets the tcpip port to use when connecting to the Oracle server*/
    public void setDatabasePort(int inDatabasePort){myDatabasePort = inDatabasePort;}
    
    /**Column Name of the shape column, since the records can only handle a single shape column, this one is used.*/
    private String myDatabaseShapeColumn = "Shape";
    /** Returns the name of the shape column. */
    public String getDatabaseShapeColumn() {return myDatabaseShapeColumn;}
    /** Sets the name of the shape column.  The contents of this column will be parsed as a shape.*/
    public void setDatabaseShapeColumn(String inDatabaseShapeColumn){myDatabaseShapeColumn = inDatabaseShapeColumn;}
    
    /**Spatial Reference ID needed for accessing shape information.*/
    private int myDatabaseSpatialReferenceID = 1;
    /** Returns the spatial reference id to use for converting shapes to and from database format.*/
    public int getDatabaseSpatialReferenceID() {return myDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(int inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = inDatabaseSpatialReferenceID;}
    /** Sets the SpatialReferenceID to use when converting shapes to and from database format.*/
    public void setDatabaseSpatialReferenceID(String inDatabaseSpatialReferenceID){myDatabaseSpatialReferenceID = Integer.parseInt(inDatabaseSpatialReferenceID);}
        
    /** The SDOParser associated with this data source, used to convert two and from oracle shape types. */
    private SDOParser mySDOParser = new SDOParser();
    
    /** The SDOAdapter that converts from oracle.STRUCT shape structures to oracle shape types. */
    private oracle.sdoapi.adapter.AdapterSDO mySDOAdapter = null;

    /** Creates new SpatialExtenderDataSource */
    public OracleDataSource() {
    }
    
    /**The Envelope of the dataset.*/
    protected Envelope myEnvelope = null;
        
    /**Connection to the Oracle datasource used for maintaining persistent connections.*/
    protected Connection myCon = null;
    
    /**Statment used to maintain distributed transactions.*/
    protected Statement myStmt = null;
    
    /**
     * Initializes the connection to the database.
     */
    public Connection connect() throws Exception{
        if (myCon != null) return myCon;
        if (myDatabaseDriver == null)
            throw new Exception("No Database Driver Class defined");
        if (myDatabasePassword == null)
            throw new Exception("No Database Password defined");
        if (myDatabaseSchema == null)
            throw new Exception("No Database Schema defined");
        if (myDatabaseName == null)
            throw new Exception("No Database Name defined");
        if (myDatabaseServername == null)
            throw new Exception("No Database Servername defined");
        if (myDatabaseURLBase == null)
            throw new Exception("No Database URL Base defined");
        if (myDatabaseUsername == null)
            throw new Exception("No Database Username defined");
        
        // load the driver
        try {
            Class.forName(getDatabaseDriver()).newInstance();
        }
        catch (Exception e) {
            System.out.println("Error Loading DBDriver Class " + e);
            throw new Exception("Error Loading Database Driver " + e);
        }
        
        // URL is jdbc:db2:dbname
        String url = getDatabaseURLBase()+"@"+getDatabaseServername()+":"+myDatabasePort+":"+getDatabaseName();
        try {
            myCon = DriverManager.getConnection(url, getDatabaseUsername(), getDatabasePassword());
            myStmt = myCon.createStatement();
            String tempQuery = new String("SELECT count(*) FROM DUAL");
            myStmt.execute(tempQuery);
            mySDOAdapter = new oracle.sdoapi.adapter.AdapterSDO((oracle.jdbc.OracleConnection) myCon);    
        }
        catch (Exception e) {
            throw new Exception("Error Connecting " + e);
        }
        return myCon;
    }
    
    /** Converts the Oracle JDBC struct type to a GISToolkit shape. */
    protected Shape parseSDOStruct(Object inObject)throws oracle.sdoapi.geom.InvalidGeometryException, oracle.sdoapi.adapter.GeometryInputTypeNotSupportedException {
        return SDOParser.convertSDO(mySDOAdapter.importGeometry(inObject));
    }
    
    /** Converts the GISToolkit shape into an oracle JDBC struct type. */
    protected Object parseGISToolkitShape(Shape inShape)throws oracle.sdoapi.geom.InvalidGeometryException, oracle.sdoapi.adapter.GeometryOutputTypeNotSupportedException{
        return mySDOAdapter.exportGeometry(oracle.sql.STRUCT.class, mySDOParser.convert(inShape));
    }
    
    /**Returns the bounding rectangle of all the shapes in the Data Source.*/
    public Envelope readEnvelope() throws Exception {
        readDataset();
        return myEnvelope;
    }    
    
    /** Get the where clause based on the Envelope */
    protected String getWhereString(Envelope inEnvelope){
        // if the Envelope form a point, then construct the point.
        String tempWhereString = "";
        if (inEnvelope.getMinX() == inEnvelope.getMaxX()){
            Point tempPoint = new Point(inEnvelope.getMinX(), inEnvelope.getMaxY());
            tempWhereString = " sdo_relate("+getDatabaseShapeColumn()+", "
            +"mdsys.sdo_geometry(2001, "
            +"NULL, "
            +"NULL, "
            +"mdsys.sdo_elem_info_array(1,1,1), "
            +"mdsys.sdo_ordinate_array("
            +tempPoint.getX()+", "+tempPoint.getY()+""
            +")),"
            +"'mask=anyinteract querytype=window'"
            +") = 'TRUE'";
        }
        else{
            Point tempTopLeft = new Point(inEnvelope.getMinX(), inEnvelope.getMaxY());
            Point tempTopRight = new Point(inEnvelope.getMaxX(), inEnvelope.getMaxY());
            Point tempBottomLeft = new Point(inEnvelope.getMinX(), inEnvelope.getMinY());
            Point tempBottomRight = new Point(inEnvelope.getMaxX(), inEnvelope.getMinY());
            
            tempWhereString = " sdo_relate("+getDatabaseShapeColumn()+", "
            +"mdsys.sdo_geometry(2003, "
            +"NULL, "
            +"NULL, "
            +"mdsys.sdo_elem_info_array(1,1003,3), "
            +"mdsys.sdo_ordinate_array("
            +tempTopRight.getX()+", "+tempTopRight.getY()+", "
            +tempBottomLeft.getX()+", "+tempBottomLeft.getY()+""
            +")),"
            +"'mask=anyinteract querytype=window'"
            +") = 'TRUE'";
        }
        return tempWhereString;
    }
    
    private static final String SERVER_NAME = "Servername";
    private static final String PORT_NUMBER = "PortNumber";
    private static final String USERNAME = "Username";
    private static final String PASSWORD = "Password";
    private static final String DATABASE_NAME = "DatabaseName";
    private static final String SCHEMA = "Schema";
    private static final String SHAPE_COLUMN = "ShapeColumn";
    private static final String DRIVER = "Driver";
    private static final String URLBASE = "URLBase";
    private static final String SPATIAL_REFERENCE_ID = "SpatialReferenceID";
    
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("OracleLocatorDataSource");
        
        // connection parameters
        tempRoot.addAttribute(SERVER_NAME, getDatabaseServername());
        tempRoot.addAttribute(PORT_NUMBER, ""+getDatabasePort());
        tempRoot.addAttribute(USERNAME, getDatabaseUsername());
        tempRoot.addAttribute(PASSWORD, getDatabasePassword());
        tempRoot.addAttribute(DATABASE_NAME, getDatabaseName());
        tempRoot.addAttribute(SCHEMA, getDatabaseSchema());
        tempRoot.addAttribute(SHAPE_COLUMN, getDatabaseShapeColumn());
        tempRoot.addAttribute(DRIVER, getDatabaseDriver());
        tempRoot.addAttribute(URLBASE, getDatabaseURLBase());
        tempRoot.addAttribute(SPATIAL_REFERENCE_ID, ""+getDatabaseSpatialReferenceID());
        return tempRoot;
    }            
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        if (inNode == null) throw new Exception("Can not set up Oracle Datasource configuration information is null");
        super.setNode(inNode);
        String tempName = null;
        String tempValue = null;
        try{
            // connection parameters
            tempName = SERVER_NAME;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseServername(tempValue);
            tempName = PORT_NUMBER;
            tempValue = inNode.getAttribute(tempName);
            setDatabasePort(Integer.parseInt(tempValue));
            tempName = USERNAME;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseUsername(tempValue);
            tempName = PASSWORD;
            tempValue = inNode.getAttribute(tempName);
            setDatabasePassword(tempValue);
            tempName = DATABASE_NAME;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseName(tempValue);
            tempName = SCHEMA;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseSchema(tempValue);
            tempName = DRIVER;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseDriver(tempValue);
            tempName = SHAPE_COLUMN;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseShapeColumn(tempValue);
            tempName = URLBASE;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseURLBase(tempValue);
            tempName = SPATIAL_REFERENCE_ID;
            tempValue = inNode.getAttribute(tempName);
            setDatabaseSpatialReferenceID(tempValue);
        }
        catch (Exception e){
            throw new Exception("Can not read value for "+tempName+" to configure "+getName()+ " Arc SDE Datasource");
        }
    }    
    /** Returns the converter for this Database. */
    public SQLConverter getSQLConverter(){return new OracleSQLConverter();}  
}
