/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application;

import java.io.*;
/**
 * Allows filtering of files in the JFileChooser.  This class doesn't have anything really to do with GIS.  It is
 * here because I didn't know where else to put it.
 * @author  ithaqua
 */
public class GISFileFilter extends javax.swing.filechooser.FileFilter {

    /** Creates new FileFilter */
    public GISFileFilter() {
    }
    /** Creates new FileFilter */
    public GISFileFilter(String inExtension,String inDescription) {
        myExtension = inExtension;
        myDescription = inDescription;
    }
    
    /** Set the file extension to filter fore */
    private String myExtension = null;
    /** Retrieve the file extension to filter for */
    public String getExtension(){return myExtension;}
    /** Set the file extension to filter for */
    public void setExtension(String inExtension){myExtension = inExtension;}
    
    /** The description for this filter */
    private String myDescription = null;
    /** retrieve the description of this filter */
    public String getDescription(){return myDescription;}
    /** Set the description of this filter */
    public void setDescrption(String inD){myDescription = inD;}
    
    /** accept the value */
    public boolean accept(File inFile){
        if (inFile == null )return false;
        if (myExtension == null) return true;
        if (inFile.isDirectory()) return true;
        
        String tempString = inFile.getName();
        int tempIndex = tempString.lastIndexOf(".");
        if (tempIndex >0){
            if (myExtension.equalsIgnoreCase(tempString.substring(tempIndex+1))) return true;
        }
        return false;    
    }

}
