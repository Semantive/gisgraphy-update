/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.application.layers.layerpanel;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.imagefile.*;
import gistoolkit.datasources.imagefile.imagereaders.*;
import gistoolkit.application.*;
import gistoolkit.application.layers.*;

/**
 *  Allows the user to interactively input the parameters to the Image Data Source.
 */
public class ImageFileDataSourcePanel extends JPanel implements ActionListener, DataSourcePanel, ComponentListener{
    
    /** Creates new ImageFileDataSourcePanel */
    public ImageFileDataSourcePanel() {
        super();
        initPanel();
    }
    
    /** Keep a reference to the display. */
    private GISDisplay myGISDisplay = null;
    public void setGISDisplay(GISDisplay inDisplay){myGISDisplay = inDisplay;}
    
    /**
     * Label for the coordinates.
     */
    private JLabel myLabelCoordinates = new JLabel("Image Extents in World Coordinates");
    
    /**
     * Text field to allow the user to type the location directly.
     */
    private JTextField myTextFieldLocation;
    
    /**
     * Minimum X value for extents.
     */
    private JTextField myTextFieldMinX;
    
    /**
     * Minimum Y value for extents.
     */
    private JTextField myTextFieldMinY;
    
    /**
     * Maximum X value for extents.
     */
    private JTextField myTextFieldMaxX;
    
    /**
     * maximum Y value for extents.
     */
    private JTextField myTextFieldMaxY;
    
    /**
     * Button for looking up a location.
     */
    private JButton myButtonLocation;
    
    /**
     * Reference to the Datasource.
     */
    private DataSource myDatasource = null;
    
    /**
     * Handle events coming from the button.
     */
    public void actionPerformed(ActionEvent inAE){
        if (myChooser == null){
            myChooser = new JFileChooser();
        }
        String tempString = myTextFieldLocation.getText();
        if ((tempString != null) && (tempString.length() >0)){
            File tempFile = new File(tempString);
            if (tempFile.exists()){
                if (tempFile.isDirectory()){
                    myChooser.setCurrentDirectory(tempFile);
                }
                if (tempFile.isFile()){
                    myChooser.setSelectedFile(tempFile);
                }
            }
        }
        
        int returnVal = myChooser.showOpenDialog(this);
        
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            myTextFieldLocation.setText(myChooser.getSelectedFile().getAbsolutePath());
            checkForWorldFile();
        }
    }
    
    /** Check for World file. */
    private void checkForWorldFile(){
        myLabelCoordinates.setText("Image Extents in World Coordinates");
        defaultValues();
        String tempLocation = myTextFieldLocation.getText();
        if ((tempLocation != null) && (tempLocation.length() > 0)){
            // try to find the extension
            int tempIndex = tempLocation.lastIndexOf(".");
            if (tempIndex != -1){
                String tempFileBase = tempLocation.substring(0, tempIndex);
                
                // try to find the file
                boolean tempFound = false;
                File tempFile = new File(tempFileBase+".tfw");
                if (tempFile.exists()){
                    tempFound = true;
                }
                if (!tempFound){
                    tempFile = new File(tempFileBase + ".jgw");
                    if (tempFile.exists()){
                        tempFound = true;
                    }
                }
                if (!tempFound){
                    tempFile = new File(tempFileBase + ".tifw");
                    if (tempFile.exists()){
                        tempFound = true;
                    }
                }
                if (!tempFound) return;
                
                try{
                    // read the contents
                    FileReader fread = new FileReader(tempFile);
                    BufferedReader bread = new BufferedReader(fread);
                    String tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The dimension of a pixel in map units in the x-direction) is not available");
                    double tempXScale = Double.parseDouble(tempLine);
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The rotation factor in the x-direction (generally 0)) is not available");
                    double  tempXRot = 0;
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The rotation factor in the y-direction (generally 0)) is not available");
                    double  tempYRot = 0;
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The negative of the dimension of a pixel in map units in the y-direction) is not available");
                    double  tempYScale = Double.parseDouble(tempLine);
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The x-coordinate of the center of the upper left pixel) is not available");
                    double  tempXStart = Double.parseDouble(tempLine);
                    tempLine = bread.readLine();
                    if (tempLine == null) throw new Exception("First line of tfw (The y-coordinate of the center of the upper left pixel) is not available");
                    double  tempYStart = Double.parseDouble(tempLine);
                    
                    // how many pixels are there in the image
                    String tempImageLocation = myTextFieldLocation.getText();
                    
                    // read the image from a file.
                    int tempWidth = 0;
                    int tempHeight = 0;
                    try{
                        ImageInformation tempInfo = ImageReader.readImage(tempLocation);
                        tempWidth = tempInfo.getImageWidth();
                        tempHeight = tempInfo.getImageHeight();
                    }
                    catch (Exception e){
                        e.printStackTrace();
                        Image tempImage = Toolkit.getDefaultToolkit().createImage(tempImageLocation);
                        System.out.println(tempImage);
                        
                        // track the image
                        MediaTracker mt = new MediaTracker(new Panel());
                        mt.addImage(tempImage, 0);
                        mt.waitForAll();
                        
                        // get the height.
                        tempWidth = tempImage.getWidth(this);
                        tempHeight = tempImage.getHeight(this);
                        
                        // OK, even though we have waited for this image to load
                        // It can still return -1 for both the width and height.
                        // I hate Java Image architectures and judging by the sheer number of them, I am not the only one.
                        
                        
                    }
                    
                    // calculate the bounds.
                    if ((tempWidth > -1 ) && (tempHeight > -1)){
                        double tempTopX = tempXStart;
                        double tempBottomX = tempWidth*tempXScale + tempXStart;
                        double tempTopY = tempYStart;
                        double tempBottomY = tempHeight*tempYScale + tempYStart;
                        
                        // save the coordinates.
                        myTextFieldMaxX.setText(""+ tempBottomX);
                        myTextFieldMinX.setText(""+ tempTopX);
                        myTextFieldMaxY.setText(""+ tempTopY);
                        myTextFieldMinY.setText(""+ tempBottomY);
                        
                        // update the prompt
                        myLabelCoordinates.setText("Read From World File");
                    }
                    
                }
                catch (Exception e){
                    System.out.println(""+e);
                    String tempString = e.getMessage();
                    if (tempString != null){
                        JOptionPane.showMessageDialog(this, tempString, "Error parsing world file "+tempFile.getAbsolutePath(), JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
    }
    
    /** Constants for the initialization parameters. */
    private static final String FILENAME_TAG = "ImageFileDataSourceFile";
    
    /**
     * Returns the fully configured datasource.
     */
    public DataSource getDataSource() throws Exception{
        // Check the file location.
        File tempFile = new File(myTextFieldLocation.getText());
        if (!tempFile.exists()) throw new Exception ("File "+tempFile.getAbsolutePath()+" Does not exist");
        
        ImageFileDataSource tempDataSource = new ImageFileDataSource();
        
        // set the file name
        tempDataSource.setImageFile(tempFile);
        
        // set the envelope
        tempDataSource.setImageEnvelope(
        new gistoolkit.features.Envelope(
        Double.parseDouble(myTextFieldMinX.getText()),
        Double.parseDouble(myTextFieldMaxY.getText()),
        Double.parseDouble(myTextFieldMaxX.getText()),
        Double.parseDouble(myTextFieldMinY.getText())
        )
        );
        
        // save the configuration information.
        System.getProperties().setProperty(Constants.getApplicationName()+"."+FILENAME_TAG, tempFile.getAbsolutePath());
        return tempDataSource;
    }
    
    /**
     * Set up the GUI components for requesting the information from the user.
     */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        
        // create the type in box for the filename
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        JLabel tempLabelFile = new JLabel("File");
        add(tempLabelFile, c);
        c.gridx++;
        c.weightx = 1;
        myTextFieldLocation = new JTextField();
        add(myTextFieldLocation, c);
        myTextFieldLocation.setText(System.getProperty(Constants.getApplicationName()+"."+FILENAME_TAG, myTextFieldLocation.getText()));
        
        c.gridx++;
        c.weightx = 0;
        myButtonLocation = new JButton("Browse");
        add(myButtonLocation, c);
        
        // extents label
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myLabelCoordinates, c);
        c.gridwidth = 1;
        
        // MinX
        c.gridx = 0;
        c.gridy++;
        JLabel tempLabel = new JLabel("Minimum X");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMinX = new JTextField(), c);
        c.gridwidth = 1;
        
        // MinY
        c.gridx = 0;
        c.gridy++;
        tempLabel = new JLabel("Minimum Y");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMinY = new JTextField(), c);
        c.gridwidth = 1;
        
        // MaxX
        c.gridx = 0;
        c.gridy++;
        tempLabel = new JLabel("Maximum X");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMaxX = new JTextField(), c);
        c.gridwidth = 1;
        
        // MaxY
        c.gridx = 0;
        c.gridy++;
        tempLabel = new JLabel("Maximum Y");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMaxY = new JTextField(), c);
        c.gridwidth = 1;
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        add(new JPanel(), c);
        
        // listen to the button
        myButtonLocation.addActionListener(this);
        addComponentListener(this);
    }
    
    public void defaultValues(){
        if (myGISDisplay != null){
            gistoolkit.features.Envelope tempEnvelope = myGISDisplay.getEnvelope();
            if (tempEnvelope != null){
                myTextFieldMaxX.setText(""+tempEnvelope.getMaxX());
                myTextFieldMinX.setText(""+tempEnvelope.getMinX());
                myTextFieldMaxY.setText(""+tempEnvelope.getMaxY());
                myTextFieldMinY.setText(""+tempEnvelope.getMinY());
            }
        }
    }
    
    public void componentResized(java.awt.event.ComponentEvent componentEvent) {
    }
    
    public void componentMoved(java.awt.event.ComponentEvent componentEvent) {
    }
    
    public void componentShown(java.awt.event.ComponentEvent componentEvent) {
        defaultValues();
    }
    
    public void componentHidden(java.awt.event.ComponentEvent componentEvent) {
    }
    
    /**
     * Save the file chooser for future reference
     */
    private static JFileChooser myChooser = new JFileChooser();
    
}
