/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.widgets.*;
/**
 * Class for the editing of the properties of a layer.  There are many properties of layers, color, font,
 * Data Source, Projection etc.  This is a good place to start for these items.
 */
public class LayerPropertiesDialog extends GISToolkitDialog {

    /** Creates new LayerPropertiesPanel */
    public LayerPropertiesDialog() {
        initPanel();
        setSize(600, 400);
        centerDialog();
    }
    
    /** Tabbed Pane for displaying other panels */
    private JTabbedPane myTabbPanel = new JTabbedPane();
    
    /** Panel for displaying the Layer attributes */
    private LayerAttributesPanel myPanelLayer = new LayerAttributesPanel();
    
    /** Panel for displaying the Shader attributes */
    private ShaderSelectPanel myPanelStyle = new ShaderSelectPanel();
    
    /** Panel for modifying the labeler */
    private LabelerSelectPanel myPanelLabeler = new LabelerSelectPanel();
    
    /** Panel for modifying the renderer */
    private RendererSelectPanel myPanelRenderer = new RendererSelectPanel();

    /** Panel for modifying the from projection of the layer. */
    private ProjectionSelectPanel myPanelProjection = new ProjectionSelectPanel(false);
    
    /** Panel for modifying the filters of a layer. */
    private FilterSelectPanel myPanelFilter = new FilterSelectPanel();
    
    /** Initialize the GUI display for the user interface */
    private void initPanel(){
        Container tempPanel = getContentPane();
        tempPanel.setLayout(new BorderLayout());
        
        // add the tabb panel to the layout
        tempPanel.add(myTabbPanel, BorderLayout.CENTER);
        
        // add the tabs.
        myTabbPanel.addTab("Layer", myPanelLayer);
        myTabbPanel.addTab("Style", myPanelStyle);
        myTabbPanel.addTab("Labeler", myPanelLabeler);
        myTabbPanel.addTab("Renderers", myPanelRenderer);
        myTabbPanel.addTab("From Projection", myPanelProjection);
        myTabbPanel.addTab("Filters", myPanelFilter);
    }

    /** Reference to the curently edited layer */
    private Layer myLayer = null;
    
    /** set the layer into the dialog */
    public void setLayer(Layer inLayer){
        if (inLayer == null) return;
        myLayer = inLayer;
        myPanelLayer.setLayer(myLayer);
        myPanelStyle.setLayer(myLayer);
        myPanelLabeler.setLayer(myLayer);
        myPanelRenderer.setLayer(myLayer);
        myPanelProjection.setLayer(myLayer);
        myPanelFilter.setLayer(myLayer);
    }
    
    /** get the layer from the dialog */
    public Layer getLayer() throws Exception{
        myPanelProjection.getLayer();
        myPanelLayer.getLayer();
        myPanelStyle.getLayer();
        myPanelLabeler.getLayer();
        myPanelRenderer.getLayer();
        myPanelFilter.getLayer();
        return myLayer;
    }
}
