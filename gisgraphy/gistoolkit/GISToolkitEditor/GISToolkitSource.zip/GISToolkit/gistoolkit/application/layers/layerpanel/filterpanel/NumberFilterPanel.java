/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.layerpanel.filterpanel;

import gistoolkit.datasources.filter.*;


/**
 * Class to create date filters.
 */
public class NumberFilterPanel extends SimpleAttributeFilterPanel{
    
    /** Create a new DateFilterPanel. */
    public NumberFilterPanel(){
        super();
        setValueLabel("Number:");
    }
    
    /** Set a filter to be used as the template.  */
    public void setFilter(Filter inFilter) {
        if (inFilter instanceof DateAttributeFilter){
            DateAttributeFilter tempFilter = (DateAttributeFilter) inFilter;
            
            // set the attribute
            String tempAttributeName = tempFilter.getAttributeName();
            setAttributeName(tempAttributeName);
            
            // set the comparison.
            int tempComparison = tempFilter.getComparison();
            setComparison(tempComparison);
            
            // set the value. in YYYY-MM-DD hh:mm:ss
            Number tempNumber= (Number) tempFilter.getAttributeValue(); 
            setTextField(""+tempNumber);
        }
    }
    
    /** Retrieve the configured filter from the filter panel.  */
    public Filter getFilter() throws Exception{
        // attribute name
        String tempAttributeName = getAttributeName();
        
        // comparison
        int tempComparison = getComparison();
        
        // Value
        String tempValue = getTextField();
        
        // convert to number
        try{
            double tempDouble = Double.parseDouble(tempValue);
            
            // create the filter
            NumberAttributeFilter tempFilter = new NumberAttributeFilter(tempAttributeName, tempComparison, tempDouble);
            tempFilter.setFilterName(tempFilter.createFilterName());
            return tempFilter;
        }
        catch (NumberFormatException e){
            throw new Exception("The value "+tempValue+" is not a number.");
        }
    }
}
