/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.layerpanel;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.GISDisplay;
import gistoolkit.application.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.db2spatialextender.UpdateableSpatialExtenderDataSource;
import gistoolkit.application.layers.*;
/**
 * Panel for collecting the information required for creating a DB2 Spatial Extender data source.
 * Creation date: (5/1/2001 11:05:59 AM)
 */
public class UpdateableSpatialExtenderDataSourcePanel extends JPanel implements DataSourcePanel{
    
    /**
     * Database connection parameters.
     */
    private JTextField myTextFieldDatabaseURLBase = new JTextField("jdbc:db2");
    private JTextField myTextFieldDatabaseServername= new JTextField("Servername");
    private JTextField myTextFieldDatabaseName = new JTextField("Databasename");
    private JTextField myTextFieldDatabaseSchema = new JTextField("DatabaseSchema");
    private JTextField myTextFieldDatabaseUsername = new JTextField("Username");
    private JTextField myTextFieldDatabaseDriver = new JTextField("COM.ibm.db2.jdbc.net.DB2Driver");
    private JTextField myTextFieldDatabasePassword = new JTextField("Password");
    private JTextField myTextFieldDatabasePort =  new JTextField("1150");
    private JTextField myTextFieldDatabaseTable = new JTextField("Tablename");
    private JTextField myTextFieldDatabaseColumn =  new JTextField("Shape");
    private JTextField myTextFieldSpatialReferenceID =  new JTextField("1");
    
    /**
     * ShapeFilePanel constructor comment.
     */
    public UpdateableSpatialExtenderDataSourcePanel() {
        super();
        initPanel();
    }
    
    /**
     * ShapeFilePanel constructor comment.
     * @param layout java.awt.LayoutManager
     */
    public UpdateableSpatialExtenderDataSourcePanel(java.awt.LayoutManager layout) {
        super(layout);
        initPanel();
    }
    
    /**
     * ShapeFilePanel constructor comment.
     * @param layout java.awt.LayoutManager
     * @param isDoubleBuffered boolean
     */
    public UpdateableSpatialExtenderDataSourcePanel(java.awt.LayoutManager layout,boolean isDoubleBuffered) {
        super(layout, isDoubleBuffered);
        initPanel();
    }
    
    /**
     * ShapeFilePanel constructor comment.
     * @param isDoubleBuffered boolean
     */
    public UpdateableSpatialExtenderDataSourcePanel(boolean isDoubleBuffered) {
        super(isDoubleBuffered);
        initPanel();
    }
    
    /** Constants for the initialization parameters. */
    private static final String URLBASE_TAG = "SpatialExtenderDataSourceURLBase";
    private static final String SERVERNAME_TAG = "SpatialExtenderDataSourceServername";
    private static final String DATABASENAME_TAG = "SpatialExtenderDataSourceName";
    private static final String SCHEMA_TAG = "SpatialExtenderDataSourceSchema";
    private static final String USERNAME_TAG = "SpatialExtenderDataSourceUsername";
    private static final String DRIVER_TAG = "SpatialExtenderDataSourceDriver";
    private static final String PASSWORD_TAG = "SpatialExtenderDataSourcePassword";
    private static final String PORT_TAG = "SpatialExtenderDataSourcePort";
    private static final String SHAPECOLUMN_TAG = "SpatialExtenderDataSourceShapeColumn";
    private static final String SRID_TAG = "SpatialExtenderDataSourceSpatialReferenceID";
    private static final String TABLENAME_TAG = "SpatialExtenderDataSourceTablename";
    /**
     * Returns the fully configured datasource.
     */
    public DataSource getDataSource() throws Exception{
        UpdateableSpatialExtenderDataSource tempDatasource = new UpdateableSpatialExtenderDataSource();
        
        // set the properties
        tempDatasource.setDatabaseShapeColumn(myTextFieldDatabaseColumn.getText());
        tempDatasource.setDatabaseDriver(myTextFieldDatabaseDriver.getText());
        tempDatasource.setDatabaseName(myTextFieldDatabaseName.getText());
        tempDatasource.setDatabasePassword(myTextFieldDatabasePassword.getText());
        tempDatasource.setDatabaseSchema(myTextFieldDatabaseSchema.getText());
        tempDatasource.setDatabaseServername(myTextFieldDatabaseServername.getText());
        tempDatasource.setDatabaseURLBase(myTextFieldDatabaseURLBase.getText());
        tempDatasource.setDatabaseUsername(myTextFieldDatabaseUsername.getText());
        tempDatasource.setDatabaseTableName(myTextFieldDatabaseTable.getText());
        try{
            tempDatasource.setDatabasePort(Integer.parseInt(myTextFieldDatabasePort.getText()));
        }
        catch (NumberFormatException e){
            tempDatasource.setDatabasePort(1150);
        }
        tempDatasource.setDatabaseSpatialReferenceID(myTextFieldSpatialReferenceID.getText());
        tempDatasource.connect();

        // save the configuration information.
        System.getProperties().setProperty(Constants.getApplicationName()+"."+URLBASE_TAG, tempDatasource.getDatabaseURLBase());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SERVERNAME_TAG, tempDatasource.getDatabaseServername());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+DATABASENAME_TAG, tempDatasource.getDatabaseName());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SCHEMA_TAG, tempDatasource.getDatabaseSchema());        
        System.getProperties().setProperty(Constants.getApplicationName()+"."+USERNAME_TAG, tempDatasource.getDatabaseUsername());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+DRIVER_TAG, tempDatasource.getDatabaseDriver());        
        System.getProperties().setProperty(Constants.getApplicationName()+"."+PASSWORD_TAG, tempDatasource.getDatabasePassword());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+PORT_TAG, ""+tempDatasource.getDatabasePort());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SHAPECOLUMN_TAG, ""+tempDatasource.getDatabaseShapeColumn());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SRID_TAG, ""+tempDatasource.getDatabaseSpatialReferenceID());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+TABLENAME_TAG, tempDatasource.getDatabaseTableName());

        return tempDatasource;
    }
    
    /**
     * Set up the GUI components for requesting the information from the user.
     */
    private void initPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2, 2, 2, 2);
        
        // URL Base
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        JLabel tempLabel = new JLabel("URL Base");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseURLBase, c);
        myTextFieldDatabaseURLBase.setText(System.getProperty(Constants.getApplicationName()+"."+URLBASE_TAG, myTextFieldDatabaseURLBase.getText()));
        
        // Servername
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Servername");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseServername, c);
        myTextFieldDatabaseServername.setText(System.getProperty(Constants.getApplicationName()+"."+SERVERNAME_TAG, myTextFieldDatabaseServername.getText()));
        
        // DatabaseName
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Database Name");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseName, c);
        myTextFieldDatabaseName.setText(System.getProperty(Constants.getApplicationName()+"."+DATABASENAME_TAG, myTextFieldDatabaseName.getText()));
        
        // Schema
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Schema");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseSchema, c);
        myTextFieldDatabaseSchema.setText(System.getProperty(Constants.getApplicationName()+"."+SCHEMA_TAG, myTextFieldDatabaseSchema.getText()));
        
        // Username
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Username");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseUsername, c);
        myTextFieldDatabaseUsername.setText(System.getProperty(Constants.getApplicationName()+"."+USERNAME_TAG, myTextFieldDatabaseUsername.getText()));

        // Driver
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Driver");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseDriver, c);
        myTextFieldDatabaseDriver.setText(System.getProperty(Constants.getApplicationName()+"."+DRIVER_TAG, myTextFieldDatabaseDriver.getText()));
        
        // Password
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Password");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabasePassword, c);
        myTextFieldDatabasePassword.setText(System.getProperty(Constants.getApplicationName()+"."+PASSWORD_TAG, myTextFieldDatabasePassword.getText()));
        
        // Port
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Port");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabasePort, c);
        myTextFieldDatabasePort.setText(System.getProperty(Constants.getApplicationName()+"."+PORT_TAG, myTextFieldDatabasePort.getText()));
        
        // Column
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Column");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseColumn, c);
        myTextFieldDatabaseColumn.setText(System.getProperty(Constants.getApplicationName()+"."+SHAPECOLUMN_TAG, myTextFieldDatabaseColumn.getText()));

        // Spatial Reference ID
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Spatial Reference ID");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldSpatialReferenceID, c);
        myTextFieldSpatialReferenceID.setText(System.getProperty(Constants.getApplicationName()+"."+SRID_TAG, myTextFieldSpatialReferenceID.getText()));
        
        // SQLQuery
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Table");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseTable, c);
        myTextFieldDatabaseTable.setText(System.getProperty(Constants.getApplicationName()+"."+TABLENAME_TAG, myTextFieldDatabaseTable.getText()));
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        c.weighty = 1;
        add(new JPanel(), c);
    }
    
    /**
     * Sets the GISDisplay in case the panel should need it.
     */
    public void setGISDisplay(GISDisplay inDisplay) {
    }
    
}