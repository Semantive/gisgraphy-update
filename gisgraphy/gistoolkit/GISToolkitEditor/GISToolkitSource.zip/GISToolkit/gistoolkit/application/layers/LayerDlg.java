/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.application.layers;

import gistoolkit.display.renderer.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.datasources.DataSource;
import gistoolkit.display.*;
import gistoolkit.display.shader.*;

/**
 * The LayerDlg is used to create a new layer.  It contains primarily information
 * about how to connect to a datasource, and how to create that layer.  This requires that this panel
 * know about all of the datasource panels available on the system, an unfortunate restriction, but one that can
 * be relaxed in a future release.  Typical usage is as shown below
 * <p>
 * <pre>
 *  LayerDlg tempDialog = new LayerDialog();
 *  tempDialog.show();
 *  if (tempDialog.getOK()){
 *    myLayer = tempDialog.getLayer();
 *  }
 *  else{
 *    // handle the cancel case
 *  }
 * </pre>
 * Creation date: (4/30/2001 4:29:07 PM)
 * </p>
 */
public class LayerDlg extends JDialog implements ItemListener, ActionListener{
    
    // The datasource for this layer, and congured by it's specific DataSourcePanel.
    private DataSource myDataSource = null;
    
    // Holds the Panels created so they can be indexed in actionPerformed.
    private Vector myPanelVect = new Vector();
    
    // reference to the display panel incase the layer panels need some information.
    private GISDisplay myDisplay = null;
    public void setDisplay(GISDisplay inDisplay){myDisplay = inDisplay;}
        
    /**
     * Tabbed pane to switch between the types of data sources, and the projection to use for that datasource.
     */
    private JTabbedPane myTabb;
    
    /**
     * Panel to select the projection to use with this layer.
     */
    private ProjectionSelectPanel myProjectionPanel;
    
    /**
     * Holds the choice box for user input in selecting the type of datasource to use.
     */
    private JComboBox myChoiceTypes;
    
    /**
     * Holds a reference to the card layout so it can be flipped.
     */
    private CardLayout myCardLayout;
    
    /**
     * Holds a reference to the card panel so it can be flipped.
     */
    private JPanel myCardPanel;
    
    /**
     * Holds a reference to the OK button
     */
    private JButton myOKButton;
    
    /**
     * Holds a reference to the Cancel button
     */
    private JButton myCancelButton;
    
    /**
     * Determines if the OK Button was pressed, true if it has, false if it has not.
     */
    private boolean myOK = false;
        
    /**
     * Create a new LayerDlg with the proper initialization and parent dialog.
     */
    public LayerDlg(java.awt.Dialog owner) {
        super(owner);
        initPanel();
    }
        
    /**
     * Sets up the dialog and makes it modal.
     */
    public LayerDlg(java.awt.Dialog owner, boolean modal) {
        super(owner, modal);
        setModal(modal);
        initPanel();
    }
    
    
    /**
     * See Parent.
     * @param owner java.awt.Frame
     */
    public LayerDlg(java.awt.Frame owner) {
        super(owner);
        initPanel();
    }
        
    /**
     * See Parent.
     * @param owner java.awt.Frame
     * @param title java.lang.String
     * @param modal boolean
     */
    public LayerDlg(java.awt.Frame owner, boolean modal) {
        super(owner, modal);
        setModal(modal);
        initPanel();
    }    
    
    /** Show the dialog */
    public void show(){
        super.show();
    }
    
    /**
     * Respond to the events from the OK and Cancel buttons.  OK will set the OK flag, get the datasource, and close the dialog.
     * Cancel will just close the dialog, the OK flag will be set to false.
     */
    public void actionPerformed(ActionEvent inAE){
        if (inAE.getSource() == myOKButton){
            
            // retrieve the datasource
            try{
                DataSourcePanel tempPanel = (DataSourcePanel) myPanelVect.elementAt(myChoiceTypes.getSelectedIndex());
                myDataSource = tempPanel.getDataSource();
                myOK = true;
                this.setVisible(false);
            }
            catch (Exception e){
                System.out.println(e);
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, e.getMessage(), "DataSource Error", JOptionPane.ERROR_MESSAGE);
            }
            
        }
        if (inAE.getSource() == myCancelButton){
            myOK = false;
            this.setVisible(false);
        }
    }
    
    /**
     * Returns a layer from the dialog with the appropriate information.  Typically, code looks like this.
     * <pre>
     *  LayerDlg tempDialog = new LayerDialog();
     *  tempDialog.show();
     *  if (tempDialog.getOK()){
     *    myLayer = tempDialog.getLayer();
     *  }
     *  else{
     *    // handle the cancle case
     *  }
     * </pre>
     */
    public Layer getLayer()throws Exception{
        Layer tempLayer = new Layer(myDataSource);
        tempLayer.setLayerName(myDataSource.getName());
        tempLayer.setFromProjection(myProjectionPanel.getProjection());
        Style tempStyle;
        if(myDataSource.getStyle() == null) {
            tempStyle = new Style();
            tempStyle.setShader(new MonoShader(Color.black, Color.white));
            tempStyle.add(new PolygonRenderer());
            tempStyle.add(new MultiPolygonRenderer());
        }else{
            tempStyle = myDataSource.getStyle();
        }
        tempLayer.setStyle(tempStyle);
        
        return tempLayer;
    }
    
    /**
     * Sets up all of the buttons and things on the display.
     */
    private void initPanel(){
        setTitle("Open Layer");
        
        // create a border layout with the choice in the top, and the panel in the bottom.
        Container tempContainer = getContentPane();
        tempContainer.setLayout(new BorderLayout());
        myTabb = new JTabbedPane();
        tempContainer.add(myTabb, BorderLayout.CENTER);
        JPanel p = new JPanel(new BorderLayout());
        myTabb.addTab("Data Source", p);
        myProjectionPanel = new ProjectionSelectPanel();
        myTabb.addTab("From Projection", myProjectionPanel);
        
        p.setLayout(new BorderLayout(2,2));
        
        myChoiceTypes = new JComboBox();
        p.add(myChoiceTypes, BorderLayout.NORTH);
        
        // create the flip layout and a panel for it.
        CardLayout cl = new CardLayout();
        JPanel tempPanel = new JPanel(cl);
        p.add(tempPanel, BorderLayout.CENTER);
        
        // add the different datasource panels.
        Vector dataSourcePanelList = new Vector();
        int panelID = 1;
        String tmpBase = gistoolkit.application.Constants.getApplicationName()+".datasourcepanel.";
        String tmpKey = tmpBase+panelID;
        String tmpVal = System.getProperties().getProperty(tmpKey);
        while( tmpVal != null) {
            try {
                DataSourcePanel tmpDS = (DataSourcePanel) Class.forName(tmpVal).newInstance();
                dataSourcePanelList.addElement(tmpDS);
            }
            catch(NoClassDefFoundError err) {
                System.out.println(tmpVal+".class not found.");
            }
            catch(Exception ex) {
                System.out.println("Error creating panel ("+tmpVal+")\n"+ex);
            }
            panelID++;
            tmpKey = tmpBase+panelID;
            tmpVal = System.getProperties().getProperty(tmpKey);
        }
        // add the shape file panel.
        DataSourcePanel tempDataSourcePanel;
        for (int i=0;i<dataSourcePanelList.size();i++) {
            tempDataSourcePanel = (DataSourcePanel) dataSourcePanelList.elementAt(i);
            tempDataSourcePanel.setGISDisplay(myDisplay);
            String tempIdentifierString = tempDataSourcePanel.getClass().getName();
            tempIdentifierString = tempIdentifierString.substring(tempIdentifierString.lastIndexOf(".")+1,tempIdentifierString.length()-5);
            tempPanel.add((Component) tempDataSourcePanel, tempIdentifierString);
            myChoiceTypes.addItem(tempIdentifierString);
            myPanelVect.addElement(tempDataSourcePanel);
        }
        
        // save the references
        myCardLayout = cl;
        myCardPanel = tempPanel;
        
        // add the OK and cancel button
        JPanel tempButtonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        
        myOKButton = new JButton("OK");
        myCancelButton = new JButton("Cancel");
        
        // set the size of the OK button to that of the cancel button.
        // keeps them the same size and looks beter.
        myOKButton.setPreferredSize(myCancelButton.getPreferredSize());
        
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.anchor = GridBagConstraints.EAST;
        tempButtonPanel.add(myOKButton, c);
        c.weightx = 0;
        c.gridx = 1;
        tempButtonPanel.add(myCancelButton, c);
        tempContainer.add(tempButtonPanel, BorderLayout.SOUTH);
        
        // Listen to the combo box.
        myChoiceTypes.addItemListener(this);
        
        // Listen to the buttons
        myOKButton.addActionListener(this);
        myCancelButton.addActionListener(this);
        
        // set the width
        setSize(300,400);
        
        // set the size of the screen
        Dimension tempScreenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension tempSize = this.getSize();
        if (tempSize.width > tempScreenSize.width)
            tempSize.width = tempScreenSize.width;
        if (tempSize.height > tempScreenSize.height)
            tempSize.height = tempScreenSize.height;
        this.setLocation((tempScreenSize.width - tempSize.width) / 2, (tempScreenSize.height - tempSize.height) / 2);
        
    }
    
    /**
     * Returns true if the OK button has been pressed, false if the Cancel button has been pressed
     */
    public boolean isOK(){
        return myOK;
    }
    
    /**
     * React to the actions of the combo box.
     */
    public void itemStateChanged(ItemEvent inIE){
        myCardLayout.show(myCardPanel, (String)inIE.getItem());
    }
}