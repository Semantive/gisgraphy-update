/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.datasources.filter.*;
import gistoolkit.display.*;
import gistoolkit.display.widgets.*;
import gistoolkit.application.layers.layerpanel.filterpanel.*;
/**
 * Allows the user to select the filter they would like applied to this layer.
 */
public class FilterSelectPanel extends JPanel implements ActionListener{
        
    /** Creates new FilterSelectPanel */
    public FilterSelectPanel() {
        initPanel();
    }

    /** The List to contain the filters currently in use. */
    private JList myListFilter = new JList();
    /** The list model to use with this list. */
    private DefaultListModel myListModelFilter = new DefaultListModel();
    
    /** The button to add a filter. */
    private JButton myButtonAdd = new JButton("Add");
    
    /** The button to remove a filter. */
    private JButton myButtonRemove = new JButton("Remove");
        
    /** initialize the use interface components for this panel */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        
        // the list box
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.weighty = 1;
        c.gridheight = 3;
        add(new JScrollPane(myListFilter), c);
        c.gridheight = 1;
        c.weightx = 0;
        c.weighty = 0;
        
        // the add button.
        c.gridx++;
        add(myButtonAdd, c);
        
        // the remove button
        c.gridy++;
        add(myButtonRemove, c);
        
        // some space to move the buttons up.
        c.gridy++;
        c.weighty = 1;
        add (new JPanel(), c);
        c.weighty = 0;
        
        // add the listeners
        myButtonAdd.addActionListener(this);
        myButtonRemove.addActionListener(this);
        
        // setup the list
        myListFilter.setModel(myListModelFilter);
    }
    
    /** Hold a reference to the currently edited layer */
    private Layer myLayer = null;
    
    /** set the layer to be edited */
    public void setLayer(Layer inLayer){
        if (inLayer == null) return;
        myLayer = inLayer;
        myListModelFilter.removeAllElements();
        Filter tempFilter = myLayer.getFilter();
        if (tempFilter != null){
            // call the recursive function to add the filter.
            setFilter(tempFilter);
        }
    }
    
    /** Recursive function to loop through the filters. */
    private void setFilter(Filter inFilter){
        if (inFilter instanceof Join){
            setFilter(((Join) inFilter).getFilter1());
            setFilter(((Join) inFilter).getFilter2());
        }
        else{
            myListModelFilter.addElement(inFilter);
        }
    }
        
    
    /** get the layer after it has been edited */
    public Layer getLayer()throws Exception{
        if (myLayer == null) return null;
        
        // compile all the filters.
        if (myListModelFilter.getSize() == 0) myLayer.setFilter(null);
        else if (myListModelFilter.getSize() == 1) myLayer.setFilter((Filter) myListModelFilter.get(0));
        else if (myListModelFilter.getSize() == 2) myLayer.setFilter(new Join((Filter) myListModelFilter.get(0), Join.AND, (Filter) myListModelFilter.get(1)));
        else {
            Filter tempFilter1 = new Join((Filter) myListModelFilter.get(0), Join.AND, (Filter) myListModelFilter.get(1));
            for (int i=2; i<myListModelFilter.getSize(); i++){
                Filter tempFilter2 = (Filter) myListModelFilter.get(i);
                tempFilter1 = new Join(tempFilter1, Join.AND, tempFilter2);
            }
            myLayer.setFilter(tempFilter1);
        }
        return myLayer;
    }
        
    public void actionPerformed(java.awt.event.ActionEvent inAE) {
        if (inAE.getSource() == myButtonAdd){
            // show the add dialog
            MyAddDialog tempAddDialog = new MyAddDialog();
            tempAddDialog.setModal(true);
            tempAddDialog.show();
            
            // get the filter
            if (tempAddDialog.isOK()){
                try{
                    Filter tempFilter = tempAddDialog.getFilter();
                    
                    // add the filter.
                    myListModelFilter.addElement(tempFilter);
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(this, e.getMessage(), "Error on filter create ", JOptionPane.ERROR_MESSAGE);
                }
            }            
        }
        if (inAE.getSource() == myButtonRemove){
            int tempIndex = myListFilter.getSelectedIndex();
            if (tempIndex >= 0){
                myListModelFilter.remove(tempIndex);
                if (tempIndex > myListModelFilter.size()){
                    tempIndex--;
                    if ((tempIndex >=0) && (tempIndex < myListModelFilter.size()))
                        myListFilter.setSelectedIndex(tempIndex);
                }
            }
        }
    }    
    
    /** Finds the frame in the stack. */
    private Frame getFrame(){
        Container parent = this;
        while (!(parent instanceof Frame)){
            parent = parent.getParent();
        }
        return (Frame) parent;
    }
    
    /** Dialog to add a filter. */
    private class MyAddDialog extends GISToolkitDialog implements ItemListener{
        
        /** Combo box to hold the filter types that I know about. */
        JComboBox myComboFilters = new JComboBox();
        String[] myFilterTypes = {
            "String Filter",
            "Number Filter",
            "Date Filter"};
        
        public MyAddDialog(){

            super(getFrame());
            initPanel();
        }
        
        /** Initialize the user interface compoonents of this sub dialog. */
        Container myContainer = null;
        public void initPanel(){
            setTitle("Add Filter");
            myContainer = getContentPane();
            myContainer.setLayout(new BorderLayout(2,2));
            
            // populate the combo box at the top.
            for (int i=0; i<myFilterTypes.length; i++){
                myComboFilters.addItem(myFilterTypes[i]);
            }
            myContainer.add(myComboFilters, BorderLayout.NORTH);
            myComboFilters.addItemListener(this);
            
            // populate the default selection
            StringFilterPanel tempFilterPanel = new StringFilterPanel();
            tempFilterPanel.setAttributeNames(myLayer.getAttributeNames());
            myContainer.add(tempFilterPanel, BorderLayout.CENTER);
            myFilterPanel = tempFilterPanel;
            
            // set the location of the panel.
            Dimension s = getSize();
            Dimension w = Toolkit.getDefaultToolkit().getScreenSize();
            setLocation(w.width/2-s.width/2, w.height/2-s.height/2);
            
        }
        
        /** Get the filter. */
        public Filter getFilter() throws Exception{
            if (myFilterPanel != null){
                return myFilterPanel.getFilter();
            }
            throw new Exception("No Filter created.");
        }
        
        FilterPanel myFilterPanel = null;
        public void itemStateChanged(java.awt.event.ItemEvent inIE) {
            if (inIE.getSource() == myComboFilters){
                if (myFilterPanel != null){
                    myContainer.remove(myFilterPanel);
                }
                if (myComboFilters.getSelectedIndex() == 0){
                    StringFilterPanel tempFilterPanel = new StringFilterPanel();
                    tempFilterPanel.setAttributeNames(myLayer.getAttributeNames());
                    myContainer.add(tempFilterPanel, BorderLayout.CENTER);
                    myFilterPanel = tempFilterPanel;
                }
                if (myComboFilters.getSelectedIndex() == 1){
                    NumberFilterPanel tempFilterPanel = new NumberFilterPanel();
                    tempFilterPanel.setAttributeNames(myLayer.getAttributeNames());
                    myContainer.add(tempFilterPanel, BorderLayout.CENTER);
                    myFilterPanel = tempFilterPanel;
                }
                if (myComboFilters.getSelectedIndex() == 2){
                    DateFilterPanel tempFilterPanel = new DateFilterPanel();
                    tempFilterPanel.setAttributeNames(myLayer.getAttributeNames());
                    myContainer.add(tempFilterPanel, BorderLayout.CENTER);
                    myFilterPanel = tempFilterPanel;
                }
                validate();
            }
        }        
    }
}
