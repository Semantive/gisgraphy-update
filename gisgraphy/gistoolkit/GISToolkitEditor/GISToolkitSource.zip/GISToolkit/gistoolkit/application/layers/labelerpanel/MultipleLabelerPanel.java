/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.labelerpanel;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.labeler.*;
/**
 * Panel for editing a SimpleLabeler
 */
public class MultipleLabelerPanel extends LabelerPanel implements ActionListener{

    /** The text field to use to select the record to label by */
    private String[] myColumns = new String[0];
    
    /** The combo box with the available anchors. */
    private JComboBox myComboOrientation = new JComboBox();
    
    /** The text field to type in a delimiter, the characters that go between the columns. */
    private JTextField myTextFieldDelimiter = new JTextField();
    
    /** The text field to type in an offset. */
    private JTextField myTextFieldOffset = new JTextField();
    
    /** The check box to indicate if duplicates are allowed. */
    private JCheckBox myCheckBoxDuplicates = new JCheckBox("Duplicates");
    
    /** The check box to indicate if overlaps are allowed. */
    private JCheckBox myCheckBoxOverlaps = new JCheckBox("Overlaps");
    
    /** Button for adding additional columns. */
    private JButton myButtonAdd = new JButton("Add");
    
    /** Button for removing columns. */
    private JButton myButtonRemove = new JButton("Remove");
    
    
    /** The panel to hold the other entry panels.*/
    private JPanel myColumnPanel = new JPanel(new GridLayout(0,1,2,2));
    
    /** Vector to hold the entry panels. */
    private Vector myVectEntryPanels = new Vector();
    
    /** Class for each of the entry panels. */
    private class MyEntryPanel extends JPanel implements MouseListener{
        public JTextField myTextFieldPretext = new JTextField();
        public JTextField myTextFieldPosttext = new JTextField();
        public JComboBox myComboColumns = new JComboBox();
        public JComboBox myComboFormat = new JComboBox();
        public boolean mySelected = false;
        public boolean getSelected(){return mySelected;}
        private int myColumnNum = -1;
        
        public MyEntryPanel(String[] inColumns, ColumnAttributes inAttributes){
            super();
            setLayout(new GridLayout(1,4,4,4));
            setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
            add(myTextFieldPretext);
            add(myComboColumns);
            add(myTextFieldPosttext);
            add(myComboFormat);
            myComboFormat.addItem("None");
            myComboFormat.addItem("Number");
            myComboFormat.addItem("Currency");
            addMouseListener(this);
            myTextFieldPretext.addMouseListener(this);
            myTextFieldPosttext.addMouseListener(this);
            myComboFormat.addMouseListener(this);
            myComboColumns.addMouseListener(this);
            
            // set the columns
            setColumns(inColumns);
            
            if (inAttributes != null){
                // set the other attributes
                myColumnNum = inAttributes.getColumnNum();
                if (inColumns != null){
                    if (inColumns.length > inAttributes.getColumnNum()){
                        myComboColumns.setSelectedIndex(inAttributes.getColumnNum());
                    }
                }
                myTextFieldPretext.setText(inAttributes.getColumnPreString());
                myTextFieldPosttext.setText(inAttributes.getColumnPostString());
                if (inAttributes.getColumnFormat() < myComboFormat.getItemCount()){
                    myComboFormat.setSelectedIndex(inAttributes.getColumnFormat());
                }
            }
        }
        
        public void setColumns(String[] inColumns){
            int tempSelectedIndex = myComboColumns.getSelectedIndex();
            myComboColumns.removeAllItems();
            if (inColumns != null){
                for (int i=0; i<inColumns.length; i++){
                    myComboColumns.addItem(inColumns[i]);
                }
            }
            if (myColumnNum > -1){
                if (inColumns.length > myColumnNum){
                    myComboColumns.setSelectedIndex(myColumnNum);
                }
            }
            else{
                if ((tempSelectedIndex >=0) && (tempSelectedIndex < inColumns.length)){
                    myComboColumns.setSelectedIndex(tempSelectedIndex);
                }
            }
        }
        
        /** Invoked when the mouse button has been clicked (pressed*/
        public void mouseClicked(MouseEvent e) {
        }
        
        /** Invoked when the mouse enters a component.*/
        public void mouseEntered(MouseEvent e) {
        }
        
        /** Invoked when the mouse exits a component.*/
        public void mouseExited(MouseEvent e) {
        }
        
        /** Invoked when a mouse button has been pressed on a component.*/
        public void mousePressed(MouseEvent e) {
            select(this);
        }
        
        /** Invoked when a mouse button has been released on a component.*/
        public void mouseReleased(MouseEvent e) {
        }
        
        /** Set this as the selected panel. */
        public void setSelected(boolean inSelected){
            mySelected = inSelected;
            if (inSelected == true){
                setBackground(SystemColor.black);
            }
            else{
                setBackground(SystemColor.control);
            }
        }        
    }
    
    /** Selecte the given panel. */
    private void select(MultipleLabelerPanel.MyEntryPanel inPanel){
        for (int i=0; i<myVectEntryPanels.size(); i++){
            MultipleLabelerPanel.MyEntryPanel tempPanel = (MultipleLabelerPanel.MyEntryPanel) myVectEntryPanels.elementAt(i);
            if (inPanel == tempPanel){
                tempPanel.setSelected(true);
            }
            else tempPanel.setSelected(false);
        }
    }
    
    /** Creates new SimpleLabelerPanel */
    public MultipleLabelerPanel() {
        initPanel();
    }
    
    /** Reference to the MultipleLabeler to edit.*/
    private MultipleLabeler myLabeler = null;
    
    /** Set the SimpleLabeler to be edited */
    public void setLabeler(Labeler inLabeler){
        
        // do the simple labeler stuff.
        if (inLabeler instanceof SimpleLabeler){
            myColumnPanel.removeAll();
            SimpleLabeler tempLabeler = (SimpleLabeler) inLabeler;
            myLabeler = null;
            if (myComboOrientation.getItemCount() > tempLabeler.getLabelOrientation()){
                myComboOrientation.setSelectedIndex(tempLabeler.getLabelOrientation());
            }
            if (tempLabeler.getAllowDuplicates()){
                myCheckBoxDuplicates.setSelected(true);
            }
            else{
                myCheckBoxDuplicates.setSelected(false);
            }
            if (tempLabeler.getAllowOverlaps()){
                myCheckBoxOverlaps.setSelected(true);
            }
            else{
                myCheckBoxOverlaps.setSelected(false);
            }
            myTextFieldOffset.setText(""+tempLabeler.getLabelOffset());
            
            // do the multiple labeler stuff
            if (inLabeler instanceof MultipleLabeler){
                myLabeler = (MultipleLabeler) inLabeler;
                myColumnPanel.removeAll();
                myVectEntryPanels.removeAllElements();
                
                int tempNumColumns = myLabeler.getCountLabelColumns();
                for (int i=0; i<tempNumColumns; i++){
                    MyEntryPanel tempPanel = new MultipleLabelerPanel.MyEntryPanel(myColumns, myLabeler.getLabelAttributes(i));
                    myColumnPanel.add(tempPanel);
                    myVectEntryPanels.addElement(tempPanel);
                }
                
                myTextFieldDelimiter.setText(MultipleLabeler.encodeString(myLabeler.getDelimiter()));
            }
        }
    }
    
    /** Retrieve the edited labeler */
    public Labeler getLabeler(){
        // label columns
        if (myLabeler == null) myLabeler = new MultipleLabeler();
        myLabeler.clearLabelColumns();
        for (int i=0; i<myVectEntryPanels.size(); i++){
            MyEntryPanel tempPanel = (MyEntryPanel) myVectEntryPanels.elementAt(i);
            myLabeler.addLabelColumn(
                tempPanel.myComboColumns.getSelectedIndex(), 
                tempPanel.myComboFormat.getSelectedIndex(), 
                tempPanel.myTextFieldPretext.getText(), 
                tempPanel.myTextFieldPosttext.getText());
        }
        
        // label orientation
        myLabeler.setLabelOrientation(myComboOrientation.getSelectedIndex());
        
        // set the offset from the anchor position.
        int tempOffset = 0;
        try{
            tempOffset = Integer.parseInt(myTextFieldOffset.getText());
        }
        catch (NumberFormatException e){
        }
        myLabeler.setLabelOffset(tempOffset);
        
        // the delimiter
        myLabeler.setDelimiter(MultipleLabeler.decodeString(myTextFieldDelimiter.getText()));
        
        // allow duplicates
        if (myCheckBoxDuplicates.isSelected()){
            myLabeler.setAllowDuplicates(true);
        }
        else myLabeler.setAllowDuplicates(false);
        
        // allow overlaps
        if (myCheckBoxOverlaps.isSelected()){
            myLabeler.setAllowOverlaps(true);
        }
        else myLabeler.setAllowOverlaps(false);
        
        // return the configured labeler
        return myLabeler;
    }
    
    /** Set up the user interface elements for this panel. */
    private void initPanel(){
        // populate the entries in the orientation combo
        myComboOrientation.addItem("Center");
        myComboOrientation.addItem("North");
        myComboOrientation.addItem("East");
        myComboOrientation.addItem("South");
        myComboOrientation.addItem("West");
        
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        
        // the label to tell the user which column
        c.gridx = 0;
        c.gridy = 0;
        add(new JLabel("Label Columns"), c);
        
        // The text field
        // Ad the panel to handle multiple columns
        c.gridy++;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTH;
        add(myColumnPanel, c);
        c.weightx = 0;
        c.weighty = 0;
        
        // add the add and remove buttons.
        c.gridy++;
        JPanel tempButtonPanel = new JPanel(new GridLayout(1,2,2,2));
        tempButtonPanel.add(myButtonAdd);
        tempButtonPanel.add(myButtonRemove);
        add(tempButtonPanel, c);
        myButtonAdd.addActionListener(this);
        myButtonRemove.addActionListener(this);
        
        // the label to tell the user which to select an anchor.
        c.gridy++;
        add(new JLabel("Anchor"), c);
        c.gridy++;
        add(myComboOrientation, c);
        
        // The label to tell the user to type in a delimiter.
        c.gridy++;
        add(new JLabel("Delimiter [CR] = new line"), c);
        c.gridy++;
        add(myTextFieldDelimiter, c);
        
        // Offset
        c.gridy++;
        add(new JLabel("Offset in pixels"), c);
        c.gridy++;
        add(myTextFieldOffset, c);
        
        // The checkbox for duplicates
        c.gridy++;
        add(myCheckBoxDuplicates, c);
        
        // The checkbox for overlaps
        c.gridy++;
        add(myCheckBoxOverlaps, c);
    }
    
    /** Set the columns */
    public void setColumns(String[] inColumns){
        if (inColumns == null) inColumns = new String[0];
        myColumns = inColumns;
        
        for (int i=0; i<myVectEntryPanels.size(); i++){
            ((MyEntryPanel) myVectEntryPanels.elementAt(i)).setColumns(myColumns);
        }        
    }
    
    /** Invoked when an action occurs.*/
    public void actionPerformed(ActionEvent inAE) {
        if (inAE.getSource() == myButtonAdd){
            MultipleLabelerPanel.MyEntryPanel tempPanel = new MultipleLabelerPanel.MyEntryPanel(myColumns, null);
            myColumnPanel.add(tempPanel);
            myVectEntryPanels.add(tempPanel);
            validate();
            repaint();
        }
        if (inAE.getSource() == myButtonRemove){
            for (int i=0; i<myVectEntryPanels.size(); i++){
                MultipleLabelerPanel.MyEntryPanel tempPanel = (MultipleLabelerPanel.MyEntryPanel) myVectEntryPanels.elementAt(i);
                if (tempPanel.getSelected() == true){
                    myColumnPanel.remove(tempPanel);
                    myVectEntryPanels.remove(tempPanel);
                    validate();
                    repaint();
                }
            }
        }
    }
    
}
