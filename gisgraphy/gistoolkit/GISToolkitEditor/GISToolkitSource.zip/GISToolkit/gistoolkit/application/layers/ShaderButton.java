/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.util.Vector;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.widgets.*;
import gistoolkit.display.shader.*;

/**
 * Button for modifying the shader attributes.
 * Creation date: (5/2/2001 9:09:11 AM)
 */
public class ShaderButton extends JPanel implements MouseListener{
    
    /**
     * The shader assigned to this button.
     */
    private Shader myShader;
    
    /**
     * Boolean to keep track of where the mouse is.
     */
    private boolean myMouseDown = false;
    
    /**
     * Reference to the GISDisplay.
     */
    private GISDisplay myGISDisplay;
    
    /** Infrastructure to handle action listeners. */
    private Vector myActionListeners = new Vector();
    /** Add an action listener to recieve action events from this button. */
    public void addActionListener(ActionListener inActionListener){myActionListeners.add(inActionListener);}
    /** Remove an action listener from the list of objects to recieve action events. */
    public void removeActionListener(ActionListener inActionListener){myActionListeners.remove(inActionListener);}
    /** Fire an action event. */
    public void fireActionEvent(){
    	ActionEvent tempActionEvent = new ActionEvent(this, 0, getName());
    	for (int i=0; i<myActionListeners.size(); i++){
    		ActionListener tempActionListener = (ActionListener) myActionListeners.elementAt(i);
    		try{
    			tempActionListener.actionPerformed(tempActionEvent);
    		}
    		catch(Exception e){
    			System.out.println("Exception in Event dispatch");
    			e.printStackTrace();
    		}
    	}
    }
    /**
     * ShaderButton constructor comment.
     */
    public ShaderButton() {
        super();
        initPanel();
    }
    
    /**
     * Returns the shader assigned to this button.
     */
    public Shader getShader(){
        return myShader;
    }
    
    /**
     * Set up the button, add the listeners.
     */
    private void initPanel(){
        addMouseListener(this);
    }
    
    /**
     * Mouse clicket required method.
     */
    public void mouseClicked(MouseEvent inME){
    }
    
    /**
     * Mouse clicket required method.
     */
    public void mouseEntered(MouseEvent inME){
    }
    
    /**
     * Mouse clicket required method.
     */
    public void mouseExited(MouseEvent inME){
        myMouseDown = false;
    }
    
    /**
     * Mouse Pressed required method.
     */
    public void mousePressed(MouseEvent inME){
        if (!inME.isPopupTrigger()){
            myMouseDown = true;
        }
    }
    
    /**
     * Mouse releaesed required method.
     */
    public void mouseReleased(MouseEvent inME){
        if ((myMouseDown)&&(!inME.isPopupTrigger())){
            
            // find the parent frame
            Component c = getParent();
            while (! (c instanceof Frame)){
                c = c.getParent();
                if (c == null) break;
            }
            
            // show the dialog
            if (myShader != null){
                if (myShader instanceof EditableShader){
                    GISToolkitDialog tempDialog = new GISToolkitDialog();
                    Container tempPanel = tempDialog.getContentPane();
                    tempPanel.setLayout(new BorderLayout());
                    ShaderPanel tempEditPanel = ((EditableShader) myShader).getEditPanel();
                    tempPanel.add(tempEditPanel, BorderLayout.CENTER);
                    tempDialog.setLocationRelativeTo(this);
                    tempDialog.setTitle("Edit Shader");
                    tempDialog.setModal(true);
                    tempDialog.setVisible(true);
                    tempDialog.pack();
                    if (tempDialog.isOK()){
                        myShader = tempEditPanel.getShader();
                        if (myGISDisplay != null){
                            myGISDisplay.update(myGISDisplay.getGraphics());
                        }
                    }
                }
            }
            
            // set the mouse down to false
            myMouseDown = false;
        }
    }
    
    /**
     * Overloaded draw function to draw the representation on the screen.
     */
    public void paint(Graphics inGraphics){
        super.paint(inGraphics);
        
        if (myShader != null){
            // save the color
            Color tempColor = inGraphics.getColor();
            
            // draw the fill
            Graphics tempGraphics = myShader.getFillGraphics(inGraphics, null, null);
            if (tempGraphics != null){
                tempGraphics.fillRect(2,2, getWidth()-4,getHeight()-4);
            }
            
            // draw the border
            tempGraphics = myShader.getLineGraphics(inGraphics, null, null);
            if (tempGraphics != null){
                tempGraphics.drawRect(2,2, getWidth()-4,getHeight()-4);
            }
            
            // reset the color
            inGraphics.setColor(tempColor);
        }
    }
    
    /**
     * Set the GISDisplay associated with this layer.
     */
    public void setGISDisplay(GISDisplay inDisplay){
        myGISDisplay = inDisplay;
    }
    
    /**
     * Set the shader assigned to this button;
     */
    public void setShader(Shader inShader){
        myShader = inShader;
    }
}