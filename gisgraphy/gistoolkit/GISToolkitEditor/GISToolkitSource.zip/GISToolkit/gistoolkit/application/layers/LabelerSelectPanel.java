/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.datasources.*;
import gistoolkit.display.*;
import gistoolkit.display.labeler.*;
import gistoolkit.application.layers.labelerpanel.*;
/**
 * Allows the user to update and modify the labelers assigned to a projection.
 */
public class LabelerSelectPanel extends JPanel implements ItemListener {

    /** Creates new LabelerSelectPanel */
    public LabelerSelectPanel() {
        initPanel();
    }

    /** Choice of the labelers that I know about */
    private JComboBox myComboLabelers = new JComboBox();
    private Labeler[] myLabelers = {
        new FeatureLabeler(),
        new MultipleLabeler()
    };
    
    private LabelerPanel[] myLabelerEditPanels = {
        new FeatureLabelerPanel(),
        new MultipleLabelerPanel()
    };
    
    /** Panel on which to display the edit panel for this Projection */
    private JPanel myDisplayPanel = new JPanel();
    private JLabel myLabelNotEditable = new JLabel("Non Editable Labeler");
    
    /** Handle events coming from the combo box */
    public void itemStateChanged(java.awt.event.ItemEvent p1) {
        Labeler tempLabeler = (Labeler) myComboLabelers.getSelectedItem();
        myDisplayPanel.removeAll();
        if (myLabelerPanel != null){
            myDisplayPanel.remove(myLabelerPanel);
        }
        boolean tempFound = false;
        for (int i=0; i<myLabelers.length; i++){
            if (tempLabeler == myLabelers[i]){
                myLabelerPanel = myLabelerEditPanels[i];
                myDisplayPanel.add( myLabelerPanel, BorderLayout.CENTER);
                tempFound = true;
                break;
            }
        }
        if (!tempFound){
            myLabelerPanel = null;
            myDisplayPanel.add(myLabelNotEditable, BorderLayout.CENTER);
        }
        myDisplayPanel.validate();
        myDisplayPanel.repaint();
       
    }
    
    /** set up the display properties for this panel */
    private void initPanel(){
        setLayout(new BorderLayout());
        add(myComboLabelers, BorderLayout.NORTH);
        
        // populate the combo box
        for (int i=0; i<myLabelers.length; i++){
            myComboLabelers.addItem(myLabelers[i]);
        }
        
        add(myDisplayPanel, BorderLayout.CENTER);
        myDisplayPanel.setLayout(new BorderLayout());        
        myComboLabelers.addItemListener(this);        
        myComboLabelers.setSelectedIndex(0);
    }
    
    /** Reference to the labeler panel to use to edit this labeler */
    private LabelerPanel myLabelerPanel = null;
    
    /** The labeler currently editing */
    private Labeler myLabeler = null;

    /** Layer Currently editing */
    private Layer myLayer = null;
    
    /** Set the layer to edit */
    public void setLayer(Layer inLayer){
        if (inLayer != null){
            Style tempStyle = inLayer.getStyle();
            if (tempStyle != null){
                if (tempStyle.getNumLabelers() > 0){
                    myLabeler = tempStyle.getLabeler(0);
                    String tempString = myLabeler.getClass().getName();
                    
                    // find the names of the columns
                    String[] tempColumnNames = new String[0];
                    GISDataset tempDataset = inLayer.getDataset();
                    if (tempDataset != null){
                        tempColumnNames = tempDataset.getAttributeNames();
                    }
               
                    // look for the labeler in question.
                    for (int i=0; i<myComboLabelers.getItemCount(); i++){
                        String tempClassString = myComboLabelers.getItemAt(i).getClass().getName();
                        if (tempClassString.equals(tempString)){
                            myComboLabelers.setSelectedIndex(i);
                            itemStateChanged(null);
                            if (myLabelerPanel != null){
                                myLabelerPanel.setLabeler(myLabeler);                                
                            }
                        }
                        myLabelerEditPanels[i].setColumns(tempColumnNames);
                    }
                    myLayer = inLayer;
                }
            }
        }
    }
    
    /** Retrieve the edited Layer from the dialog */
    public Layer getLayer(){
        if (myLayer != null){
            Style tempStyle = myLayer.getStyle();
            if (tempStyle != null){
                if (myLabelerPanel != null){
                    tempStyle.setLabeler(0, myLabelerPanel.getLabeler());
                }
            }
        }
        return myLayer;
    }    
}
