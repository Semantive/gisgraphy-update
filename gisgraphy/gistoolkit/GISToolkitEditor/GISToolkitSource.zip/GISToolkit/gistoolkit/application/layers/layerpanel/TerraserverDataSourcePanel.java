/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.layerpanel;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.GISDisplay;
import gistoolkit.datasources.*;
import gistoolkit.datasources.terraserver.*;
import gistoolkit.application.*;
import gistoolkit.application.layers.*;
/**
 * A panel for entering the information associated with connecting to terraserver.
 * @author  ithaqua
 */
public class TerraserverDataSourcePanel extends JPanel implements  DataSourcePanel, ActionListener{
    /**
     * Text field to allow the user to type the location directly.
     */
    private JTextField myTextFieldLocation = new JTextField("http://terraserver-usa.com/tile.ashx");
    
    /** Allows the user to select the meter resolution to use with the imagery */
    private JComboBox myChoiceResolution = new JComboBox();
    
    /** Allows the user to select the DOQ type of image they want to view */
    private JRadioButton myRadioButtonDOQ = new JRadioButton("DOQ", true);
    
    /** Allows the user to select the DRG type of image they want to view */
    private JRadioButton myRadioButtonDRG = new JRadioButton("DRG", false);
    
    /** Allows the user to select the number of tiles to keep in memory */
    private JTextField myTextFieldCache = new JTextField("20");
    
    /** Allows the user to select the location for caching of tiles */
    private JTextField myTextFieldCacheDirectory = new JTextField("C:\\temp");
    
    /** Allows the user to select the optimization for the terraserver projection transformation */
    private JTextField myTextFieldOptimization = new JTextField("100");
    
    /** Creates new TerraserverDataSourcePanel */
    public TerraserverDataSourcePanel() {
        initPanel();
    }
    
    /** Set up the user interface elements of this panel */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        
        // create the type in box for the filename
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        JLabel tempLabelFile = new JLabel("Web URL Base for Terraserver");
        add(tempLabelFile, c);
        
        c.gridy++;
        c.weightx = 1;
        add(myTextFieldLocation, c);
        myTextFieldLocation.setText(System.getProperty(Constants.getApplicationName()+"."+LOCATION_TAG, myTextFieldLocation.getText()));
        
        // create the radio buttons for the type of imagery
        ButtonGroup tempGroup = new ButtonGroup();
        c.gridy++;
        add(myRadioButtonDOQ, c);
        myRadioButtonDOQ.addActionListener(this);        
        tempGroup.add(myRadioButtonDOQ);
        
        c.gridy++;
        add(myRadioButtonDRG, c);
        myRadioButtonDRG.addActionListener(this);
        tempGroup.add(myRadioButtonDRG);
        
        String tempString = System.getProperty(Constants.getApplicationName()+"."+IMAGETYPE_TAG, "DOQ");
        if (tempString.equalsIgnoreCase("DOQ")) myRadioButtonDOQ.setSelected(true);
        else myRadioButtonDRG.setSelected(true);

        // create the combo box for the resolution to use
        c.gridy++;
        JLabel tempLabelResolution = new JLabel("Image Resolution to use in Meters");
        add(tempLabelResolution, c);
        
        c.gridy++;
        add(myChoiceResolution, c);
        String tempResolution = System.getProperty(Constants.getApplicationName()+"."+RESOLUTION_TAG, "0");
        
        // add the items to the list of available resolutions
        int[] tempResolutions = TerraserverDataSource.getDOQResolutions();
        int tempSelectedIndex = 0;
        myChoiceResolution.addItem("0");
        for (int i=0; i<tempResolutions.length; i++){
            tempString = ""+tempResolutions[i];
            myChoiceResolution.addItem(tempString);
            if (tempString.equalsIgnoreCase(tempResolution)){
                tempSelectedIndex = i+1;
            }
        }
        myChoiceResolution.setSelectedIndex(tempSelectedIndex);
                
        // the number of tiles to keep in memory
        c.gridx = 0;
        c.gridy++;
        add(new JLabel("Number of tiles to keep in memory"), c);
        c.gridy++;
        add(myTextFieldCache, c);
        myTextFieldCache.setText(System.getProperty(Constants.getApplicationName()+"."+CACHESIZE_TAG, myTextFieldCache.getText()));
        
        // The location of the disk cache directory
        c.gridy++;
        add(new JLabel("Directory to cache tiles to "), c);
        c.gridy++;
        add(myTextFieldCacheDirectory, c);
        myTextFieldCacheDirectory.setText(System.getProperty(Constants.getApplicationName()+"."+CACHELOCATION_TAG, myTextFieldCacheDirectory.getText()));
        
        // The amount of optimization to use
        c.gridx = 0;
        c.gridy++;
        add(new JLabel("Optimization level to use"), c);
        c.gridy++;
        add(myTextFieldOptimization, c);
        myTextFieldOptimization.setText(System.getProperty(Constants.getApplicationName()+"."+OPTIMIZATION_TAG, myTextFieldOptimization.getText()));
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weighty = 1;
        add(new JPanel(), c);        
    }
    
     /** Constants for the initialization parameters. */
    private static final String LOCATION_TAG = "TerraserverFileLocation";
    private static final String IMAGETYPE_TAG = "TerraserverFileImageType";
    private static final String RESOLUTION_TAG = "TerraserverResolution";
    private static final String CACHESIZE_TAG = "TerraserverMemoryCacheSize";
    private static final String CACHELOCATION_TAG = "TerraserverDiskCacheLocation";
    private static final String OPTIMIZATION_TAG = "TerraserverOptimizationLevel";
    
   
    /**
     * Return the fully configured datasource.
     */
    public DataSource getDataSource() throws Exception {
        TerraserverDataSource tempDataSource = new TerraserverDataSource();
        tempDataSource.setName("Terraserver");
        tempDataSource.setURLBase(myTextFieldLocation.getText());
        String tempType = "DRG";
        if (myRadioButtonDOQ.isSelected()){
            tempType = "DOQ";
            tempDataSource.setImageType(TerraserverDataSource.DOQ);
        }
        else tempDataSource.setImageType(TerraserverDataSource.DRG);
        tempDataSource.setResolution(Integer.parseInt((String) myChoiceResolution.getSelectedItem()));
        tempDataSource.setMemoryCache(Integer.parseInt((String) myTextFieldCache.getText()));
        tempDataSource.setDiskCache(myTextFieldCacheDirectory.getText());
        tempDataSource.setOptimization(Integer.parseInt(myTextFieldOptimization.getText()));
        
        //Save the configuration information.
        System.getProperties().setProperty(Constants.getApplicationName()+"."+LOCATION_TAG, tempDataSource.getURLBase());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+IMAGETYPE_TAG, tempType);
        System.getProperties().setProperty(Constants.getApplicationName()+"."+RESOLUTION_TAG, (String) myChoiceResolution.getSelectedItem());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+CACHESIZE_TAG, ""+tempDataSource.getMemoryCache());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+CACHELOCATION_TAG, tempDataSource.getDiskCache());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+OPTIMIZATION_TAG, ""+tempDataSource.getOptimization());

        return tempDataSource;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent p1) {
        // add the items to the list of available resolutions
        int[] tempResolutions = null;
        if (myRadioButtonDOQ.isSelected()){
            tempResolutions = TerraserverDataSource.getDOQResolutions();
        }
        else{
            tempResolutions = TerraserverDataSource.getDRGResolutions();
        }
        int tempSelectedIndex = 0;
        myChoiceResolution.removeAllItems();
        myChoiceResolution.addItem("0");
        for (int i=0; i<tempResolutions.length; i++){
            String tempString = ""+tempResolutions[i];
            myChoiceResolution.addItem(tempString);
        }
    }    
    
    /**
     * Sets the GISDisplay in case the panel should need it.
     */
    public void setGISDisplay(GISDisplay inDisplay) {
    }
    
}
