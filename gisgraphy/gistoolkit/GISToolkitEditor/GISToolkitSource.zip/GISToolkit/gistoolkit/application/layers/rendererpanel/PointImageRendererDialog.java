/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.rendererpanel;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.widgets.*;
import gistoolkit.display.renderer.*;
import gistoolkit.display.renderer.images.ImageSource;

/**
 * Panel for editing the Point Image Renderer.
 */
public class PointImageRendererDialog extends JDialog{
    
    /** Combo for selecting the images so far. */
    private JComboBox myComboImages = new JComboBox();
    private String[] myIconList = {
        "house.png",
        "city.png",
        "blackcross.png",
        "bluecross.png",
        "redcross.png",
        "blackx.png",
        "redx.png",
        "bluex.png",
        "smilie.png"
    };
    
    /** Pointer to the PointImageRenderer. */
    private PointImageRenderer myPointImageRenderer = null;
    /** Set the renderer in the dialog */
    public void setPointImageRenderer(PointImageRenderer inRenderer){
        String tempImagePath = inRenderer.getImageFileName();
        if (tempImagePath == null){
            myTextFieldLocation.setText("");

            // set the default image
            ImageSource tempImageSource = new ImageSource();
            myImagePath = myIconList[0];
            myImagePanel.setImage(tempImageSource.getImage(myImagePath));
        }
        else{
            myImagePath = tempImagePath;
            boolean tempFound = false;
            for (int i=0; i<myIconList.length; i++){
                if (myIconList[i].equals(tempImagePath)) {
                    tempFound = true;
                    myComboImages.setSelectedIndex(i);
                }
            }
            if(!tempFound) myTextFieldLocation.setText(myImagePath);
            myImagePanel.setImage(inRenderer.getImage());
        }
        myPointImageRenderer = inRenderer;
    }
    /** Return the edited point image renderer. */
    public PointImageRenderer getPointImageRenderer(){return myPointImageRenderer;}
    
    /** Path to the image. */
    private String myImagePath = null;
    
    private class MyListener implements ActionListener, ItemListener{
        /**
         * Save the file chooser for future reference
         */
        private JFileChooser myChooser = new JFileChooser();
        
        public void actionPerformed(java.awt.event.ActionEvent inAE) {
            if (inAE.getSource() == myButtonCancel){
                dispose();
            }
            if (inAE.getSource() == myButtonOK){
                if (myPointImageRenderer != null){
                    try{
                        myPointImageRenderer.setImage(myImagePath);
                        dispose();
                    }
                    catch (Exception e){
                        JOptionPane.showMessageDialog(getthis(), ""+e, "Error", JOptionPane.ERROR_MESSAGE);
                        e.printStackTrace();
                    }
                }
                else{
                    dispose();
                }
            }
            if (inAE.getSource() == myButtonLocation){
                if (myChooser == null){
                    myChooser = new JFileChooser();
                }
                String tempString = myTextFieldLocation.getText();
                if ((tempString != null) && (tempString.length() >0)){
                    File tempFile = new File(tempString);
                    if (tempFile.exists()){
                        if (tempFile.isDirectory()){
                            myChooser.setCurrentDirectory(tempFile);
                        }
                        if (tempFile.isFile()){
                            myChooser.setSelectedFile(tempFile);
                        }
                    }
                }

                int returnVal = myChooser.showOpenDialog(getthis());

                if(returnVal == JFileChooser.APPROVE_OPTION) {                
                    String tempFile = myChooser.getSelectedFile().getAbsolutePath();
                    myTextFieldLocation.setText(tempFile);
                    try{
                        myImagePanel.setImage(Toolkit.getDefaultToolkit().createImage(tempFile));
                        myImagePath = tempFile;
                    }
                    catch(Exception e){
                    }
                }
            }
        }
                
        public void itemStateChanged(java.awt.event.ItemEvent itemEvent) {
            // retreave the image
            ImageSource tempImageSource = new ImageSource();
            myImagePath = myIconList[myComboImages.getSelectedIndex()];
            myImagePanel.setImage(tempImageSource.getImage(myImagePath));
        }
        
    }
    private MyListener myListener = new MyListener();
    private JDialog getthis(){return this;}
        
    
    /**
     * Text field to allow the user to type the location directly.
     */
    private JTextField myTextFieldLocation;
    
    /**
     * Button for looking up a location.
     */
    private JButton myButtonLocation;
    
    /** The OK Button. */
    private JButton myButtonOK = new JButton("OK");
    /** The Cancel Button. */
    private JButton myButtonCancel = new JButton("Cancel");
    
    /**
     * Image panel for displaying the selected images.
     */
    private ImagePanel myImagePanel = new ImagePanel();
    
    
    /** Creates new PointImageRendererPanel */
    public PointImageRendererDialog() {
        initPanel();
    }
    
    /** laye out the gui widgets on the panel. */
    public void initPanel(){
        setTitle("Select Point Image");
        JPanel tempPanel = new JPanel();
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        c.weighty = 0;
        
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 3;
        tempPanel.add(myComboImages, c);
        ImageSource tempImageSource = new ImageSource();
        for (int i=0; i<myIconList.length; i++){
            myComboImages.addItem(tempImageSource.getIcon(myIconList[i]));
        }
        myComboImages.addItemListener(myListener);
        c.gridwidth = 1;
        
        // create the type in box for the filename
        c.gridx = 0;
        c.gridy++;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0;
        JLabel tempLabelFile = new JLabel("File");
        tempPanel.add(tempLabelFile, c);
        
        c.gridx++;
        c.weightx = 1;
        myTextFieldLocation = new JTextField();
        tempPanel.add(myTextFieldLocation, c);
        
        c.gridx++;
        c.weightx = 0;
        myButtonLocation = new JButton("Browse");
        tempPanel.add(myButtonLocation, c);
        myButtonLocation.addActionListener(myListener);
        
        // add the image panel for displaying the selected image
        c.gridx = 0;
        c.gridy ++;
        c.weighty = 1;
        c.gridwidth = 3;
        JScrollPane tempScrollPane = new JScrollPane(myImagePanel);
        tempPanel.add(tempScrollPane, c);
        
        // add the OK and cancel buttons
        c.gridy++;
        c.gridx = 0;
        c.gridwidth = 3;
        c.weightx = 0;
        c.weighty = 0;
        c.fill = GridBagConstraints.VERTICAL;
        c.anchor = GridBagConstraints.EAST;
        JPanel tempButtonPanel = new JPanel(new GridLayout(1,2,2,2));
        tempButtonPanel.add(myButtonOK);
        myButtonOK.addActionListener(myListener);
        tempButtonPanel.add(myButtonCancel);
        myButtonCancel.addActionListener(myListener);
        tempPanel.add(tempButtonPanel, c);
        setContentPane(tempPanel);
        Dimension d = getToolkit().getScreenSize();
        Dimension s = getSize();
        setLocation(d.width/2 - s.width/2, d.height/2-s.height/2);        
    }
    
    public static void main(String[] inArgs){
        PointImageRendererDialog tempDialog = new PointImageRendererDialog();
        tempDialog.setModal(true);
        tempDialog.show();
        System.exit(0);
    }
}
