/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.projection.*;
import gistoolkit.display.*;
/**
 * Allows the user to select the projection they would like applied to this layer.
 * @author  ithaqua
 */
public class ProjectionSelectPanel extends JPanel implements ItemListener{
    
    /** Determines which projection this panel will modify. */
    private boolean myToProjection = true;
    
    /** Creates new ProjectionSelectPanel */
    public ProjectionSelectPanel() {
        initPanel();
    }
    
    /** An internal class to wrap the projection so it displays correctly in the combo box.*/
    private class ProjectionWrapper {
        public Projection myProjection = null;
        public Projection getProjection(){return myProjection;}
        public ProjectionWrapper(Projection inProjection){
            myProjection = inProjection;
        }
        
        /** The to string function is the whole purpose */
        public String toString(){
            if (myProjection == null) return "Null Projeciton";
            else return myProjection.getProjectionName();
        }
    }
    
    /** Creates new ProjectionSelectPanel to modify the to projection(true), or from projection(false)*/
    public ProjectionSelectPanel(boolean inToProjection) {
        myToProjection = inToProjection;
        initPanel();
    }
    
    /** Choice of the projections that I know about */
    private JComboBox myComboProjections = new JComboBox();
    
    /** Vector to contain the Projections */
    private Vector myVectProjections = new Vector();
    
    /** Panel to keep so it can be removed */
    private Component myCurrentComponent = null;
    
    /** respond to Item events from the JComboBox */
    public void itemStateChanged(ItemEvent inIE){
        Projection tempProjection = ((ProjectionWrapper) myComboProjections.getSelectedItem()).getProjection();
        if (myCurrentComponent != null) remove(myCurrentComponent);
        if (tempProjection instanceof EditableProjection){
            myCurrentComponent = ((EditableProjection) tempProjection).getEditPanel();
        }
        else {
            myCurrentComponent = new JLabel("Uneditable Projection");
        }
        add( myCurrentComponent, BorderLayout.CENTER);
        validate();
    }
    
    /** initialize the use interface components for this panel */
    private void initPanel(){
        setLayout(new BorderLayout());
        add(myComboProjections, BorderLayout.NORTH);
        
        // populate the choice of projections.
        myComboProjections.addItem(new ProjectionWrapper(new NoProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new AlbersEqualAreaProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new LambertConicConformalProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new UniversalTransverseMercatorProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new BritishNationalGridProjection()));
        myComboProjections.setSelectedIndex(0);
        itemStateChanged(null);
        
        myComboProjections.addItemListener(this);
    }
    
    /** Hold a reference to the currently edited layer */
    private Layer myLayer = null;
    
    /** set the layer to be edited */
    public void setLayer(Layer inLayer){
        if (inLayer == null) return;
        myLayer = inLayer;
        Projection tempProjection = null;
        if (myToProjection){
            tempProjection = myLayer.getProjection();
        }
        else{
            tempProjection = myLayer.getFromProjection();
        }
        if (tempProjection == null) return;
        
        String tempInProjectionClass = tempProjection.getClass().getName();
        boolean tempFound = false;
        for (int i=0; i<myComboProjections.getItemCount(); i++){
            Projection tempTestProjection = ((ProjectionWrapper) myComboProjections.getItemAt(i)).getProjection();
            String tempString = tempTestProjection.getClass().getName();
            if (tempInProjectionClass.equals(tempString)){
                myComboProjections.removeItemAt(i);
                myComboProjections.insertItemAt(new ProjectionWrapper(tempProjection), i);
                myComboProjections.setSelectedIndex(i);
                tempFound = true;
                itemStateChanged(null);
            }            
        }
        if (!tempFound){
            myComboProjections.addItem(new ProjectionWrapper(tempProjection));
            myComboProjections.setSelectedIndex(myComboProjections.getItemCount()-1);
            itemStateChanged(null);
        }
    }
    
    /** get the layer after it has been edited */
    public Layer getLayer()throws Exception{
        if (myLayer == null) return null;
        Projection tempProjection = null;
        if (myCurrentComponent instanceof ProjectionPanel){
            tempProjection =  ((ProjectionPanel) myCurrentComponent).getProjection();
        }
        else{
            tempProjection = ((ProjectionWrapper) myComboProjections.getSelectedItem()).getProjection();
        }
        if (myToProjection){
            myLayer.setProjection(tempProjection, true);
        }
        else{
            myLayer.setFromProjection(tempProjection);
        }
        return myLayer;
    }
    
    /** get the selected projection. */
    public Projection getProjection(){
        if (myCurrentComponent instanceof ProjectionPanel){
            Projection tempProjection =  ((ProjectionPanel) myCurrentComponent).getProjection();
            return tempProjection;
        }
        return ((ProjectionWrapper) myComboProjections.getSelectedItem()).getProjection();
    }
}
