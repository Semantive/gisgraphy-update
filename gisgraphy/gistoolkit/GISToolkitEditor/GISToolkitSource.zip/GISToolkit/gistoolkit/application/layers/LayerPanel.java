/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.datasources.DataSource;

/**
 * Managers the layers involved in the map, by containing the LayerEntryPanels.
 * Creation date: (4/30/2001 4:09:40 PM)
 */
public class LayerPanel extends javax.swing.JPanel {
    private GISDisplay myGISDisplay;
    
    // static
    private static final String NEW = "New";
    private static final String MODIFY = "Modify";
    private static final String DELETE = "Delete";
    
    // Panel for displaying the layers
    private JPanel myLayerPanel;
    
    // Vector for storeing the layers
    private Vector myLayerVect = new Vector();
    
    // The datasource created by the panel.
    private DataSource myDataSource = null;
    
    /**
     * LayerPanel constructor comment.
     */
    public LayerPanel() {
        super();
        initPanel();
    }
    
    /**
     * LayerPanel constructor comment.
     * @param layout java.awt.LayoutManager
     */
    public LayerPanel(java.awt.LayoutManager layout) {
        super(layout);
        initPanel();
    }
    
    /**
     * LayerPanel constructor comment.
     * @param layout java.awt.LayoutManager
     * @param isDoubleBuffered boolean
     */
    public LayerPanel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
        super(layout, isDoubleBuffered);
        initPanel();
    }
    
    /**
     * LayerPanel constructor comment.
     * @param isDoubleBuffered boolean
     */
    public LayerPanel(boolean isDoubleBuffered) {
        super(isDoubleBuffered);
        initPanel();
    }
    
    /**
     * returns the datasource created when the OK button was pressed.
     */
    public DataSource getDataSource(){
        return myDataSource;
    }
    
    /**
     * Insert the method's description here.
     * Creation date: (4/30/2001 4:17:40 PM)
     * @return gistoolkit.display.GISDisplay
     */
    public GISDisplay getGISDisplay() {
        return myGISDisplay;
    }
    
    /**
     * Panel to manage layers.
     * Creation date: (4/30/2001 4:10:15 PM)
     */
    private void initPanel() {
        setLayout(new BorderLayout());
        
        // create a panel for the layer panels
        myLayerPanel = new JPanel(new GridBagLayout());
        add(myLayerPanel, BorderLayout.CENTER);
        
    }
    
    /**
     * Refresh the display from the GISDisplay
     */
    public void refresh(){
        if (myGISDisplay != null){
            myLayerPanel.removeAll();
            myLayerVect.removeAllElements();
            myLayerPanel.setLayout(new GridBagLayout());
            Layer tempLayers[] = myGISDisplay.getLayers();
            GridBagConstraints c = new GridBagConstraints();
            c.weightx = 1;
            c.gridx= 0;
            c.fill = GridBagConstraints.BOTH;
            for (int i=tempLayers.length-1; i>=0; i--){
                c.gridy++;
                LayerEntryPanel tempEntryPanel = new LayerEntryPanel(tempLayers[i], this);
                tempEntryPanel.setGISDisplay(myGISDisplay);
                myLayerPanel.add(tempEntryPanel, c);
                myLayerVect.add(tempEntryPanel);
                if (tempLayers[i] == myGISDisplay.getSelectedLayer()){
                    select(tempEntryPanel);
                    tempEntryPanel.setSelected(true);
                }
            }
            c.gridy++;
            c.weighty = 1;
            c.gridx = 0;
            myLayerPanel.add(new JPanel(), c);
            getParent().validate();
        }
    }
    
    /**
     * Insert the method's description here.
     * Creation date: (4/30/2001 4:17:40 PM)
     * @param newGISDisplay gistoolkit.display.GISDisplay
     */
    public void setGISDisplay(GISDisplay newGISDisplay) {
        myGISDisplay = newGISDisplay;
        refresh();
    }
    
    /**
     * Move the layer down in the display
     */
    protected void moveDown(LayerEntryPanel inLayerEntryPanel){
        if (inLayerEntryPanel == null) return;
        
        // Move the layer down in the display.
        Layer tempLayer = inLayerEntryPanel.getLayer();
        myGISDisplay.moveLayerDown(tempLayer);
        refresh();
    }
    
    /**
     * Remove the layer from the display.
     */
    protected void moveUp(LayerEntryPanel inLayerEntryPanel){
        if (inLayerEntryPanel == null) return;
        
        // Move the layer up in the display.
        Layer tempLayer = inLayerEntryPanel.getLayer();
        myGISDisplay.moveLayerUp(tempLayer);
        refresh();
    }
    
    /**
     * Remove the layer from the display.
     */
    protected void remove(LayerEntryPanel inLayerEntryPanel){
        if (inLayerEntryPanel == null) return;
        
        // remove the layer from the display.
        Layer tempLayer = inLayerEntryPanel.getLayer();
        myGISDisplay.removeLayer(tempLayer);
        refresh();
    }
    
    /**
     * Called when the layer entry panel has been selected.
     */
    protected void select(LayerEntryPanel inLayerEntryPanel){
        for (int i=0; i<myLayerVect.size(); i++){
            LayerEntryPanel tempPanel = (LayerEntryPanel) myLayerVect.elementAt(i);
            if (tempPanel != inLayerEntryPanel){
                tempPanel.setSelected(false);
            }
            else{
                myGISDisplay.setSelectedLayer(tempPanel.getLayer());
            }
        }
    }
}