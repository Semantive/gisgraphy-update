/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.layerpanel.filterpanel;

import java.util.*;
import gistoolkit.datasources.filter.*;


/**
 * Class to create date filters.
 */
public class DateFilterPanel extends SimpleAttributeFilterPanel{
    
    /** Create a new DateFilterPanel. */
    public DateFilterPanel(){
        super();
        setValueLabel("Date in YYYY-MM-DD hh:mm:ss format.");
    }
    
    /** Set a filter to be used as the template.  */
    public void setFilter(Filter inFilter) {
        if (inFilter instanceof DateAttributeFilter){
            DateAttributeFilter tempFilter = (DateAttributeFilter) inFilter;
            
            // set the attribute
            String tempAttributeName = tempFilter.getAttributeName();
            setAttributeName(tempAttributeName);
            
            // set the comparison.
            int tempComparison = tempFilter.getComparison();
            setComparison(tempComparison);
            
            // set the value. in YYYY-MM-DD hh:mm:ss
            Date tempDate = (Date)tempFilter.getAttributeValue(); 
            Calendar c = Calendar.getInstance();
            c.setTime(tempDate);
            int tempYear = c.get(Calendar.YEAR);
            int tempMonth = c.get(Calendar.MONTH) + 1;
            int tempDay = c.get(Calendar.DAY_OF_MONTH);
            int tempHour = c.get(Calendar.HOUR_OF_DAY);
            int tempMin = c.get(Calendar.MINUTE);
            int tempSecond = c.get(Calendar.SECOND);
            String tempString = ""+tempYear+"-"+tempMonth+"-"+tempDay+" "+tempHour+":"+tempMin+":"+tempSecond;
            setTextField(tempString);
        }
    }
    
    /** Retrieve the configured filter from the filter panel.  */
    public Filter getFilter() throws Exception{
        // attribute name
        String tempAttributeName = getAttributeName();
        
        // comparison
        int tempComparison = getComparison();
        
        // Value
        String tempValue = getTextField();
        
        // convert to date
        java.text.SimpleDateFormat tempDateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date tempDate = tempDateFormat.parse(tempValue);
        
        // create the filter
        DateAttributeFilter tempFilter = new DateAttributeFilter(tempAttributeName, tempComparison, tempDate);
        tempFilter.setFilterName(tempFilter.createFilterName());
        return tempFilter;
    }
}
