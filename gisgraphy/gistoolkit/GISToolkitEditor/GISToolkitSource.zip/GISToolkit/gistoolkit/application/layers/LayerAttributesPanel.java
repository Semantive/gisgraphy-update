/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.*;
/**
 * Panel to handle the attributes of layers, zoom ranges for example.
 * @author  ithaqua
 */
public class LayerAttributesPanel extends JPanel {

    /** Creates new LayerAttributesPanel */
    public LayerAttributesPanel() {
        initPanel();
    }

    /** Sets the name of the layer */
    private JTextField myTextFieldName = new JTextField();
    
    /** Allows the entry of a maximum distance in the zoom range */
    private JTextField myTextFieldMaxDistance = new JTextField();
    
    /** Allows the entry of a minimum distance to the zoom range */
    private JTextField myTextFieldMinDistance = new JTextField();
    
    /** Allows the entry of a maximum label distance in the zoom range */
    private JTextField myTextFieldMaxLabelDistance = new JTextField();
    
    /** Allows the entry of a minimum label distance to the zoom range */
    private JTextField myTextFieldMinLabelDistance = new JTextField();

    /** Determines if this layer is visible */
    private JCheckBox myCheckboxVisible = new JCheckBox("Visible");
    
    /** set up the User interface for this panel */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.fill = GridBagConstraints.BOTH;
        
        // the name of the text field
        c.gridx = 0;
        c.gridy = 0;
        add(new JLabel("Layer Name:"), c);
        c.gridx = 1;
        add(myTextFieldName, c);
        
        // the maximum and minimum zoom ranges
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(new JLabel("Zoom Ranges for display"), c);
        
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = 1;
        add(new JLabel("Maximum = "), c);
        c.gridx = 1;
        add(myTextFieldMaxDistance, c);
        
        c.gridx = 0;
        c.gridy++;
        add(new JLabel("Minimum = "), c);
        c.gridx = 1;
        add(myTextFieldMinDistance, c);
        
        // maximum and minimum label ranges
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(new JLabel("Zoom Ranges for labeling"), c);
        
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = 1;
        add(new JLabel("Maximum = "), c);
        c.gridx = 1;
        add(myTextFieldMaxLabelDistance, c);
        
        c.gridx = 0;
        c.gridy++;
        add(new JLabel("Minimum = "), c);
        c.gridx = 1;
        add(myTextFieldMinLabelDistance, c);
        
        // the visible flag
        c.gridx = 0;
        c.gridy++;
        add(myCheckboxVisible, c);
        
        // Some space
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weightx = 1;
        c.weighty = 1;
        add(new JPanel(), c);
    }
    
    /** The layer currently being edited */
    private Layer myLayer = null;
    
    /** set the layer in the display and populates the user interface with the attributes of the layer.*/
    public void setLayer(Layer inLayer){
        if (inLayer == null) return;
        myLayer = inLayer;
        myCheckboxVisible.setSelected(inLayer.isVisible());
        myTextFieldName.setText(inLayer.getLayerName());
        myTextFieldMaxDistance.setText(""+inLayer.getMaxDistance());
        myTextFieldMinDistance.setText(""+inLayer.getMinDistance());
        myTextFieldMaxLabelDistance.setText(""+inLayer.getMaxLabelDistance());
        myTextFieldMinLabelDistance.setText(""+inLayer.getMinLabelDistance());
    }
    
    /** Retrieves the layer from the panel, populating it's attributes bassed on those entered */
    public Layer getLayer(){
        if (myLayer == null) return null;
        myLayer.setVisible(myCheckboxVisible.isSelected());
        myLayer.setLayerName(myTextFieldName.getText());
        myLayer.setMaxDistance(Double.parseDouble(myTextFieldMaxDistance.getText()));
        myLayer.setMinDistance(Double.parseDouble(myTextFieldMinDistance.getText()));
        myLayer.setMaxLabelDistance(Double.parseDouble(myTextFieldMaxLabelDistance.getText()));
        myLayer.setMinLabelDistance(Double.parseDouble(myTextFieldMinLabelDistance.getText()));
        return myLayer;
    }
}
