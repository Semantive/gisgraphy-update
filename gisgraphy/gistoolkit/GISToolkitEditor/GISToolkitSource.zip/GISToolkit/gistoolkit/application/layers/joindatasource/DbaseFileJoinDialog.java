/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.application.layers.joindatasource;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.shapefile.*;
import gistoolkit.application.*;

/**
 * Class for creating a Dbase 3 join to an existing data source.
 */
public class DbaseFileJoinDialog extends gistoolkit.display.widgets.GISToolkitDialog{
    // Database columns
    private JTextField myTextFieldDBaseFileName = new JTextField(".dbf");
    private String getDbaseFileName(){return myTextFieldDBaseFileName.getText();}
    
    // Join columns
    private JTextField myTextFieldJoinSource = new JTextField("SourceColumn");
    private String getJoinSourceColumn(){return myTextFieldJoinSource.getText();}
    private JTextField myTextFieldJoinDestination = new JTextField("DestinationColumn");
    private String getJoinDestinationColumn(){return myTextFieldJoinDestination.getText();}
    private JCheckBox myCheckboxCache = new JCheckBox("Cache Source");
    private boolean getCacheSource(){return myCheckboxCache.isSelected();}
    
    /** Creates new DB2Query */
    public DbaseFileJoinDialog() {
        super();
        initPanel();
        setTitle("DB2 Join Database Panel");
    }
    
    /** Return a fully configured DbaseFile Join Datasource. */
    public DbaseFileJoinDataSource getJoinDataSource(DataSource inSourceDataSource) throws Exception{
        DbaseFileJoinDataSource tempJoinDatasource = new DbaseFileJoinDataSource(inSourceDataSource);
        tempJoinDatasource.setDbaseFileName(getDbaseFileName());
        tempJoinDatasource.setDatasourceJoinColumn(getJoinSourceColumn());
        tempJoinDatasource.setTableJoinColumn(getJoinDestinationColumn());
        tempJoinDatasource.setJoinedDataCached(getCacheSource());
        return tempJoinDatasource;
    }
    
    /** Set up the GUI components for the main panel. */
    private void initPanel(){
        
        // create a split pane with the connect information at the top.
        JSplitPane tempSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        JPanel tempConnectPanel = initConnectPanel();
        tempConnectPanel.setMinimumSize(new Dimension(0,0));
        tempSplitPane.setTopComponent(tempConnectPanel);
        
        // set the query panel to the bottom component.
        myQueryPanel = new MyQueryPanel();
        myQueryPanel.initQueryPanel();
        tempSplitPane.setBottomComponent(myQueryPanel);
        setContentPane(tempSplitPane);
        
        // set the size and location
        resetSize();
    }
    
    /**
     * Set up the GUI components for requesting the information from the user.
     */
    private JPanel initConnectPanel() {
        JPanel tempPanel = new JPanel();
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2, 2, 2, 2);
        
        // URL Base
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        JLabel tempLabel = new JLabel("Filename: ");
        tempPanel.add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        tempPanel.add(myTextFieldDBaseFileName, c);
        myTextFieldDBaseFileName.setText(System.getProperty(Constants.getApplicationName()+".DbaseFileName", myTextFieldDBaseFileName.getText()));
        
        // Join Source
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Source Column");
        tempPanel.add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        tempPanel.add(myTextFieldJoinSource, c);
        
        // Join Destination
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Table Column");
        tempPanel.add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        tempPanel.add(myTextFieldJoinDestination, c);
        
        // checkbox for cached.
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        c.gridwidth = 2;
        tempPanel.add(myCheckboxCache, c);
        c.gridwidth = 1;
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);
        return tempPanel;
    }
    /** Return the frame associated with this application so sub dialogs can be displayed properly. */
    private JDialog getDialog(){return this;}
    
    private class MyQueryPanel extends JPanel implements ActionListener, Runnable {
        // The button for executing the query.
        private JButton myButtonExecute = new JButton("Load");
        
        // combo box for holding the old queries.
        JComboBox myComboOldQueries = new JComboBox();
        
        // the label for show ing the status of the describe
        private JLabel myLabelStatus = new JLabel("Status");
        // The status label for this panel.
        private JLabel getLabelStatus(){return myLabelStatus;}
        
        // The JTable for displaying the results of the query.
        private JTable myTable = new JTable();
        
        
        private void initQueryPanel(){
            setLayout(new BorderLayout());
            
            // set the Top panel.
            JPanel tempTopPanel = new JPanel(new GridBagLayout());
            GridBagConstraints c = new GridBagConstraints();
            c.insets = new Insets(2, 2, 2, 2);
            
            // Query button.
            c.gridx = 0;
            c.gridy = 0;
            c.weightx = 0;
            c.fill = GridBagConstraints.BOTH;
            tempTopPanel.add(myButtonExecute, c);
            c.gridx++;
            c.weightx = 1;
            tempTopPanel.add(myLabelStatus, c);
            add(tempTopPanel, BorderLayout.NORTH);
            
            // set the bottom panel.
            add(new JScrollPane(myTable), BorderLayout.CENTER);
            myTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            
            // the action events.
            myButtonExecute.addActionListener(this);
        }
        
        public void actionPerformed(java.awt.event.ActionEvent inAE) {
            if (inAE.getSource() == myButtonExecute){
                if (myThread == null){
                    myButtonExecute.setEnabled(false);
                    myThread = new Thread(this);
                    myThread.start();
                }
            }
        }
        
        // thread to use to run the run command.
        private Thread myThread = null;
        
        public void run() {
            getLabelStatus().setText("Reading File");
            int tempRecordCount = 0;
            try{
                // read the header informatil.
                DbaseFileReader tempFileReader = new DbaseFileReader(getDbaseFileName());
                String[] tempAttributeNames = tempFileReader.getFieldNames();
                AttributeType[] tempAttributeTypes = tempFileReader.getFieldTypes();
                int tempCount = tempAttributeNames.length;
                
                // add the headers to the table.
                DefaultTableModel tempModel = new DefaultTableModel(0, tempCount);
                myTable.setModel(tempModel);
                for (int i=0; i<tempCount; i++){
                    TableColumn tempColumn = myTable.getColumnModel().getColumn(i);
                    tempColumn.setHeaderValue(tempAttributeNames[i]);
                }
                
                // add the data
                Record tempRecord = tempFileReader.read();
                while (tempRecord != null){
                    tempRecordCount++;
                    if (tempRecordCount % 100 == 0) getLabelStatus().setText("Record "+tempRecordCount);
                    Object[] tempAttributes = tempRecord.getAttributes();
                    String[] tempString = new String[tempCount];
                    for (int i=0; i<tempCount; i++) tempString[i] = ""+tempAttributes[i];
                    tempModel.addRow(tempString);
                    tempRecord = tempFileReader.read();
                }                
            }
            catch(Exception e){
                getLabelStatus().setText(e.getMessage());
                e.printStackTrace();
            }
            getLabelStatus().setText("Read "+tempRecordCount);          
            
            myButtonExecute.setEnabled(true);
            myThread = null;
            return;
        }
    }
    private MyQueryPanel myQueryPanel = null;
    
    /** The main routine for running the panel. */
    public static void main(String[] inString){
        DbaseFileJoinDialog tempQuery = new DbaseFileJoinDialog();
        
        // create a window listener to close this window when the X is selected
        WindowListener tempListener = new WindowAdapter(){
            public void windowClosing(WindowEvent inWE){
                System.exit(0);
            }
            public void windowClosed(WindowEvent inWE){
                System.exit(0);
            }
        };
        tempQuery.addWindowListener(tempListener);
        
        // set the size and location on the screen.
        Dimension tempScreenSize = Toolkit.getDefaultToolkit().getScreenSize();
        tempQuery.setSize(600, 600);
        Dimension tempSize = tempQuery.getSize();
        tempQuery.setLocation((tempScreenSize.width - tempSize.width) / 2, (tempScreenSize.height - tempSize.height) / 2);
        
        // show the main window.
        tempQuery.setVisible(true);
    }
}
