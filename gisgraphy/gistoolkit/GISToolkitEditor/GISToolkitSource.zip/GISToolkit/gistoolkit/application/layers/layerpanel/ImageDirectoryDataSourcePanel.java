/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.application.layers.layerpanel;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.imagefile.*;
import gistoolkit.application.*;
import gistoolkit.application.layers.*;

/**
 *  Allows the user to interactively input the parameters to the Image Directory Data Source.
 */
public class ImageDirectoryDataSourcePanel extends JPanel implements ActionListener, DataSourcePanel{
    
    /** Creates new ImageDirectoryDataSourcePanel */
    public ImageDirectoryDataSourcePanel() {
        super();
        initPanel();
    }
    
    /** Keep a reference to the display. */
    private GISDisplay myGISDisplay = null;
    public void setGISDisplay(GISDisplay inDisplay){myGISDisplay = inDisplay;}
    
    /**
     * Label for the coordinates.
     */
    private JLabel myLabelCoordinates = new JLabel("Image Extents in World Coordinates");
    
    /**
     * Text field to allow the user to type the location directly.
     */
    private JTextField myTextFieldLocation;
    
    /**
     * Minimum X value for extents.
     */
    private JTextField myTextFieldMinX;
    
    /**
     * Minimum Y value for extents.
     */
    private JTextField myTextFieldMinY;
    
    /**
     * Maximum X value for extents.
     */
    private JTextField myTextFieldMaxX;
    
    /**
     * maximum Y value for extents.
     */
    private JTextField myTextFieldMaxY;
    
    /**
     * Button for looking up a location.
     */
    private JButton myButtonLocation;
    
    /**
     * Reference to the Datasource.
     */
    private ImageDirectoryDataSource myDatasource = null;
    
    /**
     * Reference to the file to determine if we need to regenerate.
     */
    private String myDatasourceFile = null;
    
    /**
     * Handle events coming from the button.
     */
    public void actionPerformed(ActionEvent inAE){
        if (myChooser == null){
            myChooser = new JFileChooser();
        }
        myChooser.setDialogTitle("Select Source Directory");
        String tempFile = myTextFieldLocation.getText();
        if ((tempFile == null)||(tempFile.length() == 0)){
            tempFile = ".";
        }
        myChooser.setCurrentDirectory(new File(tempFile));
        myChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (myChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File tempResultFile = myChooser.getSelectedFile();
            if (tempResultFile != null){
                myTextFieldLocation.setText(tempResultFile.getAbsolutePath());
                readIndex();
            }
        }        
    }
    
    /**
     * Read the directory for the index.
     */
    private void readIndex(){
        // check to ensure that the directory exists.
        String tempDirectoryName = myTextFieldLocation.getText();
        File tempFile = new File(tempDirectoryName);
        if (!tempFile.exists()) return;
        if (!tempFile.isDirectory()) {
            // use the one above it.
            tempFile = tempFile.getParentFile();
            if (tempFile == null) return;
            if (!tempFile.isDirectory()) return;
            if (tempFile.isDirectory()){
                myTextFieldLocation.setText(tempFile.getAbsolutePath());
            }
        }
        tempDirectoryName = myTextFieldLocation.getText();
        
        // set the Directory name
        try{
            ImageDirectoryDataSource tempDataSource = new ImageDirectoryDataSource(tempFile);
            myDatasource = tempDataSource;
            myDatasourceFile = tempDirectoryName;
            
            // populate the envelope
            Envelope tempEnvelope = tempDataSource.readEnvelope();
            if (tempEnvelope != null){
                myTextFieldMinX.setText(""+tempEnvelope.getMinX());
                myTextFieldMinY.setText(""+tempEnvelope.getMinY());
                myTextFieldMaxX.setText(""+tempEnvelope.getMaxX());
                myTextFieldMaxY.setText(""+tempEnvelope.getMaxY());
            }
        }
        catch (Exception e){
        }
    }
    
    /** Constants for the initialization parameters. */
    private static final String FILENAME_TAG = "ImageFileDataSourceFile";
    
    /**
     * Returns the fully configured datasource.
     */
    public DataSource getDataSource() throws Exception{
        String tempDirectoryName = myTextFieldLocation.getText();
        if ((myDatasource != null)&&(myDatasourceFile != null)){
            if (myDatasourceFile.equalsIgnoreCase(tempDirectoryName)){
                return myDatasource;
            }
        }
        
        // check to ensure that the directory exists.
        File tempFile = new File(tempDirectoryName);
        if (!tempFile.exists()) throw new Exception("Can not find Directory "+tempDirectoryName);
        if (!tempFile.isDirectory()) throw new Exception("File "+tempFile.getAbsoluteFile()+" Does not exist!");
        
        // set the Directory name
        ImageDirectoryDataSource tempDataSource = new ImageDirectoryDataSource(tempFile);
        
        // save the configuration information.
        System.getProperties().setProperty(Constants.getApplicationName()+"."+FILENAME_TAG, tempFile.getAbsolutePath());
        return tempDataSource;
    }
    
    /**
     * Set up the GUI components for requesting the information from the user.
     */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        
        // create the type in box for the filename
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        JLabel tempLabelFile = new JLabel("File");
        add(tempLabelFile, c);
        c.gridx++;
        c.weightx = 1;
        myTextFieldLocation = new JTextField();
        add(myTextFieldLocation, c);
        myTextFieldLocation.setText(System.getProperty(Constants.getApplicationName()+"."+FILENAME_TAG, myTextFieldLocation.getText()));
        
        c.gridx++;
        c.weightx = 0;
        myButtonLocation = new JButton("Browse");
        add(myButtonLocation, c);
        
        // extents label
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myLabelCoordinates, c);
        c.gridwidth = 1;
        
        // MinX
        c.gridx = 0;
        c.gridy++;
        JLabel tempLabel = new JLabel("Minimum X");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMinX = new JTextField(), c);
        myTextFieldMinX.setEditable(false);
        c.gridwidth = 1;
        
        // MinY
        c.gridx = 0;
        c.gridy++;
        tempLabel = new JLabel("Minimum Y");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMinY = new JTextField(), c);
        myTextFieldMinY.setEditable(false);
        c.gridwidth = 1;
        
        // MaxX
        c.gridx = 0;
        c.gridy++;
        tempLabel = new JLabel("Maximum X");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMaxX = new JTextField(), c);
        myTextFieldMaxX.setEditable(false);
        c.gridwidth = 1;
        
        // MaxY
        c.gridx = 0;
        c.gridy++;
        tempLabel = new JLabel("Maximum Y");
        add(tempLabel, c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        add(myTextFieldMaxY = new JTextField(), c);
        myTextFieldMaxY.setEditable(false);
        c.gridwidth = 1;
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        add(new JPanel(), c);
        
        // listen to the button
        myButtonLocation.addActionListener(this);
    }
    
    /**
     * Save the file chooser for future reference
     */
    private static JFileChooser myChooser = new JFileChooser();
    
}
