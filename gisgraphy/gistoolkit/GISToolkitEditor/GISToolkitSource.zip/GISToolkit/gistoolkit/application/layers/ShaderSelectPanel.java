/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.shader.*;
/**
 * Panel that allows the user to select the appropriate shader for their application, and to
 * modify the attributes of that panel.
 */
public class ShaderSelectPanel extends JPanel implements ItemListener{

    /** Creates new ShaderSelectPanel */
    public ShaderSelectPanel() {
        initPanel();
    }
    
    /** Choice of the shaders that I know about */
    private JComboBox myComboShaders = new JComboBox();
    
    /** Vector to contain the shaders */
    private Vector myVectShaders = new Vector();
    
    /** Panel on which to display the edit panel for this shader */
    private JPanel myDisplayPanel = new JPanel();
    
    /** Hold a reference to the currently selected Shader Panel */
    private ShaderPanel myShaderPanel = null;
    
    /** respond to Item events from the JComboBox */
    public void itemStateChanged(ItemEvent inIE){
        Shader tempShader = (Shader) myVectShaders.elementAt(myComboShaders.getSelectedIndex());
        myDisplayPanel.removeAll();
        if (tempShader instanceof EditableShader){
            myShaderPanel = ((EditableShader) tempShader).getEditPanel();
            myDisplayPanel.add( myShaderPanel, BorderLayout.CENTER);
        }
        else{
            myDisplayPanel.add(new JLabel("Non Editable Shader"), BorderLayout.CENTER);
        }
        myDisplayPanel.validate();
    }
    
    /** initialize the use interface components for this panel */
    private void initPanel(){
        setLayout(new BorderLayout());
        add(myComboShaders, BorderLayout.NORTH);
        add(myDisplayPanel, BorderLayout.CENTER);
        myDisplayPanel.setLayout(new BorderLayout());
        
        // create the shaders array
        myVectShaders.addElement(new MonoShader());
        myComboShaders.addItem("Mono Shader");
        myVectShaders.addElement(new RangeShader());
        myComboShaders.addItem("Range Shader");
        myVectShaders.addElement(new RandomShader());
        myComboShaders.addItem("Random Shader");
        myVectShaders.addElement(new BinShader());
        myComboShaders.addItem("Bin Shader");

        myComboShaders.addItemListener(this);        
        myComboShaders.setSelectedIndex(0);
    }
    
    /** Hold a reference to the currently edited layer */
    private Layer myLayer = null;
    
    /** set the layer to be edited */
    public void setLayer(Layer inLayer){
        if (inLayer == null) return;
        myLayer = inLayer;
        Style tempStyle = inLayer.getStyle();
        if (tempStyle == null ) return;
        Shader tempShader = tempStyle.getShader();
        if (tempShader == null) return;
        
        // try to find the shader in the list 
        boolean tempFound = false;
        String tempClassName = tempShader.getClass().getName();
        for (int i=0; i<myVectShaders.size(); i++){
            if (tempClassName.equals(myVectShaders.elementAt(i).getClass().getName())){
                myVectShaders.setElementAt(tempShader ,i);
                myComboShaders.setSelectedIndex(i);
                itemStateChanged(null);
                tempFound = true;
            }
        }
        if (!tempFound){
            myVectShaders.addElement(tempShader);
            myComboShaders.addItem(tempShader.getClass().getName());
        }
    }
    
    /** get the layer after it has been edited */
    public Layer getLayer(){
        if (myLayer == null) return null;
        Style tempStyle = myLayer.getStyle();
        if (myShaderPanel != null){
            tempStyle.setShader(myShaderPanel.getShader());
        }
        else tempStyle.setShader((Shader) myVectShaders.elementAt(myComboShaders.getSelectedIndex()));
        return myLayer;
    }
}
