/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.layerpanel;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.GISDisplay;
import gistoolkit.application.*;
import gistoolkit.application.layers.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.mysql.UpdateableMySQLDataSource;

/**
 * Allows the user to enter the parameters needed to initialize the UpdateableMySQLDataSource
 */
public class UpdateableMySQLDataSourcePanel extends JPanel implements DataSourcePanel{

    /**
     * Database connection parameters.
     */
    private JTextField myTextFieldDatabaseServername= new JTextField("Servername");
    private JTextField myTextFieldDatabaseName = new JTextField("Databasename");
    private JTextField myTextFieldDatabaseUsername = new JTextField("Username");
    private JTextField myTextFieldDatabasePassword = new JTextField("Password");
    private JTextField myTextFieldDatabasePort =  new JTextField("3306");
    private JTextField myTextFieldDatabaseTablename = new JTextField("Tablename");
    private JTextField myTextFieldDatabaseColumn =  new JTextField("shape");
    private JTextField myTextFieldSpatialReferenceID =  new JTextField("1");
    
    /** Creates new UpdateableMySQLDataSourcePanel */
    public UpdateableMySQLDataSourcePanel() {
        initPanel();
    }
    
    /** Creates new UpdateableMySQLDataSourcePanel */
    public UpdateableMySQLDataSourcePanel(java.awt.LayoutManager layout) {
        super(layout);
        initPanel();
    }
    
    /** Creates new ReadOnlyPostGISDataSourcePanel */
    public UpdateableMySQLDataSourcePanel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
        super(layout, isDoubleBuffered);
        initPanel();
    }

    /** Constants for the initialization parameters. */
    private static final String SERVERNAME_TAG = "MySQLDataSourceServername";
    private static final String DATABASENAME_TAG = "MySQLDataSourceDatabaseName";
    private static final String USERNAME_TAG = "MySQLDataSourceUsername";
    private static final String PASSWORD_TAG = "MySQLDataSourcePassword";
    private static final String PORT_TAG = "MySQLDataSourcePort";
    private static final String SHAPECOLUMN_TAG = "MySQLDataSourceShapeColumn";
    private static final String SRID_TAG = "MySQLDataSourceSpatialReferenceID";
    private static final String TABLENAME_TAG = "MySQLDataSourceTablename";
    
    /**
     * Returns the fully configured datasource.
     */
    public DataSource getDataSource() throws Exception{
        UpdateableMySQLDataSource tempDatasource = new UpdateableMySQLDataSource();
        
        // set the properties
        tempDatasource.setDatabaseShapeColumn(myTextFieldDatabaseColumn.getText());
        tempDatasource.setDatabaseName(myTextFieldDatabaseName.getText());
        tempDatasource.setDatabasePassword(myTextFieldDatabasePassword.getText());
        tempDatasource.setDatabaseServername(myTextFieldDatabaseServername.getText());
        tempDatasource.setDatabaseUsername(myTextFieldDatabaseUsername.getText());
        tempDatasource.setDatabaseTablename(myTextFieldDatabaseTablename.getText());
        tempDatasource.setDatabaseSpatialReferenceID(myTextFieldSpatialReferenceID.getText());
        try{
            tempDatasource.setDatabasePort(Integer.parseInt(myTextFieldDatabasePort.getText()));
        }
        catch (NumberFormatException e){
            tempDatasource.setDatabasePort(3306);
        }
        tempDatasource.connect();

        // save the configuration information.
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SERVERNAME_TAG, tempDatasource.getDatabaseServername());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+DATABASENAME_TAG, tempDatasource.getDatabaseName());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+USERNAME_TAG, tempDatasource.getDatabaseUsername());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+PASSWORD_TAG, tempDatasource.getDatabasePassword());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+PORT_TAG, ""+tempDatasource.getDatabasePort());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SHAPECOLUMN_TAG, ""+tempDatasource.getDatabaseShapeColumn());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SRID_TAG, ""+tempDatasource.getDatabaseSpatialReferenceID());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+TABLENAME_TAG, tempDatasource.getDatabaseTablename());

        return tempDatasource;
    }
    
    /**
     * Set up the GUI components for requesting the information from the user.
     */
    private void initPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2, 2, 2, 2);
        c.fill = GridBagConstraints.BOTH;
                
        // Servername
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0;
        JLabel tempLabel = new JLabel("Servername");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseServername, c);
        myTextFieldDatabaseServername.setText(System.getProperty(Constants.getApplicationName()+"."+SERVERNAME_TAG, myTextFieldDatabaseServername.getText()));
        
        // DatabaseName
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Database Name");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseName, c);
        myTextFieldDatabaseName.setText(System.getProperty(Constants.getApplicationName()+"."+DATABASENAME_TAG, myTextFieldDatabaseName.getText()));
        
        // Username
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Username");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseUsername, c);
        myTextFieldDatabaseUsername.setText(System.getProperty(Constants.getApplicationName()+"."+USERNAME_TAG, myTextFieldDatabaseUsername.getText()));

        // Password
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Password");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabasePassword, c);
        myTextFieldDatabasePassword.setText(System.getProperty(Constants.getApplicationName()+"."+PASSWORD_TAG, myTextFieldDatabasePassword.getText()));
        
        // Port
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Port");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabasePort, c);
        myTextFieldDatabasePort.setText(System.getProperty(Constants.getApplicationName()+"."+PORT_TAG, myTextFieldDatabasePort.getText()));
        
        // Column
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Column");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseColumn, c);
        myTextFieldDatabaseColumn.setText(System.getProperty(Constants.getApplicationName()+"."+SHAPECOLUMN_TAG, myTextFieldDatabaseColumn.getText()));
        
        // Spatial Reference ID
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Spatial Reference ID");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldSpatialReferenceID, c);
        myTextFieldSpatialReferenceID.setText(System.getProperty(Constants.getApplicationName()+"."+SRID_TAG, myTextFieldSpatialReferenceID.getText()));
  
        // SQLQuery
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Tablename");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseTablename, c);
        myTextFieldDatabaseTablename.setText(System.getProperty(Constants.getApplicationName()+"."+TABLENAME_TAG, myTextFieldDatabaseTablename.getText()));        
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        c.weighty = 1;
        add(new JPanel(), c);   
    }
    
    /**
     * Sets the GISDisplay in case the panel should need it.
     */
    public void setGISDisplay(GISDisplay inDisplay) {
    }
    
}
