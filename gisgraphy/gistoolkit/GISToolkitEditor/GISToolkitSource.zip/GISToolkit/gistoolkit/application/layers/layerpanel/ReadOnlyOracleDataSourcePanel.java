/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.layerpanel;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.GISDisplay;
import gistoolkit.application.*;
import gistoolkit.application.layers.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.oracle.ReadOnlyOracleDataSource;

/**
 * Allows the user to enter the parameters needed to initialize the ReadOnlyOracleDataSource
 */
public class ReadOnlyOracleDataSourcePanel extends JPanel implements DataSourcePanel{

    /**
     * Database connection parameters.
     */
    private JTextField myTextFieldDatabaseServername= new JTextField("Servername");
    private JTextField myTextFieldDatabaseName = new JTextField("Databasename");
    private JTextField myTextFieldDatabaseUsername = new JTextField("Username");
    private JPasswordField myPasswordFieldDatabasePassword = new JPasswordField("");
    private JTextField myTextFieldDatabasePort =  new JTextField("1521");
    private JTextField myTextFieldDatabaseQuery = new JTextField("Select state_name, state_abbr, shape as shape from states");
    private JTextField myTextFieldDatabaseColumn =  new JTextField("shape");
    private JTextField myTextFieldSpatialReferenceID =  new JTextField("1");
    
    /** Creates new ReadOnlyOracleDataSourcePanel */
    public ReadOnlyOracleDataSourcePanel() {
        initPanel();
    }
    
    /** Creates new ReadOnlyOracleDataSourcePanel */
    public ReadOnlyOracleDataSourcePanel(java.awt.LayoutManager layout) {
        super(layout);
        initPanel();
    }
    
    /** Creates new ReadOnlyOracleDataSourcePanel */
    public ReadOnlyOracleDataSourcePanel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
        super(layout, isDoubleBuffered);
        initPanel();
    }
    
    /** Constants for the initialization parameters. */
    private static final String SERVERNAME_TAG = "OracleDataSourceServername";
    private static final String DATABASENAME_TAG = "OracleDataSourceName";
    private static final String USERNAME_TAG = "OracleDataSourceUsername";
    private static final String PASSWORD_TAG = "OracleDataSourcePassword";
    private static final String PORT_TAG = "OracleDataSourcePort";
    private static final String SHAPECOLUMN_TAG = "OracleDataSourceShapeColumn";
    private static final String SRID_TAG = "OracleDataSourceSpatialReferenceID";
    private static final String QUERY_TAG = "OracleDataSourceQuery";
    
    /**
     * Returns the fully configured datasource.
     */
    public DataSource getDataSource() throws Exception{
        ReadOnlyOracleDataSource tempDatasource = new ReadOnlyOracleDataSource();
        
        // set the properties
        tempDatasource.setDatabaseShapeColumn(myTextFieldDatabaseColumn.getText());
        tempDatasource.setDatabaseName(myTextFieldDatabaseName.getText());
        tempDatasource.setDatabasePassword(new String(myPasswordFieldDatabasePassword.getPassword()));
        tempDatasource.setDatabaseServername(myTextFieldDatabaseServername.getText());
        tempDatasource.setDatabaseUsername(myTextFieldDatabaseUsername.getText());
        tempDatasource.setDatabaseQuery(myTextFieldDatabaseQuery.getText());
        tempDatasource.setDatabaseSpatialReferenceID(myTextFieldSpatialReferenceID.getText());
        try{
            tempDatasource.setDatabasePort(Integer.parseInt(myTextFieldDatabasePort.getText()));
        }
        catch (NumberFormatException e){
            tempDatasource.setDatabasePort(1521);
        }
        tempDatasource.connect();
        tempDatasource.setName(myTextFieldDatabaseName.getText());

        // save the configuration information.
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SERVERNAME_TAG, tempDatasource.getDatabaseServername());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+DATABASENAME_TAG, tempDatasource.getDatabaseName());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+USERNAME_TAG, tempDatasource.getDatabaseUsername());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+PASSWORD_TAG, tempDatasource.getDatabasePassword());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+PORT_TAG, ""+tempDatasource.getDatabasePort());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SHAPECOLUMN_TAG, ""+tempDatasource.getDatabaseShapeColumn());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+SRID_TAG, ""+tempDatasource.getDatabaseSpatialReferenceID());
        System.getProperties().setProperty(Constants.getApplicationName()+"."+QUERY_TAG, tempDatasource.getDatabaseQuery());
        return tempDatasource;
    }
    
    /**
     * Set up the GUI components for requesting the information from the user.
     */
    private void initPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2, 2, 2, 2);
        c.fill = GridBagConstraints.BOTH;
                
        // Servername
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0;
        JLabel tempLabel = new JLabel("Servername");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseServername, c);
        myTextFieldDatabaseServername.setText(System.getProperty(Constants.getApplicationName()+"."+SERVERNAME_TAG, myTextFieldDatabaseServername.getText()));
        
        // DatabaseName
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Database Name");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseName, c);
        myTextFieldDatabaseName.setText(System.getProperty(Constants.getApplicationName()+"."+DATABASENAME_TAG, myTextFieldDatabaseName.getText()));
        
        // Username
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Username");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseUsername, c);
        myTextFieldDatabaseUsername.setText(System.getProperty(Constants.getApplicationName()+"."+USERNAME_TAG, myTextFieldDatabaseUsername.getText()));

        // Password
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Password");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myPasswordFieldDatabasePassword, c);
        myPasswordFieldDatabasePassword.setText(System.getProperty(Constants.getApplicationName()+"."+PASSWORD_TAG, ""));
        
        // Port
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Port");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabasePort, c);
        myTextFieldDatabasePort.setText(System.getProperty(Constants.getApplicationName()+"."+PORT_TAG, myTextFieldDatabasePort.getText()));
        
        // Column
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Column");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseColumn, c);
        myTextFieldDatabaseColumn.setText(System.getProperty(Constants.getApplicationName()+"."+SHAPECOLUMN_TAG, myTextFieldDatabaseColumn.getText()));
        
        // Spatial Reference ID
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Spatial Reference ID");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldSpatialReferenceID, c);
        myTextFieldSpatialReferenceID.setText(System.getProperty(Constants.getApplicationName()+"."+SRID_TAG, myTextFieldSpatialReferenceID.getText()));
  
        // SQLQuery
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempLabel = new JLabel("Query");
        add(tempLabel, c);
        c.gridx++;
        c.weightx = 1;
        add(myTextFieldDatabaseQuery, c);
        myTextFieldDatabaseQuery.setText(System.getProperty(Constants.getApplicationName()+"."+QUERY_TAG, myTextFieldDatabaseQuery.getText()));        
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        c.weighty = 1;
        add(new JPanel(), c);   
    }
    
    /**
     * Sets the GISDisplay in case the panel should need it.
     */
    public void setGISDisplay(GISDisplay inDisplay) {
    }
    
}
