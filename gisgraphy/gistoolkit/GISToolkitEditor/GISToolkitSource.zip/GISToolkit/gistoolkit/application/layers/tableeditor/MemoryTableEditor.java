/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.tableeditor;

import java.awt.*;
import javax.swing.*;
import gistoolkit.features.*;

/**
 * Class that allows the editing of table configuration within the Memory Data Source.
 */
public class MemoryTableEditor extends JPanel{

    /** Private variable to hold the JTextFields used for editing the attribute names. */
    private JTextField[] myAttributeNameFields = new JTextField[0];
    
    /** Private variable to hold the JComboBoxes used for editing the attribute types. */
    private JComboBox[] myComboBoxTypes = new JComboBox[0];
    
    /** The types that this editor can edit. */
    private String[] myTypes = {
        AttributeType.STRING, 
        AttributeType.BOOLEAN, 
        AttributeType.FLOAT, 
        AttributeType.INTEGER, 
        AttributeType.TIMESTAMP
    };
    
    /** Creates a new instance of MemoryTableEditor */
    public MemoryTableEditor() {
    }
    
    /** Set the attributes and types to edit in this editor. */
    public void setAttributes(String[] inAttributeNames, AttributeType[] inAttributeTypes){
        // remove all previous elements from the panel
        removeAll();
        
        // Validate the data
        String[] tempAttributeNames = inAttributeNames;
        if (tempAttributeNames == null) tempAttributeNames = new String[0];
        AttributeType[] tempAttributeTypes = inAttributeTypes;
        if (tempAttributeTypes == null) tempAttributeTypes = new AttributeType[0];
        
        // create a Panel for Adding controls to
        JPanel tempPanel = new JPanel();
                        
        // Populate the panel with the new stuff
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        
        myAttributeNameFields = new JTextField[tempAttributeNames.length];
        myComboBoxTypes = new JComboBox[tempAttributeTypes.length];
        for (int i=0; i<tempAttributeNames.length; i++){
            
            // add the Text Field
            c.gridx = 0;
            c.gridy = i;
            c.weightx = 1;
            JTextField tempName = new JTextField(tempAttributeNames[i]);
            tempPanel.add(tempName, c);
            myAttributeNameFields[i] = tempName;

            // add the editor
            c.gridx = 1;
            c.weightx = 0;
            JComboBox tempType = new JComboBox(myTypes);
            tempType.setSelectedItem(tempAttributeTypes[i].getType());
            tempPanel.add(tempType, c);
            myComboBoxTypes[i] = tempType;
        }
        
        // add a panel at the bottom to push everything to the top.
        c.gridy++;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);

        // create a scroll pane for scrolling the above panel
        JScrollPane tempScrollPane = new JScrollPane(tempPanel);
        
        // Add the scroll
        setLayout(new BorderLayout());
        add(tempScrollPane, BorderLayout.CENTER);
    }
    
    /** Return the edited attribute names. */
    public String[] getAttributeNames(){
        String[] tempNames = new String[myAttributeNameFields.length];
        for (int i=0; i<myAttributeNameFields.length; i++){
            tempNames[i] = myAttributeNameFields[i].getText();
        }
        return tempNames;
    }
    
    /** Return the edited attribute types. */
    public AttributeType[] getAttributeTypes(){
        AttributeType[] tempTypes = new AttributeType[myComboBoxTypes.length];
        for (int i=0; i<myComboBoxTypes.length; i++){
            tempTypes[i] = new AttributeType((String)myComboBoxTypes[i].getSelectedItem());
        }
        return tempTypes;
    }
}
