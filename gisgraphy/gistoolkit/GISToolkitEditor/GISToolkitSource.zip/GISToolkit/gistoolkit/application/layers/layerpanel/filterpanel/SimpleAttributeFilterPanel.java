/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers.layerpanel.filterpanel;

import java.awt.*;
import javax.swing.*;
import gistoolkit.datasources.filter.*;

/**
 * Super class for attribute filter panels.
 */
public abstract class SimpleAttributeFilterPanel extends FilterPanel{
    /** Combo box to hold the attribute names. */
    private JComboBox myComboAttributes = new JComboBox();
    
    /** Combo box to hold the types of comparisons to perform. */
    private JComboBox myComboComparisons = new JComboBox();
    
    /** The label to use for the value text field. */
    private JLabel myValueLabel = new JLabel("Value:");
    /** Set the label for the value field. */
    public void setValueLabel(String inLabel){myValueLabel.setText(inLabel);}
    
    /** TextField to hold the value of the string. */
    private JTextField myTextFieldValue = new JTextField();
    
    
    /** Creates new StringFilterPanel */
    public SimpleAttributeFilterPanel() {
        initPanel();
    }

    /** set up the user interface components of this panel. */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        
        // the attribute to filter on.
        c.gridx = 0;
        c.gridy = 0;
        add(new JLabel("Column Name:"), c);
        c.gridy++;
        add(myComboAttributes, c);
        
        // The comparison to use
        myComboComparisons.addItem("Equals");
        myComboComparisons.addItem("Greater Than");
        myComboComparisons.addItem("Less Than");
        c.gridy++;
        add(new JLabel("Comparison:"), c);
        c.gridy++;
        add(myComboComparisons, c);
        
        // The value to use
        c.gridy++;
        add(myValueLabel, c);
        c.gridy++;
        add(myTextFieldValue, c);
        
        // some space to smash it all to the top.
        c.gridy++;
        c.weighty = 1;
        add(new JPanel(), c);
    }

    /** Set the attribute names. */
    public void setAttributeNames(String[] inAttributeNames){
        myComboAttributes.removeAllItems();
        if (inAttributeNames == null) return;
        for (int i=0; i<inAttributeNames.length; i++){
            myComboAttributes.addItem(inAttributeNames[i]);
        }
    }
    
    /** Method to set the attribute to use. */
    protected void setAttributeName(String inAttributeName){
        for (int i=0; i<myComboAttributes.getItemCount(); i++){
            String tempItem = (String) myComboAttributes.getItemAt(i);
            if (inAttributeName.equalsIgnoreCase(tempItem)){
                myComboAttributes.setSelectedIndex(i);
                break;
            }
        }
    }
    /** Retrieve the attribute to use. */
    protected String getAttributeName(){
        return (String) myComboAttributes.getSelectedItem();
    }
    
    /** Method to set the comparison to use. */
    protected void setComparison(int inComparison){
        if (inComparison == AttributeFilter.ATTRIBUTE_EQUALS) myComboComparisons.setSelectedIndex(0);
        else if (inComparison == AttributeFilter.ATTRIBUTE_GREATER) myComboComparisons.setSelectedIndex(1);
        else if (inComparison == AttributeFilter.ATTRIBUTE_LESS) myComboComparisons.setSelectedIndex(2);
        else myComboComparisons.setSelectedIndex(0);
    }
    /** Retrieve the comparison to use. */
    protected int getComparison(){
        int tempComparison = AttributeFilter.ATTRIBUTE_EQUALS;
        if (myComboComparisons.getSelectedIndex() == 1) tempComparison = AttributeFilter.ATTRIBUTE_GREATER;
        if (myComboComparisons.getSelectedIndex() == 2) tempComparison = AttributeFilter.ATTRIBUTE_LESS;
        return tempComparison;
    }
    
    /** Set the value of the text field. */
    protected void setTextField(String inValue){
        myTextFieldValue.setText(inValue);
    }
    /** Get the value of the text field. */
    protected String getTextField(){return myTextFieldValue.getText();}
    
    /** Set a filter to be used as the template.  */
    public abstract void setFilter(Filter inFilter);
    
    /** Retrieve the configured filter from the filter panel.  */
    public abstract Filter getFilter() throws Exception;    
}
