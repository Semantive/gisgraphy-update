/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.layers;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ListSelectionListener;
import gistoolkit.display.*;
import gistoolkit.display.renderer.*;
import gistoolkit.application.layers.rendererpanel.*;
/**
 * Allows the user to update and modify the renderers assigned to a layer.
 */
public class RendererSelectPanel extends JPanel{

    /** Choice of the renderers that I know about */
    private JComboBox myComboRenderers = new JComboBox();
    private gistoolkit.display.Renderer[] myRenderers = {
        new FeatureRenderer(),
        new LineRenderer(),
        new MultiLineRenderer(),
        new MultiPointRenderer(),
        new MultiPolygonRenderer(),
        new PointRenderer(),
        new PolygonRenderer(),
        new RasterRenderer(),
        new PointImageRenderer()
    };
    
    /** Class for handling the actions from the buttons. */
    private class RendererActionListener implements ActionListener, ListSelectionListener{
        
        public void actionPerformed(java.awt.event.ActionEvent inAE) {
            if (inAE.getSource() == myButtonAdd){
                if (myComboRenderers.getSelectedItem() != null){
                    DefaultListModel tempModel = (DefaultListModel) myListRenderers.getModel();
                    tempModel.add(0,myComboRenderers.getSelectedItem());
                }
            }
            if (inAE.getSource() == myButtonDelete){
                if (myListRenderers.getSelectedValue() != null){
                    DefaultListModel tempModel = (DefaultListModel) myListRenderers.getModel();
                    tempModel.removeElement(myListRenderers.getSelectedValue());
                }
            }
            if (inAE.getSource() == myButtonMoveUp){
                Object tempItem = myListRenderers.getSelectedValue();
                if (tempItem != null){
                    int tempIndex = myListRenderers.getSelectedIndex();
                    if (tempIndex > 0){
                        DefaultListModel tempModel = (DefaultListModel) myListRenderers.getModel();
                        tempModel.removeElement(tempItem);
                        tempModel.insertElementAt(tempItem, tempIndex-1);
                        myListRenderers.setSelectedIndex(tempIndex-1);
                    }
                }
            }
            if (inAE.getSource() == myButtonMoveDown){
                Object tempItem = myListRenderers.getSelectedValue();
                if (tempItem != null){
                    int tempIndex = myListRenderers.getSelectedIndex();
                    DefaultListModel tempModel = (DefaultListModel) myListRenderers.getModel();
                    if (tempIndex < tempModel.size()-1){
                        tempModel.removeElement(tempItem);
                        tempModel.insertElementAt(tempItem, tempIndex+1);
                        myListRenderers.setSelectedIndex(tempIndex+1);
                    }
                }
            }            
            if (inAE.getSource() == myButtonEdit){
                Object tempItem = myListRenderers.getSelectedValue();
                if (tempItem != null){
                    editRenderer((gistoolkit.display.Renderer) tempItem);
                }
            }            
        }
        
        public void valueChanged(javax.swing.event.ListSelectionEvent listSelectionEvent) {
            if (canEdit((gistoolkit.display.Renderer) myListRenderers.getSelectedValue())){
                myButtonEdit.setEnabled(true);
            }
            else myButtonEdit.setEnabled(false);
        }
        
    }
    
    private RendererActionListener myListener = new RendererActionListener();
    
    /** List of currently configured renderers. */
    private JList myListRenderers = new JList();
    
    /** Panel on which to display the edit panel for this Layer */
    private JPanel myDisplayPanel = new JPanel();
        
    /** Button for moving renderers up in the list. */
    private JButton myButtonMoveUp = new JButton("Up");
    
    /** Button for moving renderers down in the list. */
    private JButton myButtonMoveDown = new JButton("Down");
    
    /** Button for deleting renderers from the list. */
    private JButton myButtonDelete = new JButton("Delete");
    
    /** Button for adding remderers to the list. */
    private JButton myButtonAdd = new JButton("Add");
    
    /** Button for editing remderers to the list. */
    private JButton myButtonEdit = new JButton("Edit");

    /** Creates new RendererSelectPanel */
    public RendererSelectPanel() {
        initPanel();
    }

    /** set up the display properties for this panel */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.fill = GridBagConstraints.BOTH;

        // the combo
        c.gridx = 0;
        c.gridy = 0;       
        add(myComboRenderers, c);
        // populate the combo box
        for (int i=0; i<myRenderers.length; i++){
            myComboRenderers.addItem(myRenderers[i]);
        }
        
        // the list
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        c.weighty = 1;
        c.gridheight = 6;
        JScrollPane tempScrollPane = new JScrollPane(myListRenderers);
        myListRenderers.addListSelectionListener(myListener);
        add(tempScrollPane, c);
        c.weighty = 0;
        c.gridheight = 1;
        
        // the Buttons
        c.gridx = 1;
        add(myButtonAdd, c);
        myButtonAdd.addActionListener(myListener);
        c.gridy++;
        add(myButtonEdit, c);
        myButtonEdit.addActionListener(myListener);
        myButtonEdit.setEnabled(false);
        c.gridy++;
        add(myButtonDelete, c);
        myButtonDelete.addActionListener(myListener);
        c.gridy++;
        add(myButtonMoveUp, c);
        myButtonMoveUp.addActionListener(myListener);
        c.gridy++;
        add(myButtonMoveDown, c);
        myButtonMoveDown.addActionListener(myListener);
        c.gridy++;
        c.weighty = 1;
        add(new JPanel(), c);
        
    }
        
    /** Layer Currently editing */
    private Layer myLayer = null;
    
    /** Set the layer to edit */
    public void setLayer(Layer inLayer){
        DefaultListModel tempListModel = new DefaultListModel();
        myListRenderers.setModel(tempListModel);
        if (inLayer != null){
            Style tempStyle = inLayer.getStyle();
            if (tempStyle != null){
                if (tempStyle.getNumRenderers() > 0){
                    for (int i=0; i<tempStyle.getNumRenderers(); i++){
                        tempListModel.addElement(tempStyle.getRenderer(i));
                    }
                }
            }
        }
        myLayer = inLayer;
    }
    
    /** Retrieve the edited Layer from the dialog */
    public Layer getLayer(){
        if (myLayer != null){
            Style tempStyle = myLayer.getStyle();
            if (tempStyle != null){
                tempStyle.removeAllRenderers();
                DefaultListModel tempModel = (DefaultListModel) myListRenderers.getModel();
                Enumeration e = tempModel.elements();
                ArrayList tempArrayList = new ArrayList();
                while (e.hasMoreElements()){
                    tempArrayList.add(e.nextElement());
                }
                
                // flip the order of the records.
                for (int i=0; i<tempArrayList.size(); i++){
                    tempStyle.add((gistoolkit.display.Renderer) tempArrayList.get(tempArrayList.size() - (i+1)));
                }
            }
        }
        return myLayer;
    }
    
    /** Get the editor for the particular renderer. */
    public boolean canEdit(gistoolkit.display.Renderer inRenderer){
        if (inRenderer instanceof PointImageRenderer) return true;
        return false;
    }
    
    public void editRenderer(gistoolkit.display.Renderer inRenderer){
        if (inRenderer instanceof PointImageRenderer){
            PointImageRendererDialog tempDialog = new PointImageRendererDialog();
            tempDialog.setModal(true);
//1.4.4            tempDialog.setLocationRelativeTo(this);
            tempDialog.setSize(200,200);
            tempDialog.setPointImageRenderer((PointImageRenderer) inRenderer);
            tempDialog.show();
        }
    }
}
