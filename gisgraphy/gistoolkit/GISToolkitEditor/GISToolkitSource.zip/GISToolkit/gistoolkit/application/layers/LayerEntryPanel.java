/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */
package gistoolkit.application.layers;
import java.awt.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.datasources.*;
import gistoolkit.application.layers.joindatasource.*;
import gistoolkit.datasources.memory.*;
import java.awt.event.*;
/**
 * Type for displaying information about a layer to the user.  The LayerPanel class
 * acts as a container for the LayerEntryPanel classes.  Each Layer should have a
 * corresponding LayerEntryPanel which are nested within the LayerPanel of an
 * application.  This LayerEntryPanel is used to display and modify information about
 * A layer by reacting to mouse click events, and displaying dialogs and menus.
 * Creation date: (5/2/2001 9:01:24 AM)
 */
public class LayerEntryPanel
    extends JPanel
    implements MouseListener, ActionListener, LayerListener {
    /**
     * Reference to the layer to be edited.
     */
    private Layer myLayer;
    /**
     * Reference to the properties dialog.
     */
    private LayerPropertiesDialog myPropertiesDlg = new LayerPropertiesDialog();
    /**
     * Button for modifying the shading information.
     */
    private ShaderButton myShaderButton = new ShaderButton();
    /**
     * Checkbox for swiching Visible/NonVisible
     */
    private JCheckBox myVisibleChecker = new JCheckBox();
    /**
     * Reference to the GISDisplay.
     */
    private GISDisplay myGISDisplay;
    /**
     * LayerEntryPanel constructor comment.
     */
    public LayerEntryPanel() {
        super();
        initPanel();
    }
    /**
     * Returns the layer assigned to this panel.
     * Creation date: (5/2/2001 9:01:40 AM)
     * @return gistoolkit.display.Layer
     */
    public Layer getLayer() {
        return myLayer;
    }
    /**
     * Initialize the panel adding the display information.
     * Adds the display widgets to the panel
     */
    private void initPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2, 2, 2, 2);
        // switch the visibilty on item performed
        myVisibleChecker.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if (myLayer != null)
                    myLayer.setVisible(myVisibleChecker.isSelected());
                if (myGISDisplay != null)
                    myGISDisplay.redraw();
            }
        });
        c.insets = new Insets(2, 2, 2, 2);
        // add the controls to the display.
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        add(myVisibleChecker, c);
        c.gridx = 1;
        myShaderButton.setPreferredSize(new Dimension(30, 20));
        add(myShaderButton, c);
        c.weightx = 2;
        c.gridx = 2;
        add(myLabelName, c);
        // create the popup menu.
        myPopupMenu = new JPopupMenu("Layer");
        myPopupMenu.add(myMenuItemCommit);
        myPopupMenu.add(myMenuItemRollback);
        myPopupMenu.add(new JSeparator());
        myPopupMenu.add(myMenuItemRemove);
        myPopupMenu.add(myMenuItemMoveUp);
        myPopupMenu.add(myMenuItemMoveDown);
        myPopupMenu.add(myMenuItemProperties);
        myPopupMenu.add(myMenuItemZoomToLayer);
        // the popups for the JMenu items.
        myPopupMenu.add(new JSeparator());
        JMenu tempMenuJoin = new JMenu("Join To ...");
        myPopupMenu.add(tempMenuJoin);
        tempMenuJoin.add(myMenuItemJoinDB2);
        tempMenuJoin.add(myMenuItemJoinOracle);
        tempMenuJoin.add(myMenuItemJoinPostgres);
        tempMenuJoin.add(myMenuItemJoinMySQL);
        tempMenuJoin.add(myMenuItemJoindbase3);
        myPopupMenu.add(myMenuItemUnjoin);
        myPopupMenu.addSeparator();
        myPopupMenu.add(myMenuItemEditTable);
        // lisetn for events from the items.
        myMenuItemCommit.addActionListener(this);
        myMenuItemRemove.addActionListener(this);
        myMenuItemRollback.addActionListener(this);
        myMenuItemMoveUp.addActionListener(this);
        myMenuItemMoveDown.addActionListener(this);
        myMenuItemProperties.addActionListener(this);
        myMenuItemZoomToLayer.addActionListener(this);
        myMenuItemJoinDB2.addActionListener(this);
        myMenuItemJoinOracle.addActionListener(this);
        myMenuItemJoinPostgres.addActionListener(this);
        myMenuItemJoinMySQL.addActionListener(this);
        myMenuItemJoindbase3.addActionListener(this);
        myMenuItemUnjoin.addActionListener(this);
        myMenuItemEditTable.addActionListener(this);
    }
    /**
     * Set the GISDisplay associated with this layer.
     */
    public void setGISDisplay(GISDisplay inDisplay) {
        myGISDisplay = inDisplay;
        myShaderButton.setGISDisplay(inDisplay);
    }
    /**
     * Sets the layer to be modified by this panel.
     * Creation date: (5/2/2001 9:01:40 AM)
     * @param newLayer gistoolkit.display.Layer
     */
    public void setLayer(Layer newLayer) {
        if (newLayer != null) {
            myShaderButton.addMouseListener(this);
            myShaderButton.setShader(newLayer.getStyle().getShader());
            myLabelName.setText(newLayer.getLayerName());
            myName = newLayer.getLayerName();
            newLayer.addLayerListener(this);
        }
        myLayer = newLayer;
        myVisibleChecker.setSelected(newLayer.isVisible());
        // allows the user to edit updateable ones, and not other ones.
        myMenuItemCommit.setVisible(myLayer.isUpdateable());
        myMenuItemRollback.setVisible(myLayer.isUpdateable());
        if (newLayer.getDataSource() instanceof MemoryDataSource) {
            myMenuItemEditTable.setVisible(true);
        }
        else
            myMenuItemEditTable.setVisible(false);
    }
    /**
     * Display the name of the layer
     */
    private JLabel myLabelName = new JLabel();
    /**
     * Save the name of the layer so I can replace it when I am done.
     */
    private String myName;
    /**
     * Used for counting the records
     */
    private int myCount = 0;
    /**
     * Reference to the containing layer panel to handle events.
     */
    private LayerPanel myLayerPanel;
    /**
     * A menu item for displaying commiting changes.
     */
    private JMenuItem myMenuItemCommit = new JMenuItem("Commit");
    /**
     * A menu item for moving the layer down.
     */
    private JMenuItem myMenuItemMoveDown = new JMenuItem("MoveDown");
    /**
     * A menu item for moving the layer up.
     */
    private JMenuItem myMenuItemMoveUp = new JMenuItem("MoveUp");
    /**
     * A menu item for removing the layer.
     */
    private JMenuItem myMenuItemRemove = new JMenuItem("Remove");
    /**
     * A menu item for displaying rolling back changes.
     */
    private JMenuItem myMenuItemRollback = new JMenuItem("Rollback");
    /**
     * A menu item for displaying rolling back changes.
     */
    private JMenuItem myMenuItemProperties = new JMenuItem("Properties");
    /** A menu item for zooming to the extent of the layer.*/
    private JMenuItem myMenuItemZoomToLayer = new JMenuItem("Zoom to Layer");
    /** A menu item for joining this datasource with a DB2 data source.*/
    private JMenuItem myMenuItemJoinDB2 = new JMenuItem("DB2 Table");
    /** A menu item for joining this datasource with a DB2 data source.*/
    private JMenuItem myMenuItemJoinOracle = new JMenuItem("Oracle Table");
    /** A menu item for joining this datasource with a PostGIS table. */
    private JMenuItem myMenuItemJoinPostgres = new JMenuItem("Postgres Table");
    /** A menu item for joining this datasource with a PostGIS table. */
    private JMenuItem myMenuItemJoinMySQL = new JMenuItem("MySQL Table");
    /** A menu item for joining this datasource with a dbase3 table. */
    private JMenuItem myMenuItemJoindbase3 = new JMenuItem("Dbase3 Table");
    /** A menu item unjoining a datasource. */
    private JMenuItem myMenuItemUnjoin = new JMenuItem("Unjoin");
    /** A menu item to edit a datasource table. */
    private JMenuItem myMenuItemEditTable = new JMenuItem("Edit Table");
    /**
     * A menu for changing attributes about this layer.
     */
    private JPopupMenu myPopupMenu;
    /**
     * Determines if this is the selected layer or not.
     */
    private boolean mySelected = false;
    /**
     * LayerEntryPanel constructor comment.
     */
    public LayerEntryPanel(Layer inLayer, LayerPanel inPanel) {
        super();
        initPanel();
        setLayer(inLayer);
        setLayerPanel(inPanel);
        addMouseListener(this);
    }
    // keep the join dialogs.
    private static DB2JoinDialog myDB2JoinDialog = null;
    private static OracleJoinDialog myOracleJoinDialog = null;
    private static PostGISJoinDialog myPostGISJoinDialog = null;
    private static DbaseFileJoinDialog myDbaseFileJoinDialog = null;
    private static MySQLJoinDialog myMySQLJoinDialog = null;
    /**
     * Respond to the events from the menu items.
     */
    public void actionPerformed(ActionEvent inAE) {
        try {
            if (inAE.getSource() == myShaderButton) {
            }
            if (inAE.getSource() == myMenuItemCommit) {
                myLayer.commit();
            }
            if (inAE.getSource() == myMenuItemRollback) {
                myLayer.rollback();
                myGISDisplay.redraw();
            }
            if (inAE.getSource() == myMenuItemRemove) {
                myLayerPanel.remove(this);
            }
            if (inAE.getSource() == myMenuItemMoveUp) {
                myLayerPanel.moveUp(this);
            }
            if (inAE.getSource() == myMenuItemMoveDown) {
                myLayerPanel.moveDown(this);
            }
            if (inAE.getSource() == myMenuItemProperties) {
                myPropertiesDlg.setLayer(myLayer);
                myPropertiesDlg.setModal(true);
                myPropertiesDlg.setTitle("Layer Properties");
                //1.4.0                myPropertiesDlg.setLocationRelativeTo(this);
                myPropertiesDlg.show();
                if (myPropertiesDlg.isOK()) {
                    myLayer = myPropertiesDlg.getLayer();
                    myName = myLayer.getLayerName();
                    myLabelName.setText(myName);
                    myShaderButton.setShader(myLayer.getStyle().getShader());
                }
            }
            if (inAE.getSource() == myMenuItemZoomToLayer) {
                myGISDisplay.setEnvelope(myLayer.getEnvelope());
                myGISDisplay.redraw();
            }
            if (inAE.getSource() == myMenuItemJoinDB2) {
                if (myDB2JoinDialog == null)
                    myDB2JoinDialog = new DB2JoinDialog();
                myDB2JoinDialog.setModal(true);
                boolean tempShow = true;
                while (tempShow) {
                    try {
                        myDB2JoinDialog.show();
                        if (myDB2JoinDialog.isOK()) {
                            DataSource tempDatasource =
                                myDB2JoinDialog.getJoinDataSource(
                                    myLayer.getDataSource());
                            myLayer.setDataSource(tempDatasource);
                        }
                        tempShow = false;
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(
                            this,
                            e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
            if (inAE.getSource() == myMenuItemJoinOracle) {
                if (myOracleJoinDialog == null)
                    myOracleJoinDialog = new OracleJoinDialog();
                myOracleJoinDialog.setModal(true);
                boolean tempShow = true;
                while (tempShow) {
                    try {
                        myOracleJoinDialog.show();
                        if (myOracleJoinDialog.isOK()) {
                            DataSource tempDatasource =
                                myOracleJoinDialog.getJoinDataSource(
                                    myLayer.getDataSource());
                            myLayer.setDataSource(tempDatasource);
                        }
                        tempShow = false;
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(
                            this,
                            e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
            if (inAE.getSource() == myMenuItemJoinPostgres) {
                if (myPostGISJoinDialog == null)
                    myPostGISJoinDialog = new PostGISJoinDialog();
                myPostGISJoinDialog.setModal(true);
                boolean tempShow = true;
                while (tempShow) {
                    try {
                        myPostGISJoinDialog.show();
                        if (myPostGISJoinDialog.isOK()) {
                            DataSource tempDatasource =
                                myPostGISJoinDialog.getJoinDataSource(
                                    myLayer.getDataSource());
                            myLayer.setDataSource(tempDatasource);
                        }
                        tempShow = false;
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(
                            this,
                            e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
            if (inAE.getSource() == myMenuItemJoinMySQL) {
                if (myMySQLJoinDialog == null)
                    myMySQLJoinDialog = new MySQLJoinDialog();
                myMySQLJoinDialog.setModal(true);
                boolean tempShow = true;
                while (tempShow) {
                    try {
                        myMySQLJoinDialog.show();
                        if (myMySQLJoinDialog.isOK()) {
                            DataSource tempDatasource =
                                myMySQLJoinDialog.getJoinDataSource(
                                    myLayer.getDataSource());
                            myLayer.setDataSource(tempDatasource);
                        }
                        tempShow = false;
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(
                            this,
                            e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
            if (inAE.getSource() == myMenuItemJoindbase3) {
                if (myDbaseFileJoinDialog == null)
                    myDbaseFileJoinDialog = new DbaseFileJoinDialog();
                myDbaseFileJoinDialog.setModal(true);
                boolean tempShow = true;
                while (tempShow) {
                    try {
                        myDbaseFileJoinDialog.show();
                        if (myDbaseFileJoinDialog.isOK()) {
                            DataSource tempDatasource =
                                myDbaseFileJoinDialog.getJoinDataSource(
                                    myLayer.getDataSource());
                            myLayer.setDataSource(tempDatasource);
                        }
                        tempShow = false;
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(
                            this,
                            e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
            if (inAE.getSource() == myMenuItemUnjoin) {
                if (myLayer.getDataSource() instanceof SimpleJoinDataSource) {
                    myLayer.setDataSource(
                        ((SimpleJoinDataSource) myLayer.getDataSource())
                            .getJoinDataSource());
                }
            }
            if (inAE.getSource() == myMenuItemEditTable) {
                gistoolkit.display.widgets.GISToolkitDialog tempDialog =
                    new gistoolkit.display.widgets.GISToolkitDialog();
                gistoolkit
                    .application
                    .layers
                    .tableeditor
                    .MemoryTableEditor tempEditor =
                    new gistoolkit
                        .application
                        .layers
                        .tableeditor
                        .MemoryTableEditor();
                if (myLayer.getDataSource() instanceof MemoryDataSource) {
                    MemoryDataSource tempMemoryDatasource =
                        (MemoryDataSource) myLayer.getDataSource();
                    tempEditor.setAttributes(
                        tempMemoryDatasource.getAttributeNames(),
                        tempMemoryDatasource.getAttributeTypes());
                    tempDialog.setContentPane(tempEditor);
                    tempDialog.setTitle("Edit Table Definition");
                    tempDialog.setModal(true);
                    tempDialog.show();
                    if (tempDialog.isOK()) {
                        tempMemoryDatasource.setAttributeNamesAndTypes(
                            tempEditor.getAttributeNames(),
                            tempEditor.getAttributeTypes());
                    }
                }
            }
            myGISDisplay.redraw();
        }
        catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(
                this,
                e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Called when the user clicks the mouse button.
     */
    public void mouseClicked(MouseEvent e) {
    }
    /**
     * Invoked when the mouse button has been moved on a component
     * (with no buttons no down).
     */
    public void mouseDragged(MouseEvent e) {
    }
    /**
     * Called when the user clicks the mouse button.
     */
    public void mouseEntered(MouseEvent e) {
    }
    /**
     * Called when the user clicks the mouse button.
     */
    public void mouseExited(MouseEvent e) {
    }
    /**
     * Invoked when the mouse button has been moved on a component
     * (with no buttons down).
     */
    public void mouseMoved(MouseEvent e) {
    }
    /**
     * Called when the user presses the mouse button.
     */
    public void mousePressed(MouseEvent e) {
        // if this layer is not selected, then select it.
        if (!mySelected) {
            myLayerPanel.select(this);
            setSelected(true);
        }
        // determine if this is a right click.
        if (e.isPopupTrigger()) {
            myPopupMenu.show(e.getComponent(), e.getX(), e.getY());
        }
    }
    /**
     * Called when the user releases the mouse butotn.
     */
    public void mouseReleased(MouseEvent e) {
        // determine if this is a right click.
        if (e.isPopupTrigger()) {
            myPopupMenu.show(e.getComponent(), e.getX(), e.getY());
        }
    }
    /**
     * Set the layer panel used for managing these entry panels.
     */
    public void setLayerPanel(LayerPanel inLayerPanel) {
        myLayerPanel = inLayerPanel;
    }
    /**
     * Allows the containing layer panel set the state of this layer.
     */
    protected void setSelected(boolean inSelected) {
        if (mySelected == inSelected) {
            return;
        }
        else {
            mySelected = inSelected;
            if (inSelected) {
                setBackground(SystemColor.GRAY);
                myVisibleChecker.setBackground(SystemColor.GRAY);
            }
            else {
                setBackground(SystemColor.control);
                myVisibleChecker.setBackground(SystemColor.control);
            }
        }
    }
    /**
     * Called when the layer has read a record from the database.
     */
    public void recordRead(LayerEvent e) {
        if (e != null) {
            if (e.getEventType() == LayerEvent.READ_BEGIN) {
                myCount = 0;
            }
            if (e.getEventType() == LayerEvent.READ_OCCURED) {
                myCount = myCount + 1;
                myLabelName.setText("read " + myCount + " records");
            }
            if (e.getEventType() == LayerEvent.READ_COMPLETE) {
                myLabelName.setText(myName);
            }
        }
    }
}