/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.application;

import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.features.*;
import gistoolkit.features.jtsutils.*;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;

/**
 * Class to listen to the GISDisplay and pop up a context sensative menu when the user right clicks.
 */
public class PopupListener implements MouseListener, ActionListener{
    
    /** A reference to the GISToolkit Display. */
    private GISDisplay myGISDisplay = null;
    /** Return a reference to the GISDisplay. */
    public GISDisplay getGISDisplay(){return myGISDisplay;}
    
    /** The menu to display when the user right clicks.*/
    private JPopupMenu myPopupMenu;
    
    /** The menu item for caclulating the length. */
    private JMenuItem myMenuItemLength = new JMenuItem("Length");
    
    /** The menu item for calculating the area. */
    private JMenuItem myMenuItemArea = new JMenuItem("Area");
    
    /** The menu item for creating the union of these objects. */
    private JMenuItem myMenuItemUnion = new JMenuItem("Union");
    
    /** The menu item for creating the difference of these objects. */
    private JMenuItem myMenuItemDifference = new JMenuItem("Difference");
    
    /** The menu item for creating the symDifference of these objects. */
    private JMenuItem myMenuItemSymDifference = new JMenuItem("SymDifference");
    
    /** Creates a new instance of PopupListener */
    public PopupListener(GISDisplay inDisplay) {
        myGISDisplay = inDisplay;

        // create the popup menu
        myPopupMenu = new JPopupMenu("Selection");
        myPopupMenu.add(myMenuItemLength);
        myPopupMenu.add(myMenuItemArea);
        myPopupMenu.add(new JSeparator());
        myPopupMenu.add(myMenuItemUnion);
        myPopupMenu.add(myMenuItemDifference);
        myPopupMenu.add(myMenuItemSymDifference);        
        
        // add listeners for the menu.
        myMenuItemLength.addActionListener(this);
        myMenuItemArea.addActionListener(this);
        myMenuItemUnion.addActionListener(this);
        myMenuItemDifference.addActionListener(this);
        myMenuItemSymDifference.addActionListener(this);
    }
        
    /** Utility class to get the selected records from the GISDisplay. */
    public Record[] getRecords(){
        Record[] tempRecords = new Record[0];
        if (getGISDisplay() != null){
            if (getGISDisplay().getDrawModel() != null){
                if (getGISDisplay().getDrawModel() instanceof SelectDrawModel){
                    SelectDrawModel tempSelectDrawModel = (SelectDrawModel) getGISDisplay().getDrawModel();
                    tempRecords = tempSelectDrawModel.getSelectedRecords();
                    
                    if (tempRecords != null){
                        // remove any duplicates
                       ArrayList tempList = new ArrayList();
                       for (int i=0; i<tempRecords.length; i++){
                           boolean found = false;
                           for (int j=0; j<tempList.size(); j++){
                               if (tempRecords[i] == tempList.get(j)){
                                   found = true;
                                   break;
                               }
                           }
                           if (!found){
                               tempList.add(tempRecords[i]);
                           }
                       }
                       
                       Record[] tempNewRecords = new Record[tempList.size()];
                       tempList.toArray(tempNewRecords);
                       tempRecords = tempNewRecords;
                    }
                }
            }
        }
        return tempRecords;
    }
    /** Utility class to get the selected layer from the GISDisplay. */
    public Layer getLayer(){
        Layer tempLayer = null;
        if (getGISDisplay() != null){
            if (getGISDisplay().getDrawModel() != null){
                if (getGISDisplay().getDrawModel() instanceof SelectDrawModel){
                    SelectDrawModel tempSelectDrawModel = (SelectDrawModel) getGISDisplay().getDrawModel();
                    tempLayer = tempSelectDrawModel.getSelectedLayer();
                }
            }
        }
        return tempLayer;
    }
    
    /** Utility class to clear the selection. */
    public void clearSelection(){
        if (getGISDisplay() != null){
            if (getGISDisplay().getDrawModel() != null){
                if (getGISDisplay().getDrawModel() instanceof SelectDrawModel){
                    SelectDrawModel tempSelectDrawModel = (SelectDrawModel) getGISDisplay().getDrawModel();
                    tempSelectDrawModel.reset();
                }
            }
        }
    }
    /** Determine what to put on the popup menu. */
    public void generatePopup(){
        // check for the number of shapes selected.
        int tempNumShapes = 0;
        Record[] tempRecords = getRecords();
        if (tempRecords.length > 0){
            tempNumShapes = tempRecords.length;
        }       

        // turn off all the options.
        myMenuItemLength.setVisible(false);
        myMenuItemArea.setVisible(false);
        myMenuItemUnion.setVisible(false);
        myMenuItemDifference.setVisible(false);
        myMenuItemSymDifference.setVisible(false);
        
        // only turn on the options that apply.
        if (tempNumShapes > 0){
            if (tempNumShapes == 1){
                // show the options
                myMenuItemLength.setVisible(true);
                myMenuItemArea.setVisible(true);
            }
            else {
                myMenuItemLength.setVisible(true);
                myMenuItemArea.setVisible(true);
                myMenuItemUnion.setVisible(true);
                myMenuItemDifference.setVisible(true);
                myMenuItemSymDifference.setVisible(true);
            }
        }
    }
    
    
    /** Invoked when the mouse button has been clicked (pressed and released) on a component.*/
    public void mouseClicked(MouseEvent e) {
    }
    
    /** Invoked when the mouse enters a component.*/
    public void mouseEntered(MouseEvent e) {
    }
    
    /** Invoked when the mouse exits a component.*/
    public void mouseExited(MouseEvent e) {
    }
    
    /** Invoked when a mouse button has been pressed on a component.*/
    public void mousePressed(MouseEvent e) {
        // when the mouse is pressed, then display the menu.
        // determine if this is a right click.
        if (e.isPopupTrigger()){
            generatePopup();
            myPopupMenu.show(e.getComponent(), e.getX(), e.getY());
        }
    }
    
    /** Invoked when a mouse button has been released on a component.*/
    public void mouseReleased(MouseEvent e) {
    }
    
    /** Invoked when an action occurs.*/
    public void actionPerformed(ActionEvent inAe) {
        try{
            if (inAe.getSource() == myMenuItemArea){
                // get the Records.
                JTSConverter tempConverter = new JTSConverter();
                Record[] tempRecords = getRecords();
                double tempArea = 0;
                for (int i=0; i<tempRecords.length; i++){
                    Shape tempShape = tempRecords[i].getShape();
                    com.vividsolutions.jts.geom.Geometry tempGeometry = tempConverter.convertShape(tempShape);
                    tempArea = tempArea + tempGeometry.getArea();
                }

                // show the area to the user.
                JOptionPane.showMessageDialog(myGISDisplay, "Area = "+tempArea, "Area of Selected Objects", JOptionPane.INFORMATION_MESSAGE);
            }
            if (inAe.getSource() == myMenuItemLength){
                // get the Records.
                JTSConverter tempConverter = new JTSConverter();
                Record[] tempRecords = getRecords();
                double tempLength = 0;
                for (int i=0; i<tempRecords.length; i++){
                    Shape tempShape = tempRecords[i].getShape();
                    com.vividsolutions.jts.geom.Geometry tempGeometry = tempConverter.convertShape(tempShape);
                    tempLength = tempLength + tempGeometry.getLength();
                }

                // show the area to the user.
                JOptionPane.showMessageDialog(myGISDisplay, "Length = "+tempLength, "Length of Selected Objects", JOptionPane.INFORMATION_MESSAGE);
            }
            if (inAe.getSource() == myMenuItemUnion){
                // get the records
                JTSConverter tempConverter = new JTSConverter();
                Record[] tempRecords = getRecords();
                if (tempRecords.length > 1){
                    com.vividsolutions.jts.geom.Geometry tempGeometry = tempConverter.convertShape(tempRecords[0].getShape());
                    for (int i=1; i<tempRecords.length; i++){
                        com.vividsolutions.jts.geom.Geometry tempTargetGeometry = tempConverter.convertShape(tempRecords[i].getShape());                
                        tempGeometry = tempGeometry.union(tempTargetGeometry);
                    }

                    Layer tempLayer = getLayer();
                    if (tempLayer != null){
                        // insert the new record.
                        Record tempInsertRecord = (Record) tempRecords[0].clone();
                        tempInsertRecord.setShape(tempConverter.convertShape(tempGeometry));
                        try{
                            tempLayer.insert(tempInsertRecord);

                            // delete the old records.
                            for (int i=0; i<tempRecords.length; i++){
                                tempLayer.delete(tempRecords[i]);
                            }

                            // clear the selection
                            clearSelection();
                            myGISDisplay.redraw();
                        }
                        catch (Exception e){
                            // show the Erorr to the user
                            e.printStackTrace();
                            JOptionPane.showMessageDialog(myGISDisplay, e.getMessage(), "Error during Insert", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
            if (inAe.getSource() == myMenuItemDifference){
                // get the records
                JTSConverter tempConverter = new JTSConverter();
                Record[] tempRecords = getRecords();
                if (tempRecords.length > 1){
                    com.vividsolutions.jts.geom.Geometry tempGeometry = tempConverter.convertShape(tempRecords[0].getShape());
                    for (int i=1; i<tempRecords.length; i++){
                        com.vividsolutions.jts.geom.Geometry tempTargetGeometry = tempConverter.convertShape(tempRecords[i].getShape());                
                        tempGeometry = tempGeometry.difference(tempTargetGeometry);
                    }

                    Layer tempLayer = getLayer();
                    if (tempLayer != null){
                        // insert the new record.
                        Record tempInsertRecord = (Record) tempRecords[0].clone();
                        tempInsertRecord.setShape(tempConverter.convertShape(tempGeometry));
                        if (tempInsertRecord.getShape() != null){
                            try{
                                tempLayer.insert(tempInsertRecord);

                                // delete the old records.
                                for (int i=0; i<tempRecords.length; i++){
                                    tempLayer.delete(tempRecords[i]);
                                }

                                // clear the selection
                                clearSelection();
                                myGISDisplay.redraw();
                            }
                            catch (Exception e){
                                // show the Erorr to the user
                                e.printStackTrace();
                                JOptionPane.showMessageDialog(myGISDisplay, e.getMessage(), "Error during Insert", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                        else{
                            JOptionPane.showMessageDialog(myGISDisplay, "Nothing was left after the operation.", "Null Shape Generated", JOptionPane.ERROR_MESSAGE);                        
                        }
                    }
                }
            }
            if (inAe.getSource() == myMenuItemSymDifference){
                // get the records
                JTSConverter tempConverter = new JTSConverter();
                Record[] tempRecords = getRecords();
                if (tempRecords.length > 1){
                    com.vividsolutions.jts.geom.Geometry tempGeometry = tempConverter.convertShape(tempRecords[0].getShape());
                    for (int i=1; i<tempRecords.length; i++){
                        com.vividsolutions.jts.geom.Geometry tempTargetGeometry = tempConverter.convertShape(tempRecords[i].getShape());                
                        tempGeometry = tempGeometry.symDifference(tempTargetGeometry);
                    }

                    Layer tempLayer = getLayer();
                    if (tempLayer != null){
                        // insert the new record.
                        Record tempInsertRecord = (Record) tempRecords[0].clone();
                        tempInsertRecord.setShape(tempConverter.convertShape(tempGeometry));
                        try{
                            tempLayer.insert(tempInsertRecord);

                            // delete the old records.
                            for (int i=0; i<tempRecords.length; i++){
                                tempLayer.delete(tempRecords[i]);
                            }

                            // clear the selection
                            clearSelection();
                            myGISDisplay.redraw();
                        }
                        catch (Exception e){
                            // show the Erorr to the user
                            e.printStackTrace();
                            JOptionPane.showMessageDialog(myGISDisplay, e.getMessage(), "Error during Insert", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(myGISDisplay, e.getMessage(), "Error during Operation", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }        
}
