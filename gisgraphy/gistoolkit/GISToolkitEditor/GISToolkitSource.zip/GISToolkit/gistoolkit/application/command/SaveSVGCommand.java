/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.application.command;

import java.io.*;
import java.awt.*;
import javax.swing.*;
import gistoolkit.application.*;
import org.apache.batik.svggen.SVGGraphics2D;
import org.apache.batik.dom.GenericDOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DOMImplementation;
/**
 * Allows the user to save the displayed immage in several formats.
 * @author  ithaqua
 */
public class SaveSVGCommand extends SimpleCommand {
    /** The identifying name for this command */
    public static String getName() {
        return "Save SVG";
    }
    
    /** The last used file. */
    private static File myLastFile = null;
    
    /** Creates new SaveCommand */
    public SaveSVGCommand(GISEditor inEditor) {
        super(getName(), getIcon("Save24.gif"), inEditor);
        putValue(SHORT_DESCRIPTION, "Save an image of the map.");
        putValue(LONG_DESCRIPTION, "Create an image of the currently displayed map.");
    }
    
    /** Perform the action */
    public void execute() {
        JFileChooser tempChooser = new JFileChooser();
        tempChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        GISFileFilter tempSVGFileFilter = new GISFileFilter("SVG", "Scaleable Vector Graphics");
        tempChooser.addChoosableFileFilter(tempSVGFileFilter);
        tempChooser.showSaveDialog(getGISEditor());
        File tempFile = tempChooser.getSelectedFile();
        if (tempFile != null) {
            if(tempChooser.getFileFilter() == tempSVGFileFilter){
                // ensure that the file has the correct type.
                String tempPath = tempFile.getAbsolutePath();
                if (tempPath.toUpperCase().endsWith(".SVG")){
                    tempPath = tempPath.substring(0, tempPath.length()-4) + ".svg";
                }
                else {
                    tempPath =  tempPath + ".svg";
                }
                tempFile = new File(tempPath);
            }
            // Get a DOMImplementation
            DOMImplementation domImpl =
            GenericDOMImplementation.getDOMImplementation();
            
            // Create an instance of org.w3c.dom.Document
            Document document = domImpl.createDocument(null, "svg", null);
            
            // Create an instance of the SVG Generator
            SVGGraphics2D svgGenerator = new SVGGraphics2D(document);
            
            // Ask the test to render into the SVG Graphics2D implementation
            getGISDisplay().printLayers(svgGenerator, new gistoolkit.features.Envelope(0, 0, getGISDisplay().getWidth(), getGISDisplay().getHeight()));
            
            // Finally, stream out SVG to the file output using UTF-8
            // character to byte encoding
            boolean useCSS = true; // we want to use CSS style attribute
            try{
                FileOutputStream fout = new FileOutputStream(tempFile);
                BufferedOutputStream bout = new BufferedOutputStream(fout);
                Writer out = new OutputStreamWriter(bout, "UTF-8");
                svgGenerator.stream(out, useCSS);
                bout.flush();
                bout.close();
                fout.close();
            }
            catch (IOException e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(getGISEditor(), "IOException writing file. "+e, "IOException saving File "+tempFile.getName(), JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private JRadioButton myRadio1 = new JRadioButton("1x1", true);
    private JRadioButton myRadio2 = new JRadioButton("2x2", false);
    private JRadioButton myRadio4 = new JRadioButton("4x4", false);
    private JRadioButton myRadio8 = new JRadioButton("8x8", false);
    private JRadioButton myRadio16 = new JRadioButton("16x16", false);
    private JRadioButton myRadio32 = new JRadioButton("32x32", false);
    private ButtonGroup myGroup = new ButtonGroup();
    private JPanel myPanel = null;
    
    private JPanel getAccessoryPanel() {
        if (myPanel == null) {
            myPanel = new JPanel(new GridLayout(0, 1, 2, 2));
            myPanel.add(myRadio1);
            myGroup.add(myRadio1);
            myPanel.add(myRadio2);
            myGroup.add(myRadio2);
            myPanel.add(myRadio4);
            myGroup.add(myRadio4);
            myPanel.add(myRadio8);
            myGroup.add(myRadio8);
            myPanel.add(myRadio16);
            myGroup.add(myRadio16);
            myPanel.add(myRadio32);
            myGroup.add(myRadio32);
        }
        return myPanel;
    }
    
    private int getFactor() {
        if (myRadio1.isSelected())
            return 1;
        if (myRadio2.isSelected())
            return 2;
        if (myRadio4.isSelected())
            return 4;
        if (myRadio8.isSelected())
            return 8;
        if (myRadio16.isSelected())
            return 16;
        if (myRadio32.isSelected())
            return 32;
        return 1;
    }
}
