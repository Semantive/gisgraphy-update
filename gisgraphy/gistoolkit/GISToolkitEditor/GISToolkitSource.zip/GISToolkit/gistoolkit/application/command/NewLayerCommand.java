/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.*;
import gistoolkit.application.*;
import gistoolkit.datasources.memory.*;
import gistoolkit.display.Layer;
import gistoolkit.display.shader.*;
import javax.swing.*;
/**
 * Allows the user create a new layer and add it to the map.
 * @author  ithaqua
 */
public class NewLayerCommand extends SimpleCommand {
    /** The identifying name for this command */
    public static String getName(){return "New Layer";}
    
    /** Creates new NewLayerCommand */
    public NewLayerCommand(GISEditor inEditor) {
        super(getName(), getIcon("New24.gif"), inEditor);
        putValue(SHORT_DESCRIPTION, "Create a new layer.");
        putValue(LONG_DESCRIPTION, "Create a new scratch layer for holding shapes.");
    }
    
    /** Performs the action */
    public void execute(){
        // query the user for the name of the new layer
        String tempName = JOptionPane.showInputDialog(getGISEditor(), "Enter the Name", "Name", JOptionPane.QUESTION_MESSAGE);
        if (tempName != null) {
            MemoryDataSource tempDataSource = new MemoryDataSource(tempName);
            Layer tempLayer = new Layer(tempDataSource);
            tempLayer.setLayerName(tempName);
            MonoShader tempShader = new MonoShader();
            tempShader.setFillColor(Color.lightGray);
            tempShader.setLineColor(Color.black);
            tempLayer.getStyle().setShader(tempShader);
            try{
                getGISDisplay().addLayer(tempLayer);
                getGISEditor().getLayerPanel().refresh();
            }
            catch (Exception e){
                JOptionPane.showMessageDialog(getGISDisplay(), e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
