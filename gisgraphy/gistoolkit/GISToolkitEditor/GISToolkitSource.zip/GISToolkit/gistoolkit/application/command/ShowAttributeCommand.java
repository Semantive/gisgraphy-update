/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.*;
import javax.swing.*;
import gistoolkit.features.Record;
import gistoolkit.display.*;
import gistoolkit.display.widgets.*;
import gistoolkit.application.*;
/**
 * Command to select all the visible records within the selected layer.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class ShowAttributeCommand extends SimpleCommand implements AttributeTableViewerListener{
    /** The identifying name for this command */
    public static String getName(){return "Show Attributes";}
    
    /** Dialog for displaying the attributes. */
     private JDialog myDialog = null;
     private gistoolkit.display.widgets.AttributeTableViewer myViewer = new gistoolkit.display.widgets.AttributeTableViewer();
     
     /** The layer to use when the dialog is called. */
     public Layer myLayer = null;
     
     /**
     * Construct a simple command with this editor.
     */
     public ShowAttributeCommand(GISEditor inEditor) {
        super(getName(), null, inEditor);
        putValue(SHORT_DESCRIPTION, "Show all attributes");
        putValue(LONG_DESCRIPTION, "Show all the attributes for the the shapes in view and the selected layer.");
        myDialog = new JDialog(inEditor, "Attributes");
        myDialog.setContentPane(myViewer);
        myViewer.addAttributeTableViewerListener(this);
     }
     
     
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        // retrieve the display
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null){
            // retrieve the Layer
            Layer tempLayer = tempDisplay.getSelectedLayer();
            if (tempLayer != null){
                myLayer = tempLayer;
                Record[] tempRecords = tempLayer.getRecords();
                myDialog.setTitle("Attributes for "+tempLayer.getLayerName());
                myViewer.setRecords(tempRecords);
                myDialog.pack();
                myDialog.show();
            }
        }
    }
    
    /**
     * Called when a row is selected.
     */
     public void recordSelected(Record inRecord){
         if (myLayer != null){
             if (inRecord != null){
                 if (getGISDisplay() != null){
                     if (getGISDisplay().getBufferImage() != null){
                         Graphics tempGraphics = getGISDisplay().getBufferImage().getGraphics();
                         if (getGISDisplay().getMapImage() != null){
                             tempGraphics.drawImage(getGISDisplay().getMapImage(),0,0,getGISDisplay());
                             myLayer.drawHighlight(inRecord, tempGraphics, getGISDisplay().getConverter());
                             getGISDisplay().getGraphics().drawImage(getGISDisplay().getBufferImage(), 0,0, getGISDisplay());
                         }
                     }
                 }
             }
         }
     }

}