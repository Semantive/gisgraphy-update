/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.io.File;
import javax.swing.*;
import gistoolkit.datasources.shapefile.ShapeFileCreator;
import gistoolkit.application.*;
import gistoolkit.features.Record;

/**
 * Command to take the records that are current in the copy buffer, and save them to permanent storage.
 */
public class SaveSelectionCommand extends SimpleCommand{
    /** The identifying name for this command */
    public static String getName(){return "Save Selected Records";}
    
    /**
     * CutCommand constructor comment.
     */
    public SaveSelectionCommand(GISEditor inEditor) {
        super(getName(), null, inEditor);
        putValue(SHORT_DESCRIPTION, "Save Records from the clipboard.");
        putValue(LONG_DESCRIPTION, "Save the selected records to a permanent storage location.");
    }
    
    /** Store the file chooser for future use. */
    JFileChooser myChooser = null;
    
    /** Execute the cut command */
    public void execute(){
        // determine if there is a current selection
        try{
            if (getGISDisplay() != null){
                Record[] tempRecords = getGISEditor().getCopyBuffer();
                if (tempRecords != null){
                    if (myChooser == null) myChooser = new JFileChooser();
                    myChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    myChooser.addChoosableFileFilter(new GISFileFilter("SHP","Shape file"));
                    myChooser.showSaveDialog(getGISEditor());
                    File tempFile = myChooser.getSelectedFile();
                    if (tempFile != null){
                        
                        String tempName = tempFile.getName();
                        if (tempName != null) {
                            ShapeFileCreator.save(tempRecords, tempName);
                        }
                    }
                }
            }
        }
        catch (Exception e){
            showError(e);
            e.printStackTrace();
        }
    }
}
