/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.io.*;
import javax.swing.*;
import gistoolkit.config.*;
import gistoolkit.application.*;

/**
 * Command to save the configuration information for this instance of the editor.
 */
public class SaveConfigurationCommand extends SimpleCommand {

    /** Remember the last used file.*/
    private File myLastFile = null;
    
    /** Creates new SaveConfigurationCommand */
    public SaveConfigurationCommand() {
    }
    
    /**
     * Construct a simple command with this editor.
     */
    public SaveConfigurationCommand(GISEditor inEditor) {
        super(inEditor);
    }

    /**
     * Saves the configuration information.
     */
    public void execute(){
        try{
            JFileChooser tempChooser = new JFileChooser();
            tempChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            tempChooser.showSaveDialog(getGISEditor());
            if (myLastFile != null) tempChooser.setSelectedFile(myLastFile);
            File tempFile = tempChooser.getSelectedFile();
            if (tempFile != null){
                Configurator.writeConfig(getGISDisplay(),tempFile.getAbsolutePath());
                myLastFile = tempFile;
            }
        }
        catch (Exception e){
            System.out.println(e);
            e.printStackTrace();
            JOptionPane.showMessageDialog(getGISEditor(), e.getMessage(), "Error Saving Configuration", JOptionPane.ERROR_MESSAGE);
        }
    }
}
