/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.features.*;
import java.awt.Rectangle;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.application.*;
/**
 * Command to zoom the extents of the map in to a new location.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class ZoomOutCommand extends SimpleCommand {
    /**
     * SelectCommand constructor comment.
     */
    public ZoomOutCommand() {
        super();
    }
    
    /**
     * Construct a simple command with this display.
     */
    public ZoomOutCommand(GISDisplay inDisplay) {
        super();
        setGISDisplay(inDisplay);
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null) tempDisplay.setDrawModel(new BoxDrawModel(this));
    }
    
    /**
     * On the first call for the select model, it will change the model to the edit model.
     */
    public void executeDraw(DrawModel inDrawModel){
        if (inDrawModel instanceof BoxDrawModel){
            BoxDrawModel tempBoxDrawModel = (BoxDrawModel) inDrawModel;
            
            // retrieve the rectangle from the box
            Rectangle tempRectangle = tempBoxDrawModel.getRectangle();
            if ((tempRectangle.width < 6) || (tempRectangle.height < 6)){
                
                // if the rectangle is too small, then increase the extents by a factor of 2
                Envelope tempEnvelope = getGISDisplay().getEnvelope();
                if (tempEnvelope == null) return;
                double width = tempEnvelope.getWidth();
                double height = tempEnvelope.getHeight();
                
                // find the point of the click location
                Converter tempConverter = getGISDisplay().getConverter();
                
                if (tempConverter != null){
                    // Make the new extents half the size of the old ones, and centered
                    // on the click location.
                    double tempCenterX = tempConverter.toWorldX(tempRectangle.x);
                    double tempCenterY = tempConverter.toWorldY(tempRectangle.y);
                    width = width*2;
                    height = height*2;
                    double tempMinX = tempCenterX - width;
                    double tempMinY = tempCenterY - height;
                    double tempMaxX = tempCenterX+width;
                    double tempMaxY = tempCenterY+height;
                    try{
                        getGISDisplay().setEnvelope(new Envelope(tempMinX, tempMinY, tempMaxX, tempMaxY));
                    }
                    catch (Exception e){showError(e);}
                }
            }
            else{
                // attempt to fit the current rectangle within the given rectangle.
                
                // find the proportion of the screen in X
                int newWidth = getGISDisplay().getWidth() * (getGISDisplay().getWidth()/tempRectangle.width);
                int newHeight = getGISDisplay().getHeight() * (getGISDisplay().getHeight()/tempRectangle.height);
                
                // find the center of the rectangle
                int tempCenterX = tempRectangle.x + tempRectangle.width/2;
                int tempCenterY = tempRectangle.y + tempRectangle.height/2;
                
                // calculate the new Extents
                Converter tempConverter = getGISDisplay().getConverter();
                
                if (tempConverter != null){
                    double tempTopX = tempConverter.toWorldX(tempCenterX - newWidth/2);
                    double tempTopY = tempConverter.toWorldY(tempCenterY - newHeight/2);
                    double tempBottomX = tempConverter.toWorldX(tempCenterX + newWidth/2);
                    double tempBottomY = tempConverter.toWorldY(tempCenterY + newHeight/2);
                    
                    // set the new extents
                    tempBoxDrawModel.setRectangle(null);
                    try{
                        getGISDisplay().setEnvelope(new Envelope(tempTopX, tempTopY, tempBottomX, tempBottomY));
                    }
                    catch (Exception e){showError(e);}
                        
                }
            }
        }
    }
    
    /**
     * Construct a simple command with this display.
     */
    public ZoomOutCommand(GISEditor inEditor) {
        super(inEditor);
    }
}