/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.display.widgets.*;
import gistoolkit.application.*;
import java.awt.*;
import javax.swing.*;

/**
 * Exits the application.
 * @author  ithaqua
 * @version 
 */
public class AboutCommand extends SimpleCommand {
    /** The identifying name for this command */
    public static String getName(){return "About";}

    /** Creates new ExitCommand */
    public AboutCommand(GISEditor inEditor) {
        super(getName(), getIcon("Help24.gif"), inEditor);
        putValue(SHORT_DESCRIPTION, "Show About Dialog.");
        putValue(LONG_DESCRIPTION, "Show information about the GISToolkitEditor.");
    }
    
    /** Perform the action */
    public void execute(){
        try{
            GISToolkitDialog tempHelpDialog = new GISToolkitDialog(getGISEditor(), "About GISToolkitEditor");
            JPanel tempPanel = new JPanel();
            tempHelpDialog.setContentPane(tempPanel);
            
            // initialize the panel.
            tempPanel.setLayout(new GridBagLayout());
            GridBagConstraints c =new GridBagConstraints();
            c.weightx = 1;
            c.weighty = 0;
            c.fill = GridBagConstraints.NONE;
            c.gridx = 0;
            c.gridy = 0;
            tempPanel.add(new JLabel("Version " + GISEditor.getVersion()), c);
            
            c.gridy++;
            c.weightx = 1;
            c.weighty = 1;
            c.fill = GridBagConstraints.BOTH;
            StringBuffer sb = new StringBuffer();
            sb.append("GISToolkit - Geographical Information System Toolkit\n");
            sb.append("(C) 2003, Ithaqua Enterprises Inc.\n\n");
            sb.append("This library is free software; you can redistribute it and/or\n");
            sb.append("modify it under the terms of the GNU Lesser General Public\n");
            sb.append("License as published by the Free Software Foundation; \n");
            sb.append("version 2.1 of the License.\n\n");
            sb.append("This library is distributed in the hope that it will be useful,\n");
            sb.append("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
            sb.append("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU\n");
            sb.append("Lesser General Public License for more details.\n\n");
            sb.append("You should have received a copy of the GNU Lesser General Public\n");
            sb.append("License along with this library; if not, write to the Free Software\n");
            sb.append("Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n");
            JTextArea tempTextArea = new JTextArea(sb.toString());
            tempTextArea.setEditable(false);
            JScrollPane tempScroll = new JScrollPane(tempTextArea);
            tempPanel.add(tempScroll, c);
            tempHelpDialog.pack();
            tempHelpDialog.setVisible(true);
        }
        catch (Exception e){
            showError(e);
        }
    }    
}
