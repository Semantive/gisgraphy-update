/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;
import gistoolkit.application.*;
import gistoolkit.features.Record;
import gistoolkit.display.Layer;

/**
 * Command to insert the records in the copy buffer into another data source.
 */
public class PasteCommand extends SimpleCommand{
    /** The identifying name for this command */
    public static String getName(){return "Paste";}
        
    /**
     * CutCommand constructor comment.
     */
    public PasteCommand(GISEditor inEditor) {
        super(getName(), getIcon("Paste24.gif"), inEditor);
        putValue(SHORT_DESCRIPTION, "Paste records from the clipboard");
        putValue(LONG_DESCRIPTION, "Insert records into this layer that were previously cut or coppied from another layer.");
    }
    
    /** Execute the cut command */
    public void execute(){
        // determine if there is a current selection
        try{
            if (getGISEditor() != null){
                Layer tempSelectedLayer = getGISDisplay().getSelectedLayer();
                if (tempSelectedLayer != null){
                    Record[] tempRecords = getGISEditor().getCopyBuffer();
                    if (tempRecords != null){
                        if (tempSelectedLayer.isUpdateable()){
                            for (int i=0; i<tempRecords.length; i++){
                                tempSelectedLayer.insert(tempRecords[i]);
                            }
                            getGISEditor().refresh();
                        }
                        else{
                            showInformation("Layer Not Updateable", "Can not insert records.");
                        }
                    }
                }
            }
        }
        catch (Exception e){
            showError(e);
        }
    }
}
