/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.display.*;
import gistoolkit.features.*;
import gistoolkit.application.*;

/**
 * Command to reset the Envelope of the map to a preset ammount.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class ResetEnvelopeCommand extends SimpleCommand {
    
    /**
     * Holds the Envelope when this command is selected, it will set the Envelope
     * of its display to this values.
     */
    private Envelope myEnvelope = null;
    
    /**
     * SelectCommand constructor comment.
     */
    public ResetEnvelopeCommand() {
        super();
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null) {
            try{
                tempDisplay.setEnvelope(myEnvelope);
            }
            catch (Exception e){
                showError(e);
            }
            
        }
    }
    
    /**
     * Set the Envelope in this command.
     */
    public void setEnvelope(Envelope inEnvelope){
        myEnvelope = inEnvelope;
    }
    
    /**
     * Construct a simple command with this display.
     */
    public ResetEnvelopeCommand(GISEditor inEditor) {
        super(inEditor);
    }
}