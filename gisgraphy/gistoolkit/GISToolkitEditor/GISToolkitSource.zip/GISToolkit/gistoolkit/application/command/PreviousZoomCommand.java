/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.util.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
//import gistoolkit.display.drawmodel.*;
import gistoolkit.application.*;

/**
 * Command to record the extents of the map, and recall those extents.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class PreviousZoomCommand extends SimpleCommand implements GISDisplayListener{
    
    /** Holds pointers to the extents so they can be recalled. */
    private ArrayList myArrayListEnvelopes = new ArrayList();
    
    /** Indicates whether the new Extents should be recorded */
    private boolean myRecordExtents = true;
    
    /** Construct a PreviousZoomCommand.*/
    public PreviousZoomCommand() {
        super();
    }
    
    /** Construct a PreviousZoomCommand with this editor.*/
    public PreviousZoomCommand(GISEditor inEditor) {
        super(inEditor);
        getGISDisplay().addGISDisplayListener(this);
    }
    
    /** Place to store the currently displayed extents */
    private Envelope myCurrentEnvelope = null;
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        // find the last zoom on the list
        if (myArrayListEnvelopes.size() > 0){
            myRecordExtents = false;
            try{
                Envelope tempEnvelope = (Envelope) myArrayListEnvelopes.remove(myArrayListEnvelopes.size()-1);
                if (myArrayListEnvelopes.size() == 0) myArrayListEnvelopes.add(tempEnvelope);
                if (tempEnvelope != null){
                    getGISDisplay().setEnvelope(tempEnvelope);
                    myCurrentEnvelope = tempEnvelope;
                }
            }
            catch(Exception e){
                System.out.println("Exception setting Envelope "+e);
            }
            myRecordExtents = true;
        }
    }
        
    
    /** Extents have changed  */
    public void envelopeChanged(Envelope inEnvelope) {
        if (inEnvelope == null) return;
        if (myRecordExtents){
            if (myArrayListEnvelopes.size() == 0) {
                myArrayListEnvelopes.add(inEnvelope);
            }
            if (myCurrentEnvelope != null) myArrayListEnvelopes.add(myCurrentEnvelope);
            myCurrentEnvelope = inEnvelope;
            
        }
    }
    
}