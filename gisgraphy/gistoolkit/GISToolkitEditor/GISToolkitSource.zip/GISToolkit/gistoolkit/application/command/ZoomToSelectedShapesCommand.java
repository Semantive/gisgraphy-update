/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import javax.swing.*;
import gistoolkit.features.Record;
import gistoolkit.features.Envelope;
import gistoolkit.features.featureutils.EnvelopeBuffer;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.application.*;
/**
 * Command to select all the visible records within the selected layer.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class ZoomToSelectedShapesCommand extends SimpleCommand{
    /** The identifying name for this command */
    public static String getName(){return "Zoom To Shapes";}
    
    /** The layer to use when the dialog is called. */
    public Layer myLayer = null;
    
    /**
     * Construct a simple command with this editor.
     */
    public ZoomToSelectedShapesCommand(GISEditor inEditor) {
        super(getName(), null, inEditor);
        putValue(SHORT_DESCRIPTION, "Zoop to selected shapes.");
        putValue(LONG_DESCRIPTION, "Zoom to the selected shapes.");
    }
    
    /**
     * Zooms to the selected records, or the selected layer if no records selected.
     */
    public void execute(){
        // retrieve the display
        GISEditor tempEditor = getGISEditor();
        if (tempEditor != null){
            Envelope tempEnvelope = null;
            
            // check for the selected records.
            if (getGISDisplay().getDrawModel() instanceof SelectDrawModel){
                Record[] tempRecords = ((gistoolkit.display.drawmodel.SelectDrawModel) getGISDisplay().getDrawModel()).getSelectedRecords();
                if ((tempRecords != null) && (tempRecords.length > 0)){
                    EnvelopeBuffer tempEnvelopeBuffer = new EnvelopeBuffer();
                    for (int i=0; i<tempRecords.length; i++){
                        if (tempRecords[i] != null){
                            gistoolkit.features.Shape tempShape = tempRecords[i].getShape();
                            if (tempShape != null){
                                tempEnvelopeBuffer.expandToInclude(tempShape.getEnvelope());
                            }
                        }
                    }
                    tempEnvelope = tempEnvelopeBuffer.getEnvelope();
                }
            }
            
            // check the layer
            if (tempEnvelope == null){
                Layer tempLayer = getGISDisplay().getSelectedLayer();
                if (tempLayer != null){
                    try{
                        tempEnvelope = tempLayer.getEnvelope();
                    }
                    catch (Exception e){
                    }
                }
            }
            
            // xoom to this Envelope
            if (tempEnvelope != null){
                try{
                    getGISDisplay().setEnvelope(tempEnvelope);
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(getGISEditor(), e.getMessage(), "Error on set Envelope", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}