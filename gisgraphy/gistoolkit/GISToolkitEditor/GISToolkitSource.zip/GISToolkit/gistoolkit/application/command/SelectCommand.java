/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.application.*;
/**
 * Command to enable the select draw model on the display
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class SelectCommand extends SimpleCommand implements KeyListener{
    /** The identifying name for this command */
    public static String getName(){return "Select";}

    /**
     * Construct a simple command with this editor.
     */
    public SelectCommand(GISEditor inEditor) {
        super(getName(), null, inEditor);
        putValue(SHORT_DESCRIPTION, "Select Features");
        putValue(LONG_DESCRIPTION, "Select features from the currently selected layer.");
    }
     
    
    HighlightDrawModel myDrawModel = null;
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        // retrieve the display
        GISDisplay tempDisplay = getGISDisplay();
        tempDisplay.addKeyListener(this);
        
        // create a new HighlightDrawModel
        HighlightDrawModel tempDrawModel = new HighlightDrawModel(this);
        myDrawModel = tempDrawModel;
        
        //Set the draw model to modify the drawing of the display
        if (tempDisplay != null){
            tempDisplay.setDrawModel(tempDrawModel);
            JPanel tempPanel = getGISEditor().getAuxillaryPanel();
            if (tempPanel != null){
                // add the listener panel
                HighlightDrawModelListener tempDrawModelListener = new HighlightDisplay();
                tempDrawModel.add(tempDrawModelListener);
                tempPanel.removeAll();
                tempPanel.setLayout(new BorderLayout());
                tempPanel.add((Component) tempDrawModelListener, BorderLayout.CENTER);
                tempPanel.validate();
            }
        }
    }
        
    public void keyPressed(java.awt.event.KeyEvent ke) {
        // handle the escape key
        if ((ke.getKeyCode() == KeyEvent.VK_BACK_SPACE)||
        (ke.getKeyCode() == KeyEvent.VK_DELETE)){
            if (myDrawModel != null){
                if (myDrawModel.getRecord() != null){
                    // retrieve the layer.
                    try{
                        myDrawModel.getLayer().delete(myDrawModel.getRecord());
                        myDrawModel.reset();
                        getGISDisplay().update(getGISDisplay().getGraphics());
                    }
                    catch (Exception e){
                        System.out.println("Error Deleting Record "+e);
                        getGISDisplay().update(getGISDisplay().getGraphics());
                    }
                }
            }
        }
    }    
    public void keyTyped(java.awt.event.KeyEvent ke) {
    }
    
    public void keyReleased(java.awt.event.KeyEvent ke) {
    }
}