/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.display.*;
import gistoolkit.application.*;
import gistoolkit.application.dialog.*;
/**
 * Edit the Scale Bar
 */
public class ScaleBarCommand extends SimpleCommand {
    /** The identifying name for this command */
    public static String getName(){return "Edit Scale Bar";}
    
    /** Reference to the ScaleBarDialog so we don't have to recreate it. */
    private ScaleBarDialog myScaleBarDialog = null;
    
    /** Creates new ScaleBarCommand */
    public ScaleBarCommand(GISEditor inEditor) {
        super(getName(), null, inEditor);
        putValue(SHORT_DESCRIPTION, "Edit the current scale bar.");
        putValue(LONG_DESCRIPTION, "Select a different Scale Bar, or edit the current Scale Bar.");
    }
    
    /** Executed when the button is pushed. Displays the Scale Bar edit dialog.*/
    public void execute(){
        ScaleBar tempScaleBar = getGISDisplay().getScaleBar();
        if (myScaleBarDialog == null) myScaleBarDialog = new ScaleBarDialog(getGISEditor());
        myScaleBarDialog.setScaleBar(tempScaleBar);
        myScaleBarDialog.setModal(true);
        myScaleBarDialog.setVisible(true);
        if (myScaleBarDialog.isOK()){
            getGISDisplay().setScaleBar(myScaleBarDialog.getScaleBar());
        }
        getGISDisplay().redraw();
    }
}
