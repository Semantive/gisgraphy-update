/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.display.*;
import gistoolkit.application.*;
import javax.swing.JOptionPane;

/**
 * Exits the application.
 * @author  ithaqua
 * @version 
 */
public class ExitCommand extends SimpleCommand {
    /** The identifying name for this command */
    public static String getName(){return "Exit";}

    /** Creates new ExitCommand */
    public ExitCommand(GISEditor inEditor) {
        super(getName(), getIcon("Exit24.gif"), inEditor);
        putValue(SHORT_DESCRIPTION, "Exit the Application");
        putValue(LONG_DESCRIPTION, "Exit the Application.");
    }
    
    /** Perform the action */
    public void execute(){
        try{
            // check that there are no Layers that are not saved.
            if (getGISEditor() != null){
                if (getGISDisplay() != null){
                    Layer[] tempLayers = getGISDisplay().getLayers();
                    if (tempLayers != null){
                        for (int i=0; i<tempLayers.length; i++){
                            if (tempLayers[i].isDirty()){
                                int tempChoice = JOptionPane.showConfirmDialog(getGISEditor(), tempLayers[i].getLayerName(), "Save Layer?", JOptionPane.YES_NO_CANCEL_OPTION);
                                if (tempChoice == JOptionPane.YES_OPTION){
                                    tempLayers[i].commit();
                                }
                                if (tempChoice == JOptionPane.CANCEL_OPTION){
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            getGISEditor().dispose();
            getGISEditor().saveConfig();
            System.exit(0);
        }
        catch (Exception e){
            showError(e);
        }
    }

}
