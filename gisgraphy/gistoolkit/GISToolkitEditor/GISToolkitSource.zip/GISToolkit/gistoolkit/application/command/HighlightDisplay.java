/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.*;
import javax.swing.*;
import gistoolkit.features.*;
import gistoolkit.display.drawmodel.*;
/**
 * Panel for displaying the attribute data associated with a shape.
 * Creation date: (5/7/2001 9:33:14 AM)
 */
public class HighlightDisplay extends javax.swing.JPanel implements HighlightDrawModelListener, SelectDrawModelListener{
    
    // Text Area for displaying the text information.
    private JTextArea myTextArea = new JTextArea();
    
    /**
     * HighlightDisplay constructor comment.
     */
    public HighlightDisplay(){
        super();
        initPanel();
    }
    /**
     * Add the GUI widgets to the display.
     */
    private void initPanel(){
        
        // set the layout
        setLayout(new BorderLayout());
        
        // create the text area
        myTextArea = new JTextArea();
        myTextArea.setEditable(false);
        
        // create a scroll panel
        JScrollPane tempScrollPane = new JScrollPane(myTextArea);
        
        // set the scroll pane as the center of the border
        add(tempScrollPane, BorderLayout.CENTER);
    }
    /**
     * Called when a record has been deselected.
     */
    public void recordDeselected(Record inRecord){
        myTextArea.setText("");
    }
    /**
     * Called when a record has been selected.
     */
    public void recordSelected(Record inRecord){
        String[] tempNames = inRecord.getAttributeNames();
        Object[] tempValues = inRecord.getAttributes();
        
        // create a string to manage this data
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<tempNames.length; i++){
            sb.append(tempNames[i]);
            sb.append("=");
            sb.append(tempValues[i]);
            sb.append("\n");
        }
        
        
        // add to the text area
        myTextArea.setText(sb.toString());
    }
    
    /** Called when records have been selected.*/
    public void recordsSelected(Record[] inRecords){
        if (inRecords == null) return;
        if (inRecords.length == 1){
            recordSelected(inRecords[0]);
        }
    }
    
    /** Called when records have been deselected. */
    public void recordsDeselected(Record[] inRecords){
        if (inRecords == null) return;
        if (inRecords.length > 0){
            recordDeselected(inRecords[0]);
        }
    }
}
