/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.Rectangle;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.application.*;
/**
 * Command to zoom the envelope of the map in to a new location.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class ZoomInCommand extends SimpleCommand {
    /**
     * SelectCommand constructor comment.
     */
    public ZoomInCommand() {
        super();
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null) tempDisplay.setDrawModel(new BoxDrawModel(this));
    }
    
    /**
     * On the first call for the select model, it will change the model to the edit model.
     */
    public void executeDraw(DrawModel inDrawModel){
        if (inDrawModel instanceof BoxDrawModel){
            BoxDrawModel tempBoxDrawModel = (BoxDrawModel) inDrawModel;
            
            // retrieve the rectangle from the box
            Rectangle tempRectangle = tempBoxDrawModel.getRectangle();
            if ((tempRectangle.width < 6) || (tempRectangle.height < 6)){
                
                // if the rectangle is too small, then decrease the Envelope by a factor of 2
                Envelope tempEnvelope = getGISDisplay().getEnvelope();
                if (tempEnvelope == null) return;
                double width = tempEnvelope.getWidth();
                double height = tempEnvelope.getHeight();
                
                // find the point of the click location
                Converter tempConverter = getGISDisplay().getConverter();
                
                if (tempConverter != null){
                    // Make the new Envelope half the size of the old ones, and centered
                    // on the click location.
                    double tempCenterX = tempConverter.toWorldX(tempRectangle.x);
                    double tempCenterY = tempConverter.toWorldY(tempRectangle.y);
                    width = width/4.0;
                    height = height/4.0;
                    tempEnvelope = new Envelope(
                        tempCenterX - width,
                        tempCenterY - height,
                        tempCenterX+width,
                        tempCenterY+height
                    );
                    try{
                        getGISDisplay().setEnvelope(tempEnvelope);
                    }
                    catch (Exception e){
                        showError(e);
                    }
                }
            }
            else{
                try{
                    getGISDisplay().setEnvelope(tempBoxDrawModel.getEnvelope());
                }
                catch (Exception e){
                    showError(e);
                }
            }
            tempBoxDrawModel.setRectangle(null);
            tempBoxDrawModel.draw();
        }
    }
    
    /**
     * Construct a simple command with this editor.
     */
    public ZoomInCommand(GISEditor inEditor) {
        super(inEditor);
    }
}