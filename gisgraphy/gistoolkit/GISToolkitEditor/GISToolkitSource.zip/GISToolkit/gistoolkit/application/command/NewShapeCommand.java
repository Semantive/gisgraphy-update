/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.display.widgets.*;
import gistoolkit.application.*;
/**
 * Command to select objects on the display to edit, and then edit (move the nodes of the selected object)
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class NewShapeCommand extends SimpleCommand implements ActionListener, MouseListener{
    private NewShapeDrawModel myNewShapeDrawModel = null;
    
    
    /**
     * SelectCommand constructor comment.
     */
    public NewShapeCommand() {
        super();
        myNewShapeDrawModel = new NewShapeDrawModel(this);
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        GISDisplay tempDisplay = getGISDisplay();
        if (myNewShapeDrawModel == null) myNewShapeDrawModel = new NewShapeDrawModel(this);
        myNewShapeDrawModel.reset();
        if (tempDisplay != null) tempDisplay.setDrawModel(myNewShapeDrawModel);
        // add the auxiliary panel.
        JPanel tempPanel = getGISEditor().getAuxillaryPanel();
        if (tempPanel != null){
            // validate the layer
            Layer tempLayer = getGISDisplay().getSelectedLayer();
            if (tempLayer == null){
                JOptionPane.showMessageDialog(getGISDisplay(), "Please add or select a layer and retry", "Can Not Save Shape", JOptionPane.ERROR_MESSAGE);
            }
            
            // New Record
            String[] tempAttributeNames = tempLayer.getAttributeNames();
            AttributeType[] tempAttributeTypes = tempLayer.getAttributeTypes();
            if (tempAttributeNames == null) tempAttributeNames = new String[0];
            Object[] tempAttributes = new Object[tempAttributeNames.length];
            Record tempRecord = new Record();
            tempRecord.setAttributeNames(tempAttributeNames);
            tempRecord.setAttributeTypes(tempAttributeTypes);
            tempRecord.setAttributes(tempAttributes);
            
            // add the listener panel
            myAttributePanel = new AttributePanel();
            myAttributePanel.setRecord(tempRecord, tempLayer);
            tempPanel.removeAll();
            tempPanel.setLayout(new BorderLayout());
            tempPanel.add((Component) myAttributePanel, BorderLayout.CENTER);
            tempPanel.validate();
        }
    }
    
    /** Keeps a reference to the attribute panel so it can be accessed in the done method */
    private AttributePanel myAttributePanel = null;
    
    /**
     * Called when the draw model has completed it's action.
     */
    public void executeDraw(DrawModel inDrawModel){
        if (inDrawModel instanceof NewShapeDrawModel){
            
            // retrieve the shape
            gistoolkit.features.Shape tempShape = ((NewShapeDrawModel) inDrawModel).getShape();
            if (tempShape == null) {
                JOptionPane.showMessageDialog(getGISDisplay(), "The Shape is not valid", "Can Not Save Shape", JOptionPane.ERROR_MESSAGE);
            }
            else{
                // find the selected layer
                Layer tempLayer = getGISDisplay().getSelectedLayer();
                if (tempLayer == null){
                    JOptionPane.showMessageDialog(getGISDisplay(), "Please add or select a layer and retry", "Can Not Save Shape", JOptionPane.ERROR_MESSAGE);
                }
                else{
                    if (!tempLayer.isUpdateable()){
                        JOptionPane.showMessageDialog(getGISDisplay(), "The selected layer is not editable", "Can Not Save Shape", JOptionPane.ERROR_MESSAGE);
                    }
                    else{
                        // create a new record
                        try{
                            Record tempRecord = myAttributePanel.getRecord();
                            tempRecord.setShape(myNewShapeDrawModel.getShape());
                            tempLayer.insert(tempRecord);
                            inDrawModel.reset();
                            if (getGISDisplay() != null) getGISDisplay().update(getGISDisplay().getGraphics());
                            myAttributePanel.removeAll();
                        }
                        catch (Exception e){
                            System.out.println(e);
                            e.printStackTrace();
                            JOptionPane.showMessageDialog(getGISDisplay(), "The Insert Failed: "+e, "Can Not Save Shape", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
                getGISEditor().validate();
            }
            myGISMenuButton.doClick();
        }        
    }
    
    
    /** Button for adding a new polygon.*/
    private JRadioButton myButtonNewPolygon = null;
    
    /** Button for adding a new polygon.*/
    private JRadioButton myButtonNewLine = null;
    
    /** Button for adding a new polygon.*/
    private JRadioButton myButtonNewPoint = null;
    
    /** Button for finishing the edits. */
    private JRadioButton myButtonDone = null;
    
    /**
     * Reference to the GIS menu button such that it can be accessed later when the sub buttons need to be set visible.
     */
    private GISMenuButton myGISMenuButton;
    
    /**
     * Construct a simple command with this display.
     */
    public NewShapeCommand(GISEditor inEditor) {
        super(inEditor);
    }
    
    /**
     * Respont to the actions of the buttons
     */
    public void actionPerformed(ActionEvent inActionEvent){
        if (myNewShapeDrawModel == null) myNewShapeDrawModel = new NewShapeDrawModel(this);
        if (inActionEvent.getSource() == myButtonNewPoint){
            myNewShapeDrawModel.setShapeType(NewShapeDrawModel.POINT);
            myGISMenuButton.setButtonsVisible(false);
            myGISMenuButton.setToolTipText(myButtonNewPoint.getToolTipText());
            myGISMenuButton.setIcon(myButtonNewPoint.getIcon());
            myGISMenuButton.setSelectedIcon(myButtonNewPoint.getSelectedIcon());
            myGISMenuButton.setRolloverIcon(myButtonNewPoint.getRolloverIcon());
            myGISMenuButton.doClick();
        }
        if (inActionEvent.getSource() == myButtonNewLine){
            myNewShapeDrawModel.setShapeType(NewShapeDrawModel.LINE);
            myGISMenuButton.setButtonsVisible(false);
            myGISMenuButton.setToolTipText(myButtonNewLine.getToolTipText());
            myGISMenuButton.setIcon(myButtonNewLine.getIcon());
            myGISMenuButton.setSelectedIcon(myButtonNewLine.getSelectedIcon());
            myGISMenuButton.setRolloverIcon(myButtonNewLine.getRolloverIcon());
            myGISMenuButton.doClick();
        }
        if (inActionEvent.getSource() == myButtonNewPolygon){
            myNewShapeDrawModel.setShapeType(NewShapeDrawModel.POLYGON);
            myGISMenuButton.setButtonsVisible(false);
            myGISMenuButton.setToolTipText(myButtonNewPolygon.getToolTipText());
            myGISMenuButton.setIcon(myButtonNewPolygon.getIcon());
            myGISMenuButton.setSelectedIcon(myButtonNewPolygon.getSelectedIcon());
            myGISMenuButton.setRolloverIcon(myButtonNewPolygon.getRolloverIcon());
            myGISMenuButton.doClick();
        }
        if (inActionEvent.getSource() == myButtonDone){
            try{
                // retrieve the record from the attribute panel, causing it to update the record.
                if (myAttributePanel != null) myAttributePanel.getRecord();
                
                // notify the edit model that it is done.
                myNewShapeDrawModel.done();
                
                // remove the buttons.
                if (myGISMenuButton != null){
                    myGISMenuButton.setButtonsVisible(false);
                }
                
                // remove the panel
                JPanel tempPanel = getGISEditor().getAuxillaryPanel();
                if (tempPanel != null){
                    tempPanel.removeAll();
                    tempPanel.validate();
                }
                getGISDisplay().paint(getGISDisplay().getGraphics());
                getGISEditor().validate();
            }
            catch (Exception e){
                System.out.println(e);
                e.printStackTrace(System.out);
            }
        }
        if (getGISDisplay() != null) getGISDisplay().requestFocus();
    }
    
    /**
     *Removes the additional buttons from visibility.
     */
    public void removeDraw(DrawModel inDrawModel){
        if (myGISMenuButton != null) myGISMenuButton.setButtonsVisible(false);
    }
    
    /** Button group for radio button behavior of the buttons */
    private ButtonGroup myButtonGroup = new ButtonGroup();
    
    /**
     *Set up a button for use.
     */
    private JRadioButton getButton(String inToolTip, String inInactiveIcon, String inActiveIcon){
        JRadioButton tempRadioButton = new JRadioButton();
        tempRadioButton.setIcon(getIcon(inInactiveIcon));
        tempRadioButton.setSelectedIcon(getIcon(inActiveIcon));
        tempRadioButton.setRolloverIcon(tempRadioButton.getSelectedIcon());
        tempRadioButton.setRolloverEnabled(true);
        tempRadioButton.setToolTipText(inToolTip);
        tempRadioButton.addActionListener(this);
        tempRadioButton.setBorder(null);
        myButtonGroup.add(tempRadioButton);
        return tempRadioButton;
    }
     
    /**
     * Set the button in this command.  Allows this button to assign the sub buttons to the menu.
     */
    public void setButton(GISMenuButton inButton){
        if (inButton != null){
            myButtonNewPolygon = getButton("New Polygon","NewPolygonInactive.png","NewPolygonActive.png");
            inButton.addButton(myButtonNewPolygon);
            myButtonNewLine = getButton("New Line","NewLineInactive.png","NewLineActive.png");
            inButton.addButton(myButtonNewLine);
            myButtonNewPoint = getButton("New Point","NewPointInactive.png","NewPointActive.png");
            inButton.addButton(myButtonNewPoint);
            myButtonDone = getButton("Done Editing","DoneEditingInactive.png","DoneEditingActive.png");
            inButton.addButton(myButtonDone);
            myGISMenuButton = inButton;
            myGISMenuButton.addMouseListener(this);
        }
    }
    
    public void mousePressed(java.awt.event.MouseEvent inMouseEvent) {
    }
    
    public void mouseEntered(java.awt.event.MouseEvent inMouseEvent) {
    }
    
    public void mouseReleased(java.awt.event.MouseEvent inMouseEvent) {
        if ((inMouseEvent.getModifiers() & MouseEvent.BUTTON3_MASK) != 0){
            myGISMenuButton.setButtonsVisible(true);
        }
    }
    
    public void mouseClicked(java.awt.event.MouseEvent inMouseEvent) {
    }
    
    public void mouseExited(java.awt.event.MouseEvent inMouseEvent) {
    }
    
}