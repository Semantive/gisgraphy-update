/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.features.Record;
import gistoolkit.display.*;
import gistoolkit.application.*;
/**
 * Command to select all the visible records within the selected layer.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class SelectAllCommand extends SimpleCommand{
    /** The identifying name for this command */
    public static String getName(){return "Select All";}
    
    /**
     * Construct a simple command with this editor.
     */
    public SelectAllCommand(GISEditor inEditor) {
        super(getName(), null, inEditor);
        putValue(SHORT_DESCRIPTION, "Select All Features");
        putValue(LONG_DESCRIPTION, "Select all visible features from the currently selected layer.");
     }
        
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        // retrieve the display
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null){
            // retrieve the Layer
            Layer tempLayer = tempDisplay.getSelectedLayer();
            if (tempLayer != null){
                Record[] tempRecords = tempLayer.getRecords();
                if (tempRecords != null){
                    for (int i=0; i<tempRecords.length; i++){
                        tempLayer.drawHighlight(tempRecords[i], tempDisplay.getGraphics(), tempDisplay.getConverter());
                    }
                    getGISEditor().setCopyBuffer(tempRecords);
                    try{
                        Thread.sleep(1000);
                    }
                    catch(InterruptedException e){
                    }
                    tempDisplay.redraw();
                }
            }
        }
    }
}