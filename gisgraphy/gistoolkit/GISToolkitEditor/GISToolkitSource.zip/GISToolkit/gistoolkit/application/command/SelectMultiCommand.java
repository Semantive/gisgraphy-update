/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.projection.*;
import gistoolkit.datasources.GISDataset;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.display.widgets.*;
import gistoolkit.application.*;
/**
 * Command to allow the selection of one or more objects on the display.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class SelectMultiCommand extends SimpleCommand implements ActionListener, MouseListener{
    
    public static final int SELECT_POINTER = 0; // select with the pointer
    public static final int SELECT_BOX = 1; // select by drawing a box on the screen
    public static final int SELECT_POINTS = 2; // select by drawing points on the screen.
    public static final int SELECT_DISTANCE = 3; // select by drawing a point on the screen and entering a distance.
    
    /** The currently selected type of selection to use. */
    private int myType = 0;
    
    /** Set the type of select to use. */
    public void setType(int inType){myType = inType;}
    
    /** Update the draw model with the currently selected type */
    private void updateType(int inType){
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null) {
            if (inType == SELECT_POINTER){
                SelectPointerModel tempModel = new SelectPointerModel();
                tempDisplay.setDrawModel(tempModel);
                
                //Set the draw model to modify the drawing of the display
                JPanel tempPanel = getGISEditor().getAuxillaryPanel();
                if (tempPanel != null){
                    // add the listener panel
                    SelectDrawModelListener tempDrawModelListener = new HighlightDisplay();
                    tempModel.add(tempDrawModelListener);
                    tempPanel.removeAll();
                    tempPanel.setLayout(new BorderLayout());
                    tempPanel.add((Component) tempDrawModelListener, BorderLayout.CENTER);
                    tempPanel.validate();
                }
            }
            if (inType == SELECT_BOX){
                tempDisplay.setDrawModel(new SelectBoxModel(this));
            }
            if (inType == SELECT_POINTS){
                SelectPointsModel tempModel = new SelectPointsModel();
                tempDisplay.setDrawModel(tempModel);
                
                //Set the draw model to modify the drawing of the display
                JPanel tempPanel = getGISEditor().getAuxillaryPanel();
                if (tempPanel != null){
                    // add the listener panel
                    SelectDrawModelListener tempDrawModelListener = new HighlightDisplay();
                    tempModel.add(tempDrawModelListener);
                    tempPanel.removeAll();
                    tempPanel.setLayout(new BorderLayout());
                    tempPanel.add((Component) tempDrawModelListener, BorderLayout.CENTER);
                    tempPanel.validate();
                }
            }
            if (inType == SELECT_DISTANCE){
                SelectPointModel tempModel = new SelectPointModel();
                tempDisplay.setDrawModel(tempModel);
                tempModel.setCommand(this);
                
                //Set the draw model to modify the drawing of the display
                JPanel tempPanel = getGISEditor().getAuxillaryPanel();
                if (tempPanel != null){
                    // add the listener panel
                    SelectDrawModelListener tempDrawModelListener = new HighlightDisplay();
                    tempModel.add(tempDrawModelListener);
                    tempPanel.removeAll();
                    tempPanel.setLayout(new BorderLayout());
                    tempPanel.add((Component) tempDrawModelListener, BorderLayout.CENTER);
                    tempPanel.validate();
                }
            }
        }
        myType=inType;
    }
    
    /**
     * SelectCommand constructor comment.
     */
    public SelectMultiCommand() {
        super();
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        updateType(myType);
    }
    
    /** Keeps a reference to the attribute panel so it can be accessed in the done method */
    private AttributePanel myAttributePanel = null;
    
    /**
     * Called when the draw model has completed it's action.
     */
    public void executeDraw(DrawModel inDrawModel){
        if (myType == SELECT_DISTANCE){
            // Units of measure.
            String tempUnits = "Map Units";
            Projection tempProjection = getGISDisplay().getProjection();
            if (tempProjection != null){
                tempUnits = tempProjection.getUnitOfMeasure();
            }
            
            // show a dialog asking for the distance.
            String tempDistanceString = JOptionPane.showInputDialog(getGISDisplay(), "Enter the distance in "+tempUnits, "Enter Select Distance", JOptionPane.QUESTION_MESSAGE);
            if (tempDistanceString != null){
                // attempt to convert the distance
                try{
                    double tempDistance = Double.parseDouble(tempDistanceString);
                    
                    // find the point of interest
                    gistoolkit.features.Point tempPoint = ((SelectPointModel) inDrawModel).getPoint();
                    if (tempPoint != null){
                    
                        // find all the shapes within this distance.
                        Layer tempLayer = getGISDisplay().getSelectedLayer();
                        if (tempLayer != null){
                            // get the dataset from this layer
                            GISDataset tempDataset = tempLayer.getDataset();
                            GISDataset tempSelectedDataset = new GISDataset();
                            for (int i=0; i<tempDataset.size(); i++){
                                gistoolkit.features.Shape tempShape = tempDataset.getShape(i);
                                if (tempShape != null){
                                    if (tempShape.getDistanceToPoint(tempPoint.getX(), tempPoint.getY())<tempDistance){
                                        tempSelectedDataset.add(tempDataset.getRecord(i));
                                    }
                                }
                            }

                            // set the selected records.
                            ((SelectPointModel) inDrawModel).setSelectedLayer(tempLayer);
                            ((SelectPointModel) inDrawModel).setSelectedRecords(tempSelectedDataset.getRecords());
                        }
                        else{
                            JOptionPane.showMessageDialog(getGISDisplay(), "Please select a layer.", "Layer not selected", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
                catch(NumberFormatException e){
                    JOptionPane.showMessageDialog(getGISDisplay(), "Distance "+tempDistanceString+" is not a number", "Distance not a number", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    
    /** Button for adding a new polygon.*/
    private JRadioButton myButtonSingleSelect = null;
    
    /** Button for adding a new polygon.*/
    private JRadioButton myButtonBoxSelect = null;
    
    /** Button for adding a new polygon.*/
    private JRadioButton myButtonPointSelect = null;
    
    /** Button for selecting shapes by radius.*/
    private JRadioButton myButtonDistanceSelect = null;
    
    /**
     * Reference to the GIS menu button such that it can be accessed later when the sub buttons need to be set visible.
     */
    private GISMenuButton myGISMenuButton;
    
    /**
     * Construct a simple command with this display.
     */
    public SelectMultiCommand(GISEditor inEditor) {
        super(inEditor);
    }
    
    /**
     * Respont to the actions of the buttons
     */
    public void actionPerformed(ActionEvent inActionEvent){
        if (inActionEvent.getSource() == myButtonSingleSelect){
            updateType(SELECT_POINTER);
            myGISMenuButton.setButtonsVisible(false);
            myGISMenuButton.setToolTipText(myButtonSingleSelect.getToolTipText());
            myGISMenuButton.setIcon(myButtonSingleSelect.getIcon());
            myGISMenuButton.setSelectedIcon(myButtonSingleSelect.getSelectedIcon());
            myGISMenuButton.setRolloverIcon(myButtonSingleSelect.getRolloverIcon());
        }
        if (inActionEvent.getSource() == myButtonBoxSelect){
            updateType(SELECT_BOX);
            myGISMenuButton.setButtonsVisible(false);
            myGISMenuButton.setToolTipText(myButtonBoxSelect.getToolTipText());
            myGISMenuButton.setIcon(myButtonBoxSelect.getIcon());
            myGISMenuButton.setSelectedIcon(myButtonBoxSelect.getSelectedIcon());
            myGISMenuButton.setRolloverIcon(myButtonBoxSelect.getRolloverIcon());
        }
        if (inActionEvent.getSource() == myButtonPointSelect){
            updateType(SELECT_POINTS);
            myGISMenuButton.setButtonsVisible(false);
            myGISMenuButton.setToolTipText(myButtonPointSelect.getToolTipText());
            myGISMenuButton.setIcon(myButtonPointSelect.getIcon());
            myGISMenuButton.setSelectedIcon(myButtonPointSelect.getSelectedIcon());
            myGISMenuButton.setRolloverIcon(myButtonPointSelect.getRolloverIcon());
        }
        if (inActionEvent.getSource() == myButtonDistanceSelect){
            updateType(SELECT_DISTANCE);
            myGISMenuButton.setButtonsVisible(false);
            myGISMenuButton.setToolTipText(myButtonDistanceSelect.getToolTipText());
            myGISMenuButton.setIcon(myButtonDistanceSelect.getIcon());
            myGISMenuButton.setSelectedIcon(myButtonDistanceSelect.getSelectedIcon());
            myGISMenuButton.setRolloverIcon(myButtonDistanceSelect.getRolloverIcon());
        }
        if (getGISDisplay() != null) getGISDisplay().requestFocus();
    }
    
    /**
     *Removes the additional buttons from visibility.
     */
    public void removeDraw(DrawModel inDrawModel){
        if (myGISMenuButton != null) myGISMenuButton.setButtonsVisible(false);
    }
    
    /** Button group for radio button behavior of the buttons */
    private ButtonGroup myButtonGroup = new ButtonGroup();
    
    /**
     *Set up a button for use.
     */
    private JRadioButton getButton(String inToolTip, String inInactiveIcon, String inActiveIcon){
        JRadioButton tempRadioButton = new JRadioButton();
        tempRadioButton.setIcon(getIcon(inInactiveIcon));
        tempRadioButton.setSelectedIcon(getIcon(inActiveIcon));
        tempRadioButton.setRolloverIcon(tempRadioButton.getSelectedIcon());
        tempRadioButton.setRolloverEnabled(true);
        tempRadioButton.setToolTipText(inToolTip);
        tempRadioButton.addActionListener(this);
        tempRadioButton.setBorder(null);
        myButtonGroup.add(tempRadioButton);
        return tempRadioButton;
    }
    
    /**
     * Set the button in this command.  Allows this button to assign the sub buttons to the menu.
     */
    public void setButton(GISMenuButton inButton){
        if (inButton != null){
            myButtonSingleSelect = getButton("Select with pointer","SelectInactive.png","SelectActive.png");
            inButton.addButton(myButtonSingleSelect);
            myButtonBoxSelect = getButton("Select with box.","SelectBoxInactive.png","SelectBoxActive.png");
            inButton.addButton(myButtonBoxSelect);
            myButtonPointSelect = getButton("Select with points.","SelectMultiInactive.png","SelectMultiActive.png");
            inButton.addButton(myButtonPointSelect);
            myButtonDistanceSelect = getButton("Select with distance.","SelectDistanceInactive.png","SelectDistanceActive.png");
            inButton.addButton(myButtonDistanceSelect);
            myGISMenuButton = inButton;
            myGISMenuButton.addMouseListener(this);
        }
    }
    
    public void mousePressed(java.awt.event.MouseEvent inMouseEvent) {
    }
    
    public void mouseEntered(java.awt.event.MouseEvent inMouseEvent) {
    }
    
    public void mouseReleased(java.awt.event.MouseEvent inMouseEvent) {
        if ((inMouseEvent.getModifiers() & MouseEvent.BUTTON3_MASK) != 0){
            myGISMenuButton.setButtonsVisible(true);
        }
    }
    
    public void mouseClicked(java.awt.event.MouseEvent inMouseEvent) {
    }
    
    public void mouseExited(java.awt.event.MouseEvent inMouseEvent) {
    }
}