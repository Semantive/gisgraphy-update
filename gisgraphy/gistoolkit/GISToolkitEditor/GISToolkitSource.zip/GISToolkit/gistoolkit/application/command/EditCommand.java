/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.Component;
import java.awt.BorderLayout;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.display.widgets.*;
import gistoolkit.display.shapeeditor.*;
import gistoolkit.application.*;
/**
 * Command to select objects on the display to edit, and then edit (move the nodes of the selected object)
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class EditCommand extends SimpleCommand implements ActionListener, ShapeEditorListener, EditNodesDrawModelListener{
    private EditNodesDrawModel myEditModel = null;
    
    
    /**
     * SelectCommand constructor comment.
     */
    public EditCommand() {
        super();
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null) tempDisplay.setDrawModel(new SelectPointerModel(this));
    }
    
    /** Keeps a reference to the attribute panel so it can be accessed in the done method */
    private AttributePanel myAttributePanel = null;
    
    /**
     * On the first call for the select model, it will change the model to the edit model.
     */
    public void executeDraw(DrawModel inDrawModel){
        if (inDrawModel instanceof SelectPointerModel){
            SelectPointerModel tempSelPointerDrawModel = (SelectPointerModel) inDrawModel;
            if(!tempSelPointerDrawModel.getSelectedLayer().isUpdateable()) {
                JOptionPane.showMessageDialog(getGISDisplay(),"Layer '"+tempSelPointerDrawModel.getSelectedLayer().getLayerName()+"' is not editable.", "Not an editable Layer", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (tempSelPointerDrawModel.getSelectedRecords() != null){
                myEditModel.setCommand(this);
                Record tempRecord = (Record) tempSelPointerDrawModel.getSelectedRecords()[0].clone();
                myEditModel.setRecord(tempRecord);
                Layer tempLayer = tempSelPointerDrawModel.getSelectedLayer();
                myEditModel.setLayer(tempLayer);
                JPanel tempPanel = getGISEditor().getAuxillaryPanel();
                if (tempPanel != null){
                    // add the listener panel
                    myAttributePanel = new AttributePanel();
                    myAttributePanel.setRecord(tempRecord, tempLayer);
                    tempPanel.removeAll();
                    tempPanel.setLayout(new BorderLayout());
                    tempPanel.add((Component) myAttributePanel, BorderLayout.CENTER);
                    tempPanel.validate();
                }
                getGISDisplay().setDrawModel(myEditModel);
                getGISDisplay().paint(getGISDisplay().getGraphics());
                myGISMenuButton.setButtonsVisible(true);
                getGISEditor().validate();
                
            }
        }
    }
    
    /**
     * Insert the method's description here.
     * Creation date: (4/24/2001 4:56:44 PM)
     * @return display.drawmodel.EditNodesDrawModel
     */
    public EditNodesDrawModel getEditModel() {
        return myEditModel;
    }
    
    /**
     * Determines if the command has selected a shape to edit yet.
     * Creation date: (4/27/2001 3:07:31 PM)
     */
    public boolean isSelected() {
        if (myEditModel != null){
            return myEditModel.isSelected();
        }
        return false;
    }
    
    /**
     * Set the state of the EditNodesDrawModel to Add.
     */
    public void setAdd(){
        if (myEditModel != null) myEditModel.setMode(EditNodesDrawModel.ADD);
    }
    
    /**
     * Set the state of the EditNodesDrawModel to Delete.
     */
    public void setDelete(){
        if (myEditModel != null) myEditModel.setMode(EditNodesDrawModel.DELETE);
    }
    
    /**
     * Insert the method's description here.
     * Creation date: (4/24/2001 4:56:44 PM)
     * @param newEditModel display.drawmodel.EditNodesDrawModel
     */
    public void setEditModel(EditNodesDrawModel newEditModel) {
        System.out.println("Edit Model Set");
        if (myEditModel != null) myEditModel.removeEditNodesDrawModelListener(this);
        myEditModel = newEditModel;
        if (myEditModel != null) myEditModel.addEditNodesDrawModelListener(this);
    }
    
    /**
     * Set the state of the EditNodesDrawModel to Move.
     */
    public void setMove(){
        if (myEditModel != null) myEditModel.setMode(EditNodesDrawModel.MOVE);
    }
    
    /**
     * Button for adding nodes to the shape.
     */
    private JRadioButton myButtonAdd = null;
    
    /**
     * Button for Deleting nodes from a shape.
     */
    private JRadioButton myButtonDelete = null;
    
    /**
     * Button for moving the entire shape on the display.
     */
    private JRadioButton myButtonMoveShape = null;
    
    /**
     * Button for moving nodes in a shape.
     */
    private JRadioButton myButtonMove = null;
    
    /**
     * Button for editing points within a shape.
     */
    private JRadioButton myButtonDialog = null;
    
    /**
     * Button for finishing the edits.
     */
    private JRadioButton myButtonDone = null;
    
    /**
     * Dialog for editing the points in a shape.
     */
    private ShapeEditorDlg myShapeEditorDlg = null;
    
    /**
     * Reference to the GIS menu button such that it can be accessed later when the sub buttons need to be set visible.
     */
    private GISMenuButton myGISMenuButton;
    
    /**
     * Construct a simple command with this display.
     */
    public EditCommand(GISEditor inEditor) {
        super(inEditor);
    }
    
    /**
     * Respont to the actions of the buttons
     */
    public void actionPerformed(ActionEvent inActionEvent){
        if (inActionEvent.getSource() == myButtonAdd){
            myEditModel.setMode(EditNodesDrawModel.ADD);
        }
        if (inActionEvent.getSource() == myButtonMove){
            myEditModel.setMode(EditNodesDrawModel.MOVE);
        }
        if (inActionEvent.getSource() == myButtonMoveShape){
            myEditModel.setMode(EditNodesDrawModel.MOVE_SHAPE);
        }
        if (inActionEvent.getSource() == myButtonDelete){
            myEditModel.setMode(EditNodesDrawModel.DELETE);
        }
        if (inActionEvent.getSource() == myButtonDialog){
            if (myEditModel != null){
                if (myEditModel.getRecord() != null){
                    if (myEditModel.getRecord().getShape() != null){
                        if (myShapeEditorDlg == null) {
                            myShapeEditorDlg = new ShapeEditorDlg(getGISEditor(), false);
                            myShapeEditorDlg.addShapeEditorListener(this);
                        }
                        myShapeEditorDlg.setShape(myEditModel.getRecord().getShape());
                        myEditModel.setMode(EditNodesDrawModel.DELETE);
                        myShapeEditorDlg.show();
                    }
                }
            }
        }
        if (inActionEvent.getSource() == myButtonDone){
            try{
                // retrieve the record from the attribute panel, causing it to update the record.
                if (myAttributePanel != null) myAttributePanel.getRecord();
                
                // notify the edit model that it is done.
                myEditModel.done();
                
                // remove the buttons.
                if (myGISMenuButton != null){
                    myGISMenuButton.setButtonsVisible(false);
                }
                
                // close the dialog
                if (myShapeEditorDlg != null){
                    myShapeEditorDlg.dispose();
                    myShapeEditorDlg = null;
                }
                // remove the panel
                JPanel tempPanel = getGISEditor().getAuxillaryPanel();
                if (tempPanel != null){
                    tempPanel.removeAll();
                    tempPanel.validate();
                    tempPanel.repaint();
                }
                getGISDisplay().paint(getGISDisplay().getGraphics());
                getGISEditor().validate();
            }
            catch (Exception e){
                System.out.println(e);
                e.printStackTrace(System.out);
            }
        }
    }
    
    /**
     *Removes the additional buttons from visibility.
     */
    public void removeDraw(DrawModel inDrawModel){
        // close the dialog
        if (myShapeEditorDlg != null){
            myShapeEditorDlg.dispose();
            myShapeEditorDlg = null;
        }
        if (myGISMenuButton != null) myGISMenuButton.setButtonsVisible(false);
    }
    
    /** Button group for radio button behavior of the buttons */
    private ButtonGroup myButtonGroup = new ButtonGroup();
    
    /**
     *Set up a button for use.
     */
    private JRadioButton getButton(String inToolTip, String inInactiveIcon, String inActiveIcon){
        JRadioButton tempRadioButton = new JRadioButton();
        tempRadioButton.setIcon(getIcon(inInactiveIcon));
        tempRadioButton.setSelectedIcon(getIcon(inActiveIcon));
        tempRadioButton.setRolloverIcon(tempRadioButton.getSelectedIcon());
        tempRadioButton.setRolloverEnabled(true);
        tempRadioButton.setToolTipText(inToolTip);
        tempRadioButton.addActionListener(this);
        tempRadioButton.setBorder(null);
        myButtonGroup.add(tempRadioButton);
        return tempRadioButton;
    }
    
    /**
     * Set the button in this command.  Allows this button to assign the sub buttons to the menu.
     */
    public void setButton(GISMenuButton inButton){
        if (inButton != null){
            myButtonMove = getButton("Move Nodes","MoveNodesInactive.png","MoveNodesActive.png");
            inButton.addButton(myButtonMove);
            myButtonAdd = getButton("Add Nodes","AddNodesInactive.png","AddNodesActive.png");
            inButton.addButton(myButtonAdd);
            myButtonDelete = getButton("Delete Nodes","DeleteNodesInactive.png","DeleteNodesActive.png");
            inButton.addButton(myButtonDelete);
            myButtonMoveShape = getButton("Move Shape","MoveShapeInactive.png","MoveShapeActive.png");
            inButton.addButton(myButtonMoveShape);
            myButtonDialog = getButton("Edit Points","EditDialogInactive.png","EditDialogActive.png");
            inButton.addButton(myButtonDialog);
            myButtonDone = getButton("Done Editing","DoneEditingInactive.png","DoneEditingActive.png");
            inButton.addButton(myButtonDone);
            myGISMenuButton = inButton;
        }
    }
    
    /** Called when a point is removed.  */
    public void pointRemoved(Point inPoint) {
        myEditModel.draw();
    }
    
    /** Called when a point is added to the shape.  */
    public void pointAdded(Point inPoint) {
        myEditModel.draw();
    }
    
    /** Called when a point is deselected.  */
    public void pointDeselected(Point inPoint) {
        myEditModel.draw();
    }
    
    /** Called when any update happens to the shape.  */
    public void shapeUpdated(Shape inShape) {
        myEditModel.draw();
    }
    
    /** Called when a point is selected.  */
    public void pointSelected(Point inPoint) {
        myEditModel.draw();
        myEditModel.drawPoint(inPoint);
    }
    
    /** called when the shape is updated in any way.  */
    public void shapeUpdated(EditNodesDrawModelEvent inEvent) {
        if (myShapeEditorDlg != null){
            if (inEvent.getShape() != null){
                myShapeEditorDlg.shapeUpdated(inEvent.getShape());
            }
        }
    }
}