/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.features.*;
import java.awt.Image;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.application.*;

/**
 * Command to pan the map to a new location.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class PanCommand extends SimpleCommand {
    
    /**
     * SelectCommand constructor comment.
     */
    public PanCommand() {
        super();
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        GISDisplay tempDisplay = getGISDisplay();
        if (tempDisplay != null) tempDisplay.setDrawModel(new PanDrawModel(this));
    }
    
    /**
     * On the first call for the select model, it will change the model to the edit model.
     */
    public void executeDraw(DrawModel inDrawModel){
        if (inDrawModel instanceof PanDrawModel){
            
            // retrieve the offsets
            PanDrawModel tempPanDrawModel = (PanDrawModel) inDrawModel;
            int dx = tempPanDrawModel.getEndPoint().x - tempPanDrawModel.getStartPoint().x;
            int dy = tempPanDrawModel.getEndPoint().y - tempPanDrawModel.getStartPoint().y;
            
            // convert the screen coordinates into world coordinates
            Converter c = getGISDisplay().getConverter();
            if (c != null){
                Envelope tempEnvelope = new Envelope(
                    c.toWorldX(0-dx),
                    c.toWorldY(getGISDisplay().getHeight()-dy),
                    c.toWorldX(getGISDisplay().getWidth()-dx),
                    c.toWorldY(0-dy)
                );
                
                // set the start point to null so it quits drawing panned.
                tempPanDrawModel.setStartPoint(null);
                
                // update the map data
                Image tempMapImage = getGISDisplay().getMapImage();
                Image tempImage = getGISDisplay().getBufferImage();
                tempImage.getGraphics().drawImage(tempMapImage, 0, 0, getGISDisplay());
        		tempMapImage.getGraphics().clearRect(0,0, getGISDisplay().getWidth(), getGISDisplay().getHeight());
                tempMapImage.getGraphics().drawImage(tempImage, dx, dy, getGISDisplay());
                
                // set the Envelope.
                try{
                    getGISDisplay().setEnvelope(tempEnvelope);
                }
                catch (Exception e){
                    System.out.println("Exception "+e+" caught in Pan Command when setting Envelope");
                }
            }
        }
    }

    /**
     * Construct a simple command with this display.
     */
    public PanCommand(GISEditor inEditor) {
        super(inEditor);
    }
}