/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import gistoolkit.projection.*;
import gistoolkit.application.*;
import gistoolkit.application.dialog.*;
/**
 * Command to display the Command dialog, and then set the command into the layers
 * for reinterpretation.
 * @author  ithaqua
 * @version 
 */
public class ProjectionCommand extends SimpleCommand {
    /** The identifying name for this command */
    public static String getName(){return "Edit Projection";}

    /** Creates new ProjectionCommand */
    public ProjectionCommand(GISEditor inEditor) {
        super(getName(), null, inEditor);
        putValue(SHORT_DESCRIPTION, "Edit the projection parameters");
        putValue(LONG_DESCRIPTION, "Select a different projection or edit the current projection parameters.");
    }
    
    /** Show the Projection dialog, and then update the display */
    public void execute(){
        ProjectionDialog tempDialog = new ProjectionDialog(getGISEditor());
        tempDialog.setProjection(getGISDisplay().getProjection());
        tempDialog.setModal(true);
        tempDialog.show();
        if (tempDialog.isOK()){
            Projection tempProjection = tempDialog.getProjection();
            try{
                getGISDisplay().setProjection(tempProjection);
            }
            catch (Exception e){
                showError(e);
            }
        }
    }

}
