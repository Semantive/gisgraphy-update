/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;
import gistoolkit.application.*;
import gistoolkit.features.Record;
import gistoolkit.display.Layer;
import gistoolkit.display.drawmodel.SelectDrawModel;

/**
 * Command to delete the selected items from their current data source and insert them into another data source.
 */
public class CutCommand extends SimpleCommand{
    
    /** The identifying name for this command */
    public static String getName(){return "Cut";}
    
    /**
     * CutCommand constructor comment.
     */
    public CutCommand(GISEditor inEditor) {
        super(getName(), getIcon("Cut24.gif"), inEditor);
        putValue(SHORT_DESCRIPTION, "Cut Records and copy to the clipboard");
        putValue(LONG_DESCRIPTION, "Delete the records from the current layer, and copy them to the clipboard for insertion into another layer.");
    }
    
    /** Execute the cut command */
    public void execute(){
        // determine if there is a current selection
        try{
            if (getGISDisplay() != null){
                if (getGISDisplay().getDrawModel() != null){
                    if (getGISDisplay().getDrawModel() instanceof SelectDrawModel){
                        SelectDrawModel tempSelectDrawModel = (SelectDrawModel) getGISDisplay().getDrawModel();
                        Record[] tempRecords = tempSelectDrawModel.getSelectedRecords();
                        if (tempRecords != null){
                            Layer tempSelectedLayer = getGISDisplay().getSelectedLayer();
                            if (tempSelectedLayer != null){

                                // If the layer is updateable, then delete the records
                                if (tempSelectedLayer.isUpdateable()){
                                    for (int i=0; i<tempRecords.length; i++){
                                        tempSelectedLayer.delete(tempRecords[i]);
                                    }
                                }

                                // The layer is not updateable, so show an information message.
                                else{
                                    showInformation("Layer Not Updatable", "Can Not Cut, a Copy will be performed");
                                }

                                // copy the records to a place where they can be retrieved.
                                getGISEditor().setCopyBuffer(tempRecords);
                                getGISDisplay().redraw();
                                tempSelectDrawModel.reset();

                            }
                        }
                    }
                }
            }
        }
        catch (Exception e){
            showError(e);
        }
    }
}
