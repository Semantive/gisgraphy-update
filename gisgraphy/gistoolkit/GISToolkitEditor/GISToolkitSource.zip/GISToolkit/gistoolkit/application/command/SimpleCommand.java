/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.application.*;
import gistoolkit.application.images.*;
/**
 * A simple command, meant to be subclassed.
 * Creation date: (4/24/2001 1:54:36 PM)
 */
public abstract class SimpleCommand extends AbstractAction implements Command{
    
    /**
     * Pointer to the GIS Display such that it can find the working interface.
     */
    private GISDisplay myGISDisplay;
    
    /**
     * Create a new simple command.
     */
    public SimpleCommand(){
        super();
    }
    
    /**
     * SimpleCommand constructor comment.
     */
    public SimpleCommand(GISEditor inEditor) {
        super();
        if (inEditor != null){
            myGISEditor = inEditor;
            myGISDisplay = myGISEditor.getDisplay();
        }
    }
    
    /**
     * SimpleCommand constructor comment.
     */
    public SimpleCommand(String inName, Icon inIcon, GISEditor inEditor) {
        super(inName, inIcon);
        if (inEditor != null){
            myGISEditor = inEditor;
            myGISDisplay = myGISEditor.getDisplay();
        }
    }

    /**
     * Execute is called when the button is pressed.
     * When the button is pressed, this method is executed.  Typically, it will change the state of the application
     * by setting a draw model, or updating the selected objects or something. 
     * If it sets a draw model, it will usually set itself as the target of the drawmodel, so executeDraw will be called
     * when the drawmodel has completed it's task.
     */
    public void execute(){
    }
    
    /**
     * This method is called by the draw model when it has completed it's task.
     * If the command created a click draw model, then this method is called when the mouse is clicked on the
     * display.
     */
    public void executeDraw(DrawModel inDrawModel){
    }
    
    /**
     * Called when the alternate path in the draw model is executed.
     * Currently used for sending right click events to the command.
     */
    public void executeAlternate(DrawModel inDrawModel){
    }
    
    /**
     * Return the GISDisplay to modify.
     */
    public GISDisplay getGISDisplay(){
        if (myGISDisplay == null) {
            if (myGISEditor != null){
                myGISDisplay = myGISEditor.getDisplay();
            }
        }
        return myGISDisplay;
    }
    
    /**
     * Set the GISDisplay to reference for this command.
     */
    public void setGISDisplay(GISDisplay inGISDisplay){
        myGISDisplay = inGISDisplay;
    }
    
    /**
     * Pointer to the Editor this command is associated with.
     */
    private GISEditor myGISEditor;
    
    /**
     * Return the GISEditor associated with this command.
     */
    public GISEditor getGISEditor(){
        return myGISEditor;
    }
    
    /**
     * called when the draw model has been removed
     */
    public void removeDraw(DrawModel inDrawModel){
    }
    
    /**
     * Set the GISEditor assocated with this command.
     */
    public void setGISEditor(GISEditor inEditor){
        myGISEditor = inEditor;
    }
    
    /** Show the information message to the user */
    public void showInformation(String inTitle, String inMessage){
        JOptionPane.showMessageDialog(getGISEditor(), inMessage, inTitle, JOptionPane.INFORMATION_MESSAGE);        
    }

    /** Show the error to the user */
    public void showError(Exception e){
        if ((e.getMessage() == null) || (e.getMessage().length() == 0)){
            JOptionPane.showMessageDialog(getGISEditor(), "No Message see stdout", "Error", JOptionPane.ERROR_MESSAGE);
        }
        JOptionPane.showMessageDialog(getGISEditor(), e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    
    /**
     * Retrieve an Icon from the Images Directory.
     */
    protected static Icon getIcon(String inName){
        return new ImageSource().getIcon(inName);
    }
    
    /** Respond to action events from the action interface */
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        try{
            execute();
        }
        catch (Throwable t){
            System.out.println(""+t);
            t.printStackTrace();
        }
    }
}