/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.util.Vector;
import javax.swing.Action;
/**
 * Object for holding the commands associated with an application.
 */
public class ActionList {

    /** Vector for holding the Actions.*/
    private Vector myActionVect = new Vector();
    
    /** Creates new CommandList */
    public ActionList() {
    }

    /** Add a command to the list */
    public void addAction(Action inAction){
        if (inAction != null){
            myActionVect.addElement(inAction);
        }
    }
    
    /** Retrieve the command with the given name */
    public Action getAction(String inName){
        for (int i=0; i<myActionVect.size(); i++){
            Action tempAction = (Action) myActionVect.elementAt(i);
            String tempName = (String) tempAction.getValue(Action.NAME);
            if ((tempName != null) && (tempName.equalsIgnoreCase(inName))){
                return tempAction;
            }
        }
        return null;
    }
    
    /** Remove the command with the given name */
    public Action removeAction(String inName){
        Action tempRemoveAction = null;
        for (int i=0; i<myActionVect.size(); i++){
            Action tempAction = (Action) myActionVect.elementAt(i);
            String tempName = (String) tempAction.getValue(Action.NAME);
            if ((tempName != null) && (tempName.equalsIgnoreCase(inName))){
                tempRemoveAction = tempAction;
                myActionVect.remove(tempAction);
            }
        }
        return tempRemoveAction;
    }
    
}
