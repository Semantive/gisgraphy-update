/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.application.*;

/**
 * Command to delete items from the display, currently only works for polygons and multi polygons.
 * Creation date: (4/24/2001 2:17:21 PM)
 */
public class DeleteCommand extends SimpleCommand {
    
    /**
     * SelectCommand constructor comment.
     */
    public DeleteCommand() {
        super();
    }
    
    /**
     * Sets the draw model in the display.
     */
    public void execute(){
        // retrieve the display
        GISDisplay tempDisplay = getGISDisplay();
        
        // create a new HighlightDrawModel
        HighlightDrawModel tempDrawModel = new HighlightDrawModel(this);
        
        //Set the draw model to modify the drawing of the display
        if (tempDisplay != null){
            tempDisplay.setDrawModel(tempDrawModel);
            JPanel tempPanel = getGISEditor().getAuxillaryPanel();
            if (tempPanel != null){
                // add the listener panel
                HighlightDrawModelListener tempDrawModelListener = new HighlightDisplay();
                tempDrawModel.add(tempDrawModelListener);
                tempPanel.removeAll();
                tempPanel.setLayout(new BorderLayout());
                tempPanel.add((Component) tempDrawModelListener, BorderLayout.CENTER);
                tempPanel.validate();
            }
        }
    }
    
    /**
     * Construct a simple command with this editor.
     */
    public DeleteCommand(GISEditor inEditor) {
        super(inEditor);
    }
    
    /**
     * If there is a record selected, then delete it.
     */
    public void executeDraw(DrawModel inDrawModel){
        if (inDrawModel instanceof HighlightDrawModel){
            HighlightDrawModel tempHighlightDrawModel = (HighlightDrawModel) inDrawModel;
            if (tempHighlightDrawModel.getRecord() != null){
                // retrieve the layer.
                try{
                    tempHighlightDrawModel.getLayer().delete(tempHighlightDrawModel.getRecord());
                    getGISDisplay().setDrawModel(new HighlightDrawModel(this));
                }
                catch (Exception e){
                    System.out.println("Error Deleting Record "+e);
                }
                getGISDisplay().update(getGISDisplay().getGraphics());
                
            }
        }
    }
}