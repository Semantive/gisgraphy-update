/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;

import java.io.*;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import gistoolkit.features.*;
import gistoolkit.application.*;
import com.sun.media.jai.codec.*;
/**
 * Allows the user to save the displayed immage in several formats.
 * @author  ithaqua
 */
public class SaveImageCommand extends SimpleCommand {
	/** The identifying name for this command */
	public static String getName() {
		return "Save Image";
	}

	/** The last used file. */
	private static File myLastFile = null;

	/** Creates new SaveCommand */
	public SaveImageCommand(GISEditor inEditor) {
		super(getName(), getIcon("Save24.gif"), inEditor);
		putValue(SHORT_DESCRIPTION, "Save an image of the map.");
		putValue(LONG_DESCRIPTION, "Create an image of the currently displayed map.");
	}

	/** Perform the action */
	public void execute() {
		JFileChooser tempChooser = new JFileChooser();
		tempChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        GISFileFilter tempBMPFilter = new GISFileFilter("BMP", "Windows Bitmap Images");
		tempChooser.addChoosableFileFilter(tempBMPFilter);
        GISFileFilter tempPNGFilter = new GISFileFilter("PNG", "PNG Images");
		tempChooser.addChoosableFileFilter(tempPNGFilter);
        GISFileFilter tempJPGFilter = new GISFileFilter("JPG", "JPEG Images");
		tempChooser.addChoosableFileFilter(tempJPGFilter);
		JPanel tempPanel = new JPanel(new GridLayout(1, 1, 2, 2));
		tempChooser.setAccessory(getAccessoryPanel());
		if (myLastFile != null) {
			tempChooser.setSelectedFile(myLastFile);
		}
		tempChooser.showSaveDialog(getGISEditor());
		File tempFile = tempChooser.getSelectedFile();
		if (tempFile != null) {
            if(tempChooser.getFileFilter() == tempBMPFilter){
                // ensure that the file has the correct type.
                String tempPath = tempFile.getAbsolutePath();
                if (tempPath.toUpperCase().endsWith(".BMP")) tempPath = tempPath.substring(0, tempPath.length()-4) + ".bmp";
                else tempPath =  tempPath + ".bmp";
                tempFile = new File(tempPath);
            }
            if(tempChooser.getFileFilter() == tempPNGFilter){
                // ensure that the file has the correct type.
                String tempPath = tempFile.getAbsolutePath();
                if (tempPath.toUpperCase().endsWith(".PNG")) tempPath = tempPath.substring(0, tempPath.length()-4) + ".png";
                else tempPath =  tempPath + ".png";
                tempFile = new File(tempPath);
            }
            if(tempChooser.getFileFilter() == tempJPGFilter){
                // ensure that the file has the correct type.
                String tempPath = tempFile.getAbsolutePath();
                if (tempPath.toUpperCase().endsWith(".JPG")) tempPath = tempPath.substring(0, tempPath.length()-4) + ".jpg";
                else tempPath =  tempPath + ".jpg";
                tempFile = new File(tempPath);
            }
			myLastFile = tempFile;
			try {
				BufferedImage tempImage = null;
				int tempFactor = getFactor();
				if (tempFactor == 1)
					tempImage = (BufferedImage) getGISDisplay().getMapImage();
				else {
					int tempWidth = tempFactor * getGISDisplay().getWidth();
					int tempHeight = tempFactor * getGISDisplay().getHeight();

					BufferedImage tempBufferedImage = new BufferedImage(tempWidth, tempHeight, BufferedImage.TYPE_INT_BGR);
					Graphics tempGraphics = tempBufferedImage.getGraphics();
					tempGraphics.setColor(Color.white);
					tempGraphics.fillRect(0, 0, tempWidth, tempHeight);
					Envelope tempEnvelope = new Envelope(0.0, 0.0, (double) tempWidth, (double) tempHeight);
					getGISDisplay().printLayers(tempBufferedImage.getGraphics(), tempEnvelope);
					tempImage = tempBufferedImage;
				}
				String tempName = tempFile.getName().toUpperCase().trim();
				if ((tempName.endsWith(".JPG")) || (tempName.endsWith(".JPEG"))) {
					// Store the image in the JPG format.
					FileOutputStream out = new FileOutputStream(tempFile);
					JPEGEncodeParam params = new JPEGEncodeParam();
					params.setQuality((float) .99);
					ImageEncoder encoder = ImageCodec.createImageEncoder("JPEG", out, params);
					if (encoder == null) {
						System.out.println("jpg imageEncoder is null");
					}
					else {
						encoder.encode(tempImage);
					}
					out.close();
				}
				else if (tempName.endsWith(".PNG")) {
					// Store the image in the JPG format.
					FileOutputStream out = new FileOutputStream(tempFile);
					ImageEncoder encoder = ImageCodec.createImageEncoder("PNG", out, null);
					if (encoder == null) {
						System.out.println("png imageEncoder is null");
					}
					else {
						encoder.encode(tempImage);
					}
					out.close();
				}
				else if (tempName.endsWith(".BMP")) {
					// Store the image in the JPG format.
					FileOutputStream out = new FileOutputStream(tempFile);
					BMPEncodeParam param = new BMPEncodeParam();
					ImageEncoder encoder = ImageCodec.createImageEncoder("BMP", out, param);
					if (encoder == null) {
						System.out.println("png imageEncoder is null");
					}
					else {
						encoder.encode(tempImage);
					}
					out.close();
				}
				else
					throw new Exception("Unknown File Type for " + tempFile.getName());
			}
			catch (Exception e) {
				JOptionPane.showMessageDialog(getGISEditor(), e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private JRadioButton myRadio1 = new JRadioButton("1x1", true);
	private JRadioButton myRadio2 = new JRadioButton("2x2", false);
	private JRadioButton myRadio4 = new JRadioButton("4x4", false);
	private JRadioButton myRadio8 = new JRadioButton("8x8", false);
	private JRadioButton myRadio16 = new JRadioButton("16x16", false);
	private JRadioButton myRadio32 = new JRadioButton("32x32", false);
	private ButtonGroup myGroup = new ButtonGroup();
	private JPanel myPanel = null;

	private JPanel getAccessoryPanel() {
		if (myPanel == null) {
			myPanel = new JPanel(new GridLayout(0, 1, 2, 2));
			myPanel.add(myRadio1);
			myGroup.add(myRadio1);
			myPanel.add(myRadio2);
			myGroup.add(myRadio2);
			myPanel.add(myRadio4);
			myGroup.add(myRadio4);
			myPanel.add(myRadio8);
			myGroup.add(myRadio8);
			myPanel.add(myRadio16);
			myGroup.add(myRadio16);
			myPanel.add(myRadio32);
			myGroup.add(myRadio32);
		}
		return myPanel;
	}

	private int getFactor() {
		if (myRadio1.isSelected())
			return 1;
		if (myRadio2.isSelected())
			return 2;
		if (myRadio4.isSelected())
			return 4;
		if (myRadio8.isSelected())
			return 8;
		if (myRadio16.isSelected())
			return 16;
		if (myRadio32.isSelected())
			return 32;
		return 1;
	}
}
