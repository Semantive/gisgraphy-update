/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.command;
import gistoolkit.application.*;
import gistoolkit.features.Record;
import gistoolkit.display.Layer;
import gistoolkit.display.drawmodel.SelectDrawModel;

/**
 * Command to copy the selected items from their current data source and store them in the copy buffer for later insertion into another data source.
 */
public class CopyCommand extends SimpleCommand{
    /** The identifying name for this command */
    public static String getName(){return "Copy";}
        
    /**
     * CopyCommand constructor comment.
     */
    public CopyCommand(GISEditor inEditor) {
        super(getName(), getIcon("Copy24.gif"), inEditor);
        putValue(SHORT_DESCRIPTION, "Copy Records to the clipboard");
        putValue(LONG_DESCRIPTION, "Create a copy of the records, and send them to the clipboard for pasting into another layer.");
    }
    
    /** Execute the cut command */
    public void execute(){
        // determine if there is a current selection
        try{
            if (getGISDisplay() != null){
                if (getGISDisplay().getDrawModel() != null){
                    if (getGISDisplay().getDrawModel() instanceof SelectDrawModel){
                        SelectDrawModel tempSelectDrawModel = (SelectDrawModel) getGISDisplay().getDrawModel();
                        Record[] tempRecords = tempSelectDrawModel.getSelectedRecords();
                        if (tempRecords != null){
                            Layer tempSelectedLayer = getGISDisplay().getSelectedLayer();
                            if (tempSelectedLayer != null){
                                
                                // Create copies of the records.
                                Record[] tempCopyRecords = new Record[tempRecords.length];
                                for (int i=0; i<tempRecords.length; i++){
                                    tempCopyRecords[i] = (Record) tempRecords[i].clone();
                                }
                                                                
                                // copy the records to a place where they can be retrieved.
                                getGISEditor().setCopyBuffer(tempRecords);
                                getGISDisplay().redraw();
                                tempSelectDrawModel.reset();
                                
                            }
                        }
                    }
                }
            }
        }
        catch (Exception e){
            showError(e);
        }
    }
}
