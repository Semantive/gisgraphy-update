/*
 * Config.java
 *
 */

package gistoolkit.application.config;

import java.util.*;
import java.io.*; // using the InputStream to read the properties.

/**
 * Class for holding the configuration information for the editor.
 */
public class Config {
    
    /** This class uses a properties class as it's data holder. */
    private Properties myProperties = new Properties();
    
    /**
     * This class can read and write configuration information for the application.
     * Send in the name of the properties file to use.  If no properties file is available, then send null and the application will use defaults.
     */
    public Config(String inFileName) {
        try{
            InputStream tempIOStream = null;
            
            // open the file should it exist
            File tempFile = new File(inFileName);
            if (tempFile.exists()){
                // create a stream for the properties
                tempIOStream = new FileInputStream(inFileName);
                myProperties.load(tempIOStream);
                tempIOStream.close();
            }
            else{
                
                // look for the properties file from the string sent in.
                if (inFileName != null){
                    tempIOStream = this.getClass().getClassLoader().getResourceAsStream(inFileName);
                    if (tempIOStream != null){
                        myProperties.load(tempIOStream);
                        tempIOStream.close();
                    }
                    else{
                
                        // read the default properties from the file.
                        inFileName = "gistoolkit.properties";
                        tempIOStream = this.getClass().getClassLoader().getResourceAsStream(inFileName);
                        if (tempIOStream == null){
                            throw new Exception("Could not find "+inFileName+" configuration file, using defaults") ;
                        }
                        myProperties.load(tempIOStream);
                        tempIOStream.close();
                    }
                }
            }
        }
        catch(Exception e){
            System.out.println("Exception reading Configuration\n"+e);
            
            // load the defaults
            // Available Data Source Layers.
            myProperties.put("gistoolkit.init.datasourcepanel.1","gistoolkit.application.layers.layerpanel.ShapeFileDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.2","gistoolkit.application.layers.layerpanel.ReadOnlyShapeFileDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.3","gistoolkit.application.layers.layerpanel.ReadOnlyPostGISDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.4","gistoolkit.application.layers.layerpanel.UpdateablePostGISDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.5","gistoolkit.application.layers.layerpanel.ReadOnlyMySQLDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.6","gistoolkit.application.layers.layerpanel.UpdateableMySQLDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.7","gistoolkit.application.layers.layerpanel.ReadOnlyOracleDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.8","gistoolkit.application.layers.layerpanel.UpdateableOracleDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.9","gistoolkit.application.layers.layerpanel.ReadOnlySpatialExtenderDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.10","gistoolkit.application.layers.layerpanel.UpdateableSpatialExtenderDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.11","gistoolkit.application.layers.layerpanel.ImageFileDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.12","gistoolkit.application.layers.layerpanel.SeamlessDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.13","gistoolkit.application.layers.layerpanel.TerraserverDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.14","gistoolkit.application.layers.layerpanel.OGCWebServiceDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.15","proprietary.datasources.arcsde.ArcSDEDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.16","proprietary.datasources.arcsde.UpdateableArcSDEDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.17","proprietary.datasources.arcims.ArcIMSDataSourcePanel");
            myProperties.put("gistoolkit.init.datasourcepanel.18","proprietary.datasources.ermapper.ERMapperDataSourcePanel");
        }
        
        // loop through the properties adding the ones that do not exist to the list.
        Enumeration e = myProperties.keys();
        while (e.hasMoreElements()){
            String tempName = (String) e.nextElement();
            if (System.getProperty(tempName) == null){
                System.setProperty(tempName, myProperties.getProperty(tempName));
            }
        }
    }
    
    /** Return the Value associated with this key, returns void if the key was not found */
    public String getValue(String inKey){
        return myProperties.getProperty(inKey);
    }
    
    /** Return the Value associated with this key, returns void if the key was not found */
    public String getValue(String inKey, String inDefault){
        return myProperties.getProperty(inKey, inDefault);
    }
    
}
