/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.application;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.display.shader.*;
import gistoolkit.display.widgets.*;
import gistoolkit.display.drawmodel.*;
import gistoolkit.projection.Projection;
import gistoolkit.application.dialog.*;
import gistoolkit.application.layers.*;
import gistoolkit.application.command.*;
import gistoolkit.application.images.*;

/**
 * Used to test the display panel, and the objects in the toolkit, but has some
 * features of its own.
 * Creation date: (4/13/2001 2:06:06 PM)
 * @author: butterstorm
 */
public class GISEditor extends JFrame implements GISDisplayListener {
    /** The version of this editor. */
    public static String getVersion(){ return "2.8.1";}
        
    /** Displays the extents of the map.*/
    private JTextArea myTextAreaInfo = new JTextArea();
    
    /** List of actions. */
    private ActionList myActionList = new ActionList();
    
    /** A class to listen for popup events from the display. */
    private PopupListener myPopupListener = null;
    
    /**
     * Allows external tools to edit the layers.
     */
    private LayerPanel myLayerPanel = null;
    /** Retrieve the LayerPanel from the display */
    public LayerPanel getLayerPanel(){return myLayerPanel;}
    
    /** refresh the display */
    public void refresh(){
        myDisplay.redraw();
        getLayerPanel().refresh();
    }
    
    /**
     * class for handling messages from the window expecially the window closing event to end
     * the process when the window closes.
     */
    class WindowHandler extends java.awt.event.WindowAdapter implements ComponentListener, ChangeListener{
        /**
         * Invoked when a window has been closed.
         */
        public void windowClosing(WindowEvent e) {
            saveConfig();
            System.exit(0);
        }
        
        public void componentResized(java.awt.event.ComponentEvent componentEvent) {
            updateInfo();
        }
        
        public void componentMoved(java.awt.event.ComponentEvent componentEvent) {
        }
        
        public void componentShown(java.awt.event.ComponentEvent componentEvent) {
            updateInfo();
        }
        
        public void componentHidden(java.awt.event.ComponentEvent componentEvent) {
        }
        
        public void stateChanged(ChangeEvent inEvent){
            updateInfo();
        }
    }
    private WindowHandler myWindowHandler = new WindowHandler();
    
    /**
     * Creates a new test display with the default constructor.
     */
    public GISEditor() {
        super();
    }
    
    /**
     * Creates a new test display frame with the given title.
     * @param title java.lang.String
     */
    public GISEditor(String title) {
        super(title);
    }
    
    /**
     * Sets the initial state of this panel, creating any objects needed for display
     * such as combo boxes, text boxes, and buttons.
     * Creation date: (4/13/2001 2:08:13 PM)
     */
    public void initPanel() {
        
        setTitle("GIS Toolkit Editor");
        createActions();
        try {
            // add the menu
            setJMenuBar(getGISMenuBar());
            
            // set the window handler
            addWindowListener(myWindowHandler);
            
            // create the display as it is needed by some of the command initialization routines.
            myDisplay = new GISDisplay();
            myDisplay.setBackground(Color.white);
            
            // get the panel for the frame
            Container tempPanel = getContentPane();
            tempPanel.setLayout(new BorderLayout());
            tempPanel.add(getGISToolBar(), BorderLayout.NORTH);
            
            // The screen will be divided in half with the drawing region on the left, and
            // an editing region on the right.  Use a splitter for this.]
            JSplitPane tempMainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
            tempPanel.add(tempMainSplit, BorderLayout.CENTER);
            
            // to the left of the split pane, add a panel for additional layouts
            JTabbedPane tempTabbedPane = new JTabbedPane();
            tempMainSplit.setLeftComponent(tempTabbedPane);
            JPanel tempMainLeftPanel = new JPanel(new BorderLayout());
            tempTabbedPane.add(tempMainLeftPanel, "Map");
            
            // add a panel for information
            JPanel tempInfoPanel = new JPanel();
            tempInfoPanel.setLayout(new BorderLayout());
            tempInfoPanel.add(myTextAreaInfo, BorderLayout.CENTER);
            myTextAreaInfo.setEditable(false);
            tempTabbedPane.add(new JScrollPane(tempInfoPanel), "Info");
            tempInfoPanel.addComponentListener(myWindowHandler);
            tempTabbedPane.addChangeListener(myWindowHandler);
            
            // to the right of the split panel add another split panel
            JSplitPane tempRightSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
            tempMainSplit.setRightComponent(tempRightSplit);
            
            // add a panel to the top and bottom of the JSplitPane.
            myLayerPanel = new LayerPanel(new BorderLayout());
            LayerPanel tempRightTopPanel = myLayerPanel;
            JPanel tempRightBottomPanel = new JPanel(new BorderLayout());
            tempRightSplit.setTopComponent(tempRightTopPanel);
            tempRightSplit.setBottomComponent(tempRightBottomPanel);
            myAuxillaryPanel = tempRightBottomPanel;
            
            // add a panel for the tools.
            JPanel tempToolPanel = new JPanel();
            // JPanel tempToolContainer = new JPanel(new GridLayout(0,1));
            // tempToolContainer.add(tempToolPanel);
            tempMainLeftPanel.add(tempToolPanel, BorderLayout.WEST);
            
            // add a panel for any additional buttons
            myAuxillaryButtonPanel = new JPanel(new GridLayout(0,1));
            myAuxillaryButtonPanel.setBorder(new EtchedBorder());
            
            // add the display to the panel
            JPanel tempDisplayPanel = new JPanel(new BorderLayout(4,4));
            tempDisplayPanel.setBorder(new SoftBevelBorder(SoftBevelBorder.RAISED));
            tempMainLeftPanel.add(tempDisplayPanel, BorderLayout.CENTER);
            
            // add the GISDisplay to the Layer panel
            tempRightTopPanel.setGISDisplay(myDisplay);
            tempRightTopPanel.setMinimumSize(new Dimension(0,0));
            
            // Populate the DISDisplay
            myDisplay.initPanel();
            
            // add the buttons
            addTools(tempToolPanel, myDisplay);
            
            // set the location of the splitter
            tempMainSplit.setDividerLocation(500);
            
            // set the display
            tempDisplayPanel.add(myDisplay, BorderLayout.CENTER);
            myDisplay.addGISDisplayListener(this);
            
            // validate the display
            validate();
            
            if (isJTSAvailable()){
                // add the popup menu listener
                myPopupListener = new PopupListener(myDisplay);
                myDisplay.addMouseListener(myPopupListener);
            }
        }
        catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }
    
    /** Reference to the legend dialog */
    public LegendDialog myLegendDialog = new LegendDialog(this);
    /** returns true if the legend is visible, false if not */
    public boolean isLegendVisible(){return myLegendDialog.isVisible();}
    /** display or hide the legend dialog */
    public void setLegendVisible(boolean inVisible){
        myLegendDialog.setModal(false);
        myLegendDialog.setVisible(inVisible);
        myLegendDialog.setLegend(myDisplay.getLegend());
    }
    
    /**
     * Main entry point of the test display.
     * Creation date: (4/13/2001 2:07:09 PM)
     * @param args java.lang.String[]
     */
    public static void main(String[] args) {
        try{
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception e){
            System.out.println("Error setting the look and feel.");
            e.printStackTrace();
        }
        GISEditor tempGISEditor = new GISEditor();
        if (args.length > 0){
            tempGISEditor.loadConfig(args[0]);
        }
        else tempGISEditor.loadConfig(null);
        tempGISEditor.setSize(640,480);
        tempGISEditor.initPanel();
        tempGISEditor.show();
    }
    
    /**
     * Reference to a panel for displaying additional buttons.
     */
    private JPanel myAuxillaryButtonPanel = null;
    
    /**
     * Panel for displaying additional information, used for attributes when selecting, and posibly other stuff.
     */
    private JPanel myAuxillaryPanel = null;
    
    /**
     * Reference to the Display used in this editor.
     */
    private GISDisplay myDisplay;
    
    /**
     * Add a button to the display.
     */
    public void addButton(Component inComponent){
        if (myAuxillaryButtonPanel != null){
            myAuxillaryButtonPanel.add(inComponent);
            myAuxillaryButtonPanel.getParent().validate();
        }
    }
    
    /**
     * Retrieve an Icon from the Images Directory.
     */
    public Icon getIcon(String inName){
        return new ImageSource().getIcon(inName);
    }
    
    
    /** Button group for pan, zoom, and all exclusive tools */
    private ButtonGroup myButtonGroup = new ButtonGroup();
    
    /**
     * Add the tools to the tools panel.
     */
    private void addTools(JPanel inPanel, GISDisplay inDisplay){
        inPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(1,1,1,1);
        c.weightx = 1;
        
        // set the width of the panel.
        inPanel.setPreferredSize(new Dimension(40,40));
        inPanel.setMinimumSize(new Dimension(40,10));
        
        // the select tool not that it does anything
        c.gridy = 0;
        c.gridx = 0;
        JRadioButton tempRadioButton = new JRadioButton();
        tempRadioButton.setBorder(null);
        tempRadioButton.setIcon(getIcon("SelectInactive.png"));
        tempRadioButton.setSelectedIcon(getIcon("SelectActive.png"));
        tempRadioButton.setRolloverIcon(tempRadioButton.getSelectedIcon());
        tempRadioButton.setRolloverEnabled(true);
        tempRadioButton.setToolTipText("Select Features");
        myButtonGroup.add(tempRadioButton);
        SelectMultiCommand tempSelectMultiCommand = new SelectMultiCommand(this);
        GISMenuButton tempMenuButton = new GISMenuButton(tempSelectMultiCommand, tempRadioButton);
        tempSelectMultiCommand.setButton(tempMenuButton);
        tempMenuButton.initPanel();
        inPanel.add(tempMenuButton, c);
        
        // the zoom in tool
        c.gridy++;
        GISRadioButton tempGISButton = new GISRadioButton("Zoom In", new ZoomInCommand(this));
        tempGISButton.setBorder(null);
        tempGISButton.setIcon(getIcon("ZoomInInactive.png"));
        tempGISButton.setSelectedIcon(getIcon("ZoomInActive.png"));
        tempGISButton.setRolloverIcon(tempGISButton.getSelectedIcon());
        tempGISButton.setRolloverEnabled(true);
        tempGISButton.setToolTipText(tempGISButton.getText());
        tempGISButton.setText("");
        myButtonGroup.add(tempGISButton);
        inPanel.add(tempGISButton, c);
        
        // the zoom out tool
        c.gridy++;
        tempGISButton = new GISRadioButton("Zoom Out", new ZoomOutCommand(this));
        tempGISButton.setBorder(null);
        tempGISButton.setIcon(getIcon("ZoomOutInactive.png"));
        tempGISButton.setSelectedIcon(getIcon("ZoomOutActive.png"));
        tempGISButton.setRolloverIcon(tempGISButton.getSelectedIcon());
        tempGISButton.setRolloverEnabled(true);
        tempGISButton.setToolTipText(tempGISButton.getText());
        tempGISButton.setText("");
        myButtonGroup.add(tempGISButton);
        inPanel.add(tempGISButton, c);
        
        // The Pan Tool
        c.gridy++;
        tempGISButton = new GISRadioButton("Pan Around", new PanCommand(this));
        tempGISButton.setBorder(null);
        tempGISButton.setIcon(getIcon("PanInactive.png"));
        tempGISButton.setSelectedIcon(getIcon("PanActive.png"));
        tempGISButton.setRolloverIcon(tempGISButton.getSelectedIcon());
        tempGISButton.setRolloverEnabled(true);
        tempGISButton.setToolTipText(tempGISButton.getText());
        tempGISButton.setText("");
        myButtonGroup.add(tempGISButton);
        inPanel.add(tempGISButton, c);
        
        // The Recenter Tool
        c.gridy++;
        tempGISButton = new GISRadioButton("Center", new CenterOnPointCommand(this));
        tempGISButton.setBorder(null);
        tempGISButton.setIcon(getIcon("CenterInactive.png"));
        tempGISButton.setSelectedIcon(getIcon("CenterActive.png"));
        tempGISButton.setRolloverIcon(tempGISButton.getSelectedIcon());
        tempGISButton.setRolloverEnabled(true);
        tempGISButton.setToolTipText(tempGISButton.getText());
        tempGISButton.setText("");
        myButtonGroup.add(tempGISButton);
        inPanel.add(tempGISButton, c);
        
        // Reset tool
        //        c.gridy++;
        //        inPanel.add(new GISCommandButton("Reset", new ResetExtentsCommand(this)), c);
        
        // the edit nodes tool
        c.gridy++;
        tempRadioButton = new JRadioButton();
        tempRadioButton.setBorder(null);
        tempRadioButton.setIcon(getIcon("EditInactive.png"));
        tempRadioButton.setSelectedIcon(getIcon("EditActive.png"));
        tempRadioButton.setRolloverIcon(tempRadioButton.getSelectedIcon());
        tempRadioButton.setRolloverEnabled(true);
        tempRadioButton.setToolTipText("Edit Nodes");
        myButtonGroup.add(tempRadioButton);
        EditCommand tempEditNodesCommand = new EditCommand(this);
        EditNodesDrawModel tempEditNodesDrawModel = new EditNodesDrawModel();
        tempEditNodesDrawModel.setShader(new MonoShader(Color.black, Color.green, Color.red));
        tempEditNodesCommand.setEditModel(tempEditNodesDrawModel);
        tempMenuButton = new GISMenuButton(tempEditNodesCommand, tempRadioButton);
        tempEditNodesCommand.setButton(tempMenuButton);
        tempMenuButton.initPanel();
        inPanel.add(tempMenuButton, c);
        
        // the create shape tool.
        c.gridy++;
        tempRadioButton = new JRadioButton();
        tempRadioButton.setBorder(null);
        tempRadioButton.setIcon(getIcon("NewPolygonInactive.png"));
        tempRadioButton.setSelectedIcon(getIcon("NewPolygonActive.png"));
        tempRadioButton.setRolloverIcon(tempRadioButton.getSelectedIcon());
        tempRadioButton.setRolloverEnabled(true);
        tempRadioButton.setToolTipText("New Polygon");
        myButtonGroup.add(tempRadioButton);
        NewShapeCommand tempNewShapeCommand = new NewShapeCommand(this);
        tempMenuButton = new GISMenuButton(tempNewShapeCommand, tempRadioButton);
        tempNewShapeCommand.setButton(tempMenuButton);
        tempMenuButton.initPanel();
        inPanel.add(tempMenuButton, c);
        
        // The delete tool
        //        c.gridy++;
        //        inPanel.add(new GISCommandButton("Delete", new DeleteCommand(this)), c);
        
        // Add a panel for the additional buttons.
        c.gridy++;
        c.anchor = GridBagConstraints.NORTH;
        c.weighty = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        inPanel.add(new JPanel(), c);
        //        inPanel.add(myAuxillaryButtonPanel, c);
    }
    
    /**
     * Returns an additional panel for displaying buttons.
     */
    private JPanel getAuxillaryButtonPanel(){
        return myAuxillaryButtonPanel;
    }
    
    /**
     * Returns a panel on the display where additional information can be displayed for information or edit.
     */
    public JPanel getAuxillaryPanel(){
        return myAuxillaryPanel;
    }
    
    /**
     * Return the display used in this editor, mostly used for commands.
     */
    public GISDisplay getDisplay(){
        return myDisplay;
    }
    
    /**
     * Remove a button from the display.
     */
    public void removeButton(Component inComponent){
        if (myAuxillaryButtonPanel != null){
            myAuxillaryButtonPanel.remove(inComponent);
            myAuxillaryButtonPanel.getParent().validate();
        }
    }
    
    /** Extents have changed  */
    public void envelopeChanged(Envelope inEnvelope) {
        updateInfo();
    }
    
    /** Update the info message. */
    public void updateInfo(){
        if (myDisplay == null){
            myTextAreaInfo.setText("");
            return;
        }
        
        // show the screen size
        StringBuffer sb = new StringBuffer();
        sb.append("Screen Size");
        sb.append("\tWidth\t");
        sb.append(Integer.toString(myDisplay.getWidth()));
        sb.append("\n");
        sb.append("\tHeight\t");
        sb.append(Integer.toString(myDisplay.getHeight()));
        sb.append("\n");
        sb.append("\n");
        
        // show the extents of the map
        Envelope tempEnvelope = myDisplay.getEnvelope();
        if (tempEnvelope != null){
            sb.append("Map Extents\n");
            sb.append("\tMinX\t");
            sb.append(Double.toString(tempEnvelope.getMinX()));
            sb.append("\n");
            sb.append("\tMinY\t");
            sb.append(Double.toString(tempEnvelope.getMinY()));
            sb.append("\n");
            sb.append("\tMaxX\t");
            sb.append(Double.toString(tempEnvelope.getMaxX()));
            sb.append("\n");
            sb.append("\tMaxY\t");
            sb.append(Double.toString(tempEnvelope.getMaxY()));
            sb.append("\n");
            sb.append("\tWidth\t");
            sb.append(Double.toString(tempEnvelope.getWidth()));
            sb.append("\n");
            sb.append("\tHeight\t");
            sb.append(Double.toString(tempEnvelope.getHeight()));
            sb.append("\n");
            sb.append("\n");
            sb.append("Center");
            sb.append("\n");
            sb.append("\tX\t");
            sb.append(Double.toString( (tempEnvelope.getMinX()+tempEnvelope.getMaxX())/2 ));
            sb.append("\n");
            sb.append("\tY\t");
            sb.append(Double.toString( (tempEnvelope.getMinY()+tempEnvelope.getMaxY())/2 ));
            sb.append("\n\n");
        }
        
        // Projection information
        Projection tempProjection = myDisplay.getProjection();
        if (tempProjection == null){
            sb.append("Not Projected");
            sb.append("\n\n");
        }
        else{
            sb.append("Projection :");
            sb.append(tempProjection.getProjectionName());
            sb.append("\n\n");
        }
        // list the number of records visible for each layer.
        Layer[] tempLayers = myDisplay.getLayers();
        for (int i=0; i<tempLayers.length; i++){
            if (i == 0) sb.append("Visible Shapes");
            sb.append("\n\t");
            sb.append(tempLayers[i].getLayerName());
            sb.append("\n\t");
            if (tempLayers[i].isVisible()){
                Record[] tempRecords = tempLayers[i].getRecords();
                if (tempRecords != null) sb.append(Integer.toString(tempRecords.length));
                else sb.append("0");
            }
            else sb.append("0");
            sb.append("\n");
        }
        
        myTextAreaInfo.setText(sb.toString());
    }
    
    /** Create the actions */
    private void createActions(){
        //File
        try{myActionList.addAction(new NewLayerCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new OpenLayerCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new SaveImageCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new SaveSVGCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new PrintCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new ExitCommand(this));}catch(Throwable t){}
        
        //Edit
        try{myActionList.addAction(new SelectAllCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new CutCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new CopyCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new PasteCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new SaveSelectionCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new ShowAttributeCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new ZoomToSelectedShapesCommand(this));}catch(Throwable t){}
        
        // options
        try{myActionList.addAction(new ProjectionCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new LegendCommand(this));}catch(Throwable t){}
        try{myActionList.addAction(new ScaleBarCommand(this));}catch(Throwable t){}
        
        // help
        try{myActionList.addAction(new AboutCommand(this));}catch(Throwable t){}
    }
    
    /** retrieve the menu bar */
    private JMenuBar getGISMenuBar(){
        JMenuBar jMenuBar = new JMenuBar();
        
        // ************************************************************File menu
        JMenu jMenuFile = new JMenu("File");
        JMenuItem tempItem = null;
        
        // Read the configuration information from disk
        try{
            tempItem = new GISMenuItem("Open Configuration", new OpenConfigurationCommand(this));
            jMenuFile.add(tempItem);
            
            // Save configuration
            tempItem = new GISMenuItem("Save Configuration", new SaveConfigurationCommand(this));
            jMenuFile.add(tempItem);
            jMenuFile.add(new JSeparator());
        }
        catch (Throwable e){System.out.println("Error creatingConfiguration is xerces installed?");}
        
        // New Layer
        jMenuFile.add(myActionList.getAction(NewLayerCommand.getName()));
        
        // Open Layer
        jMenuFile.add(myActionList.getAction(OpenLayerCommand.getName()));
        
        // Sub menu for save.
        JMenu tempSubMenu = new JMenu("Export");
        tempSubMenu.setIcon(getIcon("Save24.gif"));
        
        // Save As Image
        try{tempSubMenu.add(myActionList.getAction(SaveImageCommand.getName()));} catch(Throwable e){System.out.println("Error creating Save Image, is JIMI installed?");}
        
        // Save as SVG
        try{tempSubMenu.add(myActionList.getAction(SaveSVGCommand.getName()));} catch(Throwable e){System.out.println("Error creating Save SVG, is BATIK installed?");}
        jMenuFile.add(tempSubMenu);
        
        // Print
        jMenuFile.add(new JSeparator());
        jMenuFile.add(myActionList.getAction(PrintCommand.getName()));
        
        // Exit Command.
        jMenuFile.add(new JSeparator());
        jMenuFile.add(myActionList.getAction(ExitCommand.getName()));
        jMenuBar.add(jMenuFile);
        
        // ************************************************ Edit menu
        JMenu jMenuSelect = new JMenu("Edit");
        jMenuSelect.add(myActionList.getAction(SelectAllCommand.getName()));
        jMenuSelect.add(myActionList.getAction(ZoomToSelectedShapesCommand.getName()));
        jMenuSelect.add(new JSeparator());
        jMenuSelect.add(myActionList.getAction(CutCommand.getName()));
        jMenuSelect.add(myActionList.getAction(CopyCommand.getName()));
        jMenuSelect.add(myActionList.getAction(PasteCommand.getName()));
        jMenuSelect.add(new JSeparator());
        jMenuSelect.add(myActionList.getAction(SaveSelectionCommand.getName()));
        jMenuSelect.add(myActionList.getAction(ShowAttributeCommand.getName()));
        jMenuBar.add(jMenuSelect);
        
        // ************************************************ Options menu
        JMenu jMenuOptions = new JMenu("Options");
        jMenuOptions.add(myActionList.getAction(ProjectionCommand.getName()));
        jMenuOptions.add(myActionList.getAction(LegendCommand.getName()));
        jMenuOptions.add(myActionList.getAction(ScaleBarCommand.getName()));
        jMenuBar.add(jMenuOptions);
        
        // *********************************************** Tools menu
        JMenu jMenuTools = new JMenu("Tools");
        tempItem = new GISMenuItem("ShapeFile Projector", new ShapeFileProjectorCommand(this));
        jMenuTools.add(tempItem);
        JMenu jMenuImageTools = new JMenu("Image Tools");
        jMenuTools.add(jMenuImageTools);
        tempItem = new GISMenuItem("Raster Catalog Creator", new RasterCatalogCreatorCommand(this));
        jMenuImageTools.add(tempItem);
        tempItem = new GISMenuItem("Image Chopper", new ImageChopperCommand(this));
        jMenuImageTools.add(tempItem);
        jMenuBar.add(jMenuTools);
        
        // *********************************************** Help menu
        JMenu jMenuHelp = new JMenu("Help");
        jMenuHelp.setAlignmentX(JMenu.RIGHT_ALIGNMENT);
        jMenuHelp.add(myActionList.getAction(AboutCommand.getName()));
        jMenuBar.add(jMenuHelp);
        
        return jMenuBar;
    }
    
    /** Create the tool bar for the application */
    public JToolBar getGISToolBar(){
        // create the tool bar
        JToolBar toolBar = new JToolBar();
        
        // add the open button
        toolBar.add(myActionList.getAction(OpenLayerCommand.getName()));
        
        // add the save button
        toolBar.add(myActionList.getAction(SaveCommand.getName()));
        
        // add the previous zoom button
        GISCommandButton button = new GISCommandButton(getIcon("PreviousZoom24.gif"));
        button.setToolTipText("Previous Zoom");
        button.setCommand(new PreviousZoomCommand(this));
        //         button.setMargin(new Insets(0,0,0,0));
        toolBar.add(button);
        toolBar.addSeparator();
        
        // add the cut command
        toolBar.add(myActionList.getAction(CutCommand.getName()));
        
        // add the copy command
        toolBar.add(myActionList.getAction(CopyCommand.getName()));
        
        // add the paste command
        toolBar.add(myActionList.getAction(PasteCommand.getName()));
        
        //toolBar.setRollover(true);  Damn, only works in Java 1.4 Beta.
        return toolBar;
    }
    
    /** A place to store records that have been copied, or cut and are waiting to be pasted. */
    private Record[] myCopyBuffer = new Record[0];
    /** Get the records that are in the copy buffer. */
    public Record[] getCopyBuffer(){return myCopyBuffer;}
    /** Set the records into the copy buffer. */
    public void setCopyBuffer(Record[] inRecords){myCopyBuffer = inRecords;}
    
    /** Check if JTS is available. */
    public boolean isJTSAvailable(){
        boolean tempJTSAvailable = false;
        
        // try to instantiate a coordinate
        try{
            Class.forName("com.vividsolutions.jts.geom.Coordinate").newInstance();
            tempJTSAvailable = true;
        }
        catch (Exception e){
        }
        return tempJTSAvailable;
    }
    
    /** Save the configuration information for the application. */
    public void saveConfig(){
        // create the Directory where the configuration file is to be saved.
        File tempConfigDirectory = new File(new File(System.getProperty("user.home")),"."+Constants.getApplicationName());
        if (!tempConfigDirectory.exists()){
            if (!tempConfigDirectory.mkdirs()){
                System.out.println("Can not make configuration directory "+tempConfigDirectory);
                return;
            }
        }
        
        // create the properties file.
        Properties tempConfigurationProperties = new Properties();
        Properties tempSystemProperties = System.getProperties();
        
        Enumeration en = tempSystemProperties.keys();
        String tempPrefix = Constants.getApplicationName();
        while (en.hasMoreElements()){
            String tempName = (String) en.nextElement();
            if(tempName.startsWith(tempPrefix)) tempConfigurationProperties.setProperty(tempName, tempSystemProperties.getProperty(tempName));
        }
        
        // write the properties file to a file.
        File tempConfigurationPropertiesFile = new File(tempConfigDirectory, Constants.getApplicationName()+".properties");
        try{
            FileOutputStream fout = new FileOutputStream(tempConfigurationPropertiesFile);
            tempConfigurationProperties.store(fout,"GISToolkit Editor Properties file.");
            fout.close();
        }
        catch (Exception ex){
            System.out.println("Can not save configuration information in "+tempConfigurationPropertiesFile);
            ex.printStackTrace();
        }
    }
    
    /** Load the configuration information for the application. */
    public void loadConfig(String inFilename){
        Properties tempApplicationProperties = null;
        String tempFilename = inFilename;
        if (tempFilename == null){
            // the file should be in the users home directory, with the name of the application
            File tempConfigDirectory = new File(new File(System.getProperty("user.home")),"."+Constants.getApplicationName());
            tempFilename = tempConfigDirectory.getAbsolutePath()+File.separatorChar+Constants.getApplicationName()+".properties";
        }
        try{
            InputStream tempIOStream = null;
            
            // open the file should it exist
            File tempFile = new File(tempFilename);
            if (tempFile.exists()){
                // create a stream for the properties
                tempIOStream = new FileInputStream(tempFilename);
                Properties tempProperties = new Properties();
                tempProperties.load(tempIOStream);
                tempIOStream.close();
                tempApplicationProperties = tempProperties;
            }
            else{
                
                // look for the properties file from the string sent in.
                if (inFilename != null){
                    tempIOStream = this.getClass().getClassLoader().getResourceAsStream(inFilename);
                    if (tempIOStream != null){
                        Properties tempProperties = new Properties();
                        tempProperties.load(tempIOStream);
                        tempIOStream.close();
                        tempApplicationProperties = tempProperties;
                    }
                    else{
                        // read the default properties from the file.
                        inFilename = "gistoolkit.properties";
                        tempIOStream = this.getClass().getClassLoader().getResourceAsStream(inFilename);
                        if (tempIOStream == null){
                            throw new Exception("Could not find "+inFilename+" configuration file, using defaults") ;
                        }
                        Properties tempProperties = new Properties();
                        tempProperties.load(tempIOStream);
                        tempIOStream.close();
                        tempApplicationProperties = tempProperties;
                    }
                }
            }
        }
        catch(Exception e){
            System.out.println("Exception reading Configuration\n"+e);
        }
        
        if (tempApplicationProperties == null){
            // load the defaults
            tempApplicationProperties = new Properties();
            // Available Data Source Layers.
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.1","gistoolkit.application.layers.layerpanel.ShapeFileDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.2","gistoolkit.application.layers.layerpanel.ReadOnlyShapeFileDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.3","gistoolkit.application.layers.layerpanel.ReadOnlyPostGISDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.4","gistoolkit.application.layers.layerpanel.UpdateablePostGISDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.5","gistoolkit.application.layers.layerpanel.ReadOnlyMySQLDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.6","gistoolkit.application.layers.layerpanel.UpdateableMySQLDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.7","gistoolkit.application.layers.layerpanel.ReadOnlyOracleDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.8","gistoolkit.application.layers.layerpanel.UpdateableOracleDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.9","gistoolkit.application.layers.layerpanel.ReadOnlySpatialExtenderDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.10","gistoolkit.application.layers.layerpanel.UpdateableSpatialExtenderDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.11","gistoolkit.application.layers.layerpanel.ImageFileDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.12","gistoolkit.application.layers.layerpanel.SeamlessDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.13","gistoolkit.application.layers.layerpanel.TerraserverDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.14","gistoolkit.application.layers.layerpanel.OGCWebServiceDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.15","proprietary.datasources.arcsde.ArcSDEDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.16","proprietary.datasources.arcsde.UpdateableArcSDEDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.17","proprietary.datasources.arcims.ArcIMSDataSourcePanel");
            tempApplicationProperties.put(Constants.getApplicationName()+".datasourcepanel.18","proprietary.datasources.ermapper.ERMapperDataSourcePanel");
        }
        
        // loop through the properties adding the ones that do not exist to the list.
        Enumeration e = tempApplicationProperties.keys();
        while (e.hasMoreElements()){
            String tempName = (String) e.nextElement();
            if (System.getProperty(tempName) == null){
                System.setProperty(tempName, tempApplicationProperties.getProperty(tempName));
            }
        }
    }
}