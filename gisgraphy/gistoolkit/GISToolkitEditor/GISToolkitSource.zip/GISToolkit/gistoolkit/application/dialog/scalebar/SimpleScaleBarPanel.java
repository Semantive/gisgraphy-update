/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.dialog.scalebar;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.widgets.*;
import gistoolkit.display.scalebar.SimpleScaleBar;
/**
 * Panel for editing the attributes of the SimpleScaleBar.
 */
public class SimpleScaleBarPanel extends ScaleBarPanel {
    
    /** Creates new SimpleScalebarPanel */
    public SimpleScaleBarPanel() {
        initPanel();
    }
    
    /**Reference to the ScaleBar to be edited.*/
    private SimpleScaleBar myScaleBar = null;
    
    /**Allows displaying the description of a scale bar.*/
    private JLabel myLabelDescription = new JLabel();    
            
    /**Reference to the Line Width*/
    private JComboBox myComboLineWidth = new JComboBox();    
    private String LINEWIDTH1 = "1.0";
    private String LINEWIDTH2 = "2.0";
    private String LINEWIDTH3 = "3.0";
    private String LINEWIDTH4 = "4.0";
    private String LINEWIDTH5 = "5.0";
    private String LINEWIDTH6 = "6.0";
    private String LINEWIDTH7 = "7.0";
    private String LINEWIDTH8 = "8.0";
    private String LINEWIDTH9 = "9.0";
    private String LINEWIDTH10 = "10.0";
    
    /**Reference to the Line color ScaleBar button*/
    private ColorButton myColorButtonLine = new ColorButton();
        
    /**Reference to the Label color ScaleBar button.*/
    private ColorButton myColorButtonLabel = new ColorButton();
    
    /**Reference to the fontbutton to use when changing the font for the labels.*/
    private FontButton myFontButtonLabel = new FontButton();
    private SimpleScaleBarPanel getThis(){return this;}
        
    /**Alpha percentage for the ScaleBar.*/
    private JComboBox myComboAlpha = new JComboBox();
    private String ALPHA1 = "1.0";
    private String ALPHA2 = "0.75";
    private String ALPHA3 = "0.50";
    private String ALPHA4 = "0.25";
    private String ALPHA5 = "0.0";

    /**Orientation for the ScaleBar.*/
    private JComboBox myComboOrientation = new JComboBox();
    private String ORIENTUL = "Upper Left";
    private String ORIENTUR = "Upper Right";
    private String ORIENTLL = "Lower Left";
    private String ORIENTLR = "Lower Right";

    /** Percentage of screen width to use. */
    private JComboBox myComboScreenPercent = new JComboBox();
    private String SCREENPERCENT1 = "100";
    private String SCREENPERCENT2 = "50";
    private String SCREENPERCENT3 = "25";
    private String SCREENPERCENT4 = "20";    
    
    /** The offset in pixels of the scale bar in the horrizontal direction. */
    private JTextField myTextFieldHorizontalOffset = new JTextField("5");
    
    /** The offset in pixels of the scale bar in the vertical direction. */
    private JTextField myTextFieldVerticalOffset = new JTextField("5");
            
    /**
     * Initialize the panel
     */
    private void initPanel() {
        // retrieve the panel and populate.
        JPanel tempPanel = this;
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2, 2, 2, 2);
        c.fill = GridBagConstraints.BOTH;
        
        // the Description
        c.gridx = 0;
        c.gridy = 0;
        tempPanel.add(new JLabel("Description "), c);
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridx++;
        tempPanel.add(myLabelDescription, c);
        c.gridwidth = 1;
        
        // the Line color
        c.gridx = 0;
        c.gridy++;
        c.weightx = 0;
        tempPanel.add(new JLabel("Line Color"), c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(myColorButtonLine, c);
        c.gridwidth = 1;
        
        // Line Width
        c.gridx = 0;
        c.gridy++;
        tempPanel.add(new JLabel("Line Width"), c);
        c.gridx++;
        c.gridwidth = 2;
        myComboLineWidth.addItem(LINEWIDTH1);
        myComboLineWidth.addItem(LINEWIDTH2);
        myComboLineWidth.addItem(LINEWIDTH3);
        myComboLineWidth.addItem(LINEWIDTH4);
        myComboLineWidth.addItem(LINEWIDTH5);
        myComboLineWidth.addItem(LINEWIDTH6);
        myComboLineWidth.addItem(LINEWIDTH7);
        myComboLineWidth.addItem(LINEWIDTH8);
        myComboLineWidth.addItem(LINEWIDTH9);
        myComboLineWidth.addItem(LINEWIDTH10);
        tempPanel.add(myComboLineWidth, c);
        c.gridwidth = 1;
                                
        // the Label Color
        c.gridx = 0;
        c.gridy++;
        tempPanel.add(new JLabel("Label Color"), c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(myColorButtonLabel, c);
        c.gridwidth = 1;
        
        // the Label Font
        c.gridx = 0;
        c.gridy++;
        tempPanel.add(new JLabel("Label Font"), c);
        c.gridx++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        tempPanel.add(myFontButtonLabel, c);
        c.gridwidth = 1;

        // Alpha Percentage
        c.gridy++;
        c.gridx = 0;
        tempPanel.add(new JLabel("Alpha Percent"), c);
        c.gridx++;
        c.gridwidth = 2;
        myComboAlpha.removeAllItems();
        myComboAlpha.addItem(ALPHA1);
        myComboAlpha.addItem(ALPHA2);
        myComboAlpha.addItem(ALPHA3);
        myComboAlpha.addItem(ALPHA4);
        myComboAlpha.addItem(ALPHA5);
        tempPanel.add(myComboAlpha, c);
        c.gridwidth = 1;
        
        //Orientation
        c.gridy++;
        c.gridx = 0;
        tempPanel.add(new JLabel("Location"), c);
        c.gridx++;
        c.gridwidth = 2;
        myComboOrientation.removeAllItems();
        myComboOrientation.addItem(ORIENTUL);
        myComboOrientation.addItem(ORIENTUR);
        myComboOrientation.addItem(ORIENTLL);
        myComboOrientation.addItem(ORIENTLR);
        tempPanel.add(myComboOrientation, c);
        c.gridwidth = 1;
        
        //Size
        c.gridy++;
        c.gridx = 0;
        tempPanel.add(new JLabel("Screen %"), c);
        c.gridx++;
        c.gridwidth = 2;
        myComboScreenPercent.removeAllItems();
        myComboScreenPercent.addItem(SCREENPERCENT1);
        myComboScreenPercent.addItem(SCREENPERCENT2);
        myComboScreenPercent.addItem(SCREENPERCENT3);
        myComboScreenPercent.addItem(SCREENPERCENT4);
        tempPanel.add(myComboScreenPercent, c);
        c.gridwidth = 1;

        // the Horrizontal Offset
        c.gridx = 0;
        c.gridy ++;
        tempPanel.add(new JLabel("HOffset (pxl) "), c);
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridx++;
        tempPanel.add(myTextFieldHorizontalOffset, c);
        c.gridwidth = 1;

        // the Horrizontal Offset
        c.gridx = 0;
        c.gridy ++;
        tempPanel.add(new JLabel("VOffset (pxl) "), c);
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridx++;
        tempPanel.add(myTextFieldVerticalOffset, c);
        c.gridwidth = 1;

        // add some space
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.weighty = 1;
        c.weightx = 1;
        tempPanel.add(new JPanel(), c);
    }
    
    /** retrieve the edited ScaleBar from the dialog */
    public ScaleBar getScaleBar(){
        if (myScaleBar == null) return null;
        myScaleBar.setDefaultLineColor(myColorButtonLine.getBackground());        
        myScaleBar.setDefaultLabelColor(myColorButtonLabel.getBackground());
        myScaleBar.setDefaultFont(myFontButtonLabel.getFont());
        
        try{
            myScaleBar.setAlpha(Float.parseFloat(myComboAlpha.getSelectedItem().toString()));
        }
        catch (Exception e){
            System.out.println("SimpleScaleBarDlg "+e);
        }
        try{
            myScaleBar.setScreenPercent(Float.parseFloat(myComboScreenPercent.getSelectedItem().toString()));
        }
        catch (Exception e){
            System.out.println("SimpleScaleBarDlg "+e);
        }
        try{
            if (myScaleBar.getStroke() instanceof BasicStroke){
                 myScaleBar.setStroke(new BasicStroke(Float.parseFloat(myComboLineWidth.getSelectedItem().toString()), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND ));
            }
        }
        catch (Exception e){
            System.out.println("SimpleScaleBarDlg "+e);
        }

        // Horizontal Offset
        try{
            myScaleBar.setHorizontalOffset(Integer.parseInt(myTextFieldHorizontalOffset.getText()));
        }
        catch (NumberFormatException e){}
        
        // Vertical Offset
        try{
            myScaleBar.setVerticalOffset(Integer.parseInt(myTextFieldVerticalOffset.getText()));
        }
        catch (NumberFormatException e){}
        
        // Orientation
        String tempString = (String) myComboOrientation.getSelectedItem();
        if (tempString == ORIENTUL) myScaleBar.setQuadrant(SimpleScaleBar.UPPER_LEFT);
        if (tempString == ORIENTUR) myScaleBar.setQuadrant(SimpleScaleBar.UPPER_RIGHT);
        if (tempString == ORIENTLL) myScaleBar.setQuadrant(SimpleScaleBar.LOWER_LEFT);
        if (tempString == ORIENTLR) myScaleBar.setQuadrant(SimpleScaleBar.LOWER_RIGHT);

        return myScaleBar;
        
    }
    /**
     * Set the ScaleBar to be edited.
     */
    public void setScaleBar(ScaleBar inScaleBar){
        if (inScaleBar instanceof SimpleScaleBar){
            myScaleBar = (SimpleScaleBar) inScaleBar;
            myLabelDescription.setText(myScaleBar.getDescription());
            myColorButtonLine.setBackground(myScaleBar.getDefaultLineColor());
            myColorButtonLabel.setBackground(myScaleBar.getDefaultLabelColor());
            myFontButtonLabel.setFont(myScaleBar.getDefaultFont());
            
            float tempAlphaF = myScaleBar.getAlpha();
            if (Float.parseFloat(ALPHA1) == tempAlphaF){
                myComboAlpha.setSelectedItem(ALPHA1);
            }
            if (Float.parseFloat(ALPHA2) == tempAlphaF){
                myComboAlpha.setSelectedItem(ALPHA2);
            }
            if (Float.parseFloat(ALPHA3) == tempAlphaF){
                myComboAlpha.setSelectedItem(ALPHA3);
            }
            if (Float.parseFloat(ALPHA4) == tempAlphaF){
                myComboAlpha.setSelectedItem(ALPHA4);
            }
            if (Float.parseFloat(ALPHA5) == tempAlphaF){
                myComboAlpha.setSelectedItem(ALPHA5);
            }

            float tempScreenPercentF = myScaleBar.getScreenPercent();
            if (Float.parseFloat(SCREENPERCENT1) == tempAlphaF){
                myComboScreenPercent.setSelectedItem(SCREENPERCENT1);
            }
            if (Float.parseFloat(SCREENPERCENT2) == tempAlphaF){
                myComboScreenPercent.setSelectedItem(SCREENPERCENT2);
            }
            if (Float.parseFloat(SCREENPERCENT3) == tempAlphaF){
                myComboScreenPercent.setSelectedItem(SCREENPERCENT3);
            }
            if (Float.parseFloat(SCREENPERCENT4) == tempAlphaF){
                myComboScreenPercent.setSelectedItem(SCREENPERCENT4);
            }

            int tempOrient = myScaleBar.getQuadrant();
            if (tempOrient == SimpleScaleBar.UPPER_LEFT){
                myComboOrientation.setSelectedItem(ORIENTUL);
            }
            if (tempOrient == SimpleScaleBar.UPPER_RIGHT){
                myComboOrientation.setSelectedItem(ORIENTUR);
            }
            if (tempOrient == SimpleScaleBar.LOWER_LEFT){
                myComboOrientation.setSelectedItem(ORIENTLL);
            }
            if (tempOrient == SimpleScaleBar.LOWER_RIGHT){
                myComboOrientation.setSelectedItem(ORIENTLR);
            }
            Stroke tempStroke = myScaleBar.getStroke();
            myComboLineWidth.setSelectedIndex(0);
            if (tempStroke instanceof BasicStroke){
                float tempLineWidthF = ((BasicStroke) tempStroke).getLineWidth();
                if (Float.parseFloat(LINEWIDTH1) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH1);
                }
                if (Float.parseFloat(LINEWIDTH2) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH2);
                }
                if (Float.parseFloat(LINEWIDTH3) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH3);
                }
                if (Float.parseFloat(LINEWIDTH4) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH4);
                }
                if (Float.parseFloat(LINEWIDTH5) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH5);
                }
                if (Float.parseFloat(LINEWIDTH6) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH6);
                }
                if (Float.parseFloat(LINEWIDTH7) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH7);
                }
                if (Float.parseFloat(LINEWIDTH8) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH8);
                }
                if (Float.parseFloat(LINEWIDTH9) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH9);
                }
                if (Float.parseFloat(LINEWIDTH10) == tempLineWidthF){
                    myComboLineWidth.setSelectedItem(LINEWIDTH10);
                }
            }
            
            // Horizontal Offset.
            myTextFieldHorizontalOffset.setText(""+myScaleBar.getHorizontalOffset());
            // Vertical Offset
            myTextFieldVerticalOffset.setText(""+myScaleBar.getVerticalOffset());
        }
    }    
}
