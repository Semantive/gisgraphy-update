/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.dialog;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.projection.*;
import gistoolkit.display.widgets.*;
/**
 * Dialog allowing the user to select from several projections for their map.
 * @author  ithaqua
 */
public class ProjectionDialog extends GISToolkitDialog implements ItemListener{

    /** Creates new ProjectionDialog */
    public ProjectionDialog(Frame parent) {
        super(parent);
        initPanel();
    }

    /** Create a list of all of the available projections */
    private JComboBox myComboProjections = new JComboBox();
    
    /** Initialize the GYI components for this dialog */
    private void initPanel(){
        setTitle("Update Projection");
        
        // create a border layout with the choice in the top, and the panel in the bottom.
        Container p = getContentPane();
        p.setLayout(new BorderLayout(2,2));
        p.add(myComboProjections, BorderLayout.NORTH);
        
        // populate the choice of projections.
        myComboProjections.addItem(new ProjectionWrapper(new NoProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new AlbersEqualAreaProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new LambertConicConformalProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new UniversalTransverseMercatorProjection()));
        myComboProjections.addItem(new ProjectionWrapper(new BritishNationalGridProjection()));
        myComboProjections.setSelectedIndex(0);
        itemStateChanged(null);
        
        // add ActionListener
        myComboProjections.addItemListener(this);
        
        // set the location of the dialog
        setLocationRelativeTo(getParent());
    }
    
    /** Panel to keep so it can be removed */
    private Component myCurrentComponent = null;
    
    /** Respond to events from the combo box */
    public void itemStateChanged(java.awt.event.ItemEvent p1) {
        Projection tempProjection = ((ProjectionWrapper) myComboProjections.getSelectedItem()).getProjection();
        Container p = getContentPane();
        if (myCurrentComponent != null) p.remove(myCurrentComponent);
        if (tempProjection instanceof EditableProjection){
            myCurrentComponent = ((EditableProjection) tempProjection).getEditPanel();
        }
        else {
            myCurrentComponent = new JLabel("Uneditable Projection");
        }
        p.add( myCurrentComponent, BorderLayout.CENTER);
        pack();
    }
    
    /** An internal class to wrap the projection so it displays correctly in the combo box.*/
    private class ProjectionWrapper {
        public Projection myProjection = null;
        public Projection getProjection(){return myProjection;}
        public ProjectionWrapper (Projection inProjection){
            myProjection = inProjection;
        }
        
        /** The to string function is the whole purpose */
        public String toString(){
            if (myProjection == null) return "Null Projeciton";
            else return myProjection.getProjectionName();
        }
    }
        
    /** set the projection into the panel */
    public void setProjection(Projection inProjection){
        if (inProjection == null) return;
        String tempInProjectionClass = inProjection.getClass().getName();
        boolean tempFound = false;
        for (int i=0; i<myComboProjections.getItemCount(); i++){
            Projection tempProjection = ((ProjectionWrapper) myComboProjections.getItemAt(i)).getProjection();
            String tempString = tempProjection.getClass().getName();
            if (tempInProjectionClass.equals(tempString)){
                myComboProjections.removeItemAt(i);
                myComboProjections.insertItemAt(new ProjectionWrapper(inProjection), i);
                myComboProjections.setSelectedIndex(i);
                tempFound = true;
                itemStateChanged(null);
            }            
        }
        if (!tempFound){
            myComboProjections.addItem(new ProjectionWrapper(inProjection));
            myComboProjections.setSelectedIndex(myComboProjections.getItemCount()-1);
            itemStateChanged(null);
        }
    }
    
    /** Retrieve the edited projection from the layout */
    public Projection getProjection(){
        if (myCurrentComponent instanceof ProjectionPanel){
            return ((ProjectionPanel) myCurrentComponent).getProjection();
        }
        else{
            return ((ProjectionWrapper) myComboProjections.getSelectedItem()).getProjection();
        }
    }
}
