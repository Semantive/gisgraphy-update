/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.dialog;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.*;
import gistoolkit.display.widgets.*;
import gistoolkit.display.scalebar.*;
import gistoolkit.application.dialog.scalebar.*;
/**
 * A dialog to display and edit the available scale bars..
 */
public class ScaleBarDialog extends GISToolkitDialog implements ItemListener{

    /** Creates new ScaleBarialog */
    public ScaleBarDialog(Frame inParent) {
        super(inParent, "ScaleBar");
        initPanel();
    }
    
    /** Choice of the ScaleBars that I know about */
    private JComboBox myComboScaleBars = new JComboBox();
    
    /** Vector to contain the ScaleBars */
    private Vector myVectScaleBars = new Vector();
    
    /** Vector to contain the associated scale bar panels. */
    private Vector myVectScaleBarPanels = new Vector();
    
    /** Panel on which to display the edit panel for this ScaleBar */
    private JPanel myDisplayPanel = new JPanel();
    
    /** Hold a reference to the currently selected ScaleBar Panel */
    private ScaleBarPanel myScaleBarPanel = null;
    
    /** Holds a reference to the ScaleBar sent in. */
    private ScaleBar myScaleBar = null;
    
    /** respond to Item events from the JComboBox */
    public void itemStateChanged(ItemEvent inIE){
        ScaleBar tempScaleBar = (ScaleBar) myVectScaleBars.elementAt(myComboScaleBars.getSelectedIndex());
        myDisplayPanel.removeAll();
        myScaleBarPanel = (ScaleBarPanel) myVectScaleBarPanels.elementAt(myComboScaleBars.getSelectedIndex());
        if (myScaleBarPanel != null){
            myScaleBarPanel.setScaleBar(tempScaleBar);
            myDisplayPanel.add(myScaleBarPanel);
        }
        else{
            myDisplayPanel.add(new JLabel("Non Editable ScaleBar"), BorderLayout.CENTER);
        }
//        myDisplayPanel.validate();
        pack();
    }
    
    /** initialize the use interface components for this panel */
    private void initPanel(){
        Container p = getContentPane();
        p.setLayout(new BorderLayout());
        p.add(myComboScaleBars, BorderLayout.NORTH);
        p.add(myDisplayPanel, BorderLayout.CENTER);
        myDisplayPanel.setLayout(new BorderLayout());
        
        // create the ScaleBars array
        myVectScaleBars.addElement(null);
        myVectScaleBarPanels.addElement(null);
        myComboScaleBars.addItem("No Scale Bar");
        myVectScaleBars.addElement(new MeterToMetricScaleBar());
        myVectScaleBarPanels.addElement(new SimpleScaleBarPanel());
        myComboScaleBars.addItem("Meter To Metric ScaleBar");
        myVectScaleBars.addElement(new MeterToEnglishScaleBar());
        myVectScaleBarPanels.addElement(new SimpleScaleBarPanel());
        myComboScaleBars.addItem("Meter To English ScaleBar");

        myComboScaleBars.addItemListener(this);        
        itemStateChanged(null);
        resetSize();
    }
    
    /** Set the ScaleBar into this dialog, it will serve as the template or defaults. */
    public void setScaleBar(ScaleBar inScaleBar){
        if (inScaleBar == null) {
            // I happen to know the first one is null
            myComboScaleBars.setSelectedIndex(0);
            itemStateChanged(null);
            return;
        }

        // try to find the ScaleBar in the list 
        boolean tempFound = false;
        String tempClassName = inScaleBar.getClass().getName();
        for (int i=0; i<myVectScaleBars.size(); i++){
            if (myVectScaleBars.elementAt(i) != null){
                if (tempClassName.equals(myVectScaleBars.elementAt(i).getClass().getName())){
                    myVectScaleBars.setElementAt(inScaleBar ,i);
                    myComboScaleBars.setSelectedIndex(i);
                    itemStateChanged(null);
                    tempFound = true;
                }
            }
        }
        myScaleBar = inScaleBar;
        
        if (!tempFound){
            myDisplayPanel.removeAll();
            myDisplayPanel.add(new JLabel("Non Editable ScaleBar"), BorderLayout.CENTER);
        }
    }
    
    /** Get the edited ScaleBar from this dialog. */
    public ScaleBar getScaleBar(){
        if (myScaleBarPanel != null){
            return myScaleBarPanel.getScaleBar();
        }
        return null;
    }
    /**
     * Testing
     * main entrypoint - starts the part when it is run as an application
     */
    public static void main(java.lang.String[] args) {
        try {
            GISToolkitDialog tempDialog = new ScaleBarDialog(new JFrame()); // change this line for your dialog.
            tempDialog.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosing(java.awt.event.WindowEvent e) {
                    System.exit(0);
                };
            });
            tempDialog.setVisible(true);
        } catch (Throwable exception) {
            System.err.println("Exception occurred in main() of GISToolkitDialog");
            exception.printStackTrace(System.out);
        }
    }
}
