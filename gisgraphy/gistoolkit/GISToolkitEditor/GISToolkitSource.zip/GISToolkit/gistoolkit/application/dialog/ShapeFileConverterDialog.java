/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.application.dialog;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.projection.*;
import gistoolkit.display.widgets.*;
import gistoolkit.projection.ellipsoid.transform.*;
import gistoolkit.datasources.shapefile.*;

/**
 * Allows the user to convert a shape file in one coordinate system to another.
 * @author  bitterstorm
 */
public class ShapeFileConverterDialog extends GISToolkitDialog implements ItemListener, ActionListener {
    
    /** Creates new ShapeFileConverterDialog */
    public ShapeFileConverterDialog(Frame parent) {
        super(parent);
        initPanel();
    }
    
    private Projection[] myKnownProjections = {
        new NoProjection(),
        new AlbersEqualAreaProjection(),
        new LambertConicConformalProjection(),
        new UniversalTransverseMercatorProjection()
    };
    
    
    /** Text field for entering the location of the shape file for projecting from */
    private JTextField myTextFieldFromFile = new JTextField();
    
    /** Button for browsing for the location of the shape file for projection from */
    private JButton myButtonFromBrowse = new JButton("Browse");
    
    /** Create a list of all of the available projections */
    private JComboBox myComboFromProjections = new JComboBox();
    
    /** Display the information for the From Projection */
    private JPanel myFromPanel = new JPanel(new BorderLayout());
    
    /*** Display the information for the Transform */
    private JPanel myTransformPanel = new JPanel(new BorderLayout());
    
    /** Text field for entering the location of the shape file for projecting to */
    private JTextField myTextFieldToFile = new JTextField();
    
    /** Button for browsing for the location of the shape file for projecting to */
    private JButton myButtonToBrowse = new JButton("Browse");
    
    /** Create a list of all of the available projections */
    private JComboBox myComboToProjections = new JComboBox();
    
    /** Display the information for the To Projection */
    private JPanel myToPanel = new JPanel(new BorderLayout());
    
    /** Create a Tab Panel for displaying the information for each conversion */
    private JTabbedPane myTabbedPanel = new JTabbedPane();
    
    /** Initialize the GYI components for this dialog */
    private void initPanel(){
        setTitle("ShapeFile Converter");
        
        // Create a Grid Bag Layout with the two Projections on the sides, and the buttons in the middle.
        Container p = getContentPane();
        p.setLayout(new BorderLayout());
        p.add(myTabbedPanel, BorderLayout.CENTER);
        myTabbedPanel.addTab("From", getFromPanel());
        myTabbedPanel.addTab("To", getToPanel());
        myTabbedPanel.addTab("Transform", getTransformPanel());
        myTabbedPanel.addTab("Test", getTestPanel());
        
        itemStateChanged(null);
    }
    
    /** Retrieve the panel for the From coordinate system */
    public JPanel getFromPanel(){
        JPanel tempPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.weightx = 1;
        c.fill = GridBagConstraints.BOTH;
        
        // The From Label
        c.gridx = 0;
        c.gridy = 0;
        tempPanel.add(new JLabel("Read Shape File From"), c);
        
        // The From File
        c.gridx = 0;
        c.gridy++;
        JPanel tempPanelFile = new JPanel(new BorderLayout());
        tempPanelFile.add(myTextFieldFromFile, BorderLayout.CENTER);
        tempPanelFile.add(myButtonFromBrowse, BorderLayout.EAST);
        tempPanel.add(tempPanelFile,c);
        
        // The From Projections
        c.gridx=0;
        c.gridy++;
        tempPanel.add(myComboFromProjections, c);
        for (int i=0; i<myKnownProjections.length; i++){
            myComboFromProjections.addItem(myKnownProjections[i].clone());
        }
        
        // The From Panel
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myFromPanel, c);
        
        // The Space Panel
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);
        
        // add ActionListener
        myComboFromProjections.addItemListener(this);
        myButtonFromBrowse.addActionListener(this);
        
        return tempPanel;
    }
    
    /** Retrieve the panel for the From coordinate system */
    public JPanel getToPanel(){
        JPanel tempPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.weightx = 1;
        c.fill = GridBagConstraints.BOTH;
        
        // The To Label
        c.gridx = 0;
        c.gridy = 0;
        tempPanel.add(new JLabel("Read Shape File To"), c);
        
        
        // The To File
        c.gridx = 0;
        c.gridy++;
        JPanel tempPanelFile = new JPanel(new BorderLayout());
        tempPanelFile.add(myTextFieldToFile, BorderLayout.CENTER);
        tempPanelFile.add(myButtonToBrowse, BorderLayout.EAST);
        tempPanel.add(tempPanelFile,c);
        
        // The To Projections
        c.gridx=0;
        c.gridy++;
        tempPanel.add(myComboToProjections, c);
        for (int i=0; i<myKnownProjections.length; i++){
            myComboToProjections.addItem(myKnownProjections[i].clone());
        }
        
        // The To Panel
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myToPanel, c);
        
        // The Space Panel
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);
        
        // add ActionListener
        myComboToProjections.addItemListener(this);
        myButtonToBrowse.addActionListener(this);
        
        return tempPanel;
    }
    
    private JLabel myLabelTransform = new JLabel("Type of Transform");
    private JButton myButtonGuessTransform = new JButton("Guess");
    private JComboBox myComboTransforms = new JComboBox();
    private EllipsoidTransform[] myKnownTransforms = new EllipsoidTransform[0];
    
    private TransformFactory myTransformFactory = new TransformFactory();
    
    /** Retrieve the panel for the Transforming the Ellipsoid*/
    public JPanel getTransformPanel(){
        myKnownTransforms = myTransformFactory.getKnownTransforms();
        JPanel tempPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.weightx = 1;
        c.fill = GridBagConstraints.BOTH;
        
        // The To Label
        c.gridx = 0;
        c.gridy = 0;
        tempPanel.add(myLabelTransform, c);
        c.gridx++;
        c.weightx = 0;
        tempPanel.add(myButtonGuessTransform, c);
        c.weightx = 1;
        c.gridwidth = 2;
        
        // The Transforms
        c.gridx=0;
        c.gridy++;
        tempPanel.add(myComboTransforms, c);
        for (int i=0; i<myKnownTransforms.length; i++){
            myComboTransforms.addItem(myKnownTransforms[i]);
        }
        
        // The Transform Panel
        c.gridx = 0;
        c.gridy++;
        c.weightx = 1;
        tempPanel.add(myTransformPanel, c);
        
        // The Space Panel
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);
        
        // add ActionListener
        myComboTransforms.addItemListener(this);
        myButtonGuessTransform.addActionListener(this);
        return tempPanel;
    }
    
    
    private JTextField myTextFieldInLatitude = new JTextField();
    private JTextField myTextFieldInLongitude = new JTextField();
    private JTextField myTextFieldOutLatitude = new JTextField();
    private JTextField myTextFieldOutLongitude = new JTextField();
    private JButton myButtonConvert = new JButton("Convert");
    /** Allow the user to test the transform on a few coordinates if they happen to have them */
    private JPanel getTestPanel(){
        JPanel tempPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.weightx = 0;
        c.fill = GridBagConstraints.BOTH;
        
        // The Input Coordinates
        c.gridx = 0;
        c.gridy = 0;
        tempPanel.add(new JLabel("Input Latitude"), c);
        c.gridx++;
        c.weightx = 1;
        tempPanel.add(myTextFieldInLatitude, c);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy++;
        tempPanel.add(new JLabel("Input Longitude"), c);
        c.gridx++;
        tempPanel.add(myTextFieldInLongitude, c);
        
        //The Button to convert
        c.gridx = 0;
        c.gridy++;
        tempPanel.add(myButtonConvert, c);
        
        
        // The Output Coordinates
        c.gridx = 0;
        c.gridy++;
        tempPanel.add(new JLabel("Output Latitude"), c);
        c.gridx++;
        c.weightx = 1;
        tempPanel.add(myTextFieldOutLatitude, c);
        myTextFieldOutLatitude.setEditable(false);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy++;
        tempPanel.add(new JLabel("Output Longitude"), c);
        c.gridx++;
        tempPanel.add(myTextFieldOutLongitude, c);
        myTextFieldOutLongitude.setEditable(false);
        
        
        // The Space Panel
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        tempPanel.add(new JPanel(), c);
        
        // add ActionListener
        myButtonConvert.addActionListener(this);
        return tempPanel;
    }
    
    /** Retrieve the conversion */
    private Converter getConversion()throws Exception{
        // retrieve the first Projection
        Projection tempFromProjection = new NoProjection();
        if (myCurrentFromComponent instanceof ProjectionPanel){
            tempFromProjection = (Projection) ((ProjectionPanel) myCurrentFromComponent).getProjection();
        }
        System.out.println("From Projection = "+tempFromProjection);
        // set up the translation
        Projection tempToProjection = new NoProjection();
        if (myCurrentToComponent instanceof ProjectionPanel){
            tempToProjection = (Projection) ((ProjectionPanel) myCurrentToComponent).getProjection();
        }
        EllipsoidTransform tempTransform = new NoTransform();
        if (myCurrentTransformComponent instanceof TransformEditPanel){
            tempTransform = (EllipsoidTransform) ((TransformEditPanel) myCurrentTransformComponent).getTransform();
        }
        System.out.println("Transform = "+tempTransform);
        
        if (tempFromProjection instanceof EllipsoidProjection){
            tempTransform.setFromEllipsoid( ((EllipsoidProjection) tempFromProjection).getEllipsoid());
            System.out.println("From Ellipsoid = "+tempTransform.getFromEllipsoid());
        }
        if (tempToProjection instanceof EllipsoidProjection){
            tempTransform.setToEllipsoid( ((EllipsoidProjection) tempToProjection).getEllipsoid());
            System.out.println("To Ellipsoid = "+tempTransform.getToEllipsoid());
        }
        System.out.println("To Projeciton = "+tempToProjection);
        Converter tempConversion = new Converter();
        tempConversion.myFromProjection = tempFromProjection;
        tempConversion.myToProjection = tempToProjection;
        tempConversion.myTransform = tempTransform;
        return tempConversion;
    }
    
    /** Convert the coordinates from the input parameters to the coordinates in the output parameters */
    private void convert(){
        try{
            double tempLatitude = Double.parseDouble(myTextFieldInLatitude.getText());
            double tempLongitude = Double.parseDouble(myTextFieldInLongitude.getText());
            gistoolkit.features.Point tempPoint = new gistoolkit.features.Point (tempLongitude, tempLatitude);
            
            Converter tempConverter = getConversion();
            tempConverter.forward(tempPoint);
            
            myTextFieldOutLatitude.setText(""+tempPoint.getY());
            myTextFieldOutLongitude.setText(""+tempPoint.getX());
        }
        catch (Exception e){
            System.out.println(e);
        }
        
    }
    
    private Component myCurrentFromComponent;
    private Component myCurrentToComponent;
    private Component myCurrentTransformComponent;
    
    /** Respond to events from the combo box */
    public void itemStateChanged(java.awt.event.ItemEvent p1) {
        if ((p1 == null)||(p1.getSource() == myComboFromProjections)){
            Projection tempFromProjection = (Projection) myComboFromProjections.getSelectedItem();
            if (myCurrentFromComponent != null) myFromPanel.remove(myCurrentFromComponent);
            if (tempFromProjection instanceof EditableProjection){
                myCurrentFromComponent = ((EditableProjection) tempFromProjection).getEditPanel();
            }
            else{
                myCurrentFromComponent = new JLabel("Projection Not Editable");
            }
            myFromPanel.add( myCurrentFromComponent, BorderLayout.NORTH);
        }
        if ((p1==null)||(p1.getSource() == myComboToProjections)){
            Projection tempToProjection = (Projection) myComboToProjections.getSelectedItem();
            if (myCurrentToComponent != null) myToPanel.remove(myCurrentToComponent);
            if (tempToProjection instanceof EditableProjection){
                myCurrentToComponent = ((EditableProjection) tempToProjection).getEditPanel();
            }
            else{
                myCurrentToComponent = new JLabel("Projection Not Editable");
            }
            myToPanel.add( myCurrentToComponent, BorderLayout.NORTH);
        }
        if ((p1 == null) || (p1.getSource() == myComboTransforms)){
            EllipsoidTransform tempTransform = (EllipsoidTransform) myComboTransforms.getSelectedItem();
            if (myCurrentTransformComponent != null) myTransformPanel.remove (myCurrentTransformComponent);
            TransformEditPanel tempPanel = tempTransform.getEditPanel();
            if (tempPanel != null){
                myCurrentTransformComponent = tempPanel;
            }
            else{
                myCurrentTransformComponent = new JLabel("Transform Not Editable");
            }
            myTransformPanel.add(myCurrentTransformComponent, BorderLayout.NORTH);
        }
        validate();
        
        // ensure that the conversion can be performed and proceed.
    }
    
    /** Check the ellipsoids and attempt to find a translation */
    private void guessTransform(){
        boolean tempTransformFound = false;
        Ellipsoid tempFromEllipsoid = null;
        if (myCurrentFromComponent instanceof ProjectionPanel){
            Projection tempFromProjection = (Projection) ((ProjectionPanel) myCurrentFromComponent).getProjection();
            if (tempFromProjection instanceof EllipsoidProjection){
                tempFromEllipsoid = ((EllipsoidProjection) tempFromProjection).getEllipsoid();
            }
        }
        
        Ellipsoid tempToEllipsoid = null;
        if (myCurrentToComponent instanceof ProjectionPanel){
            Projection tempToProjection = (Projection) ((ProjectionPanel) myCurrentToComponent).getProjection();
            if (tempToProjection instanceof EllipsoidProjection){
                tempToEllipsoid = ((EllipsoidProjection) tempToProjection).getEllipsoid();
            }
        }
        if ((tempFromEllipsoid != null) && (tempToEllipsoid != null)){
            EllipsoidTransform tempTransform = myTransformFactory.getTransform(tempFromEllipsoid, tempToEllipsoid);
            if (tempTransform != null){
                boolean tempFound = false;
                for (int i=0; i<myComboTransforms.getItemCount(); i++){
                    EllipsoidTransform tempComboTransform = (EllipsoidTransform) myComboTransforms.getItemAt(i);
                    if (tempComboTransform.toString().equalsIgnoreCase(tempTransform.toString())){
                        myComboTransforms.setSelectedIndex(i);
                        tempFound = true;
                        break;
                    }
                }
                if (!tempFound){
                    myComboTransforms.addItem(tempTransform);
                    myComboTransforms.setSelectedItem(tempTransform);
                }
                if (myCurrentTransformComponent != null) myTransformPanel.remove (myCurrentTransformComponent);
                TransformEditPanel tempPanel = tempTransform.getEditPanel();
                if (tempPanel != null){
                    myCurrentTransformComponent = tempPanel;
                }
                else{
                    myCurrentTransformComponent = new JLabel("Transform Not Editable");
                }
                myTransformPanel.add(myCurrentTransformComponent, BorderLayout.NORTH);
                myLabelTransform.setText("Best Guess");
                tempTransformFound = true;
                validate();
            }
        }
        if (!tempTransformFound) myLabelTransform.setText("I have no idea");
    }
    
    private JFileChooser myChooser = null;
    public void actionPerformed(java.awt.event.ActionEvent p1) {
        super.actionPerformed(p1);
        if (myChooser == null){
            myChooser = new JFileChooser();
        }
        if (p1.getSource() == myButtonFromBrowse){
            String tempString = myTextFieldFromFile.getText();
            if ((tempString != null) && (tempString.length() >0)){
                File tempFile = new File(tempString);
                if (tempFile.exists()){
                    if (tempFile.isDirectory()){
                        myChooser.setCurrentDirectory(tempFile);
                    }
                    if (tempFile.isFile()){
                        myChooser.setSelectedFile(tempFile);
                    }
                }
            }
            
            int returnVal = myChooser.showOpenDialog(this);
            if(returnVal == JFileChooser.APPROVE_OPTION) {
                myTextFieldFromFile.setText(myChooser.getSelectedFile().getAbsolutePath());
            }
        }
        if (p1.getSource() == myButtonToBrowse){
            String tempString = myTextFieldToFile.getText();
            if ((tempString != null) && (tempString.length() >0)){
                File tempFile = new File(tempString);
                if (tempFile.exists()){
                    if (tempFile.isDirectory()){
                        myChooser.setCurrentDirectory(tempFile);
                    }
                    if (tempFile.isFile()){
                        myChooser.setSelectedFile(tempFile);
                    }
                }
            }
            
            int returnVal = myChooser.showOpenDialog(this);
            if(returnVal == JFileChooser.APPROVE_OPTION) {
                myTextFieldToFile.setText(myChooser.getSelectedFile().getAbsolutePath());
            }
        }
        if (p1.getSource() == myButtonGuessTransform){
            this.guessTransform();
        }
        if (p1.getSource() == myButtonConvert){
            this.convert();
        }
    }
    
    protected boolean doOK(){
        try{
            // read the shape file
            File tempFromFile = new File(myTextFieldFromFile.getText());
            if (!tempFromFile.exists()){
                throw new Exception("From File "+tempFromFile.getAbsolutePath()+" does not exist");
            }
            
            ShapeFile tempShapeFile = new ShapeFile(tempFromFile.getAbsolutePath());
            System.out.println("Reading");
            tempShapeFile.readRecords();
            ShapeFileRecord[] tempRecords = tempShapeFile.getRecords();
            
            // get the converter
            Converter tempConverter = getConversion();
            
            
            // Convert the records
            for (int i=0; i<tempRecords.length; i++){
                gistoolkit.features.Shape tempShape = tempRecords[i].getShape();
                gistoolkit.features.Point[] tempPoints = tempShape.getPoints();
                System.out.println("Shape "+i+" Points "+tempPoints.length);
                for (int j=0; j<tempPoints.length; j++){
                    tempConverter.forward(tempPoints[j]);
                }
            }
            
            // write the shape file.
            tempShapeFile.setFile(myTextFieldToFile.getText());
            tempShapeFile.setRecords(tempRecords);
            tempShapeFile.writeRecords();
            return true;
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error Projecting", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
    
    private class Converter {
        Projection myFromProjection = null;
        EllipsoidTransform myTransform = null;
        Projection myToProjection = null;
        
        public void forward(gistoolkit.features.Point inPoint) throws Exception{
            if (myFromProjection != null) myFromProjection.projectBackward(inPoint);
            if (myTransform != null) myTransform.forward(inPoint);
            if (myToProjection != null) myToProjection.projectForward(inPoint);
        }
    }
}
