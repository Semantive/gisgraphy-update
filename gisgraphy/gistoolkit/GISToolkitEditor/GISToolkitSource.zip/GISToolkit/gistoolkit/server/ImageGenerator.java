/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import gistoolkit.display.*;
import gistoolkit.features.*;
/**
 * Class to generate an image from the layer definitions, and a real world Envelope.
 * @author  ithaqua
 */
public class ImageGenerator extends Object {
    /** Holds a reference to the image */
    private BufferedImage myImage = null;
    
    /** The layers to draw to the image */
    private Vector myLayers = new Vector();
    
    /** The width in pixels that the image should be */
    private int myWidth = 255;
    
    /** the hight in pixels that the image should be */
    private int myHeight = 255;
    
    /** Creates new ImageGenerator */
    public ImageGenerator(String inLayersFile) throws Exception{
        initGenerator(inLayersFile);
    }
    
    /**
     * Method to initialize the layers and renderers and other objects in the
     * image generator.  The file sent in is a layer file, containing the list
     * of layer configuration files.
     */
    private void initGenerator(String inLayersFile) throws Exception{
        
        // read the file containing the layers
        File tempFile = new File(inLayersFile);
        if (!tempFile.exists()){
            throw new Exception("Can not find LayersFile "+inLayersFile);
        }
        FileReader fread = new FileReader(tempFile);
        BufferedReader bread = new BufferedReader(fread);
        Vector tempVectLayerFiles = new Vector();
        String tempLine = bread.readLine();
        while(tempLine != null){
            tempFile = new File(tempLine);
            if (!tempFile.exists()) {
                // attempt to find it in the same place as the layers file
                String tempFileString = inLayersFile;
                int i=0;
                for (i = inLayersFile.length()-1; i>0; i--){
                    if (tempFileString.charAt(i) == File.separatorChar){
                        tempFileString = inLayersFile.substring(0,i);
                        break;
                    }
                }
                tempFile = new File(tempFileString + File.separatorChar + tempLine);
                if (!tempFile.exists())
                    throw new Exception("Layer Definition "+tempLine+" Does not exist");
            }
            tempVectLayerFiles.addElement(tempFile.getAbsolutePath());
            tempLine = bread.readLine();
        }
        
        // load the layers.
        for (int i=0; i<tempVectLayerFiles.size(); i++){
            Properties tempProperties = new Properties();
            tempProperties.load(new FileInputStream((String) tempVectLayerFiles.elementAt(i)));
            Layer tempLayer = new Layer();
            myLayers.addElement(tempLayer);
        }
    }
    
    /**
     * Draw the map to an immage and return the image.
     */
    public BufferedImage drawImage(Converter inConverter){
        Envelope tempScreenEnvelope = inConverter.getScreenEnvelope();
        if ((myImage == null)||
            ((myImage.getHeight() != tempScreenEnvelope.getHeight())||
            (myImage.getWidth() != tempScreenEnvelope.getWidth()))){
                myWidth = (int) Math.abs(tempScreenEnvelope.getWidth());
                myHeight = (int) Math.abs(tempScreenEnvelope.getHeight());
                myImage = new BufferedImage(myWidth, myHeight ,BufferedImage.TYPE_INT_ARGB);
        }
        Graphics g = myImage.getGraphics();
        g.setColor(Color.white);
        g.fillRect(0,0,myImage.getWidth(), myImage.getHeight());

        for (int i=0; i<myLayers.size(); i++){
            Layer tempLayer = (Layer) myLayers.elementAt(i);
            tempLayer.drawLayer(myImage.getGraphics(), inConverter);
        }
        for (int i=0; i<myLayers.size(); i++){
            Layer tempLayer = (Layer) myLayers.elementAt(i);
            tempLayer.labelLayer(myImage.getGraphics(), inConverter);
        }
        return myImage;
    }
    
    /**
     * Retrieve a layer by name. Returns the layer with the given name, if there
     * are duplicates, it will return the first one.  If this layer does not exist
     * then it will return null.
     */
    public Layer getLayer(String inLayerName){
        if (inLayerName == null) return null;
        if (myLayers == null) return null;
        for (int i=0; i<myLayers.size(); i++){
            Layer tempLayer = (Layer) myLayers.elementAt(i);
            if (tempLayer.getLayerName().equals(inLayerName)){
                return tempLayer;
            }
        }
        return null;
    }
}
