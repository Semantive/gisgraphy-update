/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server;

import java.util.*;
import java.awt.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.filter.*;
import gistoolkit.projection.*;
/**
 * Class to handle all of the service related information.  
 */
public class Service extends Object {
    /** Provides the ability to find this server amungst a forest of thousands. */
    private String myServiceName = "TEST";
    /** Set the name of the service. */
    public void setServiceName(String inServiceName){myServiceName = inServiceName;}
    /** Get the name of the service. */
    public String getServiceName(){return myServiceName;}
    
    /** Provides a nice title to allow people to identify this service. */
    private String myServiceTitle = "Default Service Title.";
    /** Set the Title of the service. */
    public void setServiceTitle(String inServiceTitle){myServiceTitle = inServiceTitle;}
    /** Get the Title of the service. */
    public String getServiceTitle(){return myServiceTitle;}

    /** Provides a URL link to the outside world to provide a web site for more description of this service.*/
    private String myServiceLink = "Default Service Title.";
    /** Set the Link to be used to get more information about this service. */
    public void setServiceLink(String inServiceLink){myServiceLink = inServiceLink;}
    /** Gets the Link to be used to get more information about this service. */
    public String getServiceLink(){return myServiceLink;}

    /** The spatial reference system for this layer. */
    private String mySRS = "EPSG:4326"; //WGS84 Lat/lon
    /** Set the spatial reference string for this layer. */
    public void setSRS(String inSRS){
        if (inSRS != null){
            if (inSRS.toUpperCase().startsWith("AUTO")){
                mySRSAuto = true;
            }
            else mySRSAuto = false;
        }
        mySRS = inSRS;
    }
    /** Return the Spatial Reference String for this service. */
    public String getSRS(){return mySRS;}
    
    /** Determines if the SRS is AUTO or not. */
    private boolean mySRSAuto = false;
    
    /** The projection to use with this service. */
    private Projection myProjection = new NoProjection();
    /** Set the projection to use with this layer. */
    public void setProjection(Projection inProjection) throws Exception{
        myProjection = inProjection;
        for (int i=0; i<myLayerDefinitions.size(); i++){
            ((LayerDefinition) myLayerDefinitions.get(i)).setProjection(inProjection);
        }
    }
    /** Get the projection to use with this layer. */
    public Projection getProjection(){return myProjection;}
    
    /** The Scale Bar to use with this layer. */
    private ScaleBar myScaleBar = new gistoolkit.display.scalebar.MeterToMetricScaleBar();
    /** set the scale bar to use with this layer. */
    public void setScaleBar(ScaleBar inScaleBar){myScaleBar = inScaleBar;}
    /** get the scale bar to use with this layer. */
    public ScaleBar getScaleBar(){return myScaleBar;}
    
    /** Stores the layers associated with this layer. */
    private Vector myLayerDefinitions = new Vector();
    /** Add a layer Definition to this service. */
    public void addLayerDefinition(LayerDefinition inLayerDefinition) throws Exception{
        if (inLayerDefinition != null){
            inLayerDefinition.setProjection(myProjection);
        }
        myLayerDefinitions.addElement(inLayerDefinition);
    }
    /**Remove a layer Definition from this service. */
    public void removeLayerDefinition(LayerDefinition inLayerDefinition){myLayerDefinitions.remove(inLayerDefinition);}
    /** Return the complete list of layer definitions for this service. */
    public LayerDefinition[] getLayerDefinitions(){
        LayerDefinition[] tempDefinitions = new LayerDefinition[myLayerDefinitions.size()];
        myLayerDefinitions.toArray(tempDefinitions);
        return tempDefinitions;
    }
    /** Return the layer definition with the requested name.*/
    public LayerDefinition getLayerDefinition(String inLayerDefinitionName){
        for (int i=0; i<myLayerDefinitions.size(); i++){
            LayerDefinition tempDefinition = (LayerDefinition) myLayerDefinitions.elementAt(i);
            if (tempDefinition.getLayerName().equalsIgnoreCase(inLayerDefinitionName)){
                return tempDefinition;
            }
        }
        return null;
    }
    

    /** Creates new Server */
    public Service() {
    }
    
    // constants for accessing the layer information.
    private static final String SERVICE_NAME = "ServiceName";
    private static final String SERVICE_TITLE = "ServiceTitle";
    private static final String SERVICE_LINK = "ServiceLink";
    private static final String NODE_LAYER_DEFINITION = "LayerDefinition";
    private static final String LAYER_NAME="LayerName";
    private static final String LAYER_TITLE="LayerTitle";
    private static final String MAX_DISPLAY_DISTANCE = "MaxDisplayDistance";
    private static final String MIN_DISPLAY_DISTANCE = "MinDisplayDistance";
    private static final String MAX_LABEL_DISTANCE = "MaxLabelDistance";
    private static final String MIN_LABEL_DISTANCE = "MinLabelDistance";
    private static final String LATLON_BOUNDINGBOX = "LatLonBoundingBox";
    private static final String LATLON_MAXX = "LatLonMaxX";
    private static final String LATLON_MINX = "LatLonMaxY";
    private static final String LATLON_MAXY = "LatLonMinX";
    private static final String LATLON_MINY = "LatLonMinY";
    private static final String DATA_SOURCE_CLASS = "DataSourceClass";
    private static final String NODE_DATASOURCE="DataSourceInformation";
    private static final String NODE_STYLE = "StyleInformation";
    private static final String STYLE_CLASS = "StyleClass";
    private static final String SERVICE_SRS = "SRSName";
    private static final String PROJECTION_CLASS = "ProjectionClass";
    private static final String NODE_PROJECTION = "Projection";
    private static final String SCALEBAR_CLASS = "ScaleBarClass";
    private static final String NODE_SCALEBAR = "ScaleBar";
    
    /** Set the configuration node. */
    public Node getNode() throws Exception{
        Node tempNode = new Node(Server.SERVICE_TAG);
        
        // set the name of this service.
        tempNode.addAttribute(SERVICE_NAME, getServiceName());
        tempNode.addAttribute(SERVICE_TITLE, getServiceTitle());
        tempNode.addAttribute(SERVICE_LINK, getServiceLink());
        tempNode.addAttribute(SERVICE_SRS, getSRS());
        
        // get the projection.
        Node tempProjectionNode = new Node(NODE_PROJECTION);
        tempProjectionNode.addAttribute(PROJECTION_CLASS, myProjection.getClass().getName());
        tempProjectionNode.addChild(myProjection.getNode());
        tempNode.addChild(tempProjectionNode);
        
        // get the scale bar
        if (myScaleBar != null){
            Node tempScaleBarNode = new Node(NODE_SCALEBAR);
            tempScaleBarNode.addAttribute(SCALEBAR_CLASS, myScaleBar.getClass().getName());
            tempScaleBarNode.addChild(myScaleBar.getNode());
            tempNode.addChild(tempScaleBarNode);
        }
        
        // find the layers to add to the map.
        for (int i=0; i<myLayerDefinitions.size(); i++){
            // set up the layer definition.
            Node tempLayerNode = new Node(NODE_LAYER_DEFINITION);
            tempNode.addChild(tempLayerNode);
            LayerDefinition tempDefinition = (LayerDefinition) myLayerDefinitions.elementAt(i);            
            tempLayerNode.addAttribute(LAYER_NAME, tempDefinition.getLayerName());
            tempLayerNode.addAttribute(LAYER_TITLE, tempDefinition.getLayerTitle());
            
            // read the available distances for the layers.
            tempLayerNode.addAttribute(MAX_DISPLAY_DISTANCE, ""+tempDefinition.getMaxDisplayDistance());
            tempLayerNode.addAttribute(MIN_DISPLAY_DISTANCE, ""+tempDefinition.getMinDisplayDistance());
            tempLayerNode.addAttribute(MAX_LABEL_DISTANCE, ""+tempDefinition.getMaxLabelDistance());
            tempLayerNode.addAttribute(MIN_LABEL_DISTANCE, ""+tempDefinition.getMinLabelDistance());
            
            // read the Data Source.
            Node tempDataSourceNode = new Node(NODE_DATASOURCE);
            tempLayerNode.addChild(tempDataSourceNode);
            tempDataSourceNode.addAttribute(DATA_SOURCE_CLASS, tempDefinition.getDataSource().getClass().getName());
            tempDataSourceNode.addChild(tempDefinition.getDataSource().getNode());
            
            // read the latLonBoundingBox
            Node tempLatLonNode = new Node(LATLON_BOUNDINGBOX);
            tempLayerNode.addChild(tempLatLonNode);
            Envelope tempLatLonEnvelope = tempDefinition.getLatLonEnvelope();
            if (tempLatLonEnvelope != null){
                tempLatLonNode.addAttribute(LATLON_MAXX, ""+tempLatLonEnvelope.getMaxX());
                tempLatLonNode.addAttribute(LATLON_MAXY, ""+tempLatLonEnvelope.getMaxY());
                tempLatLonNode.addAttribute(LATLON_MINX, ""+tempLatLonEnvelope.getMinX());
                tempLatLonNode.addAttribute(LATLON_MINY, ""+tempLatLonEnvelope.getMinY());
            }
            
            // read all the style information
            Style[] tempStyles = tempDefinition.getStyles();
            for (int j=0; j<tempStyles.length; j++){
                Node tempStyleNode = new Node(NODE_STYLE);
                tempLayerNode.addChild(tempStyleNode);
                // read the Style information
                tempStyleNode.addAttribute(STYLE_CLASS, tempStyles[j].getClass().getName());
                tempStyleNode.addChild(tempStyles[j].getNode());
            }            
        }   
        return tempNode;
    }    

    /** Set the configuration node. */
    public void setNode(Node inNode) throws Exception{
        // set the name of this service.
        setServiceName(inNode.getAttribute(SERVICE_NAME));
        setServiceTitle(inNode.getAttribute(SERVICE_TITLE));
        setServiceLink(inNode.getAttribute(SERVICE_LINK));
        setSRS(inNode.getAttribute(SERVICE_SRS));
        
        // set the projection.
        myProjection = new NoProjection();
        Node tempProjectionNode = inNode.getChild(NODE_PROJECTION);
        if (tempProjectionNode != null){
            String tempProjectionClass = (String) tempProjectionNode.getAttribute(PROJECTION_CLASS);
            if (tempProjectionClass != null){
                try{
                    myProjection = (Projection) Class.forName(tempProjectionClass).newInstance();
                    Node[] tempNodes = tempProjectionNode.getChildren();
                    if (tempNodes.length > 0) myProjection.setNode(tempNodes[0]);
                    setProjection(myProjection);
                }
                catch (Exception e){
                    myProjection = new NoProjection();
                }
            }
        }
        
        // set the scalebar.
        Node tempScaleBarNode = inNode.getChild(NODE_SCALEBAR);
        if (tempScaleBarNode != null){
            String tempScaleBarClass = (String) tempScaleBarNode.getAttribute(SCALEBAR_CLASS);
            if (tempScaleBarClass != null){
                try{
                    ScaleBar tempScaleBar = (ScaleBar) Class.forName(tempScaleBarClass).newInstance();
                    Node[] tempNodes = tempScaleBarNode.getChildren();
                    if (tempNodes.length > 0) tempScaleBar.setNode(tempNodes[0]);
                    setScaleBar(tempScaleBar);
                }
                catch (Exception e){
                    System.out.println("Error reading Scalebar Configuration "+e);
                }
            }
        }

        // find the layers to add to the map.
        Node[] tempLayerNodes = inNode.getChildren(NODE_LAYER_DEFINITION);
        if ((tempLayerNodes == null)||(tempLayerNodes.length == 0)) throw new Exception("No layers specified in configuration file.");
        
        for (int i=0; i<tempLayerNodes.length; i++){
            String tempLayerName = tempLayerNodes[i].getAttribute(LAYER_NAME);
            LayerDefinition tempDefinition = new LayerDefinition(tempLayerName);
            tempDefinition.setLayerTitle(tempLayerNodes[i].getAttribute(LAYER_TITLE));
            
            // read the available distances for the layers.
            String tempMaxDisplayDistance = tempLayerNodes[i].getAttribute(MAX_DISPLAY_DISTANCE);
            String tempMinDisplayDistance = tempLayerNodes[i].getAttribute(MIN_DISPLAY_DISTANCE);
            String tempMaxLabelDistance = tempLayerNodes[i].getAttribute(MAX_LABEL_DISTANCE);
            String tempMinLabelDistance = tempLayerNodes[i].getAttribute(MIN_LABEL_DISTANCE);
            
            try{tempDefinition.setMaxDisplayDistance(Double.parseDouble(tempMaxDisplayDistance));}catch(Exception e){};
            try{tempDefinition.setMinDisplayDistance(Double.parseDouble(tempMinDisplayDistance));}catch(Exception e){};
            try{tempDefinition.setMaxLabelDistance(Double.parseDouble(tempMaxLabelDistance));}catch(Exception e){};
            try{tempDefinition.setMinLabelDistance(Double.parseDouble(tempMinLabelDistance));}catch(Exception e){};

            // read the Data Source.
            Node tempDataSourceNode = tempLayerNodes[i].getChild(NODE_DATASOURCE);
            if (tempDataSourceNode == null) throw new Exception("DataSource Configuration information is null");
            String tempString = tempDataSourceNode.getAttribute(DATA_SOURCE_CLASS);
            if (tempString == null) throw new Exception("DataSource class name is null");
            DataSource tempDataSource = (DataSource) Class.forName(tempString).newInstance();
            Node[] tempNodes = tempDataSourceNode.getChildren();
            if (tempNodes.length > 0) tempDataSource.setNode(tempNodes[0]);
            tempDefinition.setDataSource(tempDataSource);
            
            // read the latLonBoundingBox
            Node tempLatLonNode = tempLayerNodes[i].getChild(LATLON_BOUNDINGBOX);
            if (tempLatLonNode != null){
                String tempLatLonMaxX = tempLatLonNode.getAttribute(LATLON_MAXX);
                String tempLatLonMaxY = tempLatLonNode.getAttribute(LATLON_MAXY);
                String tempLatLonMinX = tempLatLonNode.getAttribute(LATLON_MINX);
                String tempLatLonMinY = tempLatLonNode.getAttribute(LATLON_MINY);
                double tempMaxX = 0;
                double tempMaxY = 0;
                double tempMinX = 0;
                double tempMinY = 0;
                try{tempMaxX = Double.parseDouble(tempLatLonMaxX);}catch(Exception e){throw new Exception("Error parsing LatLonBoundingBox "+LATLON_MAXX+" For Layer "+tempLayerName);}
                try{tempMaxY = Double.parseDouble(tempLatLonMinX);}catch(Exception e){throw new Exception("Error parsing LatLonBoundingBox "+LATLON_MAXY+" For Layer "+tempLayerName);}
                try{tempMinX = Double.parseDouble(tempLatLonMaxY);}catch(Exception e){throw new Exception("Error parsing LatLonBoundingBox "+LATLON_MINX+" For Layer "+tempLayerName);}
                try{tempMinY = Double.parseDouble(tempLatLonMinY);}catch(Exception e){throw new Exception("Error parsing LatLonBoundingBox "+LATLON_MINY+" For Layer "+tempLayerName);}
                tempDefinition.setLatLonEnvelope(new Envelope(tempMinX, tempMinY, tempMaxX, tempMaxY));
            }
            // try to get the bounding box from the data source.
            else{
                Envelope tempEnvelope = tempDataSource.getEnvelope();
                if (tempEnvelope == null) throw new Exception("Error reading Envelope, no "+LATLON_BOUNDINGBOX+" Specified, and Datasource not provided Service="+getServiceName()+" Layer="+tempDefinition.getLayerName());
                tempDefinition.setLatLonEnvelope(tempEnvelope);
            }
            
            // read all the style information
            Node[] tempStyles = tempLayerNodes[i].getChildren(NODE_STYLE);
            for (int j=0; j<tempStyles.length; j++){
                // read the Style information
                Node tempStyleNode = tempStyles[j];
                if (tempStyleNode == null) throw new Exception("Style configuration information is null");
                tempString = tempStyleNode.getAttribute(STYLE_CLASS);
                if (tempString == null) throw new Exception("Style class name is null");
                Style tempStyle = (Style) Class.forName(tempString).newInstance();
                tempNodes = tempStyleNode.getChildren();
                if (tempNodes.length > 0) tempStyle.setNode(tempNodes[0]);
                tempDefinition.addStyle(tempStyle);
            }
            
            // add the layerdefinition as a layer to this service.
            addLayerDefinition(tempDefinition);
        }   
    }    
    
    /** Generates an image given the description parameters. */
    public synchronized java.awt.image.BufferedImage generateImage(MapRequest inMapRequest) throws Exception{
        
        // get the width and height.
        if (inMapRequest.getWidth() < 1) throw new Exception("Width < 1");
        // get the height.
        if (inMapRequest.getHeight() < 1) throw new Exception("Height < 1");
        
        // construct the converter.
        Converter tempConverter = new Converter(
            // image Envelope
            new Envelope(0,0,inMapRequest.getWidth(), inMapRequest.getHeight()),
            // map Envelope
            new Envelope(inMapRequest.getMinX(), inMapRequest.getMaxY(), inMapRequest.getMaxX(), inMapRequest.getMinY()),
            // may not be a square.
            false
        );
        
        // create the map image.
        java.awt.image.BufferedImage tempMapImage = new java.awt.image.BufferedImage(inMapRequest.getWidth(), inMapRequest.getHeight() ,java.awt.image.BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics tempMapGraphics = tempMapImage.getGraphics();
        
        // create the Label Image
        java.awt.image.BufferedImage tempLabelImage = new java.awt.image.BufferedImage(inMapRequest.getWidth(), inMapRequest.getHeight() ,java.awt.image.BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics tempLabelGraphics = tempLabelImage.getGraphics();
        tempLabelGraphics.setColor(new java.awt.Color(0,0,0,0)); //transparent color over black.
        tempLabelGraphics.fillRect(0,0,inMapRequest.getWidth(), inMapRequest.getHeight());
        
        
        // if the background is transparent, then draw a transparent background.
        if (inMapRequest.getTransparent()){
            tempMapGraphics.setColor(new java.awt.Color(0,0,0,0)); //transparent color.
            tempMapGraphics.fillRect(0,0,inMapRequest.getWidth(), inMapRequest.getHeight());
        }
        else{
            // draw the background color.
            tempMapGraphics.setColor(inMapRequest.getBackgroundColor());
            tempMapGraphics.fillRect(0,0,inMapRequest.getWidth(), inMapRequest.getHeight());
        }
        
        // generate the projection.
        Projection tempProjection = (Projection) getProjection().clone();
        if (inMapRequest.isSRSAuto()){
            if (tempProjection instanceof SimpleProjection){
                ((SimpleProjection) tempProjection).setLatOragin(inMapRequest.getSRSLatitude());
                ((SimpleProjection) tempProjection).setLonOragin(inMapRequest.getSRSLongitude());
            }
        }
        
        // find the filters
        FilterInfo[] tempFilters = inMapRequest.getFilters();
        
        // draw the requested layers on the map.
        String[] tempLayers = inMapRequest.getLayers();
        String[] tempStyles = inMapRequest.getStyles();            
        StringBuffer sb = new StringBuffer();
        sb.append(new Date());
        sb.append(" Generating Map with Layers\n");
        for(int i=0; i<tempLayers.length; i++){
            sb.append(tempLayers[i]);
            if(tempStyles.length > i) {sb.append(","); sb.append(tempStyles[i]);}
            sb.append("\n");
        }
        System.out.println(sb.toString());
        if (tempLayers != null){
            // draw the requested layers on the map.
            for (int i=0; i<tempLayers.length; i++){
                String tempStyle = null;
                if (tempStyles.length > i) tempStyle = tempStyles[i];
                Layer tempLayer = getLayer(tempLayers[i], tempStyle);
                if (tempLayer != null){
                    long tempbTime = new Date().getTime();
                    long tempsTime = 0;
                    synchronized (tempLayer){
                        tempsTime = new Date().getTime();
                        tempLayer.setProjection(tempProjection, false);
                        setFilter(tempFilters, tempLayer);
                        tempLayer.drawLayer(tempMapImage.getGraphics(), tempConverter);
                        tempLayer.labelLayer(tempLabelImage.getGraphics(), tempConverter);
                    }
                    long tempftime = new Date().getTime();
                    System.out.println(tempLayers[i] + "Wait="+(tempbTime-tempsTime)+" Draw="+(tempftime-tempsTime));
                }
            }
        }
        
        // draw the label layer on top of the map layer
        ((Graphics2D) tempMapGraphics).drawImage(tempLabelImage, null, 0, 0);
        
        // draw the legend on the map
        try{
            if (myScaleBar != null) myScaleBar.drawScale(tempMapImage.getGraphics(), tempConverter, inMapRequest.getWidth()/2, inMapRequest.getHeight());
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return tempMapImage;
    }
    
    /** set the filter information for the layer. */
    public static void setFilter(FilterInfo[] inFilters, Layer inLayer){
        if (inFilters == null) return;
        if (inLayer == null) return;
        String tempLayerName = inLayer.getLayerName();
        for (int i=0; i<inFilters.length; i++){
            if (inFilters[i].getLayerName().equalsIgnoreCase(tempLayerName)){
                System.out.println("Found Filter "+inFilters[i].getFilterName()+" For Layer "+tempLayerName+" Value="+inFilters[i].getFilterValue());
                Filter tempFilter = inLayer.getFilter();
                setFilter(tempFilter, inFilters[i].getFilterName(), inFilters[i].getFilterValue());
                inLayer.setFilter(inLayer.getFilter());
            }
        }
    }
    /** Recursive function to set the filter information in the tree. */
    private static void setFilter(Filter inFilter, String inFilterName, String inFilterValue){
        if (inFilter instanceof Join){
            Join tempExpression = (Join) inFilter;
            setFilter(tempExpression.getFilter1(), inFilterName, inFilterValue);
            setFilter(tempExpression.getFilter2(), inFilterName, inFilterValue);
        }
        else if (inFilter instanceof AttributeFilter){
            if (inFilter.getFilterName().equals(inFilterName)){
                ((AttributeFilter) inFilter).setValue(inFilterValue);
            }
        }
    }
    
    /** Return the records identified by this map request. */
    public Record[] getRecords(MapRequest inMapRequest) throws Exception{
        
        // get the width and height.
        if (inMapRequest.getWidth() < 1) throw new Exception("Width < 1");
        // get the height.
        if (inMapRequest.getHeight() < 1) throw new Exception("Height < 1");
        
        // construct the converter.
        Converter tempConverter = new Converter(
            // image Envelope
            new Envelope(0,0,inMapRequest.getWidth(), inMapRequest.getHeight()),
            // map Envelope
            new Envelope(inMapRequest.getMinX(), inMapRequest.getMaxY(), inMapRequest.getMaxX(), inMapRequest.getMinY()),
            // may not be a square.
            false
        );
    
        // find the point on the map
        gistoolkit.features.Point tempPoint = new gistoolkit.features.Point(tempConverter.toWorldX(inMapRequest.getXPoint()), tempConverter.toWorldY(inMapRequest.getYPoint()));
        
        // query for the Records that intersect the given location
        ArrayList tempRecordList = new ArrayList();
        String[] tempLayers = inMapRequest.getLayers();
        if (tempLayers != null){
            // draw the requested layers on the map.
            for (int i=0; i<tempLayers.length; i++){
                Layer tempLayer = getLayer(tempLayers[i]);
                if (tempLayer != null){
                    DataSource tempDataSource= tempLayer.getDataSource();
                    if(tempDataSource != null){
                        GISDataset tempDataset = tempDataSource.readDataset(tempConverter.getWorldEnvelope());
                        if (tempDataset != null) {
                            for (int j=0; j<tempDataset.size(); j++){
                                Record tempRecord = tempDataset.getRecord(j);
                                if (tempRecord != null){
                                    gistoolkit.features.Shape tempShape = tempRecord.getShape();
                                    if (tempShape != null){
                                        if (tempShape.contains(tempPoint)){
                                            tempRecordList.add(tempRecord);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        Record[] tempRecords = new Record[tempRecordList.size()];
        tempRecordList.toArray(tempRecords);
        return tempRecords;
    }

    /** Convenience function to retrieve a layer. */
    private Layer getLayer(String inName)throws Exception{
        if (inName == null) return null;
        for (int i=0; i<myLayerDefinitions.size(); i++){
            LayerDefinition tempLayerDefinition = (LayerDefinition) myLayerDefinitions.elementAt(i);
            if (inName.equalsIgnoreCase(tempLayerDefinition.getLayerName())){
                return tempLayerDefinition.getLayer();
            }
        }
        return null;
    }    
    
    /** Convenience function to retrieve a layer with the given name, and Style. */
    private Layer getLayer(String inName, String inStyleName) throws Exception{
        if (inName == null) return null;
        for (int i=0; i<myLayerDefinitions.size(); i++){
            LayerDefinition tempLayerDefinition = (LayerDefinition) myLayerDefinitions.elementAt(i);
            if (inName.equalsIgnoreCase(tempLayerDefinition.getLayerName())){
                return tempLayerDefinition.getLayer(inStyleName);
            }
        }
        return null;
    }
}
