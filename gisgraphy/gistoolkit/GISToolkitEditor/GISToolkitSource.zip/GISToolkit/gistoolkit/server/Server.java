/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.server;

import java.util.Vector;
// Node is an abstraction to protect the toolkit from XML Parsers.
import gistoolkit.common.Node;
// The configurator is another place where XML is used.
import gistoolkit.config.Configurator;
import gistoolkit.features.*;
// use the JIMI stuff from sun.
import com.sun.media.jai.codec.*;

/**
 *  Holds the collection of services.
 */
public class Server {
    
    /** ServerHolder fir this server. */
    private ServerHolder myHolder = null;
    
    /** Vector of currently available services.*/
    private Vector myServices = new Vector();
    /** Add a service to the list of currently available services. */
    public void addService(Service inService){if (inService != null) myServices.addElement(inService);}
    /** Remove the service from the list of currently available services. */
    public void removeService(Service inService){myServices.remove(inService);}
    /** Return the set of configured services. */
    public Service[] getServices(){
        Service[] tempServices = new Service[myServices.size()];
        myServices.copyInto(tempServices);
        return tempServices;
    }
    /** Return the service of the given name. */
    public Service getService(String inName){
        if (inName == null) return null;
        for (int i=0; i<myServices.size(); i++){
            Service tempService = (Service) myServices.elementAt(i);
            if (inName.equalsIgnoreCase(tempService.getServiceName())) return tempService;
        }
        return null;
    }
    
    /** Get the hostname. */
    public String getHostName(){return myHolder.getHostName();}
    /** Set the hostname. */
    public void setHostName(String inHostName){myHolder.setHostName(inHostName);}
    
    /** Get the port number. */
    public int getPortNumber(){return myHolder.getPort();}
    /** Set the port number. */
    public void setPortNumber(int inNumber){myHolder.setPort(inNumber);}
    
    /** Creates new Service */
    public Server(ServerHolder inHolder) {
        myHolder = inHolder;
    }
    
    /** Save the configuration of the server. */
    public void saveConfig()throws Exception{
        if (myHolder != null){
            myHolder.saveConfig();
        }
    }
    
    /** Constant used for finding configuration information in the Nodes. */
    public static final String SERVER_TAG = "GISServer";
    public static final String SERVICE_TAG = "Service";
    
    /** Set up the configuration of this server. */
    public void setNode(Node inNode)throws Exception{
        // There may be several services involved in a single server.
        Node[] tempKids = inNode.getChildren(SERVICE_TAG);
        for (int i=0; i<tempKids.length; i++){
            Service tempService = new Service();
            tempService.setNode(tempKids[i]);
            addService(tempService);
        }
    }
    /** Set up the configuration of this server. */
    public Node getNode()throws Exception{
        // There may be several services involved in a single server.
        Node tempNode = new Node(SERVER_TAG);
        for (int i=0; i<myServices.size(); i++){
            tempNode.addChild( ((Service) myServices.elementAt(i)).getNode());
        }
        return tempNode;
    }
    
    /** Read the configuration information. */
    public void init(String inFileName) throws Exception {
        Configurator.readConfig(this, inFileName);
    }
    
    /** Get the Image from the service, and return it as the appropriate value. */
    public byte[] getMap(MapRequest inMapRequest)throws Exception{
        // create the image.
        java.awt.image.BufferedImage tempImage = getMapImage(inMapRequest);
        if (tempImage == null) throw new Exception("Can not generate image with requested parameters.");
        
        // convert the image to the requested type.
        String tempType = inMapRequest.getFormat();
        if (tempType == null) tempType = MapRequest.FORMAT_JPG;
        java.io.ByteArrayOutputStream bout = new java.io.ByteArrayOutputStream();
        if (tempType == MapRequest.FORMAT_JPG) {
            // Store the image in the JPG format.
            JPEGEncodeParam params = new JPEGEncodeParam();
            params.setQuality((float) .99);
            ImageEncoder encoder = ImageCodec.createImageEncoder("JPEG", bout, params);
            if (encoder == null) {
                System.out.println("jpg imageEncoder is null");
            }
            else {
                encoder.encode(tempImage);
            }
            bout.close();
        }
        else if (tempType == MapRequest.FORMAT_PNG){            
            // Store the image in the JPG format.
            ImageEncoder encoder = ImageCodec.createImageEncoder("PNG", bout, null);
            if (encoder == null) {
                System.out.println("png imageEncoder is null");
            }
            else {
                encoder.encode(tempImage);
            }
            bout.close();
        }
        else if (tempType == MapRequest.FORMAT_GIF) {
            // Store the image in the JPG format.
            BMPEncodeParam param = new BMPEncodeParam();
            ImageEncoder encoder = ImageCodec.createImageEncoder("GIF", bout, param);
            if (encoder == null) {
                System.out.println("gif imageEncoder is null");
            }
            else {
                encoder.encode(tempImage);
            }
            bout.close();
        }
        else
            throw new Exception("Unknown File Type for " + tempType);
        bout.close();
        return bout.toByteArray();
    }
    
    /** Get the Image from the service, and return it as the appropriate value. */
    public java.awt.image.BufferedImage getMapImage(MapRequest inMapRequest)throws Exception{
        // find out which service to retrieve.
        Service tempService = null;
        String tempServiceName = inMapRequest.getServiceName();
        if (tempServiceName == null) throw new Exception("No Service specified");
        for (int i=0; i<myServices.size(); i++){
            Service tempCheckService = (Service) myServices.elementAt(i);
            if (tempServiceName.equalsIgnoreCase(tempCheckService.getServiceName())){
                tempService = tempCheckService;
                break;
            }
        }
        
        // if the service can not be found, then throw the exception
        if (tempService == null) throw new Exception("Service with Name "+tempServiceName+" Could not be found on this server.");
        
        // create the image.
        java.awt.image.BufferedImage tempImage = tempService.generateImage(inMapRequest);
        if (tempImage == null) throw new Exception("Can not generate image with requested parameters.");
        return tempImage;
    }
    
    /** gets the feature information for for this service. */
    public String getFeatureInfo(MapRequest inMapRequest)throws Exception{
        // find out which service to retrieve.
        Service tempService = null;
        String tempServiceName = inMapRequest.getServiceName();
        if (tempServiceName == null) throw new Exception("No Service specified");
        for (int i=0; i<myServices.size(); i++){
            Service tempCheckService = (Service) myServices.elementAt(i);
            if (tempServiceName.equalsIgnoreCase(tempCheckService.getServiceName())){
                tempService = tempCheckService;
                break;
            }
        }
        
        // if the service can not be found, then throw the exception
        if (tempService == null) throw new Exception("Service with Name "+tempServiceName+" Could not be found on this server.");
        
        // Get the Records.
        Record[] tempRecords = tempService.getRecords(inMapRequest);
        if ((tempRecords == null)||(tempRecords.length == 0)) throw new Exception("No objects found at specified location.");
        
        // convert the image to the requested type.
        String tempType = inMapRequest.getFormat();
        
        // the only currently supported format is text/plain
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<tempRecords.length; i++){
            sb.append("Feature ");
            sb.append(i);
            sb.append("\n");
            String[] tempNames = tempRecords[i].getAttributeNames();
            Object[] tempAttributes = tempRecords[i].getAttributes();
            for (int j=0; j<tempNames.length; j++){
                sb.append("\t");
                sb.append(tempNames[j]);
                sb.append(" = ");
                sb.append(tempAttributes[j]);
                sb.append("\n");
            }
        }
        return sb.toString();
    }
}
