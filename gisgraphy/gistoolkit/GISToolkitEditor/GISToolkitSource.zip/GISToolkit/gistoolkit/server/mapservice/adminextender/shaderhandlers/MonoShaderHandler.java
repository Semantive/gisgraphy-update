/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender.shaderhandlers;
import java.io.*;
import java.awt.*;
import gistoolkit.display.*;
import gistoolkit.display.shader.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.*;

/**
 *
 */
public class MonoShaderHandler {
    private static final String MONO_SHADER_ACTION_TAG = "MONO_SHADER_ACTION";
    private static final String MONO_SHADER_ACTION_UPDATE = "MONO_SHADER_UPDATE";
    private static final String MONO_SHADER_ACTION_GET_IMAGE = "MONO_SHADER_GET_IMAGE";
    private static final String MONO_SHADER_IMAGE_NAME_TAG = "MONO_SHADER_IMAGE_NAME";
    
    private static String[] myIconList = {
        "line.gif",
        "dash5x5.gif",
        "dash10x10.gif",
        "dash15x5.gif",
        "dash15x5x5x5.gif",
        "dash15x5x5x5x5x5.gif"
    };
    private static float[][] myDashArray = {
        {},
        {5,5},
        {10, 10},
        {15, 5},
        {15, 5, 5, 5},
        {15, 5, 5, 5, 5, 5}
    };
    
    
    /** Creates new MonoShaderHandler */
    public MonoShaderHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(MONO_SHADER_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader(), tempString);
            return;
        }
        showMonoShaderPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
    }
    public static void showMonoShaderPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader){
        MonoShader tempShader = null;
        if (inShader instanceof MonoShader){
            tempShader = (MonoShader) inShader;
        }
        else{
            tempShader = new MonoShader();
            inStyle.setShader(tempShader);
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Style "+inStyle.getStyleName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        out.println("<b>Attributes of the mono shader.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // show the line color
        out.println("<br>When specifying the RGB values here, each value is an integer in the range of 0 to 255. No color is 0, so 0,0,0 is black, and 255,255,255 is white.</br>");
        out.println("<p>");
        if (tempShader.getLineColor() != null){
            out.print("<input type=checkbox name=ulc value=true checked><b>Line Color </b>");
            out.print("Red: <input type=text name=ulr value=\""+tempShader.getLineColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulg value=\""+tempShader.getLineColor().getGreen()+"\">");
            out.println("Blue: <input type=text name=ulb value=\""+tempShader.getLineColor().getBlue()+"\">");
        }
        else{
            out.println("<input type=checkbox name=ulc value=true ><b>Line Color </b>");
            out.print("Red: <input type=text name=ulr value=\"0\">");
            out.print("Green: <input type=text name=ulg value=\"0\">");
            out.print("Blue: <input type=text name=ulb value=\"0\">");
        }
        out.println("</p>");
        out.println("<p>");
        if (tempShader.getFillColor() != null){
            out.print("<input type=checkbox name=ufc value=true checked><b>Fill Color</b>");
            out.print("Red: <input type=text name=ufr value=\""+tempShader.getFillColor().getRed()+"\">");
            out.print("Green: <input type=text name=ufg value=\""+tempShader.getFillColor().getGreen()+"\">");
            out.println("Blue: <input type=text name=ufb value=\""+tempShader.getFillColor().getBlue()+"\">");
        }
        else{
            out.print("<input type=checkbox name=ufc value=true><b>Fill Color </b>");
            out.print("Red: <input type=text name=ufr value=\"255\">");
            out.print("Green: <input type=text name=ufg value=\"255\">");
            out.println("Blue: <input type=text name=ufb value=\"255\">");
        }
        out.println("</p>");
        out.println("<p>");
        if (tempShader.getLabelColor() != null){
            out.print("<input type=checkbox name=ulac value=true checked><b>Label Color </b>");
            out.print("Red: <input type=text name=ular value=\""+tempShader.getLabelColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulag value=\""+tempShader.getLabelColor().getGreen()+"\">");
            out.println("Blue:<input type=text name=ulab value=\""+tempShader.getLabelColor().getBlue()+"\">");
        }
        else{
            out.print("<input type=checkbox name=ulac value=true><b>Label Color </b>");
            out.print("Red: <input type=text name=ular value=\"0\">");
            out.print("Green: <input type=text name=ulag value=\"0\">");
            out.println("Blue: <input type=text name=ulab value=\"255\">");
        }
        out.println("</p>");
        float tempAlpha = tempShader.getAlpha();
        out.println("<br>How opaque should this layer be? A value of 0 is transparent.");
        out.println("<br><select name=alpha>");
        if (Math.abs(tempAlpha - 1) < 0.00001) out.println("<Option Value=\"1\"  selected>100");
        else out.println("<Option Value=\"1\" >100%");
        if (Math.abs(tempAlpha - 0.75) < 0.00001) out.println("<Option Value=\"0.75\"  selected>75%");
        else out.println("<Option Value=\"0.75\" >75%");
        if (Math.abs(tempAlpha - 0.5) < 0.00001) out.println("<Option Value=\"0.5\"  selected>50%");
        else out.println("<Option Value=\"0.5\" >50%");
        if (Math.abs(tempAlpha - 0.25) < 0.00001) out.println("<Option Value=\"0.25\" selected>25%");
        else out.println("<Option Value=\"0.25\" >25%");
        out.println("</select>");
        out.println("<br>How thick would you like the line to be (in pixels)");
        out.println("<br><select name=ulw>");
        BasicStroke tempStroke = null;
        if (tempShader.getStroke() instanceof BasicStroke){
            tempStroke = (BasicStroke) tempShader.getStroke();
        }
        else{
            tempStroke = new BasicStroke();
        }
        int tempWidth = (int) tempStroke.getLineWidth();
        out.println("<Option Value=1 "+AdminExtender.getSelected(tempWidth, 1)+">1");
        out.println("<Option Value=2 "+AdminExtender.getSelected(tempWidth, 2)+">2");
        out.println("<Option Value=3 "+AdminExtender.getSelected(tempWidth, 3)+">3");
        out.println("<Option Value=4 "+AdminExtender.getSelected(tempWidth, 4)+">4");
        out.println("<Option Value=5 "+AdminExtender.getSelected(tempWidth, 5)+">5");
        out.println("<Option Value=6 "+AdminExtender.getSelected(tempWidth, 6)+">6");
        out.println("<Option Value=7 "+AdminExtender.getSelected(tempWidth, 7)+">7");
        out.println("<Option Value=8 "+AdminExtender.getSelected(tempWidth, 8)+">8");
        out.println("<Option Value=9 "+AdminExtender.getSelected(tempWidth, 9)+">9");
        out.println("<Option Value=10 "+AdminExtender.getSelected(tempWidth, 10)+">10");
        out.println("</select>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+ShaderHandler.SHADER_NAME_TAG+" value=mono>");
        out.println("<input type=hidden name="+MONO_SHADER_ACTION_TAG+" value="+MONO_SHADER_ACTION_UPDATE+">");
        out.println("<p>What line style would you like?<p>");
        float[] tempDashArray = tempStroke.getDashArray();
        for (int i=0; i<myIconList.length; i++){
            out.print("<br><input type=\"radio\" name=\"LineStyle\" value="+i);
            if (tempDashArray != null){
                if (tempDashArray.length == myDashArray[i].length){
                    boolean tempFound = true;
                    for (int j=0; j<myDashArray[i].length; j++){
                        if (myDashArray[i][j] != tempDashArray[j]){
                            tempFound = false;
                            break;
                        }
                    }
                    if (tempFound){
                        out.print(" Checked ");
                    }
                }
            }
            else{
                // if the dash array is null, it is the same as having a single line.
                if (i==0) out.print(" Checked ");
            }
            out.print(">");
            out.println("<img SRC="+tempURLBase
            +"?"+ServiceHandler.SERVICE_NAME_TAG +"="+inService.getServiceName()
            +"&"+LayerHandler.LAYER_NAME_TAG +"="+inLayer.getLayerName()
            +"&"+StyleHandler.STYLE_NAME_TAG +"="+inStyle.getStyleName()
            +"&"+ShaderHandler.SHADER_NAME_TAG+"=mono"
            +"&"+MONO_SHADER_ACTION_TAG+"="+MONO_SHADER_ACTION_GET_IMAGE
            +"&"+MONO_SHADER_IMAGE_NAME_TAG+"="+myIconList[i]
            +"></br>");
        }

        // Label Font
        out.println("<p>");
        out.println("<p>Font Name</p>");
        Font tempFont = tempShader.getLabelFont();
        out.println("<br><select name=FN>");
        String tempFontName = tempFont.getFontName();
        Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
        for (int i=0; i<tempFontSelection.length; i++){
            String tempTestName = tempFontSelection[i].getFontName();
            out.print("   <Option Value=\""+tempTestName+"\" ");
            if (tempFontName.equals(tempTestName)){
                out.print("Selected");
            }
            out.println(">"+tempTestName);
        }
        out.println("</select>");
        out.println("</p>");
        
        // Font Size
        out.println("<p>");
        out.println("<p>Font Size</p>");
        int[] tempSizes = {7,8,9,10,12,14,16,18,20,25,30,40,48,56,72};
        int tempSize = tempFont.getSize();
        out.println("<select name=FS>");
        for (int i=0; i<tempSizes.length; i++){
            out.println("   <Option Value="+tempSizes[i]+" "+AdminExtender.getSelected(tempSize, tempSizes[i])+">"+tempSizes[i]);
        }
        out.println("</select>");
        out.println("</p>");

        out.println("<p><input type=submit value=submit></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    
    /** Handle events for the mono shader. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader, String inAction){
        MonoShader tempShader = null;
        if (inShader instanceof MonoShader){
            tempShader = (MonoShader) inShader;
        }
        else{
            tempShader = new MonoShader();
            inStyle.setShader(tempShader);
        }
        if (inAction.equalsIgnoreCase(MONO_SHADER_ACTION_GET_IMAGE)){
            String tempImageName = inRequest.getParameter(MONO_SHADER_IMAGE_NAME_TAG);
            if (tempImageName != null){
                gistoolkit.display.shader.images.ImageSource tempImageSource = new gistoolkit.display.shader.images.ImageSource();
                String tempUCName = tempImageName.toUpperCase();
                inResponse.setContentType("application/octetstream");
                if (tempUCName.endsWith("PNG")){
                    inResponse.setContentType("image/png");
                }
                if (tempUCName.endsWith("GIF")){
                    inResponse.setContentType("image/gif");
                }
                if ((tempUCName.endsWith("JPEG"))||(tempUCName.endsWith("JPG"))){
                    inResponse.setContentType("image/jpeg");
                }
                
                try{
                    InputStream in = tempImageSource.getResource(tempImageName);
                    if (in == null){
                        return;
                    }
                    OutputStream out = inResponse.getOutputStream();
                    byte[] buff = new byte[1000];
                    int length = in.read(buff);
                    while (length != -1){
                        out.write(buff,0,length);
                        length = in.read(buff);
                    }
                    in.close();
                }
                catch (Exception e){
                    return;
                }
                // out is closed by the web server when it is returned.
                return;
                
            }
        }
        if (inAction.equalsIgnoreCase(MONO_SHADER_ACTION_UPDATE)){
            
            // check for the line color
            String tempString = inRequest.getParameter("ulc");
            if (tempString == null){
                tempShader.setLineColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ulr"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulg"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulb"));
                tempShader.setLineColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the fill color
            tempString = inRequest.getParameter("ufc");
            if (tempString == null){
                tempShader.setFillColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ufr"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ufg"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ufb"));
                tempShader.setFillColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the label color
            tempString = inRequest.getParameter("ulac");
            if (tempString == null){
                tempShader.setLabelColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ular"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulag"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulab"));
                tempShader.setLabelColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            // Alpha percent
            float tempAlpha = 1;
            tempString = inRequest.getParameter("alpha");
            if (tempString != null){
                try{
                    tempAlpha = Float.parseFloat(tempString);
                }
                catch (Exception e){
                }
            }
            tempShader.setAlpha(tempAlpha);
            
            // line width
            int tempLineWidth = ShaderHandler.rationalize(inRequest.getParameter("ulw"));
            // DashArray
            int tempDashArray = ShaderHandler.rationalize(inRequest.getParameter("LineStyle"));
            
            // set the stroke.
            if ((tempDashArray > 0) && (tempDashArray < myDashArray.length)){
                tempShader.setStroke(new BasicStroke((float)tempLineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1, myDashArray[tempDashArray], (float) 0 ));
            }
            else{
                tempShader.setStroke(new BasicStroke((float)tempLineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND ));
            }
            
            // check for the label font
            Font tempFont = tempShader.getLabelFont();
            String tempFontName = tempFont.getFontName();
            String tempSelectedName = inRequest.getParameter("FN");
            if (tempSelectedName != null){
                if (!tempFontName.equals(tempSelectedName)){
                    Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
                    for (int i=0; i<tempFontSelection.length; i++){
                        String tempTestName = tempFontSelection[i].getFontName();
                        if (tempSelectedName.equals(tempTestName)){
                            // set the new font into the scale bar
                            tempShader.setLabelFont(tempFontSelection[i]);
                            break;
                        }
                    }
                }
            }
            
            // check for the label font size
            tempString = inRequest.getParameter("FS");
            if (tempString != null){
                try{
                    int tempSize = Integer.parseInt(tempString);
                    tempFont = tempShader.getLabelFont();
                    int tempFontSize = tempFont.getSize();
                    if (tempFontSize != tempSize){
                        tempFont = tempFont.deriveFont((float)tempSize);
                        tempShader.setLabelFont(tempFont);
                    }
                }
                catch (NumberFormatException e){
                }
            }
            
            showMonoShaderPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
        }
    }
}

