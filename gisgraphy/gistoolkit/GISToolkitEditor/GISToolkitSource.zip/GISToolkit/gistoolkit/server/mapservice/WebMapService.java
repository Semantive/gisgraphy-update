/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice;

import java.util.*;
import java.net.*;
import java.io.*;
import gistoolkit.common.*;
import gistoolkit.config.*;
import gistoolkit.server.*;
/**
 *  A class to implement the WebMapService 1.1.1 specification.
 */
public class WebMapService implements ServerHolder{
    /** The port on which this web map service should listen. */
    private int myPort = 40320;
    /** Set the port on which this web map service should listen. */
    public void setPort(int inPort){
        if (inPort != myPort){
            try{
                if (myServerSocket != null) myServerSocket.close();
                myPort = inPort;
            }
            catch (Exception e){
                log(e);
            }
        }
    }
    /** Get the port on which this web maps service is listening. */
    public int getPort(){return myPort;}
    
    /** The name of the service. */
    private String myName = "WebMapService";
    /** Set the name of the service. */
    public void setName(String inName){myName = inName;}
    /** Get the name of the service. */
    public String getName() {return myName;}
    
    /** The default service name. */
    private String myDefaultServiceName = "client";
    /** Set the name of the default service. */
    public void setDefaultServiceName(String inServiceName){myDefaultServiceName = inServiceName;}
    /** Get the name of the default service. */
    public String getDefaultServiceName(){return myDefaultServiceName;}
    
    /** The server used for processing requests. */
    private Server myServer = null;
    /** The response thread needs to get to the server in order to generate the image. */
    protected Server getServer(){return myServer;}
    
    /** There may be several extension services for this server. */
    private Vector myExtensionServices = new Vector();
    /** Add an extension service. */
    public void addExtensionService(ExtensionService inExtensionService){myExtensionServices.addElement(inExtensionService);}
    /** Remove an extension service. */
    public void removeExtensionService(ExtensionService inExtensionService){myExtensionServices.remove(inExtensionService);}
    /** Get the extension service with the given name */
    protected ExtensionService getExtensionService(String inServiceName){
        if (inServiceName == null) return null;
        for (int i=0; i<myExtensionServices.size(); i++){
            ExtensionService tempService = (ExtensionService) myExtensionServices.elementAt(i);
            if (inServiceName.equalsIgnoreCase(tempService.getName())) return tempService;
        }
        // if the service is not found, then return null;
        return null;
    }
    
    /** A queue of all the currently active response threads. */
    private Vector myResponseThreadVect = new Vector();
    /** Add a thread to the response thread vector.
     * This list is needed so these threads are not garbage collected prematurely.
     */
    public void addResponseThread(ResponseThread inThread){
        myResponseThreadVect.addElement(inThread);
    }
    /** Remove a thread from the response thread vector.
     */
    public void removeResponseThread(ResponseThread inThread){
        myResponseThreadVect.remove(inThread);
    }
    
    /** Location of the initialization file. */
    public String myInitFileName = null;
    
    /** Creates new WebMapService1_1_1 */
    public WebMapService() {
    }
    
    public static final String WEB_MAP_SERVICE_NODE = "WEB_MAP_SERVICE";
    public static final String EXTENDER_NODE = "ExtenderInformation";
    public static final String EXTENDER_CLASS_TAG = "ExtenderClass";
    public static final String HOST_NAME_TAG = "HostName";
    public static final String PORT_NUMBER = "PortNumber";
    /** Initialize the service. */
    public void init(String inInitFile)throws Exception{
        Node tempNode = null;
        try{
            tempNode = Configurator.readConfig(inInitFile);
        }
        catch (Exception e){
        }
        if (tempNode != null){
            String tempHostName = tempNode.getAttribute(HOST_NAME_TAG);
            if (tempHostName != null) setHostName(tempHostName);
            String tempPortNumber = tempNode.getAttribute(PORT_NUMBER);
            if (tempPortNumber != null){
                try{
                    myPort = Integer.parseInt(tempPortNumber);
                }
                catch (NumberFormatException e){
                    System.out.println("Can not parse port number "+tempPortNumber);
                }
            }
            Node tempServerNode = tempNode.getChild(Server.SERVER_TAG);
            myServer = new Server(this);
            if (tempNode != null){
                myServer.setNode(tempServerNode);
            }
            
            Node[] tempExtenderNodes = tempNode.getChildren(EXTENDER_NODE);
            for (int i=0; i<tempExtenderNodes.length; i++){
                String tempExtenderClass = tempExtenderNodes[i].getAttribute(EXTENDER_CLASS_TAG);
                if (tempExtenderClass != null){
                    try{
                        ExtensionService tempExtender = (ExtensionService)  Class.forName(tempExtenderClass).newInstance();
                        Node[] tempNodes = tempExtenderNodes[i].getChildren();
                        if (tempNodes.length > 0) tempExtender.setNode(tempNodes[0]);
                        addExtensionService(tempExtender);
                    }
                    catch(Exception e){
                        log(e);
                    }
                }
            }
        }
        else{
            // add the admin extender
            myServer = new Server(this);
            myHostName = "localhost";
            setDefaultServiceName("admin");
            addExtensionService(new gistoolkit.server.mapservice.adminextender.AdminExtender());
            addExtensionService(new gistoolkit.server.mapservice.clientextender.ClientExtender());
            addExtensionService(new gistoolkit.server.mapservice.htmlclientextender.HTMLClientExtender());
        }
        myInitFileName = inInitFile;
        
    }
    public void saveConfig() throws Exception{
        save(myInitFileName);
    }
    /** Initialize the service. */
    public void save(String inInitFile)throws Exception{
        Node tempNode = new Node(WEB_MAP_SERVICE_NODE);
        if (myHostName != null) tempNode.addAttribute(HOST_NAME_TAG, myHostName);
        tempNode.addAttribute(PORT_NUMBER, ""+myPort);
        tempNode.addChild(myServer.getNode());
        for (int i=0; i<myExtensionServices.size(); i++){
            ExtensionService tempExtender = (ExtensionService) myExtensionServices.elementAt(i);
            if (tempExtender != null){
                try{
                    Node tempExtenderNode = new Node(EXTENDER_NODE);
                    tempExtenderNode.addAttribute(EXTENDER_CLASS_TAG, tempExtender.getClass().getName());
                    tempExtenderNode.addChild(tempExtender.getNode());
                    tempNode.addChild(tempExtenderNode);
                }
                catch(Exception e){
                    log(e);
                }
            }
        }
        Configurator.writeConfig(tempNode, inInitFile);
    }
    
    /** Save a reference to the server socket for getting the host name and such. */
    private ServerSocket myServerSocket = null;
    
    /** Listen for incoming requests. */
    private boolean myListen = true;
    public void listen(){
        int tempTries = 5;
        while ((myListen) && (tempTries >=0)){
            try{
                myServerSocket = new ServerSocket(myPort, 8);
                System.out.println(new Date()+"-Server "+ getName() + " Listening on Port "+myPort);
                log(new Date()+"-Server "+ getName() + " Listening on Port "+myPort);
                while(true){
                    Socket tempClientSocket = myServerSocket.accept();
                    ResponseThread tempResponseThread = new ResponseThread(this, tempClientSocket);
                    addResponseThread(tempResponseThread);
                    tempResponseThread.start();
                    tempTries = 5;
                }
            }
            catch (Exception e){
                tempTries--;
                log(e);
            }
        }
    }
    
    /** The location of the log file. */
    private File myLogFile = new File("WebMapService.log");
    /** Set the location of the log file. */
    public void setLogFile(File inLogFile){myLogFile = inLogFile;}
    
    /** The print writer to use to write the log file. */
    private PrintWriter myLogWriter = null;
    
    /** Log the string to the log file. */
    public synchronized void log(String inString){
        if (myLogWriter == null){
            try{
                FileWriter fwrite = new FileWriter(myLogFile, true);
                myLogWriter = new PrintWriter(fwrite);
            }
            catch (Exception e){
                System.out.println("Error creating output file "+myLogFile);
                e.printStackTrace(System.out);
                
                System.out.println("Orrigional Message: "+inString);
                return;
            }
        }
        myLogWriter.println(inString);
        
        // write the error to standard out.
        System.out.println(inString);
    }
    
    /** Log entries to the log files. */
    public  void log(Throwable inT){
        try{
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            PrintWriter pwrite = new PrintWriter(bout);
            pwrite.println("Exception "+inT);
            inT.printStackTrace(pwrite);
            pwrite.close();
            bout.close();
            String tempString = new String(bout.toByteArray());
            log(tempString);
        }
        catch (Exception ex){}
    }
    
    /** checks if this web server has the given service as one of it's available services. */
    public boolean hasService(String inName){
        Service tempService = myServer.getService(inName);
        if (tempService == null) return false;
        else return true;
    }
    
    /** Main entry point for the 1_1_1 web map service. */
    public static void main(String[] inArgs){
        // check for the startup parameter
        String tempInitFile = System.getProperty("InitFile");
        if (tempInitFile == null){
            
            if (inArgs.length == 0){
                showUsage();
                return;
            }
            tempInitFile = inArgs[0];
        }
        if (tempInitFile != null) tempInitFile = tempInitFile.trim();
        File tempFile = new File(tempInitFile);
        if (!tempFile.exists()){
            // try to create the initialization file.
            System.out.println("Initialization file not found:\n"+tempFile.getAbsolutePath()+"\n ...attempting to create");
            try{
                if (!tempFile.createNewFile()){
                    System.out.println("Can not Create Initialization File "+tempFile.getAbsolutePath());
                    System.exit(0);
                }
            }
            catch (IOException e){
                System.out.println("Error creating Initialization File "+tempFile.getAbsolutePath());
                System.exit(0);
            }
            System.out.println("Successfully created file. ");
            
        }
        WebMapService tempWebMapService = new WebMapService();
        // perhaps a special log file
        if (inArgs.length >1){
            String tempLogFile = inArgs[1];
            tempFile = new File(tempLogFile);
            if (tempFile.canWrite()){
                tempWebMapService.setLogFile(tempFile);
            }
        }
        
        try{
            tempWebMapService.init(tempInitFile);
            tempWebMapService.listen();
        }
        catch (Exception e){
            tempWebMapService.log(e);
        }
    }
    
    /** Show the user how to use this class. */
    public static void showUsage(){
        System.out.println("WebMapService ConfigurationFile [LogFile]");
    }
    
    /* The host name to send back to the client so they can find this server. */
    private String myHostName = null;
    /** Set the HostName.  */
    public void setHostName(String inHostName) {
        myHostName = inHostName;
    }
    
    /** Get the host name.  */
    public String getHostName() {
        if (myHostName == null){
            return myServerSocket.getInetAddress().getHostName();
        }
        return myHostName;
    }
    
}
