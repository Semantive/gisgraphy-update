/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2003, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice;

import java.util.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.server.*;

/**
 * Provides an easy way to write an extension service.
 */
public abstract class SimpleExtensionService implements ExtensionService{

    /** Creates new SimpleExtensionService */
    public SimpleExtensionService() {
    }
        
    /** Stores a reference to the map service, and the map server. */
    private Server myServer = null;
    /** Sets the servier within the extender.  Called bafore the first request is sent to the extender. */
    public void setServer(Server inServer){myServer = inServer;}
    /** Gets the reference to the server should it be needed for anything. */
    protected Server getServer(){return myServer;}
    
    /** Called to identify this service.  */
    public abstract String getName();
    
    public static final String SIMPLE_EXTENSION_SERVICE_NODE = "SimpleExtensionServiceNode";
    /** Called to set the configuration information for this service.  */
    public void setNode(Node inNode) {
    }
    /** Called to get the configuration information for this service.  */
    public Node getNode() {
        Node tempNode = new Node(SIMPLE_EXTENSION_SERVICE_NODE);
        return tempNode;
    }

    /** 
     * Reads the Envelope from the string sent in, good for reading bounding boxes from a url parameter.
     * Bounding boxes are of the form \"MinX,MinY,MaxX,MaxY\" as in BBOX=MinX,MinY,MaxX,MaxY.
     */
    public static Envelope parseBoundingBox(String inBBOXString) throws Exception{
        if (inBBOXString == null) throw new Exception("Illegal Bounding Box Format");
        
        String[] tempList = new String[4];
        StringTokenizer st = new StringTokenizer(inBBOXString);
        for (int i=0; i<4; i++){
            if (st.hasMoreElements()){
                tempList[i] = st.nextToken(",");
            }
            else{
                throw new Exception ("Illegal Bounding Box Format at coordinate "+i);
            }
        }
        
        Envelope tempEnvelope = new Envelope(
                Double.parseDouble(tempList[0]), // minX, topX
                Double.parseDouble(tempList[3]), // maxY, topY
                Double.parseDouble(tempList[2]), // maxX, bottomX
                Double.parseDouble(tempList[1]) // minY, bottomY
        );
        return tempEnvelope;
    }    
    
    /** Called when a request is sent to this service.  */
    public abstract void doGet(Request inRequest, Response inResponse) throws Exception;
    
    /** Returns a list from the given comma separated string.  */
    public static String[] getListFromString(String inString) {
        return OGCParser.getListFromString(inString);
    }
    
    /** Parse any filter information from the string. */
    public static FilterInfo[] getFilters(String inString){
        return OGCParser.getFilters(inString);
    }
    
    /** set the filter information for the layer. */
    public static void setFilter(FilterInfo[] inFilters, Layer inLayer){
        Service.setFilter(inFilters, inLayer);
    }
}
