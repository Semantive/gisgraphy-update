/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.server.mapservice.adminextender;

import java.io.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.display.*;

/**
 *
 */
public class StyleHandler {
    public static final String STYLE_NAME_TAG = "STYLE_NAME";
    private static final String STYLE_ACTION_TAG = "STYLE_ACTION";
    private static final String STYLE_ACTION_UPDATE = "STYLE_UPDATE";
    private static final String STYLE_ACTION_EDIT_SHADER = "EDIT_SHADER";
    private static final String STYLE_ACTION_LABELER_REMOVE = "LABELER_REMOVE";
    private static final String STYLE_LABELER_NUM = "LABELER_NUM";
    private static final String STYLE_ACTION_RENDERER_REMOVE = "RENDERER_REMOVE";
    private static final String STYLE_RENDERER_NUM = "RENDERER_NUM";
    private static final String STYLE_ACTION_LABELER_ADD = "LABELER_ADD";
    private static final String STYLE_ACTION_RENDERER_ADD = "RENDERER_ADD";
    
    
    
    /** Creates new StyleHandler */
    public StyleHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer) throws Exception{
        // look for the style name
        String tempStyleName = inRequest.getParameter(STYLE_NAME_TAG);
        if (tempStyleName == null) {
            AdminExtender.showErrorPage(inRequest, inResponse, "No Style Name Tag Specified");
            return;
        }
        Style tempStyle = inLayer.getStyle(tempStyleName);
        if (tempStyle == null) {
            AdminExtender.showErrorPage(inRequest, inResponse, "Style with name "+tempStyleName+" Was not found on this server.");
            return;
        }
        
        //handle any requests for the style
        String tempAction = inRequest.getParameter(STYLE_ACTION_TAG);
        if (tempAction != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, tempStyle, tempAction);
            return;
        }
        
        // If there is a shader tag, then handle requests for ths Shader.
        String tempShader = inRequest.getParameter(ShaderHandler.SHADER_NAME_TAG);
        if (tempShader != null){
            ShaderHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, tempStyle);
            return;
        }
        // If there is a labeler tag, then handle requests for ths Labeler.
        String tempLabeler = inRequest.getParameter(LabelerHandler.LABELER_NUM_TAG);
        if (tempLabeler != null){
            LabelerHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, tempStyle);
            return;
        }
        // If there is a renderer tag, then handle requests for ths Renderer.
        String tempRenderer = inRequest.getParameter(RendererHandler.RENDERER_NUM_TAG);
        if (tempRenderer != null){
            RendererHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, tempStyle);
            return;
        }
        
        // show the default style page.
        showStylePage(inRequest, inResponse, inServer, inService, inLayer, tempStyle);
    }
    public static void showStylePage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle){
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Style "+inStyle.getStyleName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        out.println("<b>Edit Style "+inStyle.getStyleName()+"</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<br><b>Style Name</b></br>");
        out.println("<br>A short just a few character name to be used in the URL.  Do not include spaces or special characters.</br>");
        out.println("<br><input type=text name=Update_Style_Name value=\""+inStyle.getStyleName()+"\"></br>");
        out.println("<br><b>Style Title</b></br>");
        out.println("<br>A long description of the Layer, may include spaces and special characters.</br>");
        out.println("<br><input type=text name=Update_Style_Title value=\""+inStyle.getStyleTitle()+"\" size=100></br>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+STYLE_ACTION_TAG+" value="+STYLE_ACTION_UPDATE+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        // show the shader information
        out.println("Shader");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<p><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+inLayer.getLayerName()+"&"+STYLE_NAME_TAG+"="+inStyle.getStyleName()+"&"+ShaderHandler.SHADER_NAME_TAG+"=1\" ><b>Edit Shader</b></a></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        
        // show the labeler information
        out.println("<b>Labelers</b>");
        out.println("<TABLE border=\"4\">");
        for (int i=0; i<inStyle.getNumLabelers(); i++){
            out.println("<tr><td>");
            out.println("<p><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+inLayer.getLayerName()+"&"+STYLE_NAME_TAG+"="+inStyle.getStyleName()+"&"+LabelerHandler.LABELER_NUM_TAG+"="+i+"\" ><b>"+inStyle.getLabeler(i).getLabelerName()+"</b></a></p>");
            out.println("</td><td>");
            out.println("<p><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+inLayer.getLayerName()+"&"+STYLE_NAME_TAG+"="+inStyle.getStyleName()+"&"+STYLE_ACTION_TAG+"="+STYLE_ACTION_LABELER_REMOVE+"&"+STYLE_LABELER_NUM+"="+i+"\"><b>Remove</b></a></p>");
            out.println("</td></tr>");
        }
        out.println("</TABLE>");
        out.println("<p><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+inLayer.getLayerName()+"&"+STYLE_NAME_TAG+"="+inStyle.getStyleName()+"&"+STYLE_ACTION_TAG+"="+STYLE_ACTION_LABELER_ADD+"\"><b>Add Labeler</b></a></p>");
        
        // show the renderer information
        out.println("<b>Renderers</b>");
        out.println("<TABLE border=\"4\">");
        for (int i=0; i<inStyle.getNumRenderers(); i++){
            out.println("<tr><td>");
            out.println("<p><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+inLayer.getLayerName()+"&"+STYLE_NAME_TAG+"="+inStyle.getStyleName()+"&"+RendererHandler.RENDERER_NUM_TAG+"="+i+"\" ><b>"+inStyle.getRenderer(i).getRendererName()+"</b></a></p>");
            out.println("</td><td>");
            out.println("<p><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+inLayer.getLayerName()+"&"+STYLE_NAME_TAG+"="+inStyle.getStyleName()+"&"+STYLE_ACTION_TAG+"="+STYLE_ACTION_RENDERER_REMOVE+"&"+STYLE_RENDERER_NUM+"="+i+"\"><b>Remove</b></a></p>");
            out.println("</td></tr>");
        }
        out.println("</TABLE>");
        out.println("<p><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+inLayer.getLayerName()+"&"+STYLE_NAME_TAG+"="+inStyle.getStyleName()+"&"+STYLE_ACTION_TAG+"="+STYLE_ACTION_RENDERER_ADD+"\"><b>Add Renderer</b></a></p>");
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, String inStyleAction)throws Exception{
        if (inStyleAction.equalsIgnoreCase(STYLE_ACTION_UPDATE)){
            String tempString = inRequest.getParameter("Update_Style_Name");
            if ((tempString != null) && (tempString.trim().length() != 0)){
                // look for duplicates
                Style tempStyle = inLayer.getStyle(tempString);
                if ((tempStyle != null) && (tempStyle != inStyle)){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Duplicate Style Name, delete the existing style before adding another. ");
                    return;
                }
                else{
                    inStyle.setStyleName(tempString);
                    tempString = inRequest.getParameter("Update_Style_Title");
                    inStyle.setStyleTitle(tempString);
                    LayerHandler.showLayerPage(inRequest, inResponse, inServer, inService, inLayer);
                    return;
                }
            }
            else{
                AdminExtender.showErrorPage(inRequest, inResponse, "New Style name not specified.");
                return;
            }
        }
        if (inStyleAction.equalsIgnoreCase(STYLE_ACTION_LABELER_REMOVE)){
            // which labeler to remove
            String tempLabelerNumString = inRequest.getParameter(STYLE_LABELER_NUM);
            if (tempLabelerNumString == null){
                AdminExtender.showErrorPage(inRequest, inResponse, "Labeler delete requested, but no "+STYLE_LABELER_NUM+" specified.");
                return;
            }
            else{
                try{
                    int tempLabelerNum = Integer.parseInt(tempLabelerNumString);
                    // remove the labeler
                    inStyle.remove(inStyle.getLabeler(tempLabelerNum));
                }
                catch(NumberFormatException e){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing "+STYLE_LABELER_NUM+" \""+tempLabelerNumString+"\" is not an integer");
                    return;
                }
            }
        }
        if (inStyleAction.equalsIgnoreCase(STYLE_ACTION_RENDERER_REMOVE)){
            // which renderer to remove
            String tempRendererNumString = inRequest.getParameter(STYLE_RENDERER_NUM);
            if (tempRendererNumString == null){
                AdminExtender.showErrorPage(inRequest, inResponse, "Renderer delete requested, but no "+STYLE_RENDERER_NUM+" specified.");
                return;
            }
            else{
                try{
                    int tempRendererNum = Integer.parseInt(tempRendererNumString);
                    // remove the renderer
                    inStyle.remove(inStyle.getRenderer(tempRendererNum));
                }
                catch(NumberFormatException e){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing "+STYLE_RENDERER_NUM+" \""+tempRendererNumString+"\" is not an integer");
                    return;
                }
            }
        }
        if (inStyleAction.equalsIgnoreCase(STYLE_ACTION_LABELER_ADD)){
            LabelerHandler.showAddPage(inRequest, inResponse, inServer, inService, inLayer, inStyle);
            return;
        }
        if (inStyleAction.equalsIgnoreCase(STYLE_ACTION_RENDERER_ADD)){
            RendererHandler.showAddPage(inRequest, inResponse, inServer, inService, inLayer, inStyle);
            return;
        }
        // show the default style page.
        showStylePage(inRequest, inResponse, inServer, inService, inLayer, inStyle);
    }
}
