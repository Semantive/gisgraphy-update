/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice;

import java.io.*;

/**
 * Represents the response to the client.
 */
public class Response {
    /** Holds the Content type. */
    private String myContentType = "text/html";
    /** Set the Content type. */
    public void setContentType(String inContentType){myContentType = inContentType;}
    /** Get the content type. */
    public String getContentType(){return myContentType;}
    
    /** The output stream for use when writing binary data. */
    private OutputStream myOutputStream = null;
    /** Get the outputstream fro writing binary data. */
    public OutputStream getOutputStream(){return myOutputStream;}
    
    /** The Print writer for use when writing to the client. */
    private PrintWriter myWriter = null;
    /** Get the Print writer for writing to the client. */
    public PrintWriter getWriter(){
        if (myWriter == null) myWriter = new PrintWriter(myOutputStream);
        return myWriter;
    }
    
    /** Creates new Response */
    public Response(OutputStream inOutputStream) {
        myOutputStream = inOutputStream;
    }    
}
