/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice;

import java.util.StringTokenizer;
import java.util.ArrayList;
import java.io.*;
import gistoolkit.server.*;

/**
 * Super class for the parsers to contain common functionality.
 */
public abstract class OGCParser {
    public abstract String getVersion();
    
    /** Creates new OGCParser */
    public OGCParser() {
    }
    
    /** Create a map request with the given web input request. */
    public abstract MapRequest getMapRequest(Request inRequest) throws Exception;
    
    /** Executes the request with the given server. */
    public void getRequest(Request inRequest, Response inResponse, Server inServer) throws Exception{
        // read the map request
        MapRequest tempRequest = getMapRequest(inRequest);
        tempRequest.setServiceName(inRequest.getParameter(ResponseThread.SERVICE_NAME_PARAMETER));
        tempRequest.setCalledURL(inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER));
        
        if (tempRequest.getRequest() == MapRequest.REQUEST_GET_MAP){
            getMapRequest(tempRequest, inResponse, inServer);
        }
        if (tempRequest.getRequest() == MapRequest.REQUEST_GET_CAPABILITIES){
            getCapabilitiesRequest(tempRequest, inResponse, inServer);
        }
        if (tempRequest.getRequest() == MapRequest.REQUEST_GET_FEATURE_INFO){
            getFeatureInfo(tempRequest, inResponse, inServer);
        }
    }
    
    /** get the map request. */
    public void getMapRequest(MapRequest inRequest, Response inResponse, Server inServer)throws Exception{
        // generate the data
        byte[] tempData = inServer.getMap(inRequest);
        
        // return the data
        String tempContentType = "text/plain";
        String tempType = inRequest.getFormat();
        if (tempType == MapRequest.FORMAT_PNG){
            tempContentType = "image/png";
        }
        if (tempType == MapRequest.FORMAT_JPG){
            tempContentType = "image/jpg";
        }
        if (tempType == MapRequest.FORMAT_GIF){
            tempContentType = "image/gif";
        }
        inResponse.setContentType(tempContentType);
        OutputStream out = inResponse.getOutputStream();
        out.write(tempData);
    }
    
    /** get the capabilities request. */
    public abstract void getCapabilitiesRequest(MapRequest inRequest, Response inResponse, Server inServer) throws Exception;
    
    /** get the map request. */
    public void getFeatureInfo(MapRequest inRequest, Response inResponse, Server inServer)throws Exception{
        // generate the data
        String tempData = inServer.getFeatureInfo(inRequest);
        
        // return the data
        String tempContentType = "text/plain";
        inResponse.setContentType(tempContentType);
        OutputStream out = inResponse.getOutputStream();
        out.write(tempData.getBytes());
    }
    
    /** Returns a list from the given comma separated string. */
    public static String[] getListFromString(String inString){
        ArrayList tempList = new ArrayList();
        if (inString != null){
            StringTokenizer st = new StringTokenizer(inString);
            while (st.hasMoreElements()){
                tempList.add(st.nextToken(","));
            }
        }
        
        String[] tempStrings = new String[tempList.size()];
        tempList.toArray(tempStrings);
        return tempStrings;
    }
    
    /** Sets the coordinates of the bounding box given the input string. */
    public static void setBoundingBox(MapRequest inRequest, String inString) throws Exception{
        if (inString == null) return;
        String[] tempCoordinates = getListFromString(inString);
        if (tempCoordinates == null) return;
        if (tempCoordinates.length == 4){
            try{
                inRequest.setMinX(Double.parseDouble(tempCoordinates[0]));
                inRequest.setMinY(Double.parseDouble(tempCoordinates[1]));
                inRequest.setMaxX(Double.parseDouble(tempCoordinates[2]));
                inRequest.setMaxY(Double.parseDouble(tempCoordinates[3]));
            }
            catch (Exception e){
                throw new Exception("Error parsing Bounding Box Value="+inString);
            }
        }
        return;
    }
    
    /** Sets the Spatial Reference system to use. */
    public static void setSRS(MapRequest inRequest, String inSRS) throws Exception{
        // the SRS
        if (inSRS != null){
            String tempSRS = inSRS;
            if (tempSRS.toUpperCase().startsWith("AUTO")){
                try{
                    // The first parameter is the identifier for the projection.
                    int tempIndex = tempSRS.indexOf(",");
                    String tempProjectionNumber = tempSRS.substring(5,tempIndex);
                    int tempStartIndex = tempIndex;
                    tempIndex = tempSRS.indexOf(",", tempIndex+1);
                    String tempUnitNumber = tempSRS.substring(tempStartIndex + 1, tempIndex);
                    inRequest.setSRS(tempSRS.substring(0,tempIndex));
                    tempStartIndex = tempIndex;
                    tempIndex = tempSRS.indexOf(",", tempIndex+1);
                    String tempLatitude = tempSRS.substring(tempStartIndex + 1, tempIndex);
                    String tempLongitude = tempSRS.substring(tempIndex + 1);
                    double tempDoubleLatitude = 0;
                    try{
                        tempDoubleLatitude = Double.parseDouble(tempLatitude);
                    }
                    catch (NumberFormatException ex){
                        throw new Exception("The Latitude parameter of the Auto SRS "+tempLatitude+" is not a number.");
                    }
                    inRequest.setSRSLatitude(tempDoubleLatitude);
                    double tempDoubleLongitude = 0;
                    try{
                        tempDoubleLongitude = Double.parseDouble(tempLongitude);
                    }
                    catch (NumberFormatException ex){
                        throw new Exception("The Longitude parameter of the Auto SRS "+tempLongitude+" is not a number.");
                    }
                    inRequest.setSRSLongitude(tempDoubleLongitude);
                    inRequest.setSRSAuto(true);
                }
                catch (Exception e){
                    throw new Exception("Can not parse SRS "+inSRS);
                }
            }
            else{
                inRequest.setSRS(tempSRS);
            }
        }
    }
    
    /** sets the format. */
    protected static String getFormat(String inFormat){
        if (inFormat == null) return MapRequest.FORMAT_PNG;
        if (inFormat.equalsIgnoreCase("JPG")) return MapRequest.FORMAT_JPG;
        if (inFormat.equalsIgnoreCase("PNG")) return MapRequest.FORMAT_PNG;
        if (inFormat.equalsIgnoreCase("GIF")) return MapRequest.FORMAT_GIF;
        return inFormat;
    }
    
    /** Parse the filter info objects out of the filter string. */
    public static FilterInfo[] getFilters(String inFilterString){
        // filters are of the form FILTERs=LayerName1:FilterName1:value,LayerName1:FilterName2:value,LayerName2:FilterName1:value etc.
        ArrayList tempArrayList = new ArrayList();
        StringTokenizer st = new StringTokenizer(inFilterString);
        while (st.hasMoreElements()){
            String tempFilterString = st.nextToken(",");
            StringTokenizer st1 = new StringTokenizer(tempFilterString);
            if (st1.hasMoreElements()){
                String tempLayer = st1.nextToken(":");
                if (st1.hasMoreElements()){
                    String tempFilter = st1.nextToken(":");
                    String tempValue = "";
                    if (st1.hasMoreElements()){
                        tempValue = st1.nextToken(":");
                    }
                    // create the filter Info Object.
                    FilterInfo tempInfo = new FilterInfo(tempLayer, tempFilter, tempValue);
                    tempArrayList.add(tempInfo);
                }
            }
        }
        FilterInfo[] tempFilterInfos = new FilterInfo[tempArrayList.size()];
        tempArrayList.toArray(tempFilterInfos);
        return tempFilterInfos;
    }
}
