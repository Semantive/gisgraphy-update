/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender;

import java.io.*;
import gistoolkit.common.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.images.ImageSource;

/**
 *  Allows the remote configuration of the server.
 */
public class AdminExtender extends SimpleExtensionService{
    
    /** Place to get the banner image. */
    private static String myBannerPageImageFileName = null;
    /** set the banner page image file name. */
    public void setBannerPageImageFileName(String inFileName){myBannerPageImageFileName = inFileName;}
    /** Get the banner page image file name. */
    public String getBannerPageImageFileName(){return myBannerPageImageFileName;}
    
    /** Creates new AdminExtender */
    public AdminExtender() {
    }
    
    /** Called to identify this service. */
    public String getName(){
        return "Admin";
    }
    
    public static final String ADMIN_EXTENDER_NODE = "AdminExtender";
    
    private static final String BANNER_PAGE_TAG = "ADMIN_EXTENDER_BANNER_PAGE";
    /** Called to set the configuration information for this service. */
    public void setNode(Node inNode){
        String tempBannerPage = inNode.getAttribute(BANNER_PAGE_TAG);
        if (tempBannerPage != null) setBannerPageImageFileName(tempBannerPage);
    }
    
    /** Called to get the configuration information for this service. */
    public Node getNode(){
        Node tempNode = new Node(ADMIN_EXTENDER_NODE);
        if (getBannerPageImageFileName() != null) tempNode.addAttribute(BANNER_PAGE_TAG, getBannerPageImageFileName());
        return tempNode;
    }
    
    private static final String ACTION_TAG = "ACTION";
    private static final String ACTION_GETIMAGE = "GETIMAGE";
    private static final String ACTION_SAVE_CONFIG = "SAVE_CONFIG";
    private static final String ACTION_SHOW_OPTIONS = "SHOW_OPTIONS";
    private static final String ACTION_UPDATE_OPTIONS = "UPDATE_OPTIONS";
    private static final String IMAGE_NAME_TAG = "IMAGE_NAME";
    
    /** Called when a request is sent to this service. */
    public void doGet(Request inRequest, Response inResponse) throws Exception{
        String tempAction = inRequest.getParameter(ACTION_TAG);
        if (tempAction != null){
            if (tempAction.equalsIgnoreCase(ACTION_GETIMAGE)){
                getImage(inRequest, inResponse);
                return;
            }
            if (tempAction.equalsIgnoreCase(ACTION_SAVE_CONFIG)){
                saveConfig(inRequest, inResponse);
                return;
            }
            if (tempAction.equalsIgnoreCase(ACTION_SHOW_OPTIONS)){
                showOptionsPage(inRequest, inResponse);
                return;
            }
            if (tempAction.equalsIgnoreCase(ACTION_UPDATE_OPTIONS)){
                handleAction(inRequest, inResponse);
                return;
            }
        }
        ServerHandler.doGet(inRequest, inResponse, getServer());
        return;
    }
    
    /** Show the options page. */
    public void showOptionsPage(Request inRequest, Response inResponse){
        showHeaderPage(inRequest, inResponse, "Acministration Options");
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        out.println("<b>Available Options</b>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<b>Banner Image File Name</b>");
        if (myBannerPageImageFileName != null){
            out.println("<br><input type=text name=BannerImageFileName value=\""+getBannerPageImageFileName()+"\" size=100></br>");
        }
        else{
            out.println("<br><input type=text name=BannerImageFileName size=100></br>");
        }
        out.println("<br><b>Host Name</b></br>");
        out.println("<br><input type=text name=HostName value=\""+getServer().getHostName()+"\" size=100></br>");
        out.println("<br><b>Port Number</b></br>");
        out.println("<br><input type=text name=PortNumber value=\""+getServer().getPortNumber()+"\" size=100></br>");
        out.println("<input type=hidden name="+ACTION_TAG+" value="+ACTION_UPDATE_OPTIONS+">");
        out.println("<p><input type=submit value=submit></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");        
        showTailerPage(inRequest, inResponse);
    }
    /** handle the update options request. */
    public void handleAction(Request inRequest, Response inResponse){
        // retrieve the banner image file name
        String tempFileName = inRequest.getParameter("BannerImageFileName");
        if ((tempFileName == null) || (tempFileName.trim().length() == 0)){
            myBannerPageImageFileName = null;
        }
        else{
            myBannerPageImageFileName = tempFileName;
        }
        String tempHostName = inRequest.getParameter("HostName");
        if ((tempHostName == null) || (tempHostName.trim().length() == 0)){
            getServer().setHostName(null);
        }
        else{
            getServer().setHostName(tempHostName);
        }
        String tempPortNumber = inRequest.getParameter("PortNumber");
        if ((tempHostName == null) || (tempHostName.trim().length() == 0)){
            // do nothing here
        }
        else{
            // try to parse the port number
            try{
                getServer().setPortNumber(Integer.parseInt(tempPortNumber));
            }
            catch (NumberFormatException e){
            }
        }
        showOptionsPage(inRequest, inResponse);
    }
    
    /** Show the heading page */
    public static void showHeaderPage(Request inRequest, Response inResponse, String inTitle){
        inResponse.setContentType("text/html");
        PrintWriter out = inResponse.getWriter();
        out.println("<HTML>");
        out.println("<HEAD>");
        out.println("<TITLE>"+inTitle+"</TITLE>");
        out.println("</HEAD>");
        out.println("<BODY bgcolor=\"#ffffcc\">");
        
        // Draw the image as the first thing.
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        if (myBannerPageImageFileName != null){
            out.println("<IMG SRC=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"="+UTF8Encoder.encode(myBannerPageImageFileName)+"\">");
        }
        else{
            out.println("<IMG SRC=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=adminbanner.png\">");
        }
        // write the navigation bar
        out.println("<table>");
        out.println("<tr><td>");
        out.println("<a href=\""+tempURLBase+"\">Server</a></td>");
        if (inRequest.getParameter(ServiceHandler.SERVICE_NAME_TAG) != null){
            out.println("<td><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inRequest.getParameter(ServiceHandler.SERVICE_NAME_TAG)+"\">Service</a></td>");
        }
        if (inRequest.getParameter(LayerHandler.LAYER_NAME_TAG) != null){
            out.println("<td><a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inRequest.getParameter(ServiceHandler.SERVICE_NAME_TAG)+"&"+LayerHandler.LAYER_NAME_TAG+"="+inRequest.getParameter(LayerHandler.LAYER_NAME_TAG)+"\">Layer</a></td>");
        }
        out.println("<td><a href=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_SHOW_OPTIONS+"\">Options</a></td>");
        out.println("<td><a href=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_SAVE_CONFIG+"\">Save Config</a></td>");
        out.println("</tr>");
        out.println("</table>");
        out.println("</br><HR SIZE=10 WIDTH=\"100%\" NOSHADE>");
        out.println("<P>");
        
    }
    
    /** Show the trailer part of the page. */
    public static void showTailerPage(Request inRequest, Response inResponse){
        PrintWriter out = inResponse.getWriter();
        out.println("</P>");
        out.println("</BODY>");
        out.println("</HTML>");
    }
    
    /** Retrieve an image from the images folder. */
    public void getImage(Request inRequest, Response inResponse)throws Exception{
        String tempName = inRequest.getParameter(IMAGE_NAME_TAG);
        if (tempName == null) return;
        String tempUCName = tempName.toUpperCase();
        inResponse.setContentType("application/octetstream");
        if (tempUCName.endsWith("PNG")){
            inResponse.setContentType("image/png");
        }
        if (tempUCName.endsWith("GIF")){
            inResponse.setContentType("image/gif");
        }
        if ((tempUCName.endsWith("JPEG"))||(tempUCName.endsWith("JPG"))){
            inResponse.setContentType("image/jpeg");
        }
        
        InputStream in = new ImageSource().getResource(tempName);
        if (in == null){
            // check on the file system
            File tempFile = new File(tempName);
            if (tempFile.exists()){
                in = new FileInputStream(tempFile);
            }
            else{
                return;
            }
        }
        OutputStream out = inResponse.getOutputStream();
        byte[] buff = new byte[1000];
        int length = in.read(buff);
        while (length != -1){
            out.write(buff,0,length);
            length = in.read(buff);
        }
        in.close();
        // out is closed by the web server when it is returned.
        return;
    }
    
    /** Show an error message to the user. */
    public static void showErrorPage(Request inRequest, Response inResponse, String inErrorString){
        showHeaderPage(inRequest, inResponse, "OOPS Error Occured.");
        PrintWriter out = inResponse.getWriter();
        out.println("<p>");
        out.println("<b>"+inErrorString+"</b>");
        out.println("</p>");
        showTailerPage(inRequest, inResponse);
    }
    /** Show an error message to the user. */
    public void saveConfig(Request inRequest, Response inResponse){
        try{
            getServer().saveConfig();
            showHeaderPage(inRequest, inResponse, "Config Saved");
            PrintWriter out = inResponse.getWriter();
            out.println("<p>");
            out.println("<b>Configuration Saved</b>");
            out.println("</p>");
            showTailerPage(inRequest, inResponse);
        }
        catch (Exception e){
            System.out.println(e);
            e.printStackTrace();
            showErrorPage(inRequest, inResponse, e.getMessage());
        }
    }

    /** Utility method for determining if a choice item should be selected. */
    public static String getSelected(int inValue, int inConstant){
        if(inValue == inConstant) return "Selected";
        return "";
    }
    /** Utility method for determining if a choice item should be selected. */
    public static String getChecked(int inValue, int inConstant){
        if(inValue == inConstant) return "Checked";
        return "";
    }
    
}
