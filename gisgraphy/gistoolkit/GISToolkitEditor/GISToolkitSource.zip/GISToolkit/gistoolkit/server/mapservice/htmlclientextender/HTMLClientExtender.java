/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.htmlclientextender;

import java.util.*;
import java.io.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.display.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.htmlclientextender.images.ImageSource;

/**
 * Extender to display the client applet to the user so they can browse the web service.
 */
public class HTMLClientExtender extends SimpleExtensionService{
    
    private static final String ACTION_TAG = "ACTION";
    private static final String ACTION_GETIMAGE = "GETIMAGE";
    private static final String ACTION_GET_SERVICE = "GET_SERVICE";
    private static final String SERVICE_NAME_TAG = "SERVICE_NAME";
    private static final String IMAGE_NAME_TAG = "IMAGE_NAME";
    private static final String LAYERS_TAG = "Layers";
    private static final String STYLES_TAG = "Styles";
    private static final String TOP_X_TAG = "TopX";
    private static final String TOP_Y_TAG = "TopY";
    private static final String BOTTOM_X_TAG = "BottomX";
    private static final String BOTTOM_Y_TAG = "BottomY";
    
    /** Place to get the banner image. */
    private static String myBannerPageImageFileName = null;
    /** set the banner page image file name. */
    public void setBannerPageImageFileName(String inFileName){myBannerPageImageFileName = inFileName;}
    /** Get the banner page image file name. */
    public String getBannerPageImageFileName(){return myBannerPageImageFileName;}
    
    private static final String CLIENT_EXTENDER_NODE="HTMLClientExtender";
    private static final String BANNER_IMAGE_TAG="BannerImage";
    /** Called to set the configuration information for this service. */
    public void setNode(Node inNode){
        String tempBannerPage = inNode.getAttribute(BANNER_IMAGE_TAG);
        if (tempBannerPage != null) setBannerPageImageFileName(tempBannerPage);
    }
    /** Called to get the configuration information for this service. */
    public Node getNode(){
        Node tempNode = new Node(CLIENT_EXTENDER_NODE);
        if (getBannerPageImageFileName() != null) tempNode.addAttribute(BANNER_IMAGE_TAG, getBannerPageImageFileName());
        return tempNode;
    }
    /** Called to identify this service.  */
    public String getName() {
        return "htmlclient";
    }
    
    /** Creates new ClientExtender */
    public HTMLClientExtender() {
    }
    
    /** Called when a request is sent to this service.  */
    public void doGet(Request inRequest, Response inResponse) throws Exception {
        String tempAction = inRequest.getParameter(ACTION_TAG);
        if (tempAction != null){
            if (tempAction.equalsIgnoreCase(ACTION_GETIMAGE)){
                getImage(inRequest, inResponse);
                return;
            }
        }
        String tempServiceName = inRequest.getParameter(SERVICE_NAME_TAG);
        if (tempServiceName != null){
            showMapPage(inRequest, inResponse, tempServiceName);
            return;
        }
        
        // ask the user to select a service.
        showSelectServicePage(inRequest, inResponse);
    }
    
    /** Allow the user to select a service.. */
    public void showSelectServicePage(Request inRequest, Response inResponse){
        
        // find out how many different map services are supported by this server.
        Server tempServer = getServer();
        Service[] tempServices = tempServer.getServices();
        showHeaderPage(inRequest, inResponse, "Client for Map Services");
        PrintWriter out = inResponse.getWriter();
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        if ((tempServices == null) || (tempServices.length == 0)){
            // Show a message indicating that no map services are currently configured.
            out.println("Sorry, there are no currently configured map services on this server.");
        }
        else if (tempServices.length == 1){
            // show the client for this particular map service.
            Service tempService = tempServices[0];
            String tempServicename = tempService.getServiceName();
            showMapPage(inRequest, inResponse, tempServicename);
        }
        else {
            out.println("<h1>Available Services</h1>");
            for (int i=0; i<tempServices.length; i++){
                out.println("<p><a href=\""+tempURLBase+"?"+SERVICE_NAME_TAG+"="+tempServices[i].getServiceName()+"\">"+tempServices[i].getServiceTitle()+"</a></P>");
            }
        }
        showTailerPage(inRequest, inResponse);
    }
    
    /** Retrieve an image from the images folder. */
    public void getImage(Request inRequest, Response inResponse)throws Exception{
        String tempName = inRequest.getParameter(IMAGE_NAME_TAG);
        if (tempName == null) return;
        String tempUCName = tempName.toUpperCase();
        inResponse.setContentType("application/octetstream");
        if (tempUCName.endsWith("PNG")){
            inResponse.setContentType("image/png");
        }
        if (tempUCName.endsWith("GIF")){
            inResponse.setContentType("image/gif");
        }
        if ((tempUCName.endsWith("JPEG"))||(tempUCName.endsWith("JPG"))){
            inResponse.setContentType("image/jpeg");
        }
        
        InputStream in = new ImageSource().getResource(tempName);
        if (in == null){
            // check on the file system
            File tempFile = new File(tempName);
            if (tempFile.exists()){
                in = new FileInputStream(tempFile);
            }
            else{
                return;
            }
        }
        OutputStream out = inResponse.getOutputStream();
        byte[] buff = new byte[1000];
        int length = in.read(buff);
        while (length != -1){
            out.write(buff,0,length);
            length = in.read(buff);
        }
        in.close();
        // out is closed by the web server when it is returned.
        return;
    }
    
    /** Show an error message. */
    public void showErrorPage(Request inRequest, Response inResponse, String inError){
        showHeaderPage(inRequest, inResponse, "Error in "+getName());
        PrintWriter out = inResponse.getWriter();
        out.println(inError);
        showTailerPage(inRequest, inResponse);
    }
    
    /** Show the heading page */
    public static void showHeaderPage(Request inRequest, Response inResponse, String inTitle){
        inResponse.setContentType("text/html");
        PrintWriter out = inResponse.getWriter();
        out.println("<HTML>");
        out.println("<HEAD>");
        out.println("<TITLE>"+inTitle+"</TITLE>");
        out.println("</HEAD>");
        out.println("<BODY bgcolor=\"#ffffcc\">");
    }
    
    /** Show the trailer part of the page. */
    public static void showTailerPage(Request inRequest, Response inResponse){
        PrintWriter out = inResponse.getWriter();
        out.println("</P>");
        out.println("</BODY>");
        out.println("</HTML>");
    }
    
    /** Show the selected Layers for this particular map server, and allow the users to turn them on or off. */
    public void showSelectLayersPage(Request inRequest, Response inResponse, String inServiceName){
        // determine which service this is.
        if (inServiceName == null) {
            showSelectServicePage(inRequest, inResponse);
            return;
        }
        else{
            Service tempService = getServer().getService(inServiceName);
            if (tempService == null){
                showErrorPage(inRequest, inResponse, "Service "+inServiceName+" Was not found on this server.");
                return;
            }
            
            // get the layers
            LayerDefinition[] tempDefinitions = tempService.getLayerDefinitions();
            if ((tempDefinitions == null) || (tempDefinitions.length == 0)){
                showErrorPage(inRequest, inResponse, "There are no Layers available for the "+tempService.getServiceTitle()+" Service");
                return;
            }
            
            // show the headings.
            showHeaderPage(inRequest, inResponse,"Select Layer for "+tempService.getServiceTitle());
            PrintWriter out = inResponse.getWriter();
            out.println("<div align=\"center\">");
            out.println("<h1><b>"+tempService.getServiceTitle()+"</b></h1>");
            
            // get the url base of the applet
            String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
            out.println("<form method=post ACTION="+tempURLBase+">");
            
            // loop through the layers.
            for (int i=0; i<tempDefinitions.length; i++){
                out.println("<div align=\"left\"><input type=\"checkbox\" name=\"Layer"+i+"\" value=\""+
                tempDefinitions[i].getLayerName()+"\">"+tempDefinitions[i].getLayerTitle()+"<br>");
                
                // list the styles for this layer.
                Style[] tempStyles = tempDefinitions[i].getStyles();
                if (tempStyles != null){
                    if (tempStyles.length == 1){
                        out.println("<input type=\"hidden\" name=Layer"+i+"Style0 value=\""+tempStyles[0].getStyleName()+">");
                    }
                    else{
                        out.println("<ul type=none>");
                        for (int j=0; j<tempStyles.length; j++){
                            out.println("<li><input type=\"radio\" name=Layer"+i+"Style value=\""+tempStyles[j].getStyleName()+"\">"+tempStyles[j].getStyleTitle()+"</li>");
                        }
                        out.println("</ul>");
                    }
                }
            }
            
            out.println("<input type=\"hidden\" name="+SERVICE_NAME_TAG+" value=\""+inServiceName+"\">");
            out.println("<br><input type=submit value=submit></br>");
            out.println("</form>");
        }
        showTailerPage(inRequest, inResponse);
    }
    
    /** Get the layers from the request. */
    public String[] getLayersStyles(Request inRequest, Response inResponse){
        String tempLayers = null;
        String tempStyles = null;
        tempLayers = inRequest.getParameter(LAYERS_TAG);
        tempStyles = inRequest.getParameter(STYLES_TAG);
        
        if (tempLayers == null){
            StringBuffer tempLayerString = new StringBuffer();
            StringBuffer tempStyleString = new StringBuffer();
            for (int i=0; i<100; i++){
                // look for the layer
                String tempLayer = inRequest.getParameter("Layer"+i);
                if (tempLayer != null){
                    if (tempLayerString.length()>0) tempLayerString.append(",");
                    if (tempStyleString.length()>0) tempStyleString.append(",");
                    tempLayerString.append(tempLayer);
                    
                    // look for the Style for the layer
                    String tempStyle = inRequest.getParameter("Layer"+i+"Style");
                    if (tempStyle != null){
                        tempStyleString.append(tempStyle);
                    }
                    else tempStyleString.append("Default");
                }
            }
            if (tempLayerString.length() > 0){
                tempLayers = tempLayerString.toString();
                tempStyles = tempStyleString.toString();
            }
        }
        
        String[] tempReturnStrings = new String[2];
        tempReturnStrings[0] = tempLayers;
        tempReturnStrings[1] = tempStyles;
        return tempReturnStrings;
    }
    /** Show the map page. */
    public void showMapPage(Request inRequest, Response inResponse, String inServiceName){
        // determine which service this is.
        if (inServiceName == null) {
            showSelectServicePage(inRequest, inResponse);
            return;
        }
        else{
            Service tempService = getServer().getService(inServiceName);
            if (tempService == null){
                showErrorPage(inRequest, inResponse, "Service "+inServiceName+" Was not found on this server.");
                return;
            }
            
            // get the selected layers.
            String[] tempLayersStyles = getLayersStyles(inRequest, inResponse);
            String tempSelectedLayers = tempLayersStyles[0];
            String tempSelectedStyles = tempLayersStyles[1];
            String[] tempLayers = null;
            String[] tempStyles = null;
            if (tempSelectedLayers == null){
                LayerDefinition[] tempDefinitions = tempService.getLayerDefinitions();
                if ((tempDefinitions != null) && (tempDefinitions.length == 1)){
                    tempSelectedLayers = tempDefinitions[0].getLayerName();
                    tempLayers = new String[1];
                    tempLayers[0] = tempSelectedLayers;
                    tempStyles = new String[1];
                    if ((tempDefinitions[0].getStyles() != null) && (tempDefinitions[0].getStyles().length > 0)){
                        tempStyles[0] = tempDefinitions[0].getStyles()[0].getStyleName();
                    }
                    else{
                        tempStyles[0] = "Default";
                    }
                }
                else{
                    showSelectLayersPage(inRequest, inResponse, inServiceName);
                    return;
                }
            }
            else{
                // parse the layers.
                ArrayList ar = new ArrayList();
                StringTokenizer st = new StringTokenizer(tempSelectedLayers, ",");
                while (st.hasMoreElements()){
                    ar.add(st.nextElement());
                }
                if (ar.size() == 0) {
                    showSelectLayersPage(inRequest, inResponse, inServiceName);
                    return;
                }
                tempLayers = new String[ar.size()];
                ar.toArray(tempLayers);
                // parse the styles
                ar = new ArrayList();
                st = new StringTokenizer(tempSelectedStyles, ",");
                while (st.hasMoreElements()){
                    ar.add(st.nextElement());
                }
                if (ar.size() == 0) {
                    showSelectLayersPage(inRequest, inResponse, inServiceName);
                    return;
                }
                tempStyles = new String[ar.size()];
                ar.toArray(tempStyles);
                
            }
            
            // find the first layer
            LayerDefinition tempLayerDefinition = tempService.getLayerDefinition(tempLayers[0]);
            if (tempLayerDefinition == null){
                for (int i=1; i<tempLayers.length; i++){
                    tempLayerDefinition = tempService.getLayerDefinition(tempLayers[i]);
                    if (tempLayerDefinition != null) break;
                }
            }
            
            // get the zoom level of the map.
            try{
                Envelope tempEnvelope = tempLayerDefinition.getLayer().getEnvelope();
                double tempTopX = tempEnvelope.getMinX();
                double tempTopY = tempEnvelope.getMaxY();
                double tempBottomX = tempEnvelope.getMaxX();
                double tempBottomY = tempEnvelope.getMinY();
                String tempString = inRequest.getParameter(TOP_X_TAG);
                if (tempString != null) try{tempTopX = Double.parseDouble(tempString);}catch (NumberFormatException e){};
                tempString = inRequest.getParameter(TOP_Y_TAG);
                if (tempString != null) try{tempTopY = Double.parseDouble(tempString);}catch (NumberFormatException e){};
                tempString = inRequest.getParameter(BOTTOM_X_TAG);
                if (tempString != null) try{tempBottomX = Double.parseDouble(tempString);}catch (NumberFormatException e){};
                tempString = inRequest.getParameter(BOTTOM_Y_TAG);
                if (tempString != null) try{tempBottomY = Double.parseDouble(tempString);}catch (NumberFormatException e){};
                
                // get the url base of the applet
                String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
                
                // The url to send back to pan the map
                String tempPanBase = tempURLBase
                +"?"+SERVICE_NAME_TAG+"="+inServiceName
                +"&"+LAYERS_TAG+"="+tempSelectedLayers
                +"&"+STYLES_TAG+"="+tempSelectedStyles;
                double tempWorldWidth = tempBottomX - tempTopX;
                double tempWorldHeight = tempTopY-tempBottomY;
                
                String tempPanNW = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth/2)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight/2)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - tempWorldWidth/2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + tempWorldHeight/2);
                String tempPanN = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight/2)
                +"&"+BOTTOM_X_TAG+"="+tempBottomX
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + tempWorldHeight/2);
                String tempPanNE = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + tempWorldWidth/2)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight/2)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth/2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + tempWorldHeight/2);
                String tempPanE = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + tempWorldWidth/2)
                +"&"+TOP_Y_TAG+"="+(tempTopY)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth/2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY);
                String tempPanSE = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + tempWorldWidth/2)
                +"&"+TOP_Y_TAG+"="+(tempTopY - tempWorldHeight/2)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth/2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight/2);
                String tempPanS = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX)
                +"&"+TOP_Y_TAG+"="+(tempTopY - tempWorldHeight/2)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight/2);
                String tempPanSW = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth/2)
                +"&"+TOP_Y_TAG+"="+(tempTopY - tempWorldHeight/2)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - tempWorldWidth/2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight/2);
                String tempPanW = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth/2)
                +"&"+TOP_Y_TAG+"="+(tempTopY)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - tempWorldWidth/2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY);
                String tempZoomIn1 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + tempWorldWidth/4)
                +"&"+TOP_Y_TAG+"="+(tempTopY - tempWorldHeight/4)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - tempWorldWidth/4)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + tempWorldHeight/4);
                String tempZoomIn2 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + (tempWorldWidth/4 + tempWorldWidth/8))
                +"&"+TOP_Y_TAG+"="+(tempTopY - (tempWorldHeight/4 + tempWorldHeight/8))
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - (tempWorldWidth/4 + tempWorldWidth/8))
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + (tempWorldHeight/4 + tempWorldHeight/8));
                String tempZoomIn3 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + (tempWorldWidth/4 + tempWorldWidth/8 + tempWorldWidth/16))
                +"&"+TOP_Y_TAG+"="+(tempTopY - (tempWorldHeight/4 + tempWorldHeight/8 + tempWorldHeight/16))
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - (tempWorldWidth/4 + tempWorldWidth/8 + tempWorldWidth/16))
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + (tempWorldHeight/4 + tempWorldHeight/8 + tempWorldHeight/16));
                String tempZoomIn4 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + (tempWorldWidth/4 + tempWorldWidth/8 + tempWorldWidth/16 + tempWorldWidth/32))
                +"&"+TOP_Y_TAG+"="+(tempTopY - (tempWorldHeight/4 + tempWorldHeight/8 + tempWorldHeight/16 + tempWorldHeight/32))
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - (tempWorldWidth/4 + tempWorldWidth/8 + tempWorldWidth/16 + tempWorldWidth/32))
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + (tempWorldHeight/4 + tempWorldHeight/8 + tempWorldHeight/16 + tempWorldHeight/32));
                String tempZoomIn5 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX + (tempWorldWidth/4 + tempWorldWidth/8 + tempWorldWidth/16 + tempWorldWidth/32 + tempWorldWidth/64))
                +"&"+TOP_Y_TAG+"="+(tempTopY - (tempWorldHeight/4 + tempWorldHeight/8 + tempWorldHeight/16 + tempWorldHeight/32 + tempWorldHeight/64))
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX - (tempWorldWidth/4 + tempWorldWidth/8 + tempWorldWidth/16 + tempWorldWidth/32 + tempWorldWidth/64))
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY + (tempWorldHeight/4 + tempWorldHeight/8 + tempWorldHeight/16 + tempWorldHeight/32 + tempWorldHeight/64));
                String tempZoomOut1 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth/2)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight/2)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth/2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight/2);
                String tempZoomOut2 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight);
                String tempZoomOut3 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth*2)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight*2)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth*2)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight*2);
                String tempZoomOut4 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth*4)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight*4)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth*4)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight*4);
                String tempZoomOut5 = tempPanBase
                +"&"+TOP_X_TAG+"="+(tempTopX - tempWorldWidth*8)
                +"&"+TOP_Y_TAG+"="+(tempTopY + tempWorldHeight*8)
                +"&"+BOTTOM_X_TAG+"="+(tempBottomX + tempWorldWidth*8)
                +"&"+BOTTOM_Y_TAG+"="+(tempBottomY - tempWorldHeight*8);
                
                
                // show the map and surrounding navigation.
                PrintWriter out = inResponse.getWriter();
                out.println("<html>");
                out.println("<head>");
                out.println("<title>"+tempService.getServiceTitle()+"</title>");
                out.println("</head>");
                out.println("<body bgcolor=\"#ffffcc\">");
                out.println("<table>");
                out.println("   <tr>");
                out.println("       <td>");
                out.println("<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" width=\"658\">");
                out.println("<tbody>");
                out.println("<tr>");
                out.println("<td valign=\"top\"><br>");
                out.println("</td>");
                out.println("<td valign=\"top\" align=\"center\">");
                out.println("<h1>"+tempService.getServiceTitle()+"</h1>");
                out.println("</td>");
                out.println("<td valign=\"top\"><br>");
                out.println("</td>");
                out.println("</tr>");
                out.println("<tr>");
                out.println("<td valign=\"top\"><a href=\""+tempPanNW+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=NWCorner.png\" alt=\"NWNav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("<td valign=\"top\" align=\"center\" width=\"638\"><a href=\""+tempPanN+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=NorthBar.png\" alt=\"NorthNav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("<td valign=\"top\"><a href=\""+tempPanNE+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=NECorner.png\" alt=\"NWNav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("</tr>");
                out.println("<tr>");
                out.println("<td valign=\"middle\"><a href=\""+tempPanW+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=WestBar.png\" alt=\"EastNav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("<td valign=\"middle\" height=\"536\" width=\"638\"><img src=\""+tempURLBase.substring(0, tempURLBase.lastIndexOf('/'))+"/"+tempService.getServiceName()+"?"+"Request=map&WMTVER=1.0.0&Layers="+tempSelectedLayers+"&Styles="+tempSelectedStyles+"&SRS=EPSG%3A4326&BBOX="+tempTopX+","+tempBottomY+","+tempBottomX+","+tempTopY+"&Width=638&Height=536&FORMAT=PNG\">");
                out.println("<br>");
                out.println("</td>");
                out.println("<td valign=\"middle\"><a href=\""+tempPanE+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=EastBar.png\" alt=\"WestNav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("</tr>");
                out.println("<tr>");
                out.println("<td valign=\"top\"><a href=\""+tempPanSW+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=SWCorner.png\" alt=\"SWNav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("<td valign=\"top\" align=\"center\"><a href=\""+tempPanS+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=SouthBar.png\" alt=\"SouthNav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("<td valign=\"top\"><a href=\""+tempPanSE+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=SECorner.png\" alt=\"SENav\" border=0></a>");
                out.println("<br>");
                out.println("</td>");
                out.println("</tr>");
                out.println("</tbody>");
                out.println("</table>");
                
                // the zoom in bar at the bottom.
                out.println("<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"1%\">");
                out.println("<tbody>");
                out.println("<tr>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomOut1+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Minus.png\" alt=\"Plus\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomOut5+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomOut4+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomOut3+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomOut2+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomOut1+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=BarS.png\" alt=\"Bar\">");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomIn1+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomIn2+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomIn3+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomIn4+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomIn5+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Bar.png\" alt=\"Bar\" border=0></a>");
                out.println("</td>");
                out.println("<td valign=\"center\"><a href=\""+tempZoomIn1+"\"><img src=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=Plus.png\" alt=\"Minus\" border=0></a>");
                out.println("</td>");
                out.println("</tr>");
                
                out.println("</tbody>");
                out.println("</table>");
                out.println("<br>");
                out.println("       </td>");
                out.println("       <td>");
                // show the form that allows the user to select the layers and styles.
                out.println("<form method=post ACTION="+tempURLBase+">");
                
                // get the layers
                LayerDefinition[] tempDefinitions = tempService.getLayerDefinitions();
                if ((tempDefinitions == null) || (tempDefinitions.length == 0)){
                    showErrorPage(inRequest, inResponse, "There are no Layers available for the "+tempService.getServiceTitle()+" Service");
                    return;
                }
                // loop through the layers.
                for (int i=0; i<tempDefinitions.length; i++){
                    
                    // determine if this layer is currently selected.
                    String tempLayerName = tempDefinitions[i].getLayerName();
                    String tempSelected = "";
                    String tempSelectedStyle = "Default";
                    for (int j=0; j<tempLayers.length; j++){
                        if (tempLayerName.equalsIgnoreCase(tempLayers[j])){
                            tempSelected = " checked";
                            tempSelectedStyle = tempStyles[j];
                            break;
                        }
                    }
                    out.println("<div align=\"left\"><input type=\"checkbox\" name=\"Layer"+i+"\" value=\""+tempDefinitions[i].getLayerName()+"\" "+tempSelected+">"+tempDefinitions[i].getLayerTitle()+"<br>");
                    
                    // list the styles for this layer.
                    Style[] tempAvailableStyles = tempDefinitions[i].getStyles();
                    if (tempAvailableStyles != null){
                        if (tempAvailableStyles.length == 1){
                            out.println("<input type=\"hidden\" name=Layer"+i+"Style0 value=\""+tempAvailableStyles[0].getStyleName()+"\">");
                        }
                        else{
                            out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name=Layer"+i+"Style>");
                            for (int j=0; j<tempAvailableStyles.length; j++){
                                tempSelected = "";
                                if (tempAvailableStyles[j].getStyleName().equalsIgnoreCase(tempSelectedStyle)) tempSelected = " selected";
                                out.println("<option value=\""+tempAvailableStyles[j].getStyleName()+"\" "+tempSelected+">"+tempAvailableStyles[j].getStyleTitle());
                            }
                            out.println("</select>");
                        }
                    }
                }
                out.println("<input type=\"hidden\" name="+TOP_X_TAG+" value=\""+tempTopX+"\">");
                out.println("<input type=\"hidden\" name="+TOP_Y_TAG+" value=\""+tempTopY+"\">");
                out.println("<input type=\"hidden\" name="+BOTTOM_X_TAG+" value=\""+tempBottomX+"\">");
                out.println("<input type=\"hidden\" name="+BOTTOM_Y_TAG+" value=\""+tempBottomY+"\">");
                out.println("<input type=\"hidden\" name="+SERVICE_NAME_TAG+" value=\""+inServiceName+"\">");
                out.println("<br><input type=submit value=submit></br>");
                out.println("</form>");
                out.println("       </td>");
                out.println("   </td>");
                out.println("<table>");
                out.println("</body>");
                out.println("</html>");
            }
            catch (Exception e){
                showErrorPage(inRequest, inResponse, e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
