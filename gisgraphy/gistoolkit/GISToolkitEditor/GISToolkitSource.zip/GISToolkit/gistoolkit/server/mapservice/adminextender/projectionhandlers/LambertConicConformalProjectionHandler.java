/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender.projectionhandlers;
import java.io.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.projection.*;
import gistoolkit.server.mapservice.adminextender.AdminExtender;
import gistoolkit.server.mapservice.adminextender.ServiceHandler;
import gistoolkit.server.mapservice.adminextender.LayerHandler;
import gistoolkit.server.mapservice.adminextender.ProjectionHandler;

/**
 *
 */
public class LambertConicConformalProjectionHandler {
    private static final String LCC_ACTION_TAG = "LCC_ACTION";
    private static final String LCC_ACTION_UPDATE = "LCC_UPDATE";
    
    /** Creates new RangeShaderHandler */
    public LambertConicConformalProjectionHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, Projection inProjection) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(LCC_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, null, inProjection);
            return;
        }
        showLCCPage(inRequest, inResponse, inServer, inService, null, inProjection);
    }
     public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(LCC_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inProjection);
            return;
        }
        showLCCPage(inRequest, inResponse, inServer, inService, inLayer, inProjection);
    }
   public static void showLCCPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection){
        LambertConicConformalProjection tempProjection = null;
        if (inProjection instanceof LambertConicConformalProjection){
            tempProjection = (LambertConicConformalProjection) inProjection;
        }
        else{
            tempProjection = new LambertConicConformalProjection();
            try{
                if (inLayer == null) inService.setProjection(tempProjection);
                else inLayer.setFromProjection(tempProjection);
            }
            catch (Exception e){
                AdminExtender.showErrorPage(inRequest, inResponse, "Error setting NoProjection "+e);
                return;
            }
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Projection "+tempProjection.getProjectionName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        out.println("<b>Attributes of the the Lambert Connic Conformal Projection.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // Show the shader parameters
        out.println("<br>A conformal conic projection. Also known as the Conic Orthomorphic projection. A USGS and Manifold favorite for maps of the US.");
        out.println("<p>First Parallel: <input type=text name=lat1 value=\""+tempProjection.getLatitude1()+"\"></p>");
        out.println("<p>Second Parallel: <input type=text name=lat2 value=\""+tempProjection.getLatitude2()+"\"></p>");
        out.println("<p>Original Latitude: <input type=text name=OrigLat value=\""+tempProjection.getLatOragin()+"\"></p>");
        out.println("<p>Original Longitude: <input type=text name=OrigLon value=\""+tempProjection.getLonOragin()+"\"></p>");
        out.println("<p>Northing Offset: <input type=text name=Northing value=\""+tempProjection.getNorthing()+"\"></p>");
        out.println("<p>Easting Offset: <input type=text name=Easting value=\""+tempProjection.getEasting()+"\"></p>");
        
        // Select a SRS (Spatial Reference System) For this projection.
        if (inLayer == null){
            out.println("<p><b>SRS</b> (Spatial Reference System) If you define an AUTO type, the client can set the orriginal latitude and longitude.</p>");
            out.println("<p>Auto types are of the form AUTO:ProjectionCode:UnitCode.  The ProjectionCodes 42400-42499 are reserved for private use, and the unit code for Metre is 9001, and kilometer is 9036 a typical Auto tag for this type is \"AUTO:42401:9001\"</p>");
            out.println("<p>For more information on auto projections, visit <a href=\"http://www.digitalearth.gov/wmt/auto.html\">http://www.digitalearth.gov/wmt/auto.html</a></p>");
            out.println("<p><input type=text name=SRS value=\""+inService.getSRS()+"\"></p>");
        }
        
        out.println("<p><input type=submit value=submit></p>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value=\""+inService.getServiceName()+"\">");
        if (inLayer != null) out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value=\""+inLayer.getLayerName()+"\">");
        out.println("<input type=hidden name="+ProjectionHandler.PROJECTION_NAME_TAG+" value=\""+tempProjection.getProjectionName()+"\">");
        out.println("<p><input type=hidden name="+LCC_ACTION_TAG+" value="+LCC_ACTION_UPDATE+"></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    /** Handle action events. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection){
        if (inLayer == null){
            // store the SRS.
            String tempSRS = inRequest.getParameter("SRS");
            if (tempSRS != null) inService.setSRS(tempSRS);
        }
        // set the LCC parameters.
        // parse the latitude 1
        LambertConicConformalProjection tempProjection = null;
        if (inProjection instanceof LambertConicConformalProjection){
            tempProjection = (LambertConicConformalProjection) inProjection;
            String tempString = inRequest.getParameter("lat1");
            if (tempString != null){
                try{
                    double tempLat1 = Double.parseDouble(tempString);
                    tempProjection.setLatitude1(tempLat1);
                }
                catch (NumberFormatException e){}
            }
            tempString = inRequest.getParameter("lat2");
            if (tempString != null){
                try{
                    double tempLat2 = Double.parseDouble(tempString);
                    tempProjection.setLatitude2(tempLat2);
                }
                catch (NumberFormatException e){}
            }
            tempString = inRequest.getParameter("OrigLat");
            if (tempString != null){
                try{
                    double tempOrigLat = Double.parseDouble(tempString);
                    tempProjection.setLatOragin(tempOrigLat);
                }
                catch (NumberFormatException e){}
            }
            tempString = inRequest.getParameter("OrigLon");
            if (tempString != null){
                try{
                    double tempOrigLon = Double.parseDouble(tempString);
                    tempProjection.setLonOragin(tempOrigLon);
                }
                catch (NumberFormatException e){}
            }
            tempString = inRequest.getParameter("Northing");
            if (tempString != null){
                try{
                    double tempNorthing = Double.parseDouble(tempString);
                    tempProjection.setNorthing(tempNorthing);
                }
                catch (NumberFormatException e){}
            }
            tempString = inRequest.getParameter("Easting");
            if (tempString != null){
                try{
                    double tempEasting = Double.parseDouble(tempString);
                    tempProjection.setEasting(tempEasting);
                }
                catch (NumberFormatException e){}
            }
        }        
        // redisplay the LCC pate.
        showLCCPage(inRequest, inResponse, inServer, inService, inLayer, inProjection);
    }
    public static String getProjectionName(){return new LambertConicConformalProjection().getProjectionName();}
}
