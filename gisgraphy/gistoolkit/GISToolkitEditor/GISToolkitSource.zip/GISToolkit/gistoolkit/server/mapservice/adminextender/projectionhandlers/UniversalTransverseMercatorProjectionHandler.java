/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender.projectionhandlers;
import java.io.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.projection.*;
import gistoolkit.server.mapservice.adminextender.AdminExtender;
import gistoolkit.server.mapservice.adminextender.ServiceHandler;
import gistoolkit.server.mapservice.adminextender.LayerHandler;
import gistoolkit.server.mapservice.adminextender.ProjectionHandler;

/**
 *
 */
public class UniversalTransverseMercatorProjectionHandler {
    private static final String UTC_ACTION_TAG = "UTC_ACTION";
    private static final String UTC_ACTION_UPDATE = "UTC_UPDATE";
    
    /** Creates new RangeShaderHandler */
    public UniversalTransverseMercatorProjectionHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, Projection inProjection) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(UTC_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, null, inProjection);
            return;
        }
        showUTCPage(inRequest, inResponse, inServer, inService, null, inProjection);
    }
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(UTC_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inProjection);
            return;
        }
        showUTCPage(inRequest, inResponse, inServer, inService, inLayer, inProjection);
    }
    public static void showUTCPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection){
        UniversalTransverseMercatorProjection tempProjection = null;
        if (inProjection instanceof UniversalTransverseMercatorProjection){
            tempProjection = (UniversalTransverseMercatorProjection) inProjection;
        }
        else{
            tempProjection = new UniversalTransverseMercatorProjection();
            try{
                if (inLayer == null) inService.setProjection(tempProjection);
                else inLayer.setFromProjection(tempProjection);
            }
            catch (Exception e){
                AdminExtender.showErrorPage(inRequest, inResponse, "Error setting NoProjection "+e);
                return;
            }
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Projection "+tempProjection.getProjectionName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        out.println("<b>Attributes of the the Universal Transverse Mercator Projection. Projection.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // Show the shader parameters
        out.println("<p>Select the UTM Zone that you would like projected to.</p>");
        out.println("<p><SELECT NAME=ZONE>");
        int tempZone = tempProjection.getZone();
        for (int i=1; i<=60; i++){
            if (i == tempZone) out.println("<OPTION SELECTED VALUE="+i+">"+i);
            else out.println("<OPTION VALUE="+i+">"+i);
        }
        out.println("</select></p>");
        
        // northern or sothern hemisphere.
        out.println("<p><SELECT NAME=Northing>");
        double tempNorthing = tempProjection.getNorthing();
        if (tempNorthing == 0){
            out.println("<OPTION SELECTED VALUE=0>North");
            out.println("<OPTION VALUE=10000000>South");
        }
        else{
            out.println("<OPTION VALUE=0>North");
            out.println("<OPTION SELECTED VALUE=10000000>South");
        }
        out.println("</select></p>");
        
        // Select a SRS (Spatial Reference System) For this projection.
        if (inLayer == null){
            out.println("<p><b>SRS</b> (Spatial Reference System).</p>");
            out.print("<p><input type=text name=SRS value=\""+inService.getSRS()+"\"></p>");
        }
        
        out.println("<p><input type=submit value=submit></p>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value=\""+inService.getServiceName()+"\">");
        if (inLayer != null) out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value=\""+inLayer.getLayerName()+"\">");
        out.println("<input type=hidden name="+ProjectionHandler.PROJECTION_NAME_TAG+" value=\""+tempProjection.getProjectionName()+"\">");
        out.println("<p><input type=hidden name="+UTC_ACTION_TAG+" value="+UTC_ACTION_UPDATE+"></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    /** Handle action events. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection){
        if (inLayer == null){
            // store the SRS.
            String tempSRS = inRequest.getParameter("SRS");
            if (tempSRS != null) inService.setSRS(tempSRS);
        }
        // set the UTC parameters.
        // parse the latitude 1
        UniversalTransverseMercatorProjection tempProjection = null;
        if (inProjection instanceof UniversalTransverseMercatorProjection){
            tempProjection = (UniversalTransverseMercatorProjection) inProjection;
            String tempString = inRequest.getParameter("Zone");
            if (tempString != null){
                try{
                    int tempZone = Integer.parseInt(tempString);
                    tempProjection.setZone(tempZone);
                }
                catch (Exception e){}
            }
            tempString = inRequest.getParameter("Northing");
            if (tempString != null){
                try{
                    int tempNorthing = Integer.parseInt(tempString);
                    tempProjection.setNorthing(tempNorthing);
                }
                catch (Exception e){}
            }
        }        
        // redisplay the UTC pate.
        showUTCPage(inRequest, inResponse, inServer, inService, inLayer, inProjection);
    }
    public static String getProjectionName(){return new UniversalTransverseMercatorProjection().getProjectionName();}
}
