/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */
package gistoolkit.server.mapservice.adminextender.labelerhandlers;
import java.io.*;
import gistoolkit.display.*;
import gistoolkit.display.labeler.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.*;

/**
 * Class to handle the HTML editing of simple labelers.
 */
public class SimpleLabelerHandler {
    public static final String SIMPLE_LABELER_ACTION_TAG = "SIMPLE_LABELER_ACTION";
    public static final String SIMPLE_LABELER_ACTION_UPDATE = "UPDATE";
    public static final String SIMPLE_LABELER_LABEL_COLUMN_TAG = "SLLC";
    public static final String SIMPLE_LABELER_LABEL_DIRECTION_TAG = "SLLDIR";
    public static final String SIMPLE_LABELER_LABEL_DISTANCE_TAG = "SLLDIS";
    public static final String SIMPLE_LABELER_ALLOW_DUPLICATE_TAG = "SLLADUP";
    public static final String SIMPLE_LABELER_ALLOW_OVERLAPS_TAG = "SLLAOVL";
    
    /** Creates a new instance of SimpleLabelerHandler */
    public SimpleLabelerHandler() {
    }
    
    /** Handle requests for this labeler. */
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Labeler inLabeler, int inLabelerIndex) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(SIMPLE_LABELER_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inStyle, inLabeler, inLabelerIndex, tempString);
            return;
        }
        showSimpleLabelerPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inLabeler, inLabelerIndex);
    }    
    
    public static void showSimpleLabelerPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Labeler inLabeler, int inLabelerIndex) throws Exception{
        SimpleLabeler tempLabeler = null;
        
        // ensure that we are working with a SimpleLabeler.
        if (inLabeler instanceof SimpleLabeler){
            tempLabeler = (SimpleLabeler) inLabeler;
        }
        else{
            tempLabeler = new FeatureLabeler();
            inStyle.setLabeler(inLabelerIndex, tempLabeler);
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Labeler "+inLabeler.getLabelerName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        // index of the column to label by.
        out.println("<b>Labeler Parameters..</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // show the line color
        out.println("The index of the column to label by.");
        out.println("<p>");
        out.println("<input type=text name=\""+SIMPLE_LABELER_LABEL_COLUMN_TAG+"\" value=\""+tempLabeler.getLabelColumn()+"\">");
        out.println("</p>");
        out.println("<p>");
        out.println("The orientation of the label relative to the anchor point.");        
        out.println("</p>");
        out.println("<p>");
        
        int tempOrientation = tempLabeler.getLabelOrientation();
        out.println("<input type=radio name=\""+SIMPLE_LABELER_LABEL_DIRECTION_TAG+"\" value=\""+SimpleLabeler.CENTER+"\" "+AdminExtender.getChecked(SimpleLabeler.CENTER, tempOrientation)+">Center");
        out.println("<input type=radio name=\""+SIMPLE_LABELER_LABEL_DIRECTION_TAG+"\" value=\""+SimpleLabeler.NORTH+"\" "+AdminExtender.getChecked(SimpleLabeler.NORTH, tempOrientation)+">North");
        out.println("<input type=radio name=\""+SIMPLE_LABELER_LABEL_DIRECTION_TAG+"\" value=\""+SimpleLabeler.EAST+"\" "+AdminExtender.getChecked(SimpleLabeler.EAST, tempOrientation)+">East");
        out.println("<input type=radio name=\""+SIMPLE_LABELER_LABEL_DIRECTION_TAG+"\" value=\""+SimpleLabeler.SOUTH+"\" "+AdminExtender.getChecked(SimpleLabeler.SOUTH, tempOrientation)+">South");
        out.println("<input type=radio name=\""+SIMPLE_LABELER_LABEL_DIRECTION_TAG+"\" value=\""+SimpleLabeler.WEST+"\" "+AdminExtender.getChecked(SimpleLabeler.WEST, tempOrientation)+">West");
        out.println("</p>");
        out.println("<p>");
        out.println("The distance (in pixels) the label should be drawn from the anchor point.");        
        out.println("</p>");
        out.println("<p>");
        out.println("<input type=text name=\""+SIMPLE_LABELER_LABEL_DISTANCE_TAG+"\" value=\""+tempLabeler.getLabelOffset()+"\">");
        out.println("</p>");
        
        // indicates whether duplicates are allowed.
        out.println("<p>");
        String tempDupChecked = "";
        if (tempLabeler.getAllowDuplicates()){
            tempDupChecked = "Checked";
        }
        out.println("<input type=checkbox name=\""+SIMPLE_LABELER_ALLOW_DUPLICATE_TAG+"\" "+tempDupChecked+" >Allow Duplicates");
        out.println("</p>");
        
        // indicates whether overlaps are allowed.
        out.println("<p>");
        String tempOVChecked = "";
        if (tempLabeler.getAllowOverlaps()){
            tempOVChecked = "Checked";
        }
        out.println("<input type=checkbox name=\""+SIMPLE_LABELER_ALLOW_OVERLAPS_TAG+"\" "+tempOVChecked+" >Allow Overlaps");
        out.println("</p>");
        
        // hidden fields to get back to this labeler handler.
        out.println("<p>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+LabelerHandler.LABELER_NUM_TAG+" value="+inLabelerIndex+">");
        out.println("<input type=hidden name="+SIMPLE_LABELER_ACTION_TAG+" value="+SIMPLE_LABELER_ACTION_UPDATE+">");        
        
        // include a submit button.
        out.println("<p><input type=submit value=submit></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);        
    }

    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Labeler inLabeler, int inLabelerIndex, String inAction) throws Exception{
        SimpleLabeler tempLabeler = null;
        
        // ensure that we are working with a SimpleLabeler.
        if (inLabeler instanceof SimpleLabeler){
            tempLabeler = (SimpleLabeler) inLabeler;
        }
        else{
            AdminExtender.showErrorPage(inRequest, inResponse, "Editing of SimpleLabeler requested but "+inLabeler.getLabelerName()+" is not a SimpleLabeler.");
            return;
        }
        if (inAction.equalsIgnoreCase(SIMPLE_LABELER_ACTION_UPDATE)){
            
            // Label Column Tag
            String tempString = inRequest.getParameter(SIMPLE_LABELER_LABEL_COLUMN_TAG);
            if (tempString != null){
                try{
                    int tempInt = Integer.parseInt(tempString);
                    tempLabeler.setLabelColumn(tempInt);
                }
                catch (NumberFormatException e){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing Labeler Columnt Tag ("+SIMPLE_LABELER_LABEL_COLUMN_TAG+") \""+tempString+"\" is not an integer");
                    return;
                }
            }
            
            // Label Orientation
            tempString = inRequest.getParameter(SIMPLE_LABELER_LABEL_DIRECTION_TAG);
            if (tempString != null){
                try{
                    int tempInt = Integer.parseInt(tempString);
                    tempLabeler.setLabelOrientation(tempInt);
                }
                catch (NumberFormatException e){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing Labeler Direction Tag ("+SIMPLE_LABELER_LABEL_DIRECTION_TAG+") \""+tempString+"\" is not an integer");
                    return;
                }
            }
            
            // Label Distance.
            tempString = inRequest.getParameter(SIMPLE_LABELER_LABEL_DISTANCE_TAG);
            if (tempString != null){
                try{
                    int tempInt = Integer.parseInt(tempString);
                    tempLabeler.setLabelOffset(tempInt);
                }
                catch (NumberFormatException e){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing Labeler Distance Tag ("+SIMPLE_LABELER_LABEL_DISTANCE_TAG+") \""+tempString+"\" is not an integer");
                    return;
                }
            }
            
            // allow duplicates
            tempString = inRequest.getParameter(SIMPLE_LABELER_ALLOW_DUPLICATE_TAG);
            if (tempString == null){
                tempLabeler.setAllowDuplicates(false);
            }
            else{
                tempLabeler.setAllowDuplicates(true);
            }
            
            // allow overlaps
            tempString = inRequest.getParameter(SIMPLE_LABELER_ALLOW_OVERLAPS_TAG);
            if (tempString == null){
                tempLabeler.setAllowOverlaps(false);
            }
            else{
                tempLabeler.setAllowOverlaps(true);
            }
        }
        
        // Show the updated page.
        showSimpleLabelerPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inLabeler, inLabelerIndex);
    }
}
