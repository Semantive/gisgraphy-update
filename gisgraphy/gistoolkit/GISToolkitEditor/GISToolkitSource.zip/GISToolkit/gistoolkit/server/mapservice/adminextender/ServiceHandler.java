/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender;

import java.io.*;
import java.awt.*;
import gistoolkit.features.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.datasources.shapefile.*;
import gistoolkit.datasources.seamless.*;
import gistoolkit.datasources.db2spatialextender.*;
import gistoolkit.datasources.postgis.*;
import gistoolkit.datasources.terraserver.*;
import gistoolkit.datasources.imagefile.*;
import gistoolkit.display.*;

/**
 * Class to handle Configuration of the service from a web page.
 */
public class ServiceHandler {
    public static final String SERVICE_NAME_TAG = "SERVICE_NAME";
    private static final String SERVICE_ACTION_TAG = "SERVICE_ACTION";
    private static final String SERVICE_ACTION_UPDATE = "UPDATE";
    private static final String SERVICE_ACTION_SHOW_ADD_LAYER = "SHOW_ADD_LAYER";
    private static final String SERVICE_ACTION_SHOW_ADD_LAYER_DATASOURCE = "SHOW_ADD_LAYER_DATASOURCE";
    private static final String SERVICE_ACTION_ADD_LAYER = "ADD_LAYER";
    private static final String SERVICE_ACTION_DELETE_LAYER = "DELETE_LAYER";
    private static final String SERVICE_ACTION_EDIT_PROJECTION = "EDIT_PROJECTION";
    private static final String SERVICE_ACTION_EDIT_SCALEBAR = "EDIT_SCALEBAR";
    
    /** Creates new ServiceHandler */
    public ServiceHandler() {
    }
    public static void doGet(Request inRequest, Response inResponse, Server inServer) throws Exception{
        // find the layer
        String tempServiceName = inRequest.getParameter(SERVICE_NAME_TAG);
        Service tempService = inServer.getService(tempServiceName);
        if (tempService == null) {
            AdminExtender.showErrorPage(inRequest, inResponse, "Service "+tempServiceName+" was not found on this server.");
            return;
        }
        
        // handle messages for this server.
        String tempAction = inRequest.getParameter(SERVICE_ACTION_TAG);
        if (tempAction != null){
            handleAction(inRequest, inResponse, inServer, tempService, tempAction);
            return;
        }
        
        // if this message is for a particular layer, then send it there.
        String tempLayerName = inRequest.getParameter(LayerHandler.LAYER_NAME_TAG);
        if (tempLayerName != null){
            LayerHandler.doGet(inRequest, inResponse, inServer, tempService);
            return;
        }
        
        // if this message is for a particular projection, then send it there.
        String tempProjecitonName = inRequest.getParameter(ProjectionHandler.PROJECTION_NAME_TAG);
        if (tempProjecitonName != null){
            ProjectionHandler.doGet(inRequest, inResponse, inServer, tempService);
            return;
        }
        
        // if this message is for a particular ScaleBar then send it there.
        String tempScaleBarName = inRequest.getParameter(ScaleBarHandler.SCALEBAR_NAME_TAG);
        if (tempScaleBarName != null){
            ScaleBarHandler.doGet(inRequest, inResponse, inServer, tempService);
            return;
        }

        // show the generic services page.
        showServicePage(inRequest, inResponse, inServer, tempService);
    }
    
    /** Show information only about the indicated server*/
    public static void showServicePage(Request inRequest, Response inResponse, Server inServer, Service inService){
        // look for this service in the list of services.
        
        // show the page that allows the user to edit this service.
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Service "+inService.getServiceName());
        PrintWriter out = inResponse.getWriter();
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        // show the information about the service.
        out.println("<P>");
        out.println("<b>Edit Service "+inService.getServiceName()+"</b>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<br><b>Service Name</b></br>");
        out.println("<br>A short just a few character name to be used in the URL.  Do not include spaces or special characters.</br>");
        out.println("<br><input type=text name=Update_Service_Name value=\""+inService.getServiceName()+"\"></br>");
        out.println("<br><b>Service Title</b></br>");
        out.println("<br>A long description of the service, may include spaces and special characters.</br>");
        out.println("<br><input type=text name=Update_Service_Title value=\""+inService.getServiceTitle()+"\" size=100></br>");
        out.println("<br><b>Service Link</b></br>");
        out.println("<br>Usually a web address where the user can find additional information about this service.</br>");
        out.println("<br><input type=text name=Update_Service_Link value=\""+inService.getServiceLink()+"\" size=100></br>");
        out.println("<input type=hidden name="+SERVICE_ACTION_TAG+" value="+SERVICE_ACTION_UPDATE+">");
        out.println("<input type=hidden name="+SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        out.println("<P>");
        
        // The projection parameters
        out.println("<b>Projection</b>");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<a href=\""+tempURLBase+"?"+SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+SERVICE_ACTION_TAG+"="+SERVICE_ACTION_EDIT_PROJECTION+"\">"+inService.getProjection().getProjectionName()+"</a>");
        out.println("</td><td>");
        out.println("<b>"+inService.getSRS()+"</b></a>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</P>");
        
        // The Scalebar Parameters.
        out.println("<b>ScaleBar</b>");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        String tempScalebarName = "No Scale Bar";
        if (inService.getScaleBar() != null)tempScalebarName = inService.getScaleBar().getDescription();
        out.println("<a href=\""+tempURLBase+"?"+SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+SERVICE_ACTION_TAG+"="+SERVICE_ACTION_EDIT_SCALEBAR+"\">"+tempScalebarName+"</a>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</P>");
        
        // show the layers.
        LayerDefinition[] tempLayerDefinitions = inService.getLayerDefinitions();
        if ((tempLayerDefinitions != null) && (tempLayerDefinitions.length >0)){
            out.println("<P>");
            out.println("<b>Available Layers</b>");
            out.println("<TABLE border=\"4\">");
            out.println("<tr><td><b>Layer Name</b></td><td><b>Layer Title</b></td><td><b>remove</b></td></tr>");
            for (int i=0; i<tempLayerDefinitions.length; i++){
                out.println("<tr><td>");
                out.println("<a href=\""+tempURLBase+"?"+SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+tempLayerDefinitions[i].getLayerName()+"\"><b>"+tempLayerDefinitions[i].getLayerName()+"</b></a>");
                out.println("</td><td>");
                out.println(tempLayerDefinitions[i].getLayerTitle());
                out.println("</td><td>");
                out.println("<a href=\""+tempURLBase+"?"+SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LayerHandler.LAYER_NAME_TAG+"="+tempLayerDefinitions[i].getLayerName()+"&"+SERVICE_ACTION_TAG+"="+SERVICE_ACTION_DELETE_LAYER+"\"><b>remove</b></a>");
                out.println("</td></tr>");
            }
            out.println("</TABLE>");
            out.println("</P>");
        }
        else{
            out.println("<b>No layers found in this service.</b>");
        }
        out.println("<P>");
        out.println("<a href=\""+tempURLBase+"?"+SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+SERVICE_ACTION_TAG+"="+SERVICE_ACTION_SHOW_ADD_LAYER+"\">Add Layer</a>");
        out.println("</P>");
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    
    /** Handle the actions coming from the services page. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, String inServiceAction){
        // if this is an update, then update the
        if (inServiceAction.equalsIgnoreCase(SERVICE_ACTION_UPDATE)){
            String tempString = inRequest.getParameter("Update_Service_Name");
            if ((tempString != null)&&(tempString.trim().length() >0)){
                // check for duplicates
                Server tempServer = inServer;
                Service tempService = tempServer.getService(tempString);
                if ((tempService != null) && (tempService != inService)){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Service "+tempString+" Already exists, delete the existing one first and then rename this one. ");
                    return;
                }
                inService.setServiceName(tempString);
                tempString = inRequest.getParameter("Update_Service_Title");
                inService.setServiceTitle(tempString);
                tempString = inRequest.getParameter("Update_Service_Link");
                inService.setServiceLink(tempString);
                showServicePage(inRequest, inResponse, inServer, inService);
                return;
            }
            AdminExtender.showErrorPage(inRequest, inResponse, "Service Name does not exist");
        }
        if (inServiceAction.equalsIgnoreCase(SERVICE_ACTION_EDIT_PROJECTION)){
            try{
                ProjectionHandler.doGet(inRequest, inResponse, inServer, inService);
            }
            catch (Exception e){
                AdminExtender.showErrorPage(inRequest, inResponse, e.getMessage());
            }
            return;
        }
         if (inServiceAction.equalsIgnoreCase(SERVICE_ACTION_EDIT_SCALEBAR)){
            try{
                ScaleBarHandler.doGet(inRequest, inResponse, inServer, inService);
            }
            catch (Exception e){
                AdminExtender.showErrorPage(inRequest, inResponse, e.getMessage());
            }
            return;
        }
        if (inServiceAction.equalsIgnoreCase(SERVICE_ACTION_SHOW_ADD_LAYER)){
            AdminExtender.showHeaderPage(inRequest, inResponse, "Add New Layer");
            PrintWriter out = inResponse.getWriter();
            String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
            // show the information about the service.
            out.println("<P>");
            out.println("<b>Add New Layer</b>");
            out.println("<form method=post ACTION="+tempURLBase+">");
            out.println("<TABLE border=\"4\">");
            out.println("<tr><td>");
            out.println("<br><b>Layer Name</b></br>");
            out.println("<br>A short just a few character name to be used in the URL.  Do not include spaces or special characters.</br>");
            out.println("<br><input type=text name=Update_Layer_Name value=\"NewLayer\"></br>");
            out.println("<br><b>Layer Title</b></br>");
            out.println("<br>A long description of the Layer, may include spaces and special characters.</br>");
            out.println("<br><input type=text name=Update_Layer_Title value=\"New Layer Title\" size=100></br>");
            out.println("<br>Select the type of data source to use </br>");
            out.println("<br><input type=\"radio\" name=DataSourceType value=ShapeFileDataSource checked>Shape File Data Source</br>");
            out.println("<br><input type=\"radio\" name=DataSourceType value=SeamlessDataSource>Seamless Data Source</br>");
            out.println("<br><input type=\"radio\" name=DataSourceType value=DB2SpatialExtenderDataSource>DB2 Spatial Extender</br>");
            out.println("<br><input type=\"radio\" name=DataSourceType value=PostGISDataSource>PostGIS Data Source</br>");
            out.println("<br><input type=\"radio\" name=DataSourceType value=TerraserverDataSource>Terraserver</br>");
            //            out.println("<br><input type=\"radio\" name=DataSourceType value=ARCSDESource>ARC SDE Data Source</br>");
            out.println("<br><input type=\"radio\" name=DataSourceType value=ImageDataSource>Image Data Source</br>");
            out.println("<br><input type=hidden name="+SERVICE_NAME_TAG+" value="+inService.getServiceName()+"></br>");
            out.println("<input type=hidden name="+SERVICE_ACTION_TAG+" value="+SERVICE_ACTION_SHOW_ADD_LAYER_DATASOURCE+">");
            out.println("<br><input type=submit value=submit></br>");
            out.println("</td></tr>");
            out.println("</TABLE>");
            out.println("</form>");
            out.println("</P>");
            AdminExtender.showTailerPage(inRequest, inResponse);
        }
        if (inServiceAction.equalsIgnoreCase(SERVICE_ACTION_SHOW_ADD_LAYER_DATASOURCE)){
            String tempString = inRequest.getParameter("DataSourceType");
            if (tempString != null){
                // show the data for the layer
                AdminExtender.showHeaderPage(inRequest, inResponse, "Add New Layer Datasource");
                PrintWriter out = inResponse.getWriter();
                String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
                out.println("<b>Add New Layer</b>");
                out.println("<form method=post ACTION="+tempURLBase+">");
                out.println("<TABLE border=\"4\">");
                out.println("<tr><td>");
                out.println("<br>Layer Name: <b>"+inRequest.getParameter("Update_Layer_Name")+"</b></br>");
                out.println("<input type=hidden name=Update_Layer_Name value="+inRequest.getParameter("Update_Layer_Name")+">");
                out.println("<br>Layer Title: <b>"+inRequest.getParameter("Update_Layer_Title")+"</b></br>");
                out.println("<input type=hidden name=Update_Layer_Title value=\""+inRequest.getParameter("Update_Layer_Title")+"\">");
                out.println("<input type=hidden name=DataSourceType value=\""+tempString+"\">");
                // Shape file data source.
                if (tempString.equalsIgnoreCase("ShapeFileDataSource")){
                    out.println("<br><b>Shape File Data Source</b></br>");
                    out.println("<br>Location of the shape file, must be somewhere on the server.</br>");
                    out.println("<br><input size=150 type=text name=ShapeFileDataSourceLocation value=\""+new File("shape.shp").getAbsolutePath()+"\"></br>");
                }
                // Seamless data source.
                if (tempString.equalsIgnoreCase("SeamlessDataSource")){
                    out.println("<br><b>Seamless Data Source</b></br>");
                    out.println("<br>Location of the index file, must be somewhere on the server.</br>");
                    out.println("<br><input size=150 type=text name=SeamlessDataSourceLocation value=\""+new File("index.shp").getAbsolutePath()+"\"></br>");
                }
                // DB2 Spatial Extender
                if (tempString.equalsIgnoreCase("DB2SpatialExtenderDataSource")){
                    out.println("<br><b>DB2 Spatial Extender</b></br>");
                    out.println("<br>Server Name: <input type=text name=DB2SEServerName></br>");
                    out.println("<br>Database Name: <input type=text name=DB2SEDatabaseName></br>");
                    out.println("<br>Schema Name: <input type=text name=DB2SESchema></br>");
                    out.println("<br>Username: <input type=text name=DB2SEUsername></br>");
                    out.println("<br>Password: <input type=password name=DB2SEPassword></br>");
                    out.println("<br>Port: <input type=text name=DB2SEPort></br>");
                    out.println("<br>Name of the shape column from the query, there can only be one.</br>");
                    out.println("<br>Shape Column: <input type=text name=DB2SEColumn></br>");
                    out.println("<br>The Spatial reference id for the shape column.</br>");
                    out.println("<br>SRID: <input type=text name=DB2SESRID value=1></br>");
                    out.println("<br>The query to send to the database when getting the spatial data.</br>");
                    out.println("<br>The query must convert the shape data to binary with the db2gse.st_AsBinary SQL Code as in this example</br>");
                    out.println("<p>select state_name, <b>db2gse.st_AsBinary(Shape) Shape</b> from state</p>");
                    out.println("<br>Query: <input type=text name=DB2SEQuery size=100></br>");
                    out.println("<br>Preread: <input type=checkbox name=DB2SEPreread>Preread the layer, cache the contents.</br>");
                }
                // Post GIS Data Source
                if (tempString.equalsIgnoreCase("PostGISDataSource")){
                    out.println("<br><b>PostGIS Data Source</b></br>");
                    out.println("<br>Server Name: <input type=text name=PostGISServerName></br>");
                    out.println("<br>Database Name: <input type=text name=PostGISDatabaseName></br>");
                    out.println("<br>Username: <input type=text name=PostGISUsername></br>");
                    out.println("<br>Password: <input type=password name=PostGISPassword></br>");
                    out.println("<br>Port: <input type=text name=PostGISPort value=\"5432\"></br>");
                    out.println("<br>Name of the shape column from the query, there can only be one and it must match the AsText() parameter value.</br>");
                    out.println("<br>Shape Column: <input type=text name=PostGISColumn value=\"the_geom\"></br>");
                    out.println("<br>The Spatial reference id for the shape column.</br>");
                    out.println("<br>SRID: <input type=text name=PostGISSRID value=1></br>");
                    out.println("<br>The query to send to the database when getting the spatial data.</br>");
                    out.println("<br>The query must convert the shape data to text with the AsText() SQL Code as in this example</br>");
                    out.println("<p>select state_name, <b>AsText(the_geom) as the_geom</b> from state</p>");
                    out.println("<br>Query: <input type=text name=PostGISQuery size=100></br>");
                    out.println("<br>Preread: <input type=checkbox name=PostGISPreread>Preread the layer, cache the contents.</br>");
                }
                // TerraserverDataSource
                if (tempString.equalsIgnoreCase("TerraserverDataSource")){
                    out.println("<br><b>Terraserver Data Source</b></br>");
                    out.println("<br>Terraserver URL.</br>");
                    out.println("<br><input size=150 type=text name=TerraserverURL value=\"http://terraserver.homeadvisor.msn.com/tile.asp\"></br>");
                    out.println("<br><input type=radio name=TerraserverLayer Value=1 checked>DOQ Airial Photos (imagery)</br>");
                    out.println("<br><input type=radio name=TerraserverLayer Value=2>DRG Digital Lin Graphics (Scanned Maps)</br>");
                    out.println("<br><select name=TerraserverResolution>");
                    out.println("<option value=0> autoselect");
                    out.println("<option value=1> 1 Meter (DOQ)");
                    out.println("<option value=2> 2 Meter");
                    out.println("<option value=4> 4 Meter");
                    out.println("<option value=8> 8 Meter");
                    out.println("<option value=16> 16 Meter");
                    out.println("<option value=32> 32 Meter");
                    out.println("<option value=64> 64 Meter");
                    out.println("<option value=128> 128 Meter (DRG)");
                    out.println("<option value=256> 256 Meter (DRG)");
                    out.println("<option value=512> 512 Meter (DRG)");
                    out.println("</select>");
                    out.println("<br>Tiles to keep in memory <input type=text name=TerraserverMemCache value=200></br>");
                    out.println("<br>TileCacheDirectory <input type=text name=TerraserverTileCache value=\""+new File("Cache").getAbsolutePath()+"\"></br>");
                    out.println("<br>OptimizationLevel<input type=text name=TerraserverOptimization value=100></br>");
                }
                // Image Data Source
                if (tempString.equalsIgnoreCase("ImageDataSource")){
                    out.println("<br><b>Image File Data Source</b></br>");
                    out.println("<br>Location of the image file, must be somewhere on the server.</br>");
                    out.println("<br><input size=150 type=text name=ImageFileDataSourceLocation value=\""+new File("shape.shp").getAbsolutePath()+"\"></br>");
                    out.println("<br>Top X:<input type=text name=TopX></br>");
                    out.println("<br>Top Y:<input type=text name=TopY></br>");
                    out.println("<br>Bottom X:<input type=text name=BottomX></br>");
                    out.println("<br>Bottom Y:<input type=text name=BottomY></br>");
                    out.println("<br><b>Remember to set a shader with a fill color defined.  If there is no fill color then the images will not draw.</b></br>");
                }
                // The submit button.
                out.println("<br><input type=submit value=submit></br>");
                out.println("<input type=hidden name="+SERVICE_NAME_TAG+" value=\""+inService.getServiceName()+"\">");
                out.println("<input type=hidden name="+SERVICE_ACTION_TAG+" value=\""+SERVICE_ACTION_ADD_LAYER+"\">");
                out.println("</td></tr>");
                out.println("</TABLE>");
                out.println("</form>");
                out.println("</P>");
                AdminExtender.showTailerPage(inRequest, inResponse);
            }
            else{
                AdminExtender.showErrorPage(inRequest, inResponse, "No Data Source Selected");
            }
        }
        if (inServiceAction.equalsIgnoreCase(SERVICE_ACTION_ADD_LAYER)){
            // find the data.
            String tempLayerName = inRequest.getParameter("Update_Layer_Name");
            // check for duplicates.
            LayerDefinition tempDefinition = inService.getLayerDefinition(tempLayerName);
            if (tempDefinition != null){
                AdminExtender.showErrorPage(inRequest, inResponse, "Duplicate layer name exists, remove existing layer before adding another "+tempLayerName);
                return;
            }
            
            // create and add the new layer.
            String tempLayerTitle = inRequest.getParameter("Update_Layer_Title");
            tempDefinition = new LayerDefinition(tempLayerName);
            tempDefinition.setLayerTitle(tempLayerTitle);
            
            // add the data source to the layer.
            String tempString = inRequest.getParameter("DataSourceType");
            if (tempString != null){
                // Shape file data source.
                if (tempString.equalsIgnoreCase("ShapeFileDataSource")){
                    String tempShapeFileDataSourceLocation = inRequest.getParameter("ShapeFileDataSourceLocation");
                    if (tempShapeFileDataSourceLocation != null){
                        try{
                            ReadOnlyShapeFileDataSource tempDataSource = new ReadOnlyShapeFileDataSource(tempShapeFileDataSourceLocation);
                            tempDefinition.setDataSource(tempDataSource);
                            tempDefinition.setLatLonEnvelope(tempDataSource.getEnvelope());
                        }
                        catch(Exception e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error creating Layer "+e);
                            return;
                        }
                    }
                    else {
                        AdminExtender.showErrorPage(inRequest, inResponse, "Error creating Layer no Shape File Location specified");
                        return;
                    }
                }
                // Seamless file data source.
                if (tempString.equalsIgnoreCase("SeamlessDataSource")){
                    String tempIndexFileDataSourceLocation = inRequest.getParameter("SeamlessDataSourceLocation");
                    if (tempIndexFileDataSourceLocation != null){
                        try{
                            SeamlessDataSource tempDataSource = new SeamlessDataSource(tempIndexFileDataSourceLocation);
                            tempDefinition.setDataSource(tempDataSource);
                            tempDefinition.setLatLonEnvelope(tempDataSource.getEnvelope());
                        }
                        catch(Exception e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error creating Layer "+e);
                            return;
                        }
                    }
                    else {
                        AdminExtender.showErrorPage(inRequest, inResponse, "Error creating Layer no Index File Location specified");
                        return;
                    }
                }
                
                // DB2 Spatial Extender
                if (tempString.equalsIgnoreCase("DB2SpatialExtenderDataSource")){
                    String tempServerName = inRequest.getParameter("DB2SEServerName");
                    if ((tempServerName == null) || (tempServerName.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Server Name specified");
                        return;
                    }
                    String tempDatabaseName = inRequest.getParameter("DB2SEDatabaseName");
                    if ((tempDatabaseName == null) || (tempDatabaseName.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Database Name specified");
                        return;
                    }
                    String tempSchemaName = inRequest.getParameter("DB2SESchema");
                    if ((tempSchemaName == null) || (tempSchemaName.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Schema Name specified");
                        return;
                    }
                    String tempUsername = inRequest.getParameter("DB2SEUsername");
                    if ((tempUsername == null) || (tempUsername.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Database Username specified");
                        return;
                    }
                    String tempPassword = inRequest.getParameter("DB2SEPassword");
                    if ((tempPassword == null) || (tempPassword.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Database Password specified");
                        return;
                    }
                    String tempPort = inRequest.getParameter("DB2SEPort");
                    int tempIntPort = 0;
                    if ((tempPort == null) || (tempPort.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified");
                        return;
                    }
                    else{
                        try{
                            tempIntPort = Integer.parseInt(tempPort);
                        }
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified is not a number="+tempPort);
                            return;
                        }
                    }
                    String tempColumn = inRequest.getParameter("DB2SEColumn");
                    if ((tempColumn == null) || (tempColumn.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Shape Column specified");
                        return;
                    }
                    String tempRowID = inRequest.getParameter("DB2SESRID");
                    int tempIntRowID = 0;
                    if ((tempRowID == null) || (tempRowID.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified");
                        return;
                    }
                    else{
                        try{
                            tempIntRowID = Integer.parseInt(tempRowID);
                        }
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified is not a number="+tempRowID);
                            return;
                        }
                    }
                    String tempQuery = inRequest.getParameter("DB2SEQuery");
                    if ((tempQuery == null) || (tempQuery.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Query specified");
                        return;
                    }
                    String tempPrereadString = inRequest.getParameter("DB2SEPreread");
                    boolean tempPreread = false;
                    if (tempPrereadString != null){
                        tempPreread = true;
                    }
                    // construct the new DB2SE data source.
                    ReadOnlySpatialExtenderDataSource tempDataSource = new ReadOnlySpatialExtenderDataSource();
                    tempDataSource.setDatabaseServername(tempServerName);
                    tempDataSource.setDatabasePort(tempIntPort);
                    tempDataSource.setDatabaseName(tempDatabaseName);
                    tempDataSource.setDatabaseSchema(tempSchemaName);
                    tempDataSource.setDatabaseShapeColumn(tempColumn);
                    tempDataSource.setDatabaseSpatialReferenceID(tempIntRowID);
                    tempDataSource.setSQLString(tempQuery);
                    tempDataSource.setDatabaseUsername(tempUsername);
                    tempDataSource.setDatabasePassword(tempPassword);
                    tempDataSource.setPreread(tempPreread);
                    tempDefinition.setDataSource(tempDataSource);
                    try{
                        tempDefinition.setLatLonEnvelope(tempDataSource.getEnvelope());
                    }
                    catch(Exception e){
                        AdminExtender.showErrorPage(inRequest, inResponse, "Error Connection to DB2 Spatial Extender "+e);
                        return;
                    }
                }
                // PosGRESQL
                if (tempString.equalsIgnoreCase("PostGISDataSource")){
                    String tempServerName = inRequest.getParameter("PostGISServerName");
                    if ((tempServerName == null) || (tempServerName.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Server Name specified");
                        return;
                    }
                    String tempDatabaseName = inRequest.getParameter("PostGISDatabaseName");
                    if ((tempDatabaseName == null) || (tempDatabaseName.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Database Name specified");
                        return;
                    }
                    String tempUsername = inRequest.getParameter("PostGISUsername");
                    if ((tempUsername == null) || (tempUsername.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Database Username specified");
                        return;
                    }
                    String tempPassword = inRequest.getParameter("PostGISPassword");
                    if ((tempPassword == null) || (tempPassword.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Database Password specified");
                        return;
                    }
                    String tempPort = inRequest.getParameter("PostGISPort");
                    int tempIntPort = 0;
                    if ((tempPort == null) || (tempPort.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified");
                        return;
                    }
                    else{
                        try{
                            tempIntPort = Integer.parseInt(tempPort);
                        }
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified is not a number="+tempPort);
                            return;
                        }
                    }
                    String tempColumn = inRequest.getParameter("PostGISColumn");
                    if ((tempColumn == null) || (tempColumn.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Shape Column specified");
                        return;
                    }
                    String tempRowID = inRequest.getParameter("PostGISSRID");
                    int tempIntRowID = 0;
                    if ((tempRowID == null) || (tempRowID.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified");
                        return;
                    }
                    else{
                        try{
                            tempIntRowID = Integer.parseInt(tempRowID);
                        }
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "No Port Number specified is not a number="+tempRowID);
                            return;
                        }
                    }
                    String tempQuery = inRequest.getParameter("PostGISQuery");
                    if ((tempQuery == null) || (tempQuery.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Query specified");
                        return;
                    }
                    String tempPrereadString = inRequest.getParameter("PostGISPreread");
                    boolean tempPreread = false;
                    if (tempPrereadString != null){
                        tempPreread = true;
                    }
                    // construct the new DB2SE data source.
                    ReadOnlyPostGISDataSource tempDataSource = new ReadOnlyPostGISDataSource();
                    tempDataSource.setDatabaseServername(tempServerName);
                    tempDataSource.setDatabasePort(tempIntPort);
                    tempDataSource.setDatabaseName(tempDatabaseName);
                    tempDataSource.setDatabaseShapeColumn(tempColumn);
                    tempDataSource.setDatabaseSpatialReferenceID(tempIntRowID);
                    tempDataSource.setDatabaseQuery(tempQuery);
                    tempDataSource.setDatabaseUsername(tempUsername);
                    tempDataSource.setDatabasePassword(tempPassword);
                    //                    tempDataSource.setPreread(tempPreread);
                    tempDefinition.setDataSource(tempDataSource);
                    try{
                        tempDefinition.setLatLonEnvelope(tempDataSource.getEnvelope());
                    }
                    catch(Exception e){
                        AdminExtender.showErrorPage(inRequest, inResponse, "Error Connection to Database "+e);
                        return;
                    }
                }
                // TerraserverDataSource
                if (tempString.equalsIgnoreCase("TerraserverDataSource")){
                    String tempURL = inRequest.getParameter("TerraserverURL");
                    if (tempURL == null){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Terraserver URL Specified");
                        return;
                    }
                    int tempType = 1; // default is DOQ
                    try{
                        tempString = inRequest.getParameter("TerraserverLayer");
                        tempType = Integer.parseInt(tempString);
                    }
                    catch (NumberFormatException e){
                        // Just use the default anyway.  This is very unlikely.
                    }
                    int tempResolution = 0; //default is automatic.
                    try{
                        tempString = inRequest.getParameter("TerraserverResolution");
                        tempResolution = Integer.parseInt(tempString);
                    }
                    catch (NumberFormatException e){
                        // still just using the default anyway.
                    }
                    int tempMemCache = 200; // needs to be big enough to render one width of image, but not too large to overrun the memory of the computer.
                    tempString = inRequest.getParameter("TerraserverMemCache");
                    try{
                        tempMemCache = Integer.parseInt(tempString);
                    }
                    catch (NumberFormatException e){
                        // The user can enter some bogus value, punish them I say.
                        AdminExtender.showErrorPage(inRequest, inResponse, "Terraserver Memory cache \""+tempString+"\" is not an integer");
                        return;
                    }
                    String tempDiskCache = inRequest.getParameter("TerraserverTileCache");
                    int tempOptimization = 200; // Determines how often the projection from the tile to the new coordinate system is recalculated.
                    tempString = inRequest.getParameter("TerraserverOptimization");
                    try{
                        tempOptimization = Integer.parseInt(tempString);
                    }
                    catch (NumberFormatException e){
                        // The user can enter some bogus value, punish them I say.
                        AdminExtender.showErrorPage(inRequest, inResponse, "Terraserver Optimization \""+tempString+"\" is not an integer");
                        return;
                    }
                    // construct the image data source
                    TerraserverDataSource tempDataSource = new TerraserverDataSource();
                    try{
                        tempDataSource.setURLBase(tempURL);
                        tempDataSource.setImageType(tempType);
                        tempDataSource.setResolution(tempResolution);
                        tempDataSource.setMemoryCache(tempMemCache);
                        tempDataSource.setResolution(tempResolution);
                        tempDataSource.setDiskCache(tempDiskCache);
                        tempDataSource.setOptimization(tempOptimization);
                        tempDefinition.setDataSource(tempDataSource);
                        tempDefinition.setLatLonEnvelope(new Envelope(-178.21759836236586,71.40623535327121,-66.96927103600244,18.924781799316406));
                    }
                    catch(Exception e){
                        AdminExtender.showErrorPage(inRequest, inResponse, "Error getting Envelope "+e);
                        return;
                    }
                }
                // Image File Data Source
                if (tempString.equalsIgnoreCase("ImageDataSource")){
                    String tempFileName = inRequest.getParameter("ImageFileDataSourceLocation");
                    if ((tempFileName == null) || (tempFileName.trim().length() == 0)){
                        AdminExtender.showErrorPage(inRequest, inResponse, "No Image File Name Specified");
                        return;
                    }
                    else{
                        File tempFile = new File(tempFileName);
                        if (!tempFile.exists()){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Image File : "+tempFileName+" can not be found on the server.");
                            return;
                        }
                        try{
                            Image tempImage = Toolkit.getDefaultToolkit().createImage(tempFileName);
                        }
                        catch(Exception e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error :"+e.getMessage()+" Retrieving image from "+tempFileName);
                            return;
                        }
                        
                        // construct the Envelope of the image.
                        tempString = inRequest.getParameter("TopX");
                        double topX = 0;
                        try{ topX = Double.parseDouble(tempString);}
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing TopX, "+tempString+" Is not a number.");
                            return;
                        }
                        tempString = inRequest.getParameter("TopY");
                        double topY = 0;
                        try{ topY = Double.parseDouble(tempString);}
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing TopY, "+tempString+" Is not a number.");
                            return;
                        }
                        tempString = inRequest.getParameter("BottomX");
                        double bottomX = 0;
                        try{ bottomX = Double.parseDouble(tempString);}
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing BottomX, "+tempString+" Is not a number.");
                            return;
                        }
                        tempString = inRequest.getParameter("BottomY");
                        double bottomY = 0;
                        try{ bottomY = Double.parseDouble(tempString);}
                        catch (NumberFormatException e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing BottomY, "+tempString+" Is not a number.");
                            return;
                        }
                        Envelope tempEnvelope = new Envelope(topX, topY, bottomX, bottomY);
                        
                        // construct the image data source
                        ImageFileDataSource tempDataSource = new ImageFileDataSource();
                        try{
                            tempDataSource.setImageFile(tempFile);
                            tempDataSource.setImageEnvelope(tempEnvelope);
                            tempDefinition.setDataSource(tempDataSource);
                            tempDefinition.setLatLonEnvelope(tempDataSource.getEnvelope());
                        }
                        catch(Exception e){
                            AdminExtender.showErrorPage(inRequest, inResponse, "Error getting Envelope "+e);
                            return;
                        }
                    }
                }
            }
            else{
                AdminExtender.showErrorPage(inRequest, inResponse, "No Data Source Selected");
                return;
            }
            
            // add the default style to the layer
            Style tempStyle = new Style();
            tempStyle.setStyleName("DefaultStyle");
            tempStyle.setStyleTitle("Default Style, Black Lines, White Solid Fill");
            tempDefinition.addStyle(new Style());
            
            // add the style to the layer to the service
            try{
                inService.addLayerDefinition(tempDefinition);
            }
            catch (Exception e){
                AdminExtender.showErrorPage(inRequest, inResponse, "Error adding layer "+e);
                return;
            }
            
            // show the layer page again.
            showServicePage(inRequest, inResponse, inServer, inService);
            return;
        }
        if (inServiceAction.equalsIgnoreCase(SERVICE_ACTION_DELETE_LAYER)){
            String tempLayerName = inRequest.getParameter(LayerHandler.LAYER_NAME_TAG);
            if (tempLayerName == null){
                AdminExtender.showErrorPage(inRequest, inResponse, "No layer name specified");
                return;
            }
            LayerDefinition tempDefinition = inService.getLayerDefinition(tempLayerName);
            if (tempDefinition == null){
                AdminExtender.showErrorPage(inRequest, inResponse, "Layer with name "+tempLayerName+" was not found on this server.");
                return;
            }
            
            inService.removeLayerDefinition(tempDefinition);
            showServicePage(inRequest, inResponse, inServer, inService);
            return;
        }
    }
}
