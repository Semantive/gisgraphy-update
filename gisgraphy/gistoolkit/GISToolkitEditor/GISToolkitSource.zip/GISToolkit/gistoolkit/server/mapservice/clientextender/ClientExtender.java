/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.clientextender;

import java.io.*;
import gistoolkit.common.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.clientextender.images.ImageSource;

/**
 * Extender to display the client applet to the user so they can browse the web service.
 */
public class ClientExtender extends SimpleExtensionService{
    
    private static final String ACTION_TAG = "ACTION";
    private static final String ACTION_GETIMAGE = "GETIMAGE";
    private static final String ACTION_GET_JAR = "GET_JAR";
    private static final String ACTION_GET_SERVICE = "GET_SERVICE";
    private static final String SERVICE_NAME_TAG = "SERVICE_NAME";
    private static final String IMAGE_NAME_TAG = "IMAGE_NAME";
    
    /** Called to set the configuration information for this service. */
    public void setNode(Node inNode){
        String tempBannerPage = inNode.getAttribute(BNNER_IMAGE_TAG);
        if (tempBannerPage != null) setBannerPageImageFileName(tempBannerPage);
    }
    
    private static final String CLIENT_EXTENDER_NODE="ClientExtender";
    private static final String BNNER_IMAGE_TAG="BannerImage";
    /** Called to get the configuration information for this service. */
    public Node getNode(){
        Node tempNode = new Node(CLIENT_EXTENDER_NODE);
        if (getBannerPageImageFileName() != null) tempNode.addAttribute(BNNER_IMAGE_TAG, getBannerPageImageFileName());
        return tempNode;
    }
    /** Place to get the banner image. */
    private static String myBannerPageImageFileName = null;
    /** set the banner page image file name. */
    public void setBannerPageImageFileName(String inFileName){myBannerPageImageFileName = inFileName;}
    /** Get the banner page image file name. */
    public String getBannerPageImageFileName(){return myBannerPageImageFileName;}
    /** Creates new ClientExtender */
    public ClientExtender() {
    }
    
    /** Called to identify this service.  */
    public String getName() {
        return "client";
    }
    /** Called when a request is sent to this service.  */
    public void doGet(Request inRequest, Response inResponse) throws Exception {
        String tempAction = inRequest.getParameter(ACTION_TAG);
        if (tempAction != null){
            if (tempAction.equalsIgnoreCase(ACTION_GETIMAGE)){
                getImage(inRequest, inResponse);
                return;
            }
            if (tempAction.equalsIgnoreCase(ACTION_GET_JAR)){
                getJAR(inRequest, inResponse);
                return;
            }
            if (tempAction.equalsIgnoreCase(ACTION_GET_SERVICE)){
                getService(inRequest, inResponse);
                return;
            }
        }
        
        // find out how many different map services are supported by this server.
        Server tempServer = getServer();
        Service[] tempServices = tempServer.getServices();
        showHeaderPage(inRequest, inResponse, "Client for Map Services");
        PrintWriter out = inResponse.getWriter();
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        if ((tempServices == null) || (tempServices.length == 0)){
            // Show a message indicating that no map services are currently configured.
            out.println("Sorry, there are no currently configured map services on this server.");
        }
        else if (tempServices.length == 1){
            // show the client for this particular map service.
            Service tempService = tempServices[0];
            String tempServicename = tempService.getServiceName();
            showService(inRequest, inResponse, tempServicename);
            
        }
        else {
            out.println("<h1>Available Services</h1>");
            for (int i=0; i<tempServices.length; i++){
                out.println("<p><a href=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GET_SERVICE+"&"+SERVICE_NAME_TAG+"="+tempServices[i].getServiceName()+"\">"+tempServices[i].getServiceTitle()+"</a></P>");
            }
        }
        showTailerPage(inRequest, inResponse);
    }
    
    /** Retrieve an image from the images folder. */
    public void getImage(Request inRequest, Response inResponse)throws Exception{
        String tempName = inRequest.getParameter(IMAGE_NAME_TAG);
        if (tempName == null) return;
        String tempUCName = tempName.toUpperCase();
        inResponse.setContentType("application/octetstream");
        if (tempUCName.endsWith("PNG")){
            inResponse.setContentType("image/png");
        }
        if (tempUCName.endsWith("GIF")){
            inResponse.setContentType("image/gif");
        }
        if ((tempUCName.endsWith("JPEG"))||(tempUCName.endsWith("JPG"))){
            inResponse.setContentType("image/jpeg");
        }
        
        InputStream in = new ImageSource().getResource(tempName);
        if (in == null){
            // check on the file system
            File tempFile = new File(tempName);
            if (tempFile.exists()){
                in = new FileInputStream(tempFile);
            }
            else{
                return;
            }
        }
        OutputStream out = inResponse.getOutputStream();
        byte[] buff = new byte[1000];
        int length = in.read(buff);
        while (length != -1){
            out.write(buff,0,length);
            length = in.read(buff);
        }
        in.close();
        // out is closed by the web server when it is returned.
        return;
    }
    /** Retrieve the client jar file from the images folder. */
    public void getJAR(Request inRequest, Response inResponse)throws Exception{
        inResponse.setContentType("application/octetstream");
        OutputStream out = inResponse.getOutputStream();
        InputStream in = new ImageSource().getResource("Client.jar");
        byte[] buff = new byte[1000];
        int length = in.read(buff);
        while (length != -1){
            out.write(buff,0,length);
            length = in.read(buff);
        }
        in.close();
        // out is closed by the map server when it returns the data.
    }
    
    /** Send a page with the requested service in it.*/
    public void getService(Request inRequest, Response inResponse)throws Exception{
        // find out how many different map services are supported by this server.
        Server tempServer = getServer();
        Service[] tempServices = tempServer.getServices();
        showHeaderPage(inRequest, inResponse, "Client for Map Services");
        PrintWriter out = inResponse.getWriter();
        
        // find the service name
        String tempServiceName = inRequest.getParameter(SERVICE_NAME_TAG);
        if (tempServiceName == null){
            out.println("No Service name specified");
        }
        else{
            boolean tempFound = false;
            for (int i=0; i<tempServices.length; i++){
                if (tempServices[i].getServiceName().equalsIgnoreCase(tempServiceName)){
                    String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
                    
                    // show the client for this particular map service.
                    Service tempService = tempServices[i];
                    String tempServicename = tempService.getServiceName();
                    showService(inRequest, inResponse, tempServicename);
                    tempFound = true;
                }
            }
            if (!tempFound){
                out.println("Web service named "+tempServiceName+" Not found on this server");
            }
        }
        showTailerPage(inRequest, inResponse);
    }
    
    /** Show the page for this service. */
    private void showService(Request inRequest, Response inResponse, String inServiceName){
        PrintWriter out = inResponse.getWriter();
        
        // find the service name
        String tempServiceName = inServiceName;
        if (tempServiceName == null){
            out.println("No Service name specified");
        }
        else{
            String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
            
            // determine which image to use in the upper part of the applet.
            String tempImageURL = null;
            if (myBannerPageImageFileName != null){
                tempImageURL = tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"="+UTF8Encoder.encode(myBannerPageImageFileName);
            }
            else{
                tempImageURL = tempURLBase+"?"+ACTION_TAG+"="+ACTION_GETIMAGE+"&"+IMAGE_NAME_TAG+"=clientbanner.png";
            }
            out.println("<P>");
            
            // construct the web service uri
            String tempURL = tempURLBase;
            int tempIndex = tempURL.lastIndexOf('/');
            if (tempIndex != -1){
                tempURL = tempURL.substring(0, tempIndex)+"/"+tempServiceName;
            }
            
            out.println("<object classid=\"clsid:8AD9C840-044E-11D1-B3E9-00805F499D93\"");
            out.println("    width=\"670\" height=\"600\" align=\"baseline\"");
            out.println("    codebase=\"http://java.sun.com/products/plugin/1.3/jinstall-13-win32.cab#Version=1,3,1,2\">");
            out.println("<param NAME=\"code\" VALUE=\"gistoolkit/server/mapclient/AppletClient.class\">");
            out.println("<param NAME=\"ARCHIVE\" VALUE=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GET_JAR+"\">");
            out.println("<param NAME=\"type\" VALUE=\"application/x-java-applet;version=1.3\">");
            out.println("<param NAME=\"scriptable\" VALUE=\"false\">");
            out.println("<param NAME=\"WEBSERVICE\" VALUE=\""+tempURL+"\">");
            out.println("<param NAME=\"LOGOIMAGE\" VALUE=\""+tempImageURL+"\">");
            out.println("<COMMENT>");
            out.println("<embed type=\"application/x-java-applet;version=1.3.1.2\" width=\"670\"");
            out.println("       height=\"600\" align=\"baseline\" code=\"gistoolkit/server/mapclient/AppletClient.class\"");
            out.println("       ARCHIVE=\""+tempURLBase+"?"+ACTION_TAG+"="+ACTION_GET_JAR+"\"");
            out.println("       pluginspage=\"http://java.sun.com/products/plugin/1.3/plugin-install.html\">");
            out.println("       LOGOIMAGE=\""+tempImageURL+"\">");
            out.println("       WEBSERVICE=\""+tempURL+"\">");
            out.println("<noembed>");
            out.println("</COMMENT>");
            out.println("No Java 2 SDK, Standard Edition v 1.3 support for APPLET!!");
            out.println("    </noembed></embed>");
            out.println("</object>");
        }
    }
    
    /** Show the heading page */
    public static void showHeaderPage(Request inRequest, Response inResponse, String inTitle){
        inResponse.setContentType("text/html");
        PrintWriter out = inResponse.getWriter();
        out.println("<HTML>");
        out.println("<HEAD>");
        out.println("<TITLE>"+inTitle+"</TITLE>");
        out.println("</HEAD>");
        out.println("<BODY bgcolor=\"#ffffcc\">");
    }
    
    /** Show the trailer part of the page. */
    public static void showTailerPage(Request inRequest, Response inResponse){
        PrintWriter out = inResponse.getWriter();
        out.println("</P>");
        out.println("</BODY>");
        out.println("</HTML>");
    }
}
