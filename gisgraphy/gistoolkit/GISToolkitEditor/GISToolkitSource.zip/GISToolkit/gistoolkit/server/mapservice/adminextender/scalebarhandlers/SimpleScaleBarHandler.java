/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender.scalebarhandlers;
import java.io.*;
import java.awt.*;
import gistoolkit.display.*;
import gistoolkit.display.scalebar.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.*;

/**
 * Class to handle configuring a simple scale bar.
 */
public class SimpleScaleBarHandler {
    private static final String SIMPLE_SCALEBAR_ACTION_TAG = "SIMPLE_SCALEBAR_ACTION";
    private static final String SIMPLE_SCALEBAR_UPDATE = "SIMPLE_SCALEBAR_UPDATE";
    
    
    /** Creates new SimpleScaleBarHandler */
    public SimpleScaleBarHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, ScaleBar inScaleBar) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(SIMPLE_SCALEBAR_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inScaleBar, tempString);
            return;
        }
        showSimpleScalebarPage(inRequest, inResponse, inServer, inService, inScaleBar);
    }
    public static void showSimpleScalebarPage(Request inRequest, Response inResponse, Server inServer, Service inService, ScaleBar inScaleBar){
        SimpleScaleBar tempScaleBar = null;
        if (inScaleBar instanceof SimpleScaleBar){
            tempScaleBar = (SimpleScaleBar) inScaleBar;
        }
        else{
            AdminExtender.showErrorPage(inRequest, inResponse, "Scale Bar "+inScaleBar+" is not a SimpleScaleBar");
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit ScaleBar "+inService.getServiceName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        out.println("<b>Attributes of the Scale Bar.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // show the line color
        out.println("<br>When specifying the RGB values here, each value is an integer in the range of 0 to 255. No color is 0, so 0,0,0 is black, and 255,255,255 is white.</br>");
        out.println("<p>");
        out.println("<p>Line Color</p>");
        if (tempScaleBar.getDefaultLineColor() != null){
            out.print("Red: <input type=text name=ulr value=\""+tempScaleBar.getDefaultLineColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulg value=\""+tempScaleBar.getDefaultLineColor().getGreen()+"\">");
            out.println("Blue: <input type=text name=ulb value=\""+tempScaleBar.getDefaultLineColor().getBlue()+"\">");
        }
        else{
            out.print("Red: <input type=text name=ulr value=\"0\">");
            out.print("Green: <input type=text name=ulg value=\"0\">");
            out.print("Blue: <input type=text name=ulb value=\"0\">");
        }
        out.println("</p>");
                
        // line width
        out.println("<p>");
        out.println("<br>How thick should the line to be (in pixels)");
        out.println("<br><select name=ulw>");
        BasicStroke tempStroke = null;
        if (tempScaleBar.getStroke() instanceof BasicStroke){
            tempStroke = (BasicStroke) tempScaleBar.getStroke();
        }
        else{
            tempStroke = new BasicStroke();
        }
        int tempWidth = (int) tempStroke.getLineWidth();
        out.println("<Option Value=1 "+AdminExtender.getSelected(tempWidth, 1)+">1");
        out.println("<Option Value=2 "+AdminExtender.getSelected(tempWidth, 2)+">2");
        out.println("<Option Value=3 "+AdminExtender.getSelected(tempWidth, 3)+">3");
        out.println("<Option Value=4 "+AdminExtender.getSelected(tempWidth, 4)+">4");
        out.println("<Option Value=5 "+AdminExtender.getSelected(tempWidth, 5)+">5");
        out.println("<Option Value=6 "+AdminExtender.getSelected(tempWidth, 6)+">6");
        out.println("<Option Value=7 "+AdminExtender.getSelected(tempWidth, 7)+">7");
        out.println("<Option Value=8 "+AdminExtender.getSelected(tempWidth, 8)+">8");
        out.println("<Option Value=9 "+AdminExtender.getSelected(tempWidth, 9)+">9");
        out.println("<Option Value=10 "+AdminExtender.getSelected(tempWidth, 10)+">10");
        out.println("</select>");
        out.println("</p>");

        // label color
        out.println("<p>");
        out.println("<p>Label Color</p>");
        if (tempScaleBar.getDefaultLabelColor() != null){
            out.print("Red: <input type=text name=ular value=\""+tempScaleBar.getDefaultLabelColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulag value=\""+tempScaleBar.getDefaultLabelColor().getGreen()+"\">");
            out.println("Blue:<input type=text name=ulab value=\""+tempScaleBar.getDefaultLabelColor().getBlue()+"\">");
        }
        else{
            out.print("Red: <input type=text name=ular value=\"0\">");
            out.print("Green: <input type=text name=ulag value=\"0\">");
            out.println("Blue: <input type=text name=ulab value=\"0\">");
        }
        out.println("</p>");

        // Label Font
        out.println("<p>");
        out.println("<p>Font Name</p>");
        Font tempFont = tempScaleBar.getDefaultFont();
        out.println("<br><select name=FN>");
        String tempFontName = tempFont.getFontName();
        Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
        for (int i=0; i<tempFontSelection.length; i++){
            String tempTestName = tempFontSelection[i].getFontName();
            out.print("   <Option Value=\""+tempTestName+"\" ");
            if (tempFontName.equals(tempTestName)){
                out.print("Selected");
            }
            out.println(">"+tempTestName);
        }
        out.println("</select>");
        out.println("</p>");
        
        // Font Size
        out.println("<p>");
        out.println("<p>Font Size</p>");
        int[] tempSizes = {7,8,9,10,12,14,16,18,20,25,30,40,48,56,72};
        int tempSize = tempFont.getSize();
        out.println("<select name=FS>");
        for (int i=0; i<tempSizes.length; i++){
            out.println("   <Option Value="+tempSizes[i]+" "+AdminExtender.getSelected(tempSize, tempSizes[i])+">"+tempSizes[i]);
        }
        out.println("</select>");
        out.println("</p>");
                      
        // alpha percent
        float tempAlpha = tempScaleBar.getAlpha();
        out.println("<br>How opaque should this layer be? A value of 0 is transparent.");
        out.println("<br><select name=alpha>");
        if (Math.abs(tempAlpha - 1) < 0.00001) out.println("<Option Value=\"1\"  selected>100");
        else out.println("<Option Value=\"1\" >100%");
        if (Math.abs(tempAlpha - 0.75) < 0.00001) out.println("<Option Value=\"0.75\"  selected>75%");
        else out.println("<Option Value=\"0.75\" >75%");
        if (Math.abs(tempAlpha - 0.5) < 0.00001) out.println("<Option Value=\"0.5\"  selected>50%");
        else out.println("<Option Value=\"0.5\" >50%");
        if (Math.abs(tempAlpha - 0.25) < 0.00001) out.println("<Option Value=\"0.25\" selected>25%");
        else out.println("<Option Value=\"0.25\" >25%");
        out.println("</select>");

        // Orientation.
        out.println("<p>");
        int tempQuadrant = tempScaleBar.getQuadrant();
        out.println("<br>Where should this layer be displayed>");
        out.println("<br><select name=quadrant>");
        if (tempQuadrant == SimpleScaleBar.UPPER_LEFT) out.println("<Option Value=\""+SimpleScaleBar.UPPER_LEFT+"\"  selected>Upper Left");
        else out.println("<Option Value=\""+SimpleScaleBar.UPPER_LEFT+"\" >Upper Left");
        if (tempQuadrant == SimpleScaleBar.UPPER_RIGHT) out.println("<Option Value=\""+SimpleScaleBar.UPPER_RIGHT+"\"  selected>Upper Right");
        else out.println("<Option Value=\""+SimpleScaleBar.UPPER_RIGHT+"\" >Upper Right");
        if (tempQuadrant == SimpleScaleBar.LOWER_LEFT) out.println("<Option Value=\""+SimpleScaleBar.LOWER_LEFT+"\"  selected>Lower Left");
        else out.println("<Option Value=\""+SimpleScaleBar.LOWER_LEFT+"\" >Lower Left");
        if (tempQuadrant == SimpleScaleBar.LOWER_RIGHT) out.println("<Option Value=\""+SimpleScaleBar.LOWER_RIGHT+"\"  selected>Lower Right");
        else out.println("<Option Value=\""+SimpleScaleBar.LOWER_RIGHT+"\" >Lower Right");
        out.println("</select>");
        out.println("</p>");


        // Screen Width percent
        float tempScreenWidth = tempScaleBar.getScreenPercent();
        out.println("<p>");
        out.println("<br>What percent of the screen width should be used for displaying the scale bar?.");
        out.println("<br><select name=screenwidth");
        if (Math.abs(tempScreenWidth - 100) < 0.00001) out.println("<Option Value=\"100\"  selected>100%");
        else out.println("<Option Value=\"100\" >100%");
        if (Math.abs(tempScreenWidth - 75) < 0.00001) out.println("<Option Value=\"0.75\"  selected>75%");
        else out.println("<Option Value=\"75\" >75%");
        if (Math.abs(tempScreenWidth - 50) < 0.00001) out.println("<Option Value=\"0.5\"  selected>50%");
        else out.println("<Option Value=\"50\" >50%");
        if (Math.abs(tempScreenWidth - 25) < 0.00001) out.println("<Option Value=\"0.25\" selected>25%");
        else out.println("<Option Value=\"25\" >25%");
        if (Math.abs(tempScreenWidth - 20) < 0.00001) out.println("<Option Value=\"0.20\" selected>20%");
        else out.println("<Option Value=\"20\" >20%");
        out.println("</select>");
        out.println("</p>");

        // horizontal Offset
        out.println("<p>");
        out.println("<br>Horizontal Offset: <input type=text name=hoff value=\""+tempScaleBar.getHorizontalOffset()+"\"></br>");
        
        // vertical Offset
        out.println("<br>Vertical Offset: <input type=text name=voff value=\""+tempScaleBar.getVerticalOffset()+"\"></br>");
        out.println("</p>");
        
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+ScaleBarHandler.SCALEBAR_NAME_TAG+" value="+inRequest.getParameter(ScaleBarHandler.SCALEBAR_NAME_TAG)+">");
        out.println("<input type=hidden name="+SIMPLE_SCALEBAR_ACTION_TAG+" value="+SIMPLE_SCALEBAR_UPDATE+">");
        out.println("<p><input type=submit value=submit></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        // show the trailing page.
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    
    /** Handle events for the SimpleScaleBar. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, ScaleBar inScaleBar, String inAction){
        SimpleScaleBar tempScaleBar = null;
        if (inScaleBar instanceof SimpleScaleBar){
            tempScaleBar = (SimpleScaleBar) inScaleBar;
        }
        else{
            AdminExtender.showErrorPage(inRequest, inResponse, "Scale Bar "+ inScaleBar+" is not an instance of SimpleScaleBar");
            return;
        }
        if (inAction.equalsIgnoreCase(SIMPLE_SCALEBAR_UPDATE)){
            
            // check for the line color
            int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ulr"));
            int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulg"));
            int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulb"));
            tempScaleBar.setDefaultLineColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            
            // line width
            int tempLineWidth = ShaderHandler.rationalize(inRequest.getParameter("ulw"));
            tempScaleBar.setStroke(new BasicStroke((float)tempLineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND ));
            
            // check for the label color
            tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ular"));
            tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulag"));
            tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulab"));
            tempScaleBar.setDefaultLabelColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            
            // check for the label font
            Font tempFont = tempScaleBar.getDefaultFont();
            String tempFontName = tempFont.getFontName();
            String tempSelectedName = inRequest.getParameter("FN");
            if (tempSelectedName != null){
                if (!tempFontName.equals(tempSelectedName)){
                    Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
                    for (int i=0; i<tempFontSelection.length; i++){
                        String tempTestName = tempFontSelection[i].getFontName();
                        if (tempSelectedName.equals(tempTestName)){
                            // set the new font into the scale bar
                            tempScaleBar.setDefaultFont(tempFontSelection[i]);
                            break;
                        }
                    }
                }
            }
            
            // check for the label font size
            String tempString = inRequest.getParameter("FS");
            if (tempString != null){
                try{
                    int tempSize = Integer.parseInt(tempString);
                    tempFont = tempScaleBar.getDefaultFont();
                    int tempFontSize = tempFont.getSize();
                    if (tempFontSize != tempSize){
                        tempFont = tempFont.deriveFont((float)tempSize);
                        tempScaleBar.setDefaultFont(tempFont);
                    }
                }
                catch (NumberFormatException e){
                }
            }
            
            // Alpha percent
            float tempAlpha = 1;
            tempString = inRequest.getParameter("alpha");
            if (tempString != null){
                try{
                    tempAlpha = Float.parseFloat(tempString);
                }
                catch (Exception e){
                }
            }
            tempScaleBar.setAlpha(tempAlpha);
            
            // Orientation
            int tempQuadrant = 0;
            tempString = inRequest.getParameter("quadrant");
            if (tempString != null){
                try{
                    tempQuadrant = Integer.parseInt(tempString);
                }
                catch (Exception e){
                }
            }
            tempScaleBar.setQuadrant(tempQuadrant);
            
            // Screen Width Percent
            float tempScreenWidth = 100;
            tempString = inRequest.getParameter("screenwidth");
            if (tempString != null){
                try{
                    tempScreenWidth = Float.parseFloat(tempString);
                }
                catch (Exception e){
                }
            }
            tempScaleBar.setScreenPercent(tempScreenWidth);
            
            // check for the horizontal offset
            tempString = inRequest.getParameter("hoff");
            if (tempString != null){
                try{
                    int tempOffset = Integer.parseInt(tempString);
                    tempScaleBar.setHorizontalOffset(tempOffset);
                }
                catch (NumberFormatException e){
                }
            }

            // check for the horizontal offset
            tempString = inRequest.getParameter("voff");
            if (tempString != null){
                try{
                    int tempOffset = Integer.parseInt(tempString);
                    tempScaleBar.setVerticalOffset(tempOffset);
                }
                catch (NumberFormatException e){
                }
            }
            
            tempScaleBar.setScreenPercent(tempScreenWidth);
            showSimpleScalebarPage(inRequest, inResponse, inServer, inService, tempScaleBar);
        }
    }
}

