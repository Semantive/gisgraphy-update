/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender;
import java.io.*;
import gistoolkit.display.*;
import gistoolkit.display.shader.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.shaderhandlers.*;
/**
 * Class for selecting amung the available shaders.
 */
public class ShaderHandler {
    public static final String SHADER_NAME_TAG = "SHADER_NAME";

    /** Creates new ShaderHandler */
    public ShaderHandler() {
    }

    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle) throws Exception{
        // look for the shader.
        String tempShaderName = inRequest.getParameter(SHADER_NAME_TAG);
        if (tempShaderName.equalsIgnoreCase("Range")){
            RangeShaderHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
            return;
        }
        if (tempShaderName.equalsIgnoreCase("Mono")){
            MonoShaderHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
            return;
        }
        if (tempShaderName.equalsIgnoreCase("Bin")){
            BinShaderHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
            return;
        }
        // show the select shader page.
        showShaderSelectPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
    }
    
    public static void showShaderSelectPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inCurrentShader){
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Style "+inStyle.getStyleName());

        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        String tempMonoChecked = "";
        if (inCurrentShader instanceof MonoShader) tempMonoChecked = "checked";
        String tempRangeChecked = "";
        if (inCurrentShader instanceof RangeShader) tempRangeChecked = "checked";
        String tempBinChecked = "";
        if (inCurrentShader instanceof BinShader) tempBinChecked = "checked";
        
        out.println("<b>Select the style of shader to use.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");        
        out.println("<br><b>Mono Shaders</b> Shade all shapes in a layer the same.  They are usefull for background layers like states, or countries.</br>");
        out.println("<br><input type=radio name="+SHADER_NAME_TAG+" value=\"Mono\" "+tempMonoChecked+">Mono Shader</br>");
        out.println("<br><b>Range Shaders</b> are capable of shading a map given a set of ranges for a particular attribute.  They are usefull for layers of interest where different colors and styles can be used to convey information.</br>");
        out.println("<br><input type=radio name="+SHADER_NAME_TAG+" value=\"Range\" "+tempRangeChecked+">Range Shader</br>");
        out.println("<br><b>Bin Shaders</b> are capable of shading a map given a set of ranges for a particular attribute.  In addition, they can use different ranges for different groups (or bins) of features.</br>");
        out.println("<br><input type=radio name="+SHADER_NAME_TAG+" value=\"Bin\" "+tempBinChecked+">Bin Shader</br>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }

    /** Given a string, this will try to convert it to a integer between 0 and 255.  If it fails, it will return 0.*/
    public static int rationalize(String inString){
        if (inString == null) return 0;
        int tempInt = 0;
        try{
            tempInt = Integer.parseInt(inString);
            if (tempInt > 255) tempInt = 255;
            if (tempInt < 0) tempInt = 0;
        }
        catch(NumberFormatException e){
        }
        return tempInt;
    }
    
}
