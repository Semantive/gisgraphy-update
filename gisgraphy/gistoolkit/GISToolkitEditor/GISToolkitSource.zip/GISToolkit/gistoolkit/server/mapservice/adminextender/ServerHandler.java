/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender;

import java.io.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;

/**
 * Handles messages for the server.
 */
public class ServerHandler {

    private static final String SERVER_ACTION_TAG = "SERVER_ACTION";
    private static final String SERVER_ACTION_SHOW_ADD_SERVICE = "SHOW_ADD_SERVICE";
    private static final String SERVER_ACTION_ADD_SERVICE = "ADD_SERVICE";
    private static final String SERVER_ACTION_DELETE_SERVICE = "DELETE_SERVICE";
    /** Creates new ServerHandler */
    public ServerHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer) throws Exception{
        // handle messages for this server.
        String tempAction = inRequest.getParameter(SERVER_ACTION_TAG);
        if (tempAction != null){
            handleAction(inRequest, inResponse, inServer, tempAction);
            return;
        }

        // if this message is for a particular service, then send it there.
        String tempServiceName = inRequest.getParameter(ServiceHandler.SERVICE_NAME_TAG);
        if (tempServiceName != null){
            ServiceHandler.doGet(inRequest, inResponse, inServer);
            return;
        }

        // show the generic server page.
        showServerPage(inRequest, inResponse, inServer);
    }

    /** Show the entire page of services. */
    public static void showServerPage(Request inRequest, Response inResponse, Server inServer){
        
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        AdminExtender.showHeaderPage(inRequest, inResponse, "Running Services");
        PrintWriter out = inResponse.getWriter();
        // loop through the services showing the names of them.
        Server tempServer = inServer;
        Service[] tempServices = tempServer.getServices();
        if (tempServices.length > 0){
            out.println("<P>");
            out.println("<b>Available Services</b>");
            out.println("<TABLE border=\"4\">");
            out.println("<tr><td><b>Service Name</b></td><td><b>Service Title</b></td><td><b>Service Link</b></td><td><b>Remove</b></td></tr>");
            for (int i=0; i<tempServices.length; i++){
                out.println("<tr><td>");
                out.println("<a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+tempServices[i].getServiceName()+"\"><b>"+tempServices[i].getServiceName()+"</b></a>");
                out.println("</td><td>");
                out.println(tempServices[i].getServiceTitle());
                out.println("</td><td>");
                out.println("<a href=\""+tempServices[i].getServiceLink()+"\" target=_blank>"+tempServices[i].getServiceLink()+"</a>");
                out.println("</td><td>");
                out.println("<a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+tempServices[i].getServiceName()+"&"+SERVER_ACTION_TAG+"="+SERVER_ACTION_DELETE_SERVICE+"\"><b>remove</b></a>");
                out.println("</td></tr>");
            }
            out.println("</TABLE>");
            out.println("</P>");
        }
        else{
            out.println("<b>No Services Found</b>");
        }
        
        // The add service button.
        out.println("<P>");
        out.println("<a href=\""+tempURLBase+"?"+SERVER_ACTION_TAG+"="+SERVER_ACTION_SHOW_ADD_SERVICE+"\">Add Service</a>");
        out.println("</P>");
        AdminExtender.showTailerPage(inRequest, inResponse);
    }

    /** Handle the actions coming from the server page. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, String inServerAction){
        // show the add service page.
        if (inServerAction.equalsIgnoreCase(SERVER_ACTION_SHOW_ADD_SERVICE)){
            AdminExtender.showHeaderPage(inRequest, inResponse, "Add New Service");
            PrintWriter out = inResponse.getWriter();
            String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
            // show the information about the service.
            out.println("<P>");
            out.println("<form method=post ACTION="+tempURLBase+">");
            out.println("<TABLE border=\"4\">");
            out.println("<tr><td>");
            out.println("<br><b>Service Name</b></br>");
            out.println("<br>A short just a few character name to be used in the URL.  Do not include spaces or special characters.</br>");
            out.println("<br><input type=text name=Update_Service_Name value=\"NewService\"></br>");
            out.println("<br><b>Service Title</b></br>");
            out.println("<br>A long description of the service, may include spaces and special characters.</br>");
            out.println("<br><input type=text name=Update_Service_Title value=\"New Service Title\" size=100></br>");
            out.println("<br><b>Service Link</b></br>");
            out.println("<br>Usually a web address where the user can find additional information about this service.</br>");
            out.println("<br><input type=text name=Update_Service_Link value=\"http://www.serviceinfoserver.com/ServiceInfo.html\" size=100></br>");
            out.println("<input type=hidden name="+SERVER_ACTION_TAG+" value="+SERVER_ACTION_ADD_SERVICE+">");
            out.println("<br><input type=submit value=submit></br>");
            out.println("</td></tr>");
            out.println("</TABLE>");
            out.println("</form>");
            out.println("</P>");
            AdminExtender.showTailerPage(inRequest, inResponse);
        }
        if (inServerAction.equalsIgnoreCase(SERVER_ACTION_ADD_SERVICE)){
            String tempString = inRequest.getParameter("Update_Service_Name");
            if ((tempString != null)&&(tempString.trim().length() >0)){
                // check for duplicates
                Service tempService = inServer.getService(tempString);
                if (tempService != null){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Service "+tempString+" Already exists, delete the existing one first and then add this one. ");
                    return;
                }
                tempService = new Service();
                tempService.setServiceName(tempString);
                tempString = inRequest.getParameter("Update_Service_Title");
                tempService.setServiceTitle(tempString);
                tempString = inRequest.getParameter("Update_Service_Link");
                tempService.setServiceLink(tempString);
                inServer.addService(tempService);
                showServerPage(inRequest, inResponse, inServer);
                return;
            }
            AdminExtender.showErrorPage(inRequest, inResponse, "Service Name does not exist");
        }
        // Delete the service
        if (inServerAction.equalsIgnoreCase(SERVER_ACTION_DELETE_SERVICE)){
            String tempString = inRequest.getParameter(ServiceHandler.SERVICE_NAME_TAG);
            if ((tempString != null)&&(tempString.trim().length() >0)){
                Service tempService = inServer.getService(tempString);
                if (tempService != null){                    
                    // Remove the given service
                    inServer.removeService(tempService);
                    showServerPage(inRequest, inResponse, inServer);
                    return;
                }
                else AdminExtender.showErrorPage(inRequest, inResponse, "Service named "+tempString+" not found on this server.");
            }
            else AdminExtender.showErrorPage(inRequest, inResponse, "Service Name does not exist");
        }
    }
}
