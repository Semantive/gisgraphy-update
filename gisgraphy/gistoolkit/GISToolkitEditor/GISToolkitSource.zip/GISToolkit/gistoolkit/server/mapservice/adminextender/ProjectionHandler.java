/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender;
import java.io.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.projection.*;
import gistoolkit.server.mapservice.adminextender.projectionhandlers.*;
/**
 *
 */
public class ProjectionHandler {
    public static final String PROJECTION_NAME_TAG = "PROJECTION_NAME";

    /** Creates new ShaderHandler */
    public ProjectionHandler() {
    }

    /** Projection function for the service aka, the To Projection. */
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService) throws Exception{
        // look for the shader.
        String tempProjectionName = inRequest.getParameter(PROJECTION_NAME_TAG);
        if (tempProjectionName != null){
            if (tempProjectionName.equalsIgnoreCase(NoProjectionHandler.getProjectionName())){
                NoProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inService.getProjection());
                return;
            }
            if (tempProjectionName.equalsIgnoreCase(LambertConicConformalProjectionHandler.getProjectionName())){
                LambertConicConformalProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inService.getProjection());
                return;
            }
            if (tempProjectionName.equalsIgnoreCase(UniversalTransverseMercatorProjectionHandler.getProjectionName())){
                UniversalTransverseMercatorProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inService.getProjection());
                return;
            }
            if (tempProjectionName.equalsIgnoreCase(AlbersEqualAreaProjectionHandler.getProjectionName())){
                AlbersEqualAreaProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inService.getProjection());
                return;
            }
        }
        // show the select shader page.
        showProjectionSelectPage(inRequest, inResponse, inServer, inService, null, inService.getProjection());
    }
    
    /** Show function for the layer, aka, the From Projection. */
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer) throws Exception{
        // look for the shader.
        String tempProjectionName = inRequest.getParameter(PROJECTION_NAME_TAG);
        if (tempProjectionName != null){
            if (tempProjectionName.equalsIgnoreCase(NoProjectionHandler.getProjectionName())){
                NoProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inLayer.getFromProjection());
                return;
            }
            if (tempProjectionName.equalsIgnoreCase(LambertConicConformalProjectionHandler.getProjectionName())){
                LambertConicConformalProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inLayer.getFromProjection());
                return;
            }
            if (tempProjectionName.equalsIgnoreCase(UniversalTransverseMercatorProjectionHandler.getProjectionName())){
                UniversalTransverseMercatorProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inLayer.getFromProjection());
                return;
            }
            if (tempProjectionName.equalsIgnoreCase(AlbersEqualAreaProjectionHandler.getProjectionName())){
                AlbersEqualAreaProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inLayer.getFromProjection());
                return;
            }
        }
        // show the select shader page.
        showProjectionSelectPage(inRequest, inResponse, inServer, inService, inLayer, inLayer.getFromProjection());
    }
        
    public static void showProjectionSelectPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection){
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Projection "+inService.getServiceName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        String tempNoneChecked = "";
        if (inProjection instanceof NoProjection) tempNoneChecked = "checked";
        String tempLLCChecked = "";
        if (inProjection instanceof LambertConicConformalProjection) tempLLCChecked = "checked";
        String tempUTMChecked = "";
        if (inProjection instanceof UniversalTransverseMercatorProjection) tempUTMChecked = "checked";
        String tempAEAChecked = "";
        if (inProjection instanceof AlbersEqualAreaProjection) tempAEAChecked = "checked";
        
        out.println("<b>Select the Projection to use.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");        
        out.println("<br><b>No Projection</b> No projection is applied, the map is in the projection of the data.</br>");
        out.println("<br><input type=radio name="+PROJECTION_NAME_TAG+" value=\""+NoProjectionHandler.getProjectionName()+"\" "+tempNoneChecked+">No Projection</br>");
        out.println("<br><b>UTM (Universal Transverse Mercator)</b> The map will be projected into one of the UTM zones.</br>");
        out.println("<br><input type=radio name="+PROJECTION_NAME_TAG+" value=\""+UniversalTransverseMercatorProjectionHandler.getProjectionName()+"\" "+tempUTMChecked+">UTM</br>");
        out.println("<br><b>Albers Equal Area</b> This projection, is predominantly used to map regions of large east-west extent, in particular the United States.</br>");
        out.println("<br><input type=radio name="+PROJECTION_NAME_TAG+" value=\""+AlbersEqualAreaProjectionHandler.getProjectionName()+"\" "+tempAEAChecked+">Albers Equal Area<</br>");
        out.println("<br><b>Lambert Conformal Conic</b>Unlike the Albers projection, Lambert's conformal projection is not equal-area. The parallels are arcs of circles with a common origin, and meridians are the equally spaced radii of these circles.</br>");
        out.println("<br><input type=radio name="+PROJECTION_NAME_TAG+" value=\""+LambertConicConformalProjectionHandler.getProjectionName()+"\" "+tempLLCChecked+">Lambert Conformal Conic</br>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        if (inLayer != null) out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }    
}
