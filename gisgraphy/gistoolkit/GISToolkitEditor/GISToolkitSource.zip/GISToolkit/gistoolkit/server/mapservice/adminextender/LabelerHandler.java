/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.server.mapservice.adminextender;
import java.io.*;
import gistoolkit.display.*;
import gistoolkit.display.labeler.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.labelerhandlers.*;
/**
 * Class for selecting amung the available labelers.
 */
public class LabelerHandler {
    public static final String LABELER_NAME_TAG = "LABELER_NAME";
    public static final String LABELER_NUM_TAG = "LABELER_NUM";
    public static final String LABELER_ACTION_TAG = "RENDERER_ACTION";
    public static final String LABELER_ACITON_ADD = "ADD";
    
    /** Creates new LabelerHandler */
    public LabelerHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle) throws Exception{
        // look for an action for this handler.
        String tempAction = inRequest.getParameter(LABELER_ACTION_TAG);
        if (tempAction != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inStyle, tempAction);
            return;
        }
        // look for the labeler.
        String tempLabelerNumString = inRequest.getParameter(LABELER_NUM_TAG);
        if (tempLabelerNumString == null){
            AdminExtender.showErrorPage(inRequest, inResponse, "Labeler edit requested, but no "+LABELER_NUM_TAG+" specified.");
            return;
        }
        else{
            try{
                int tempLabelerNum = Integer.parseInt(tempLabelerNumString);
                // edit the labeler
                Labeler tempLabeler = inStyle.getLabeler(tempLabelerNum);
                if (tempLabeler instanceof SimpleLabeler){
                    SimpleLabelerHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inStyle, tempLabeler, tempLabelerNum);
                }
            }
            catch(NumberFormatException e){
                AdminExtender.showErrorPage(inRequest, inResponse, "Error parsing "+LABELER_NUM_TAG+" \""+tempLabelerNumString+"\" is not an integer");
                return;
            }
        }        
    }    
    /** Handle any action events for this handler.*/
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, String inAction) throws Exception{
        if (inAction.equalsIgnoreCase(LABELER_ACITON_ADD)){
            // which labeler to add
            String templabelerName = inRequest.getParameter(LABELER_NAME_TAG);
            if (templabelerName != null){
                if (templabelerName.equalsIgnoreCase("FeatureLabeler")){
                    inStyle.add(new FeatureLabeler());
                }
                if (templabelerName.equalsIgnoreCase("Polygon")){
                    inStyle.add(new PolygonLabeler());
                }
                if (templabelerName.equalsIgnoreCase("Line")){
                    inStyle.add(new LineLabeler());
                }
            }
        }
        StyleHandler.showStylePage(inRequest, inResponse, inServer, inService, inLayer, inStyle);
        return;
    }
    /** Show a selection of available Labelers to be added to the style. */
    public static void showAddPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle) throws Exception{
        // show the select page.
        AdminExtender.showHeaderPage(inRequest, inResponse, "Select Renderer for style "+inStyle.getStyleName());
        
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
                
        out.println("<b>Select the renderer to add.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<br><b>Feature Labeler</b> Labels all features in the default way.</br>");
        out.println("<br><input type=radio name="+LABELER_NAME_TAG+" value=\"FeatureLabeler\" checked>Feature Labeler</br>");
        out.println("<br><b>Polygon Labeler</b>Only labels polygons.</br>");
        out.println("<br><input type=radio name="+LABELER_NAME_TAG+" value=\"Polygon\" >Polygon Labeler</br>");
        out.println("<br><b>Line Labeler</b>Only labels lines.</br>");
        out.println("<br><input type=radio name="+LABELER_NAME_TAG+" value=\"Line\" >Line Labeler</br>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+LabelerHandler.LABELER_NUM_TAG+" value=0>");
        out.println("<input type=hidden name="+LabelerHandler.LABELER_ACTION_TAG+" value="+LabelerHandler.LABELER_ACITON_ADD+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
}
