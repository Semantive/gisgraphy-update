/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package gistoolkit.server.mapservice.adminextender;
import java.io.*;
import gistoolkit.display.*;
import gistoolkit.display.renderer.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.rendererhandlers.*;
/**
 * Class for selecting amung the available Renderers.
 */
public class RendererHandler {
    public static final String RENDERER_NAME_TAG = "RENDERER_NAME";
    public static final String RENDERER_NUM_TAG = "RENDERER_NUM";
    public static final String RENDERER_ACTION_TAG = "RENDERER_ACTION";
    public static final String RENDERER_ACITON_ADD = "ADD";
    
    /** Creates new RENDERERHandler */
    public RendererHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle) throws Exception{
        // look for an action for this handler.
        String tempAction = inRequest.getParameter(RENDERER_ACTION_TAG);
        if (tempAction != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inStyle, tempAction);
            return;
        }
        // look for the renderer.
        String tempRendererNumString = inRequest.getParameter(RENDERER_NUM_TAG);
        if (tempRendererNumString != null){
            try{
                int tempRendererIndex = Integer.parseInt(tempRendererNumString);
                // find the kind of renderer
                Renderer tempRenderer = inStyle.getRenderer(tempRendererIndex);
                if (tempRenderer instanceof PointImageRenderer){
                    PointImageRendererHandler.doGet(inRequest, inResponse, inServer, inService, inLayer, inStyle, tempRenderer, tempRendererIndex);
                    return;
                }
                else{
                    AdminExtender.showErrorPage(inRequest, inResponse, "Renderer "+tempRenderer.getRendererName()+" is not editable.");
                    return;
                }
            }
            catch (NumberFormatException e){
                AdminExtender.showErrorPage(inRequest, inResponse, "Renderer editing requested but "+RENDERER_NUM_TAG+" is not an integer");
                return;
            }
        }
    }

    /** Handle any action events for this handler.*/
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, String inAction) throws Exception{
        if (inAction.equalsIgnoreCase(RENDERER_ACITON_ADD)){
            // which renderer to add
            String tempRendererName = inRequest.getParameter(RENDERER_NAME_TAG);
            if (tempRendererName != null){
                if (tempRendererName.equalsIgnoreCase("Feature")){
                    inStyle.add(new FeatureRenderer());
                }
                if (tempRendererName.equalsIgnoreCase("PointImage")){
                    inStyle.add(new PointImageRenderer());
                }
            }
        }
        StyleHandler.showStylePage(inRequest, inResponse, inServer, inService, inLayer, inStyle);
        return;
    }
    /** Show a selection of available Renderers to be added to the style. */
    public static void showAddPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle) throws Exception{
        // show the select page.
        AdminExtender.showHeaderPage(inRequest, inResponse, "Select Renderer for style "+inStyle.getStyleName());
        
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
                
        out.println("<b>Select the renderer to add.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<br><b>Feature Renderer</b> Renders all features in the default way.</br>");
        out.println("<br><input type=radio name="+RENDERER_NAME_TAG+" value=\"Feature\" checked>Feature Renderer</br>");
        out.println("<br><b>Point Image Renderer</b>Renders points and multipoints with a bitmapped image.</br>");
        out.println("<br><input type=radio name="+RENDERER_NAME_TAG+" value=\"PointImage\" >Point Image Renderer</br>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+RendererHandler.RENDERER_NUM_TAG+" value=0>");
        out.println("<input type=hidden name="+RendererHandler.RENDERER_ACTION_TAG+" value="+RendererHandler.RENDERER_ACITON_ADD+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }    
}