/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender.projectionhandlers;
import java.io.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.projection.*;
import gistoolkit.server.mapservice.adminextender.AdminExtender;
import gistoolkit.server.mapservice.adminextender.ServiceHandler;
import gistoolkit.server.mapservice.adminextender.LayerHandler;
import gistoolkit.server.mapservice.adminextender.ProjectionHandler;

/**
 *
 */
public class NoProjectionHandler {
    private static final String NO_PROJECTION_ACTION_TAG = "NO_PROJECTION_ACTION";
    private static final String NO_PROJECTION_ACTION_UPDATE = "NO_PROJECTION_UPDATE";
    
    /** Creates new RangeShaderHandler */
    public NoProjectionHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, Projection inProjection) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(NO_PROJECTION_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, null, inProjection);
            return;
        }
        showNoProjectionPage(inRequest, inResponse, inServer, inService, null, inProjection);
    }
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(NO_PROJECTION_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inProjection);
            return;
        }
        showNoProjectionPage(inRequest, inResponse, inServer, inService, inLayer, inProjection);
    }
    public static void showNoProjectionPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection){
        Projection tempProjection = null;
        if (inProjection instanceof NoProjection){
            tempProjection = (NoProjection) inProjection;
        }
        else{
            tempProjection = new NoProjection();
            try{
                if (inLayer == null) inService.setProjection(tempProjection);
                else inLayer.setFromProjection(tempProjection);
            }
            catch (Exception e){
                AdminExtender.showErrorPage(inRequest, inResponse, "Error setting NoProjection "+e);
                return;
            }
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Projection "+tempProjection.getProjectionName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        out.println("<b>Attributes of the the NoProjection.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // Show the shader parameters
        out.println("<br>There are no projection parameters for the NoProjection Projection, it just displays the raw data in it's native projection.</br>");
        out.println("<p>");
        
        // Select a SRS (Spatial Reference System) For this projection.
        if (inLayer == null){
            out.println("<p><b>SRS</b> (Spatial Reference System)<br></p>");
            out.println("<p>The SRS for Latitude/Longitude WGS84 is \"EPSG:4326\" for additional projections visit <a \"href=http://www.epsg.org\">http://www.epsg.org</a>");
            out.print("<p><input type=text name=SRS value=\""+inService.getSRS()+"\"></p>");
        }
        
        out.println("<p><input type=submit value=submit></p>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value=\""+inService.getServiceName()+"\">");
        if (inLayer != null) out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value=\""+inLayer.getLayerName()+"\">");
        out.println("<input type=hidden name="+ProjectionHandler.PROJECTION_NAME_TAG+" value=\""+tempProjection.getProjectionName()+"\">");
        out.println("<input type=hidden name="+NO_PROJECTION_ACTION_TAG+" value="+NO_PROJECTION_ACTION_UPDATE+">");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    /** Handle action events. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Projection inProjection){
        if (inLayer == null){
            // the only thing to do is to store the SRS.
            String tempSRS = inRequest.getParameter("SRS");
            if (tempSRS != null) inService.setSRS(tempSRS);
        }
        showNoProjectionPage(inRequest, inResponse, inServer, inService, inLayer, inProjection);
    }
    public static String getProjectionName(){return new NoProjection().getProjectionName();}
}
