/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender.shaderhandlers;
import java.util.*;
import java.io.*;
import java.awt.*;
import gistoolkit.display.*;
import gistoolkit.display.shader.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.*;

/**
 *
 */
public class BinShaderHandler {
    private static final String BIN_SHADER_ACTION_TAG = "BIN_SHADER_ACTION";
    private static final String BIN_SHADER_ACTION_UPDATE = "BIN_SHADER_UPDATE";
    
    /** Creates new RangeShaderHandler */
    public BinShaderHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(BIN_SHADER_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader(), tempString);
            return;
        }
        showBinShaderPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
    }
    public static void showBinShaderPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader){
        BinShader tempShader = null;
        if (inShader instanceof BinShader){
            tempShader = (BinShader) inShader;
        }
        else{
            tempShader = new BinShader();
            inStyle.setShader(tempShader);
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Style "+inStyle.getStyleName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        out.println("<b>Attributes of the bin shader.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // show the line color
        out.println("<br>When specifying the RGB values here, each value is an integer in the range of 0 to 255. No color is 0, so 0,0,0 is black, and 255,255,255 is white.</br>");
        out.println("<p>");
        if (tempShader.getDefaultLineColor() != null){
            out.print("<input type=checkbox name=ulc value=true checked><b>Line Color </b>");
            out.print("Red: <input type=text name=ulr value=\""+tempShader.getDefaultLineColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulg value=\""+tempShader.getDefaultLineColor().getGreen()+"\">");
            out.println("Blue: <input type=text name=ulb value=\""+tempShader.getDefaultLineColor().getBlue()+"\">");
        }
        else{
            out.println("<input type=checkbox name=ulc value=true ><b>Line Color </b>");
            out.print("Red: <input type=text name=ulr value=\"0\">");
            out.print("Green: <input type=text name=ulg value=\"0\">");
            out.print("Blue: <input type=text name=ulb value=\"0\">");
        }
        out.println("</p>");
        out.println("<p>");
        if (tempShader.getDefaultFillColor() != null){
            out.print("<input type=checkbox name=ufc value=true checked><b>Fill Color </b>");
            out.print("Red: <input type=text name=ufr value=\""+tempShader.getDefaultFillColor().getRed()+"\">");
            out.print("Green: <input type=text name=ufg value=\""+tempShader.getDefaultFillColor().getGreen()+"\">");
            out.println("Blue: <input type=text name=ufb value=\""+tempShader.getDefaultFillColor().getBlue()+"\">");
        }
        else{
            out.print("<input type=checkbox name=ufc value=true><b>Fill Color </b>");
            out.print("Red: <input type=text name=ufr value=\"255\">");
            out.print("Green: <input type=text name=ufg value=\"255\">");
            out.println("Blue: <input type=text name=ufb value=\"255\">");
        }
        out.println("</p>");
        out.println("<p>");
        if (tempShader.getDefaultLabelColor() != null){
            out.print("<input type=checkbox name=ulac value=true checked><b>Label Color </b>");
            out.print("Red: <input type=text name=ular value=\""+tempShader.getDefaultLabelColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulag value=\""+tempShader.getDefaultLabelColor().getGreen()+"\">");
            out.println("Blue:<input type=text name=ulab value=\""+tempShader.getDefaultLabelColor().getBlue()+"\">");
        }
        else{
            out.print("<input type=checkbox name=ulac value=true><b>Label Color </b>");
            out.print("Red: <input type=text name=ular value=\"0\">");
            out.print("Green: <input type=text name=ulag value=\"0\">");
            out.println("Blue: <input type=text name=ulab value=\"255\">");
        }
        // Label Font
        out.println("<p>");
        out.println("<p>Font Name</p>");
        Font tempFont = tempShader.getDefaultFont();
        out.println("<br><select name=FN>");
        String tempFontName = tempFont.getFontName();
        Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
        for (int i=0; i<tempFontSelection.length; i++){
            String tempTestName = tempFontSelection[i].getFontName();
            out.print("   <Option Value=\""+tempTestName+"\" ");
            if (tempFontName.equals(tempTestName)){
                out.print("Selected");
            }
            out.println(">"+tempTestName);
        }
        out.println("</select>");
        out.println("</p>");
        
        // Font Size
        out.println("<p>");
        out.println("<p>Font Size</p>");
        int[] tempSizes = {7,8,9,10,12,14,16,18,20,25,30,40,48,56,72};
        int tempSize = tempFont.getSize();
        out.println("<select name=FS>");
        for (int i=0; i<tempSizes.length; i++){
            out.println("   <Option Value="+tempSizes[i]+" "+AdminExtender.getSelected(tempSize, tempSizes[i])+">"+tempSizes[i]);
        }
        out.println("</select>");
        out.println("</p>");
                      
        // Line Width
        out.println("</p>");
        out.println("<br>How thick would you like the line to be (in pixels)");
        out.println("<br><select name=ulw>");
        BasicStroke tempStroke = null;
        if (tempShader.getStroke() instanceof BasicStroke){
            tempStroke = (BasicStroke) tempShader.getStroke();
        }
        else{
            tempStroke = new BasicStroke();
        }   
        int tempWidth = (int) tempStroke.getLineWidth();
        out.println("<Option Value=1 "+getSelected(tempWidth, 1)+">1");
        out.println("<Option Value=2 "+getSelected(tempWidth, 2)+">2");
        out.println("<Option Value=3 "+getSelected(tempWidth, 3)+">3");
        out.println("<Option Value=4 "+getSelected(tempWidth, 4)+">4");
        out.println("<Option Value=5 "+getSelected(tempWidth, 5)+">5");
        out.println("<Option Value=6 "+getSelected(tempWidth, 6)+">6");
        out.println("<Option Value=7 "+getSelected(tempWidth, 7)+">7");
        out.println("<Option Value=8 "+getSelected(tempWidth, 8)+">8");
        out.println("<Option Value=9 "+getSelected(tempWidth, 9)+">9");
        out.println("<Option Value=10 "+getSelected(tempWidth, 10)+">10");
        out.println("</select>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+ShaderHandler.SHADER_NAME_TAG+" value=Bin>");
        out.println("<input type=hidden name="+BIN_SHADER_ACTION_TAG+" value="+BIN_SHADER_ACTION_UPDATE+">");
        
        // the relevent columns to shade by.
        out.println("<p><b>Column to shade bin by</b>");
        out.println("<br><input type=text name=BinColumn value=\""+tempShader.getBinColumnName()+"\"></br></p>");
        out.println("<p><b>Column with values</b>");
        out.println("<br><input type=text name=ValueColumn value=\""+tempShader.getValueColumnName()+"\"></br></p>");

        // show the bins.
        String[] tempBinNames = tempShader.getBinNames();
        out.println("<input type=hidden name=bnum value="+(tempBinNames.length+5)+">");        
        out.println("<input type=hidden name=enum value="+(tempShader.getEntries().length+5)+">");                
        out.println("<table border=2 halign=left valigh=top>");
        
        // bin names.
        out.print("<tr><td></td><td>Bin Names</td>");
        for (int i=0; i<(tempBinNames.length+5); i++){
            out.print("<td>");
            if (i<tempBinNames.length){
                out.println("\t<input type=text name=bn"+i+" value=\""+tempBinNames[i]+"\"></br>");
            }
            else{
                out.println("\t<input type=text name=bn"+i+" ></br>");
            }
            out.print("</td>");
        }
        out.println("</tr>");
        
        // bin colors
        Color[] tempBinColors = tempShader.getBinColors();
        out.println("<tr><td></td><td>Bin Colors</td>");
        for (int i=0; i<tempBinNames.length+5; i++){
            if (i<tempBinColors.length){
                out.println("\t<td>");
                out.println("\t<br>R:<input type=text name=br"+i+" value=\""+tempBinColors[i].getRed()+"\"></br>");
                out.println("\t<br>G:<input type=text name=bg"+i+" value=\""+tempBinColors[i].getGreen()+"\"></br>");
                out.println("\t<br>B:<input type=text name=bb"+i+" value=\""+tempBinColors[i].getBlue()+"\"></br>");
                out.println("\t</td>");
            }
            else{
                out.println("\t<td>");
                out.println("\t<br>R:<input type=text name=br"+i+" ></br>");
                out.println("\t<br>G:<input type=text name=bg"+i+" ></br>");
                out.println("\t<br>B:<input type=text name=bb"+i+" ></br>");
                out.println("\t</td>");
            }
        }
        out.println("</tr>");
        
        // entries.
        BinEntry[] tempEntries = tempShader.getEntries();
        for (int i=0; i<tempEntries.length + 5; i++){
            out.print("<tr><td>");
            if (i < tempEntries.length){
                StringBuffer sb = new StringBuffer();
                String[] tempValues = tempEntries[i].getValues();
                if(tempValues.length == 0) sb.append(",");
                else{
                    for (int j=0; j<tempValues.length; j++){
                        if (j>0) sb.append(",");
                        sb.append(tempValues[j]);
                    }
                }
                out.print("<input type=text name=ev"+i+" value=\""+sb.toString()+"\">");
                out.println("</td>");
                out.println("<td>Min</td>");
                for (int j=0; j<(tempEntries[i].getBinCount()+5); j++){
                    out.println("<td>");
                    if (j<tempEntries[i].getBinCount()){
                        out.print("<input type=text name=ei"+i+"b"+j+" value=\""+tempEntries[i].getMin(j)+"\">");
                    }
                    else{
                        out.print("<input type=text name=ei"+i+"b"+j+" >");
                    }
                    out.println("</td>");
                }
                out.println("</tr>");
                out.println("<tr><td></td><td>Max</td>");
                for (int j=0; j<(tempEntries[i].getBinCount()+5); j++){
                    out.println("<td>");
                    if (j<tempEntries[i].getBinCount()){
                        out.print("<input type=text name=ea"+i+"b"+j+" value=\""+tempEntries[i].getMax(j)+"\">");
                    }
                    else{
                        out.print("<input type=text name=ea"+i+"b"+j+" >");
                    }
                    out.println("</td>");
                }
            }
            else{
                out.print("<input type=text name=ev"+i+" >");
                out.println("</td>");
                out.println("<td>Min</td>");
                for (int j=0; j<(tempBinNames.length+5); j++){
                    out.println("<td>");
                    out.print("<input type=text name=ei"+i+"b"+j+" >");
                    out.println("</td>");
                }
                out.println("<tr><td></td><td>Max</td>");
                for (int j=0; j<(tempBinNames.length+5); j++){
                    out.println("<td>");
                    out.print("<input type=text name=ea"+i+"b"+j+" >");
                    out.println("</td>");
                }
            }
            out.println("</tr>");
        }            
        out.println("</table>");
        out.println("<p><input type=submit value=submit></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    /** Utility method for determining if a choice item should be selected. */
    private static String getSelected(int inValue, int inConstant){
        if(inValue == inConstant) return "Selected";
        return "";
    }
    /** Handle events for the mono shader. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader, String inAction){
        BinShader tempShader = null;
        if (inShader instanceof BinShader){
            tempShader = (BinShader) inShader;
        }
        else{
            tempShader = new BinShader();
            inStyle.setShader(tempShader);
        }
        
        if (inAction.equalsIgnoreCase(BIN_SHADER_ACTION_UPDATE)){
            tempShader.removeAllBins();
            // check for the line color
            String tempString = inRequest.getParameter("ulc");
            if (tempString == null){
                tempShader.setDefaultLineColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ulr"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulg"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulb"));
                tempShader.setDefaultLineColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the fill color
            tempString = inRequest.getParameter("ufc");
            if (tempString == null){
                tempShader.setDefaultFillColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ufr"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ufg"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ufb"));
                tempShader.setDefaultFillColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the label color
            tempString = inRequest.getParameter("ulac");
            if (tempString == null){
                tempShader.setDefaultLabelColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ular"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulag"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulab"));
                tempShader.setDefaultLabelColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the label font
            Font tempFont = tempShader.getDefaultFont();
            String tempFontName = tempFont.getFontName();
            String tempSelectedName = inRequest.getParameter("FN");
            if (tempSelectedName != null){
                if (!tempFontName.equals(tempSelectedName)){
                    Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
                    for (int i=0; i<tempFontSelection.length; i++){
                        String tempTestName = tempFontSelection[i].getFontName();
                        if (tempSelectedName.equals(tempTestName)){
                            // set the new font into the scale bar
                            tempShader.setDefaultFont(tempFontSelection[i]);
                            break;
                        }
                    }
                }
            }
            
            // check for the label font size
            tempString = inRequest.getParameter("FS");
            if (tempString != null){
                try{
                    int tempSize = Integer.parseInt(tempString);
                    tempFont = tempShader.getDefaultFont();
                    int tempFontSize = tempFont.getSize();
                    if (tempFontSize != tempSize){
                        tempFont = tempFont.deriveFont((float)tempSize);
                        tempShader.setDefaultFont(tempFont);
                    }
                }
                catch (NumberFormatException e){
                }
            }

            // line width
            int tempLineWidth = ShaderHandler.rationalize(inRequest.getParameter("ulw"));
            tempShader.setStroke(new BasicStroke((float)tempLineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND ));
            
            // Bin Column
            tempShader.setBinColumnName(inRequest.getParameter("BinColumn"));
            // Value Column
            tempShader.setValueColumnName(inRequest.getParameter("ValueColumn"));
            
            // the bins
            int tempMaxBins = getInt(inRequest.getParameter("bnum"));
            boolean[] tempValidBins = new boolean[tempMaxBins];
            for (int i=0; i<tempMaxBins; i++){
                tempValidBins[i] = false;
                String tempBinName = inRequest.getParameter("bn"+i);
                if ((tempBinName != null) && (tempBinName.length() > 0)){
                    // Search for the bin color
                    int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("br"+i));
                    int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("bg"+i));
                    int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("bb"+i));
                    Color tempBinColor = new Color(tempIntRed, tempIntGreen, tempIntBlue);
                    // add this bin.
                    tempShader.addBin(tempBinName, tempBinColor);
                    tempValidBins[i] = true;
                }
            }
            
            // the entries.
            int tempMaxEntries = getInt(inRequest.getParameter("enum"));
            for (int i=0; i<tempMaxEntries; i++){
                // The entry values.
                String tempValueString = inRequest.getParameter("ev"+i);
                if ((tempValueString != null) && (tempValueString.length() > 0)){
                    
                    ArrayList tempValuesList = new ArrayList();
                    if ((tempValueString.length() == 1) && (tempValueString.charAt(0) == ',')){
                        // leave the value list with 0 entries.
                    }
                    else{
                        // parse out the individual values
                        StringTokenizer st = new StringTokenizer(tempValueString);
                        while (st.hasMoreElements()){
                            tempValuesList.add(st.nextToken(",").trim());
                        }
                    }
                    String[] tempValues = new String[tempValuesList.size()];
                    tempValuesList.toArray(tempValues);
                
                    // parse out the max and minimum values
                    double[] tempMins = new double[tempShader.getBinNames().length];
                    double[] tempMaxs = new double[tempShader.getBinNames().length];
                    int tempCurrentIndex = 0;
                    for (int j=0; j<tempValidBins.length; j++){
                        if (tempValidBins[j] == true){
                            tempMins[tempCurrentIndex] = getDouble(inRequest.getParameter("ei"+i+"b"+j));
                            tempMaxs[tempCurrentIndex] = getDouble(inRequest.getParameter("ea"+i+"b"+j));
                            tempCurrentIndex++;
                        }
                    }
                    
                    // add the entry
                    tempShader.addEntry(tempValues, tempMins, tempMaxs);
                }
            }
            showBinShaderPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
        }
    }
    
    // parse a double from a string.
    private static double getDouble(String inString){
        if (inString == null) return 0;
        try{
            double tempDouble = Double.parseDouble(inString);
            if (tempDouble < 0) return 0;
            return tempDouble;
        }
        catch(Exception e){
            return 0;
        }
    }
    // parse a double from a string.
    private static int getInt(String inString){
        if (inString == null) return 0;
        try{
            int tempint = Integer.parseInt(inString);
            if (tempint < 0) return 0;
            return tempint;
        }
        catch(Exception e){
            return 0;
        }
    }
}
