/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender;
import java.io.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.display.*;
import gistoolkit.display.scalebar.*;
import gistoolkit.server.mapservice.adminextender.scalebarhandlers.*;
/**
 * Allows selection of different ScaleBars.
 */
public class ScaleBarHandler {
    public static final String SCALEBAR_NAME_TAG = "SCALEBAR_NAME";
    public static final String SCALEBAR_ACTION_TAG = "SCALEBAR_ACTION";
    public static final String NO_SCALBAR_NAME = "NoScalebar";
    public static final String METER_TO_METRIC = "MeterToMetric";
    public static final String METER_TO_ENGLISH = "MeterToEnglish";

    /** Creates new ScaleBarHandler */
    public ScaleBarHandler() {
    }

    /** Handle requests for the service. */
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService) throws Exception{
        // look for the ScaleBar.
        String tempScaleBarName = inRequest.getParameter(SCALEBAR_NAME_TAG);
        if (tempScaleBarName != null){
            ScaleBar tempScaleBar = inService.getScaleBar();
            if (tempScaleBarName.equalsIgnoreCase(NO_SCALBAR_NAME)){
                inService.setScaleBar(null);
                ServiceHandler.showServicePage(inRequest, inResponse, inServer, inService);
                return;
            }
            if (tempScaleBarName.equalsIgnoreCase(METER_TO_METRIC)){
                if (!(tempScaleBar instanceof MeterToMetricScaleBar)){
                    tempScaleBar = new MeterToMetricScaleBar();
                    inService.setScaleBar(tempScaleBar);
                }
            }
            else {
                if (!(tempScaleBar instanceof MeterToEnglishScaleBar)){
                    tempScaleBar = new MeterToEnglishScaleBar();
                    inService.setScaleBar(tempScaleBar);
                }
            }
            SimpleScaleBarHandler.doGet(inRequest, inResponse, inServer, inService, tempScaleBar);
            return;
        }
        // show the select ScaleBar page.
        showScaleBarSelectPage(inRequest, inResponse, inServer, inService, inService.getScaleBar());
    }
    
        
    public static void showScaleBarSelectPage(Request inRequest, Response inResponse, Server inServer, Service inService, ScaleBar inScaleBar){
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Scale Bar "+inService.getServiceName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        String tempNoneChecked = "";
        if (inScaleBar == null) tempNoneChecked = "checked";
        String tempMeterToMetricChecked = "";
        if (inScaleBar instanceof MeterToMetricScaleBar) tempMeterToMetricChecked = "checked";
        String tempMeterToEnglishChecked = "";
        if (inScaleBar instanceof MeterToEnglishScaleBar) tempMeterToEnglishChecked = "checked";
        
        out.println("<b>Select the Projection to use.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");        
        out.println("<br><b>No Scale Bar</b> No Scalebar is applied.</br>");
        out.println("<br><input type=radio name="+SCALEBAR_NAME_TAG+" value=\""+NO_SCALBAR_NAME+"\" "+tempNoneChecked+">No ScaleBar</br>");
        out.println("<br><b>Meters to Metric</b> If your projection is in meters (most are), then this will display the map distances in metric units, kilometer, meter, centimeter, milimeter etc.</br>");
        out.println("<br><input type=radio name="+SCALEBAR_NAME_TAG+" value=\""+METER_TO_METRIC+"\" "+tempMeterToMetricChecked+">Meters to Metric</br>");
        out.println("<br><b>Meters to English</b> If your projection is in meters (most are), then this will display the map distances in english units, miles, yards, feet, inches.</br>");
        out.println("<br><input type=radio name="+SCALEBAR_NAME_TAG+" value=\""+METER_TO_ENGLISH+"\" "+tempMeterToEnglishChecked+">Meters to English</br>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }    
}
