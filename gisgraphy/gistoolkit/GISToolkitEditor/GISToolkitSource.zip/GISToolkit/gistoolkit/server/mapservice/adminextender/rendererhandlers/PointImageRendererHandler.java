/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package gistoolkit.server.mapservice.adminextender.rendererhandlers;
import java.io.*;
import gistoolkit.display.*;
import gistoolkit.display.renderer.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.*;

/**
 * Class to handle the HTML editing of simple Renderers.
 */
public class PointImageRendererHandler {
    public static final String POINT_IMAGE_RENDERER_ACTION_TAG = "SIMPLE_RENDERER_ACTION";
    public static final String POINT_IMAGE_RENDERER_ACTION_UPDATE = "UPDATE";
    public static final String POINT_IMAGE_RENDERER_IMAGE_TAG = "IMAGE";
    
    /** Creates a new instance of SimpleRendererHandler */
    public PointImageRendererHandler() {
    }
    
    /** Handle requests for this Renderer. */
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Renderer inRenderer, int inRendererIndex) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(POINT_IMAGE_RENDERER_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inStyle, inRenderer, inRendererIndex, tempString);
            return;
        }
        showPointImageRendererPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inRenderer, inRendererIndex);
    }
    
    public static void showPointImageRendererPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Renderer inRenderer, int inRendererIndex) throws Exception{
        PointImageRenderer tempRenderer = null;
        
        // ensure that we are working with a PointImageRenderer.
        if (inRenderer instanceof PointImageRenderer){
            tempRenderer = (PointImageRenderer) inRenderer;
        }
        else{
            tempRenderer = new PointImageRenderer();
            inStyle.setRenderer(inRendererIndex, tempRenderer);
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Renderer "+inRenderer.getRendererName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        // index of the column to label by.
        out.println("<b>Renderer Parameters..</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // show the line color
        out.println("Image to draw at the point.");
        out.println("<p>");
        out.println("<input type=text name=\""+POINT_IMAGE_RENDERER_IMAGE_TAG+"\" value=\""+tempRenderer.getImageFileName()+"\">");
        out.println("</p>");
        out.println("<p>");
        
        // hidden fields to get back to this Renderer handler.
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+RendererHandler.RENDERER_NUM_TAG+" value="+inRendererIndex+">");
        out.println("<input type=hidden name="+POINT_IMAGE_RENDERER_ACTION_TAG+" value="+POINT_IMAGE_RENDERER_ACTION_UPDATE+">");
        
        // include a submit button.
        out.println("<p><input type=submit value=submit></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Renderer inRenderer, int inRendererIndex, String inAction) throws Exception{
        PointImageRenderer tempRenderer = null;
        
        // ensure that we are working with a PointImageRenderer.
        if (inRenderer instanceof PointImageRenderer){
            tempRenderer = (PointImageRenderer) inRenderer;
        }
        else{
            AdminExtender.showErrorPage(inRequest, inResponse, "Editing of PointImageRenderer requested but "+inRenderer.getRendererName()+" is not a PointImageRenderer.");
            return;
        }
        if (inAction.equalsIgnoreCase(POINT_IMAGE_RENDERER_ACTION_UPDATE)){
            
            // Label Column Tag
            String tempString = inRequest.getParameter(POINT_IMAGE_RENDERER_IMAGE_TAG);
            if (tempString != null){
                try{
                    tempRenderer.setImage(tempString);
                }
                catch (Exception e){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Error setting image ("+POINT_IMAGE_RENDERER_IMAGE_TAG+") \""+tempString+"\" is not a valid image "+e);
                }
                
            }
        }
        
        // Show the updated page.
        showPointImageRendererPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inRenderer, inRendererIndex);        
    }
}