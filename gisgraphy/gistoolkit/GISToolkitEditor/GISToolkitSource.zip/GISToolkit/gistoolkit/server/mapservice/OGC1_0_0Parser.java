/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice;

import java.awt.Color;
import gistoolkit.server.MapRequest;
import java.io.*;
import gistoolkit.features.Envelope;
import gistoolkit.server.*;
import gistoolkit.display.Style;

/**
 * Parser that understands the OGC 1.1.0 specification.
 */
public class OGC1_0_0Parser extends OGCParser{

    public String getVersion(){return "1.0.0";}
    
    /** Creates new OGC1_1_0Parser */
    public OGC1_0_0Parser() {
    }
    public static final String REQUEST="REQUEST";
    public static final String LAYERS="LAYERS";
    public static final String QUERY_LAYERS="QUERY_LAYERS";    
    public static final String STYLES="STYLES";
    public static final String SRS="SRS";
    public static final String BBOX="BBOX";
    public static final String WIDTH="WIDTH";
    public static final String HEIGHT="HEIGHT";
    public static final String FORMAT="FORMAT";
    public static final String TRANSPARENT="TRANSPARENT";
    public static final String BGCOLOR="BGCOLOR";
    public static final String EXCEPTIONS="EXCEPTIONS";
    public static final String INFO_FORMAT="INFO_FORMAT";
    public static final String X_POINT="X";
    public static final String Y_POINT="Y";
    public static final String FEATURE_COUNT="FEATURE_COUNT";
    public static final String FILTER = "Filter";
    
    /** Create a map request given the web request. */
    public MapRequest getMapRequest(Request inRequest) throws Exception{
        MapRequest tempRequest = new MapRequest();
        
        // the request
        tempRequest.setRequest(getRequest(inRequest.getParameter(REQUEST)));
        
        // parse a map request.
        if (tempRequest.getRequest() == MapRequest.REQUEST_GET_MAP){
            // the layers
            String tempString = inRequest.getParameter(LAYERS);
            if (tempString == null) throw new Exception("The parameter "+LAYERS+" is required, it is a comma delimited list of layer names.");
            tempRequest.setLayers(getListFromString(inRequest.getParameter(LAYERS)));

            // the Styles
            tempRequest.setStyles(getListFromString(inRequest.getParameter(STYLES)));

            // the SRS
            setSRS(tempRequest, inRequest.getParameter(SRS));

            // the Bounding Box
            tempString = inRequest.getParameter(BBOX);
            if (tempString == null) throw new Exception("Error Parsing "+BBOX+" minx,miny,maxx,maxy is required for request type "+inRequest.getParameter(REQUEST));
            setBoundingBox(tempRequest, inRequest.getParameter(BBOX));

            // the width
            tempString = inRequest.getParameter(WIDTH);
            if (tempString == null) throw new Exception("A value is required for "+WIDTH);
            try{
                tempRequest.setWidth(Integer.parseInt(tempString));
            }
            catch (Exception e){throw new Exception("Error Parsing "+WIDTH+" Value="+tempString);}

            // the Height
            tempString = inRequest.getParameter(HEIGHT);
            if (tempString == null) throw new Exception("A value is required for "+HEIGHT);
            try{
                tempRequest.setHeight(Integer.parseInt(tempString));
            }
            catch (Exception e){throw new Exception("Error Parsing "+HEIGHT+" Value="+tempString);}

            // the Format
            tempRequest.setFormat(getFormat(inRequest.getParameter(FORMAT)));

            // the transparency of the background.
            tempString = inRequest.getParameter(TRANSPARENT);
            if (tempString != null){
                tempRequest.setTransparent(Boolean.getBoolean(tempString));
            }
            else tempRequest.setTransparent(false);

            // the Background Color
            tempString = inRequest.getParameter(BGCOLOR);
            if (tempString != null){
                try{
                    Color tempColor = new Color(Integer.parseInt(tempString));
                    tempRequest.setBackgroundColor(tempColor);
                }
                catch (Exception e){ throw new Exception("Error Parsing "+BGCOLOR+" Value="+tempString);}
            }
            else tempRequest.setBackgroundColor(Color.white);
            
            // and filters that may be present. (Proprietary Parameter)
            String tempFilters = inRequest.getParameter(FILTER);
            if (tempFilters != null){
                tempRequest.setFilters(getFilters(tempFilters));
            }
                
        }
        // parse a capabilities request.
        if (tempRequest.getRequest() == MapRequest.REQUEST_GET_CAPABILITIES){
            // There are no other parameters for a 1.0.0 get capabilities request.
        }
        // parse a feature info request.
        if (tempRequest.getRequest() == MapRequest.REQUEST_GET_FEATURE_INFO){
            // the layers
            String tempString = inRequest.getParameter(QUERY_LAYERS);
            if (tempString == null) throw new Exception("The parameter "+QUERY_LAYERS+" is required, it is a comma delimited list of layer names.");
            tempRequest.setLayers(getListFromString(tempString));

            // the SRS
            setSRS(tempRequest, inRequest.getParameter(SRS));

            // the Bounding Box
            tempString = inRequest.getParameter(BBOX);
            if (tempString == null) throw new Exception("Error Parsing "+BBOX+" minx,miny,maxx,maxy is required for request type "+inRequest.getParameter(REQUEST));
            setBoundingBox(tempRequest, inRequest.getParameter(BBOX));

            // the width
            tempString = inRequest.getParameter(WIDTH);
            if (tempString == null) throw new Exception("A value is required for "+WIDTH);
            try{
                tempRequest.setWidth(Integer.parseInt(tempString));
            }
            catch (Exception e){throw new Exception ("Error Parsing "+WIDTH+" Value="+tempString);}

            // the Height
            tempString = inRequest.getParameter(HEIGHT);
            if (tempString == null) throw new Exception("A value is required for "+HEIGHT);
            try{
                tempRequest.setHeight(Integer.parseInt(tempString));
            }
            catch (Exception e){throw new Exception ("Error Parsing "+HEIGHT+" Value="+tempString);}
            
            // The Info Format.
            tempString = inRequest.getParameter(INFO_FORMAT);
            tempRequest.setFormat(tempString);

            // The Number of features to return information about, default is 1.
            tempString = inRequest.getParameter(FEATURE_COUNT);
            if (tempString != null){
                try{
                    tempRequest.setFeatureCount(Integer.parseInt(tempString));
                }
                catch(Exception e){
                    throw new Exception("Error Parsing "+FEATURE_COUNT+" Must be an integer, value = "+tempString);
                }
            }

            // The X coordinate
            tempString = inRequest.getParameter(X_POINT);
            int tempXPoint = 0;
            try{tempXPoint = Integer.parseInt(tempString);}catch (Exception e){throw new Exception("Error parsing "+X_POINT+" Not a valid integer Value="+tempString);}
            tempRequest.setXPoint(tempXPoint);
            
            // the Y coordinate
            tempString = inRequest.getParameter(Y_POINT);
            int tempYPoint = 0;
            try{tempYPoint = Integer.parseInt(tempString);}catch (Exception e){throw new Exception("Error parsing "+Y_POINT+" Not a valid integer Value="+tempString);}
            tempRequest.setYPoint(tempYPoint);
        }
        
        return tempRequest;
    }
    
    private static String getRequest(String inRequest) throws Exception{
        if (inRequest == null) return MapRequest.REQUEST_GET_MAP;
        if (inRequest.equalsIgnoreCase("Map")) return MapRequest.REQUEST_GET_MAP;
        if (inRequest.equalsIgnoreCase("Capabilities")) return MapRequest.REQUEST_GET_CAPABILITIES;
        if (inRequest.equalsIgnoreCase("Feature_info")) return MapRequest.REQUEST_GET_FEATURE_INFO;
        throw new Exception("Unrecognized Request "+inRequest);
    }

    /** get the capabilities request. */
    public void getCapabilitiesRequest(MapRequest inRequest, Response inResponse, Server inServer) throws Exception{
        // find the service.
        String tempServiceName = inRequest.getServiceName();
        if (tempServiceName == null) throw new Exception("Service Name is required for capabilities.");
        Service tempService = inServer.getService(tempServiceName);
        if (tempService == null) throw new Exception("Can not find Service "+tempServiceName+" on this server.");

        // parse out the prefix of the called URL
        String tempCalledURL = inRequest.getCalledURL();
        String tempCalledURLBase = inRequest.getCalledURL();
        if (tempCalledURL != null){
            int tempIndex = tempCalledURL.lastIndexOf("/");
            if (tempIndex != -1){
                tempCalledURLBase = tempCalledURL.substring(0, tempIndex);
            }
        }
        
        inResponse.setContentType("text/xml");
        PrintWriter out = inResponse.getWriter();
        out.println("<?xml version='1.0' encoding=\"UTF-8\" standalone=\"no\" ?>");
        out.println("<!DOCTYPE WMT_MS_Capabilities SYSTEM \""+tempCalledURLBase+"/DTD?Version="+getVersion()+"\">");
        out.println("<WMT_MS_Capabilities version=\""+getVersion()+"\">");
        out.println("<Service>");
        out.println("\t<Name>OGC:WMS</Name>");
        out.println("\t<Title>"+tempService.getServiceTitle()+"</Title>");
        out.println("\t<OnlineResource xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:type=\"simple\" xlink:href=\""+tempService.getServiceLink()+"\" />");
        out.println("\t<Fees>none</Fees>");
        out.println("\t<AccessConstraints>none</AccessConstraints>");
        out.println("</Service>");
        out.println("<Capability>");
        out.println("\t<Request>");
        out.println("\t\t<Map>");
        out.println("\t\t\t<Format><JPEG /><PNG /></Format>");
        out.println("\t\t\t<DCPType>");
        out.println("\t\t\t\t<HTTP>");
        out.println("\t\t\t\t\t<Get OnlineResource=\""+inRequest.getCalledURL()+"\" />");
        out.println("\t\t\t\t</HTTP>");
        out.println("\t\t\t</DCPType>");
        out.println("\t\t</Map>");
        out.println("\t\t<Capabilities>");
        out.println("\t\t\t<Format><WMS_XML /></Format>");
        out.println("\t\t\t<DCPType>");
        out.println("\t\t\t\t<HTTP>");
        out.println("\t\t\t\t\t<Get OnlineResource=\""+inRequest.getCalledURL()+"\" />");
        out.println("\t\t\t\t</HTTP>");
        out.println("\t\t\t</DCPType>");
        out.println("\t\t</Capabilities>");
        out.println("\t\t<FeatureInfo>");
        out.println("\t\t\t<Format><MIME/><GML1 /></Format>");
        out.println("\t\t\t<DCPType>");
        out.println("\t\t\t\t<HTTP>");
        out.println("\t\t\t\t\t<Get OnlineResource=\""+inRequest.getCalledURL()+"\" />");
        out.println("\t\t\t\t</HTTP>");
        out.println("\t\t\t</DCPType>");
        out.println("\t\t</FeatureInfo>");
        out.println("\t</Request>");
        out.println("\t<Exception>");
        out.println("\t\t<Format>application/vnd.ogc.se_xml</Format>");
        out.println("\t</Exception>");
        out.println("\t<Layer>");
        out.println("\t\t<Title>"+tempService.getServiceTitle()+"</Title>");
        out.println("\t\t<SRS>"+tempService.getSRS()+"</SRS>");
        
        // list the layers for this service
        LayerDefinition[] tempLayerDefinitions = tempService.getLayerDefinitions();
        for (int i=0; i<tempLayerDefinitions.length; i++){
            out.println("\t\t<Layer>");
            out.println("\t\t\t<Name>"+tempLayerDefinitions[i].getLayerName()+"</Name>");
            out.println("\t\t\t<Title>"+tempLayerDefinitions[i].getLayerTitle()+"</Title>");
            Envelope tempEnvelope = tempLayerDefinitions[i].getLatLonEnvelope();
            out.println("\t\t\t<LatLongBoundingBox minx=\""+tempEnvelope.getMinX()+"\" miny=\""+tempEnvelope.getMinY()+"\" maxx=\""+tempEnvelope.getMaxX()+"\" maxy=\""+tempEnvelope.getMaxY()+"\" />");
            
            // loop through the styles, listing the available ones.
            Style[] tempStyles = tempLayerDefinitions[i].getStyles();
            for (int j=0; j<tempStyles.length; j++){
                out.println("\t\t\t<Style>");
                out.println("\t\t\t\t<Name>"+tempStyles[j].getStyleName()+"</Name>");
                out.println("\t\t\t\t<Title>"+tempStyles[j].getStyleTitle()+"</Title>");
                out.println("\t\t\t</Style>");
            }
            out.println("\t\t</Layer>");
        }
        out.println("\t</Layer>");
        out.println("</Capability>");
        out.println("</WMT_MS_Capabilities>");
    }
}
