/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender;

import java.io.*;
import gistoolkit.projection.*;
import gistoolkit.datasources.*;
import gistoolkit.display.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;

/**
 *
 */
public class LayerHandler {
    public static final String LAYER_NAME_TAG = "LAYER_NAME";
    private static final String LAYER_ACTION_TAG = "LAYER_ACTION";
    private static final String LAYER_ACTION_UPDATE = "UPDATE";
    private static final String LAYER_ACTION_DELETE_STYLE = "DELETE_STYLE";
    private static final String LAYER_ACTION_EDIT_DATASOURCE = "EDIT_DATASOURCE";
    private static final String LAYER_ACTION_EDIT_STYLE = "EDIT_STYLE";
    private static final String LAYER_ACTION_EDIT_PROJECTION = "EDIT_PROJECTION";
    private static final String LAYER_ACTION_SHOW_ADD_STYLE = "SHOW_ADD_LAYER";
    private static final String LAYER_ACTION_ADD_STYLE = "ADD_LAYER";
    
    /** Creates new LayerHandler */
    public LayerHandler() {
    }
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService) throws Exception{
        String tempLayerName = inRequest.getParameter(LAYER_NAME_TAG);
        LayerDefinition tempDefinition = inService.getLayerDefinition(tempLayerName);
        if (tempDefinition == null){
            AdminExtender.showErrorPage(inRequest, inResponse, "Layer "+tempLayerName+" was not found on this server. ");
            return;
        }
        
        // check for actions for this layer.
        String tempString = inRequest.getParameter(LAYER_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, tempDefinition, tempString);
            return;
        }
        
        // if this is a projection command, then show the projection.
        tempString = inRequest.getParameter(ProjectionHandler.PROJECTION_NAME_TAG);
        if (tempString != null){
            ProjectionHandler.doGet(inRequest, inResponse, inServer, inService, tempDefinition);
            return;
        }
        
        // if this is a style command, then show the style.
        tempString = inRequest.getParameter(StyleHandler.STYLE_NAME_TAG);
        if (tempString != null){
            StyleHandler.doGet(inRequest, inResponse, inServer, inService, tempDefinition);
            return;
        }
        
        // show the generic layer page.
        showLayerPage(inRequest, inResponse, inServer, inService, tempDefinition);
        
    }
    /** Show information only about the indicated server*/
    public static void showLayerPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inDefinition){
        
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Layer "+inDefinition.getLayerName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        // show the layer information for update.
        out.println("<b>Edit Layer "+inDefinition.getLayerName()+"</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        out.println("<br><b>Layer Name</b></br>");
        out.println("<br>A short just a few character name to be used in the URL.  Do not include spaces or special characters.</br>");
        out.println("<br><input type=text name=Update_Layer_Name value=\""+inDefinition.getLayerName()+"\"></br>");
        out.println("<br><b>Layer Title</b></br>");
        out.println("<br>A long description of the Layer, may include spaces and special characters.</br>");
        out.println("<br><input type=text name=Update_Layer_Title value=\""+inDefinition.getLayerTitle()+"\" size=100></br>");
        out.println("<br>The Maximum Display distance.  When the width of the display window gets larger than this width, the layer will no longer be displayed.</br>");
        out.println("<br><input type=text name=Update_Layer_MaxDisplay value=\""+inDefinition.getMaxDisplayDistance()+"\" size=100></br>");
        out.println("<br>The Minimum Display distance.  When the width of the display window gets smaller than this width, the layer will no longer be displayed.</br>");
        out.println("<br><input type=text name=Update_Layer_MinDisplay value=\""+inDefinition.getMinDisplayDistance()+"\" size=100></br>");
        out.println("<br>The Maximum Label distance.  When the width of the display window gets larger than this width, the layer will no longer be labeled.</br>");
        out.println("<br><input type=text name=Update_Layer_MaxLabel value=\""+inDefinition.getMaxLabelDistance()+"\" size=100></br>");
        out.println("<br>The Minimum Label distance.  When the width of the display window gets smaller than this width, the layer will no longer be labeled.</br>");
        out.println("<br><input type=text name=Update_Layer_MinLabel value=\""+inDefinition.getMinLabelDistance()+"\" size=100></br>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LAYER_NAME_TAG+" value="+inDefinition.getLayerName()+">");
        out.println("<input type=hidden name="+LAYER_ACTION_TAG+" value="+LAYER_ACTION_UPDATE+">");
        out.println("<br><input type=submit value=submit></br>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        // show the data source information.
        DataSource tempDataSource = inDefinition.getDataSource();
        if (tempDataSource != null){
            out.println("<P>");
            out.println("<b>Configured Data Source</b>");
            out.println("<TABLE border=\"4\">");
            out.println("<tr><td><b>Data Source Name</b></td><td><b>DataSourceClass</b></td></tr>");
            out.println("<tr><td>");
            out.println("<b>"+tempDataSource.getName()+"</b>");
            //            out.println("<a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LAYER_NAME_TAG+"="+inDefinition.getLayerName()+"&"+LAYER_ACTION_TAG+"="+LAYER_ACTION_EDIT_DATASOURCE+"\"><b>"+tempDataSource.getName()+"</b></a>");
            out.println("</td><td>");
            out.println(tempDataSource.getClass().getName());
            out.println("</td></tr>");
            out.println("</TABLE>");
            out.println("</P>");

            // show the projection information
            Projection tempProjection = tempDataSource.getFromProjection();
            if (tempProjection == null){
                tempProjection = new NoProjection();
            }
            out.println("<P>");
            out.println("<b>From Projection</b>");
            out.println("<TABLE border=\"4\">");
            out.println("<tr><td><b>ProjectionName</b></td></tr>");
            out.println("<tr><td>");
            out.println("<a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LAYER_NAME_TAG+"="+inDefinition.getLayerName()+"&"+LAYER_ACTION_TAG+"="+LAYER_ACTION_EDIT_PROJECTION+"\"><b>"+tempProjection.getProjectionName()+"</b></a>");
            out.println("</td></tr>");
            out.println("</TABLE>");
            out.println("</P>");
        }
        
        // loop through the styles showing each one.
        Style[] tempStyles = inDefinition.getStyles();
        out.println("<P>");
        out.println("<b>Available Styles</b>");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td><b>Style Name</b></td><td><b>StyleTitle</b></td>");
        if (tempStyles.length > 1){
            out.println("<td><b>remove</b></td>");
        }
        out.println("</tr>");
        for (int i=0; i<tempStyles.length; i++){
            out.println("<tr><td>");
            out.println("<a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LAYER_NAME_TAG+"="+inDefinition.getLayerName()+"&"+StyleHandler.STYLE_NAME_TAG+"="+tempStyles[i].getStyleName()+"\"><b>"+tempStyles[i].getStyleName()+"</b></a>");
            out.println("</td><td>");
            out.println(tempStyles[i].getStyleTitle());
            if (tempStyles.length > 1){
                out.println("</td><td>");
                out.println("<a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LAYER_NAME_TAG+"="+inDefinition.getLayerName()+"&"+StyleHandler.STYLE_NAME_TAG+"="+tempStyles[i].getStyleName()+"&"+LAYER_ACTION_TAG+"="+LAYER_ACTION_DELETE_STYLE+"\"><b>remove</b></a>");
            }
            out.println("</td></tr>");
        }
        out.println("</TABLE>");
        out.println("</P>");
        out.println("<a href=\""+tempURLBase+"?"+ServiceHandler.SERVICE_NAME_TAG+"="+inService.getServiceName()+"&"+LAYER_NAME_TAG+"="+inDefinition.getLayerName()+"&"+LAYER_ACTION_TAG+"="+LAYER_ACTION_SHOW_ADD_STYLE+"\"><b>Add New Style</b></a>");
        // show the style information.
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, String inLayerAction){
        if (inLayerAction.equalsIgnoreCase(LAYER_ACTION_UPDATE)){
            String tempString = inRequest.getParameter("Update_Layer_Name");
            if ((tempString != null) && (tempString.trim().length() != 0)){
                // look for duplicates
                LayerDefinition tempDefinition = inService.getLayerDefinition(tempString);
                if ((tempDefinition != null) && (tempDefinition != inLayer)){
                    AdminExtender.showErrorPage(inRequest, inResponse, "Duplicate Layer Name, delete the existing layer before adding another. ");
                    return;
                }
                else{
                    inLayer.setLayerName(tempString);
                    tempString = inRequest.getParameter("Update_Layer_Title");
                    inLayer.setLayerTitle(tempString);
                    
                    // the Display distances.
                    tempString = inRequest.getParameter("Update_Layer_MaxDisplay");
                    if (tempString != null){
                        try{
                            double tempDouble = Double.parseDouble(tempString);
                            inLayer.setMaxDisplayDistance(tempDouble);
                        }
                        catch (NumberFormatException e){
                        }
                    }
                    tempString = inRequest.getParameter("Update_Layer_MinDisplay");
                    if (tempString != null){
                        try{
                            double tempDouble = Double.parseDouble(tempString);
                            inLayer.setMinDisplayDistance(tempDouble);
                        }
                        catch (NumberFormatException e){
                        }
                    }

                    // the label distances.
                    tempString = inRequest.getParameter("Update_Layer_MaxLabel");
                    if (tempString != null){
                        try{
                            double tempDouble = Double.parseDouble(tempString);
                            inLayer.setMaxLabelDistance(tempDouble);
                        }
                        catch (NumberFormatException e){
                        }
                    }
                    tempString = inRequest.getParameter("Update_Layer_MinLabel");
                    if (tempString != null){
                        try{
                            double tempDouble = Double.parseDouble(tempString);
                            inLayer.setMinLabelDistance(tempDouble);
                        }
                        catch (NumberFormatException e){
                        }
                    }
                    
                    ServiceHandler.showServicePage(inRequest, inResponse, inServer, inService);
                    return;
                }
            }
            else{
                AdminExtender.showErrorPage(inRequest, inResponse, "New Layer name not specified.");
                return;
            }
        }
        if (inLayerAction.equalsIgnoreCase(LAYER_ACTION_EDIT_PROJECTION)){
            try{
                ProjectionHandler.doGet(inRequest, inResponse, inServer, inService, inLayer);
            }
            catch (Exception e){
                AdminExtender.showErrorPage(inRequest, inResponse, "Error reading Projection "+e.getMessage());
            }
            return;
        }
        if (inLayerAction.equalsIgnoreCase(LAYER_ACTION_DELETE_STYLE)){
            String tempStyleName = inRequest.getParameter(StyleHandler.STYLE_NAME_TAG);
            if ((tempStyleName != null)&&(tempStyleName.trim().length() > 0)){
                Style tempStyle = inLayer.getStyle(tempStyleName);
                if (tempStyle != null){
                    inLayer.removeStyle(tempStyle);
                    showLayerPage(inRequest, inResponse, inServer, inService, inLayer);
                    return;
                }
                else{
                    AdminExtender.showErrorPage(inRequest, inResponse, "Style named "+tempStyleName+" Was not found on this server.");
                    return;
                }
            }
            else{
                AdminExtender.showErrorPage(inRequest, inResponse, "Style name not specified.");
                return;
            }
        }
        if (inLayerAction.equalsIgnoreCase(LAYER_ACTION_SHOW_ADD_STYLE)){
            AdminExtender.showHeaderPage(inRequest, inResponse, "Add New Style");
            String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
            PrintWriter out = inResponse.getWriter();
            out.println("<b>Add New Style</b>");
            out.println("<P>");
            out.println("<form method=post ACTION="+tempURLBase+">");
            out.println("<TABLE border=\"4\">");
            out.println("<tr><td>");
            out.println("<br><b>Style Name</b></br>");
            out.println("<br>A short just a few character name to be used in the URL.  Do not include spaces or special characters.</br>");
            out.println("<br><input type=text name=Update_Style_Name value=\"NewStyleName\"></br>");
            out.println("<br><b>Style Title</b></br>");
            out.println("<br>A long description of the Style, may include spaces and special characters.</br>");
            out.println("<br><input type=text name=Update_Style_Title value=\"New Style Title\" size=100></br>");
            out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
            out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
            out.println("<input type=hidden name="+LAYER_ACTION_TAG+" value="+LAYER_ACTION_ADD_STYLE+">");
            out.println("<br><input type=submit value=submit></br>");
            out.println("</td></tr>");
            out.println("</TABLE>");
            out.println("</form>");
            out.println("</P>");
            AdminExtender.showTailerPage(inRequest, inResponse);
            return;
        }
        if (inLayerAction.equalsIgnoreCase(LAYER_ACTION_ADD_STYLE)){
            String tempStyleName = inRequest.getParameter("Update_Style_Name");
            if ((tempStyleName != null) && (tempStyleName.trim().length() >0)){
                // check for duplicates
                Style tempStyle = inLayer.getStyle(tempStyleName);
                if (tempStyle == null){
                    tempStyle = new Style();
                    tempStyle.setStyleName(tempStyleName);
                    String tempStyleTitle = inRequest.getParameter("Update_Style_Title");
                    tempStyle.setStyleTitle(tempStyleTitle);
                    inLayer.addStyle(tempStyle);
                    showLayerPage(inRequest, inResponse, inServer, inService, inLayer);
                    return;
                }
                else {
                    AdminExtender.showErrorPage(inRequest, inResponse, "Duplicate style name specified, delete the orrigional before renaming this one.");
                    return;
                }
            }
            else {
                AdminExtender.showErrorPage(inRequest, inResponse, "No new style name specified. ");
                return;
            }
        }
    }
}
