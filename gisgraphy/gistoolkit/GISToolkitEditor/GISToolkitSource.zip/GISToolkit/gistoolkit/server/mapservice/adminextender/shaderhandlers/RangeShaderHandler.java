/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapservice.adminextender.shaderhandlers;
import java.io.*;
import java.awt.*;
import gistoolkit.display.*;
import gistoolkit.display.shader.*;
import gistoolkit.server.*;
import gistoolkit.server.mapservice.*;
import gistoolkit.server.mapservice.adminextender.*;

/**
 *
 */
public class RangeShaderHandler {
    private static final String RANGE_SHADER_ACTION_TAG = "RANGE_SHADER_ACTION";
    private static final String RANGE_SHADER_ACTION_UPDATE = "RANGE_SHADER_UPDATE";
    
    /** Creates new RangeShaderHandler */
    public RangeShaderHandler() {
    }
    
    public static void doGet(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader) throws Exception{
        // check for actions for this handler
        String tempString = inRequest.getParameter(RANGE_SHADER_ACTION_TAG);
        if (tempString != null){
            handleAction(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader(), tempString);
            return;
        }
        showRangeShaderPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
    }
    public static void showRangeShaderPage(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader){
        RangeShader tempShader = null;
        if (inShader instanceof RangeShader){
            tempShader = (RangeShader) inShader;
        }
        else{
            tempShader = new RangeShader();
            inStyle.setShader(tempShader);
        }
        AdminExtender.showHeaderPage(inRequest, inResponse, "Edit Style "+inStyle.getStyleName());
        String tempURLBase = inRequest.getParameter(ResponseThread.CALLED_URL_PARAMETER);
        PrintWriter out = inResponse.getWriter();
        
        out.println("<b>Attributes of the range shader.</b>");
        out.println("<P>");
        out.println("<form method=post ACTION="+tempURLBase+">");
        out.println("<TABLE border=\"4\">");
        out.println("<tr><td>");
        
        // show the line color
        out.println("<br>When specifying the RGB values here, each value is an integer in the range of 0 to 255. No color is 0, so 0,0,0 is black, and 255,255,255 is white.</br>");
        out.println("<p>");
        if (tempShader.getDefaultLineColor() != null){
            out.print("<input type=checkbox name=ulc value=true checked><b>Line Color </b>");
            out.print("Red: <input type=text name=ulr value=\""+tempShader.getDefaultLineColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulg value=\""+tempShader.getDefaultLineColor().getGreen()+"\">");
            out.println("Blue: <input type=text name=ulb value=\""+tempShader.getDefaultLineColor().getBlue()+"\">");
        }
        else{
            out.println("<input type=checkbox name=ulc value=true ><b>Line Color </b>");
            out.print("Red: <input type=text name=ulr value=\"0\">");
            out.print("Green: <input type=text name=ulg value=\"0\">");
            out.print("Blue: <input type=text name=ulb value=\"0\">");
        }
        out.println("</p>");
        out.println("<p>");
        if (tempShader.getDefaultFillColor() != null){
            out.print("<input type=checkbox name=ufc value=true checked><b>Fill Color </b>");
            out.print("Red: <input type=text name=ufr value=\""+tempShader.getDefaultFillColor().getRed()+"\">");
            out.print("Green: <input type=text name=ufg value=\""+tempShader.getDefaultFillColor().getGreen()+"\">");
            out.println("Blue: <input type=text name=ufb value=\""+tempShader.getDefaultFillColor().getBlue()+"\">");
        }
        else{
            out.print("<input type=checkbox name=ufc value=true><b>Fill Color </b>");
            out.print("Red: <input type=text name=ufr value=\"255\">");
            out.print("Green: <input type=text name=ufg value=\"255\">");
            out.println("Blue: <input type=text name=ufb value=\"255\">");
        }
        out.println("</p>");
        out.println("<p>");
        if (tempShader.getDefaultLabelColor() != null){
            out.print("<input type=checkbox name=ulac value=true checked><b>Label Color </b>");
            out.print("Red: <input type=text name=ular value=\""+tempShader.getDefaultLabelColor().getRed()+"\">");
            out.print("Green: <input type=text name=ulag value=\""+tempShader.getDefaultLabelColor().getGreen()+"\">");
            out.println("Blue:<input type=text name=ulab value=\""+tempShader.getDefaultLabelColor().getBlue()+"\">");
        }
        else{
            out.print("<input type=checkbox name=ulac value=true><b>Label Color </b>");
            out.print("Red: <input type=text name=ular value=\"0\">");
            out.print("Green: <input type=text name=ulag value=\"0\">");
            out.println("Blue: <input type=text name=ulab value=\"255\">");
        }
        
        // Label Font
        out.println("<p>");
        out.println("<p>Font Name</p>");
        Font tempFont = tempShader.getDefaultFont();
        out.println("<br><select name=FN>");
        String tempFontName = tempFont.getFontName();
        Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
        for (int i=0; i<tempFontSelection.length; i++){
            String tempTestName = tempFontSelection[i].getFontName();
            out.print("   <Option Value=\""+tempTestName+"\" ");
            if (tempFontName.equals(tempTestName)){
                out.print("Selected");
            }
            out.println(">"+tempTestName);
        }
        out.println("</select>");
        out.println("</p>");
        
        // Font Size
        out.println("<p>");
        out.println("<p>Font Size</p>");
        int[] tempSizes = {7,8,9,10,12,14,16,18,20,25,30,40,48,56,72};
        int tempSize = tempFont.getSize();
        out.println("<select name=FS>");
        for (int i=0; i<tempSizes.length; i++){
            out.println("   <Option Value="+tempSizes[i]+" "+AdminExtender.getSelected(tempSize, tempSizes[i])+">"+tempSizes[i]);
        }
        out.println("</select>");
        out.println("</p>");

        // lineWidth
        out.println("</p>");
        out.println("<br>How thick would you like the line to be (in pixels)");
        out.println("<br><select name=ulw>");
        BasicStroke tempStroke = null;
        if (tempShader.getStroke() instanceof BasicStroke){
            tempStroke = (BasicStroke) tempShader.getStroke();
        }
        else{
            tempStroke = new BasicStroke();
        }   
        int tempWidth = (int) tempStroke.getLineWidth();
        out.println("<Option Value=1 "+getSelected(tempWidth, 1)+">1");
        out.println("<Option Value=2 "+getSelected(tempWidth, 2)+">2");
        out.println("<Option Value=3 "+getSelected(tempWidth, 3)+">3");
        out.println("<Option Value=4 "+getSelected(tempWidth, 4)+">4");
        out.println("<Option Value=5 "+getSelected(tempWidth, 5)+">5");
        out.println("<Option Value=6 "+getSelected(tempWidth, 6)+">6");
        out.println("<Option Value=7 "+getSelected(tempWidth, 7)+">7");
        out.println("<Option Value=8 "+getSelected(tempWidth, 8)+">8");
        out.println("<Option Value=9 "+getSelected(tempWidth, 9)+">9");
        out.println("<Option Value=10 "+getSelected(tempWidth, 10)+">10");
        out.println("</select>");
        out.println("<input type=hidden name="+ServiceHandler.SERVICE_NAME_TAG+" value="+inService.getServiceName()+">");
        out.println("<input type=hidden name="+LayerHandler.LAYER_NAME_TAG+" value="+inLayer.getLayerName()+">");
        out.println("<input type=hidden name="+StyleHandler.STYLE_NAME_TAG+" value="+inStyle.getStyleName()+">");
        out.println("<input type=hidden name="+ShaderHandler.SHADER_NAME_TAG+" value=range>");
        out.println("<input type=hidden name="+RANGE_SHADER_ACTION_TAG+" value="+RANGE_SHADER_ACTION_UPDATE+">");
        
        // show the Ranges
        double[] tempMinValues = tempShader.getMinValues();
        double[] tempMaxValues = tempShader.getMaxValues();
        Color[] tempLineColors = tempShader.getLineColors();
        Color[] tempFillColors = tempShader.getFillColors();
        Color[] tempLabelColors = tempShader.getLabelColors();
        int i=0;
        out.println("<p><b>Column to shade by</b>");
        out.println("<br><input type=text name=ShadeColumn value=\""+tempShader.getColumnName()+"\"></br></p>");
        out.println("<table border=2 halign=left valigh=top>");
        out.println("<tr><td><b>Min</b></td><td><b>Max</b></td><td><b>Line Color</b></td><td><b>Fill Color</b></td><td><b>Label Color</b></td></tr>");
        if (tempMinValues != null){
            for (i = 0; i<tempMinValues.length; i++){
                out.println("<tr><td>");
                if (tempMinValues[i] == Double.NEGATIVE_INFINITY){
                    out.println("\t<input type=text name=min"+i+" value=\"Min\">");
                }
                else out.println("\t<input type=text name=min"+i+" value=\""+tempMinValues[i]+"\">");
                out.println("\t</td><td>");
                if (tempMaxValues[i] == Double.POSITIVE_INFINITY){
                    out.println("\t<input type=text name=max"+i+" value=\"Max\">");
                }
                else out.println("\t<input type=text name=max"+i+" value=\""+tempMaxValues[i]+"\">");
                out.println("\t</td><td>");
                out.println("\t<br>R:<input type=text name=lr"+i+" value=\""+tempLineColors[i].getRed()+"\"></br>");
                out.println("\t<br>G:<input type=text name=lg"+i+" value=\""+tempLineColors[i].getGreen()+"\"></br>");
                out.println("\t<br>B:<input type=text name=lb"+i+" value=\""+tempLineColors[i].getBlue()+"\"></br>");
                out.println("\t</td><td>");
                out.println("\t<br>R:<input type=text name=fr"+i+" value=\""+tempFillColors[i].getRed()+"\"></br>");
                out.println("\t<br>G:<input type=text name=fg"+i+" value=\""+tempFillColors[i].getGreen()+"\"></br>");
                out.println("\t<br>B:<input type=text name=fb"+i+" value=\""+tempFillColors[i].getBlue()+"\"></br>");
                out.println("\t</td><td>");
                out.println("\t<br>R:<input type=text name=lar"+i+" value=\""+tempLabelColors[i].getRed()+"\"></br>");
                out.println("\t<br>G:<input type=text name=lag"+i+" value=\""+tempLabelColors[i].getGreen()+"\"></br>");
                out.println("\t<br>B:<input type=text name=lab"+i+" value=\""+tempLabelColors[i].getBlue()+"\"></br>");
                out.println("</td><tr>");
            }
        }
        for (int j=0; j<10; j++){
            out.println("<tr><td>");
            out.println("\t<input type=text name=min"+i+">");
            out.println("\t</td><td>");
            out.println("\t<input type=text name=max"+i+">");
            out.println("\t</td><td>");
            out.println("\t<br>R:<input type=text name=lr"+i+"></br>");
            out.println("\t<br>G:<input type=text name=lg"+i+"></br>");
            out.println("\t<br>B:<input type=text name=lb"+i+"></br>");
            out.println("\t</td><td>");
            out.println("\t<br>R:<input type=text name=fr"+i+"></br>");
            out.println("\t<br>G:<input type=text name=fg"+i+"></br>");
            out.println("\t<br>B:<input type=text name=fb"+i+"></br>");
            out.println("\t</td><td>");
            out.println("\t<br>R:<input type=text name=lar"+i+"></br>");
            out.println("\t<br>G:<input type=text name=lag"+i+"></br>");
            out.println("\t<br>B:<input type=text name=lab"+i+"></br>");
            out.println("</td><tr>");
            i++;
        }
        out.println("</table>");
        
        out.println("<p><input type=submit value=submit></p>");
        out.println("<p><input type=hidden name=MaxRanges value="+i+"></p>");
        out.println("</td></tr>");
        out.println("</TABLE>");
        out.println("</form>");
        out.println("</P>");
        
        AdminExtender.showTailerPage(inRequest, inResponse);
    }
    /** Utility method for determining if a choice item should be selected. */
    private static String getSelected(int inValue, int inConstant){
        if(inValue == inConstant) return "Selected";
        return "";
    }
    /** Handle events for the mono shader. */
    public static void handleAction(Request inRequest, Response inResponse, Server inServer, Service inService, LayerDefinition inLayer, Style inStyle, Shader inShader, String inAction){
        RangeShader tempShader = null;
        if (inShader instanceof RangeShader){
            tempShader = (RangeShader) inShader;
        }
        else{
            tempShader = new RangeShader();
            inStyle.setShader(tempShader);
        }
        
        if (inAction.equalsIgnoreCase(RANGE_SHADER_ACTION_UPDATE)){
            tempShader.removeAllEntries();
            // check for the line color
            String tempString = inRequest.getParameter("ulc");
            if (tempString == null){
                tempShader.setDefaultLineColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ulr"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulg"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulb"));
                tempShader.setDefaultLineColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the fill color
            tempString = inRequest.getParameter("ufc");
            if (tempString == null){
                tempShader.setDefaultFillColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ufr"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ufg"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ufb"));
                tempShader.setDefaultFillColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the label color
            tempString = inRequest.getParameter("ulac");
            if (tempString == null){
                tempShader.setDefaultLabelColor(null);
            }
            else{
                int tempIntRed = ShaderHandler.rationalize(inRequest.getParameter("ular"));
                int tempIntGreen = ShaderHandler.rationalize(inRequest.getParameter("ulag"));
                int tempIntBlue = ShaderHandler.rationalize(inRequest.getParameter("ulab"));
                tempShader.setDefaultLabelColor(new Color(tempIntRed, tempIntGreen, tempIntBlue));
            }
            
            // check for the label font
            Font tempFont = tempShader.getDefaultFont();
            String tempFontName = tempFont.getFontName();
            String tempSelectedName = inRequest.getParameter("FN");
            if (tempSelectedName != null){
                if (!tempFontName.equals(tempSelectedName)){
                    Font[] tempFontSelection = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
                    for (int i=0; i<tempFontSelection.length; i++){
                        String tempTestName = tempFontSelection[i].getFontName();
                        if (tempSelectedName.equals(tempTestName)){
                            // set the new font into the scale bar
                            tempShader.setDefaultFont(tempFontSelection[i]);
                            break;
                        }
                    }
                }
            }
            
            // check for the label font size
            tempString = inRequest.getParameter("FS");
            if (tempString != null){
                try{
                    int tempSize = Integer.parseInt(tempString);
                    tempFont = tempShader.getDefaultFont();
                    int tempFontSize = tempFont.getSize();
                    if (tempFontSize != tempSize){
                        tempFont = tempFont.deriveFont((float)tempSize);
                        tempShader.setDefaultFont(tempFont);
                    }
                }
                catch (NumberFormatException e){
                }
            }

            // line width
            int tempLineWidth = ShaderHandler.rationalize(inRequest.getParameter("ulw"));
            tempShader.setStroke(new BasicStroke((float)tempLineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND ));
            
            // Column to shade by
            tempShader.setColumnName(inRequest.getParameter("ShadeColumn"));
            
            // the ranges
            int tempMaxRanges = getInt(inRequest.getParameter("MaxRanges"));
            for (int i=0; i<tempMaxRanges; i++){
                String tempString1 = inRequest.getParameter("min"+i);
                String tempString2 = inRequest.getParameter("max"+i);
                if (tempString1 != null){
                    if (tempString1.trim().length() == 0) tempString1 = null;
                }
                if (tempString2 != null){
                    if (tempString2.trim().length() == 0) tempString2 = null;
                }
                
                if ((tempString1 != null)||(tempString2 != null)){
                    if (tempString1 == null) tempString1 = "Min";
                    if (tempString2 == null) tempString2 = "Max";
                    double tempMin = 0.0;
                    if (tempString1.toUpperCase().equals("MIN")){
                        tempMin = Double.NEGATIVE_INFINITY;
                    }
                    else tempMin = getDouble(tempString1);
                    double tempMax = 0.0;                    
                    if (tempString2.toUpperCase().equals("MAX")){
                        tempMax = Double.POSITIVE_INFINITY;
                    }
                    else tempMax = getDouble(tempString2);
                    
                    // add the color
                    tempShader.addColor(
                        tempMin,
                        tempMax,
                        new Color( // fill color
                            ShaderHandler.rationalize(inRequest.getParameter("fr"+i)),
                            ShaderHandler.rationalize(inRequest.getParameter("fg"+i)),
                            ShaderHandler.rationalize(inRequest.getParameter("fb"+i))
                        ),
                        new Color( // line color
                            ShaderHandler.rationalize(inRequest.getParameter("lr"+i)),
                            ShaderHandler.rationalize(inRequest.getParameter("lg"+i)),
                            ShaderHandler.rationalize(inRequest.getParameter("lb"+i))
                        ),
                        new Color( // label color
                            ShaderHandler.rationalize(inRequest.getParameter("lar"+i)),
                            ShaderHandler.rationalize(inRequest.getParameter("lag"+i)),
                            ShaderHandler.rationalize(inRequest.getParameter("lab"+i))
                        )
                    );
                }
            }
            
            showRangeShaderPage(inRequest, inResponse, inServer, inService, inLayer, inStyle, inStyle.getShader());
        }
    }
    
    // parse a double from a string.
    private static double getDouble(String inString){
        if (inString == null) return 0;
        try{
            double tempDouble = Double.parseDouble(inString);
            if (tempDouble < 0) return 0;
            return tempDouble;
        }
        catch(Exception e){
            return 0;
        }
    }
    // parse a double from a string.
    private static int getInt(String inString){
        if (inString == null) return 0;
        try{
            int tempint = Integer.parseInt(inString);
            if (tempint < 0) return 0;
            return tempint;
        }
        catch(Exception e){
            return 0;
        }
    }
}
