/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server;

import java.awt.Color;

/**
 *  Holds the parameters for an OGIS complient Map Request.
 */
public class MapRequest {
    /**
     * The name of the service to request a map from.
     */
    private String myServiceName = null;
    /** Set the name of the service to which this request is addressed. */
    public void setServiceName(String inServiceName){myServiceName = inServiceName;}
    /** Get the name of the service to which this request is addressed. */
    public String getServiceName(){return myServiceName;}
    
    /** Constant to use when requesting a map. */
    public static final String REQUEST_GET_MAP = "GET_MAP";
    /** Constant to use when requesting the capabilities XML. */
    public static final String REQUEST_GET_CAPABILITIES = "GET_CAPABILITIES";
    /** Constant to use when requesting information about a feature in a map. */
    public static final String REQUEST_GET_FEATURE_INFO = "GET_FEATURE_INFO";
    /** The type of request. */
    private String myRequest = null;
    /** Set the name of the request. */
    public void setRequest(String inRequest){myRequest = inRequest;}
    /** Get the name of the request. */
    public String getRequest(){return myRequest;}
    
    /** The layers to include in the map in the order in which they are to be included. */
    private String[] myLayers = null;
    /** Set the layers to be included in the map, in the order in which they are to be included. */
    public void setLayers(String[] inLayers){ myLayers = inLayers;}
    /** Get the layers to be included in the map, in the order in which they are to be included. */
    public String[] getLayers(){return myLayers;}
    
    /** The styles to apply to the layers. */
    private String[] myStyles = null;
    /** Set the styles to apply to the layers. */
    public void setStyles(String[] inStyles){myStyles = inStyles;}
    /** Get the list of styles to apply to the layers. */
    public String[] getStyles(){return myStyles;}
    
    /** The filters to applay to the layers. */
    private FilterInfo[] myFilters = null;
    /** Set the filters to apply to the layers. */
    public void setFilters(FilterInfo[] inFilters){myFilters = inFilters;}
    /** Get the filters to apply to the layers. */
    public FilterInfo[] getFilters(){return myFilters;}
    
    /** The Spatial Reference System identifier. */
    private String mySRS = "EPSG:4326";  // wgs84 Lat/Long.
    /** Set the Spatial Reference System Identifier. */
    public void setSRS(String inSRS){mySRS = inSRS;}
    /** Get the Spatial Reference System Identifier. */
    public String getSRS(){return mySRS;}
    
    /** For Auto SRS's, this is the required longitude value. */
    private double mySRSLongitude = 0;
    /** Set the SRSLongitude value for auto SRS's */
    public void setSRSLongitude(double inLongitude){mySRSLongitude = inLongitude;}
    /** Get the SRSLongitude value for auto SRS's */
    public double getSRSLongitude(){return mySRSLongitude;}
    
    /** For Auto SRS's, this is the required SRSLatitude value. */
    private double mySRSLatitude = 0;
    /** Set the SRSLatitude value for auto SRS's */
    public void setSRSLatitude(double inLatitude){mySRSLatitude = inLatitude;}
    /** Get the SRSLatitude value for auto SRS's */
    public double getSRSLatitude(){return mySRSLatitude;}
    
    /** For Auto SRS, this determines if there is a latitude and longitude value available. */
    private boolean mySRSAuto = false;
    /** Set to true for an AUTO SRS that allows specification of latitude and longitude. */
    public void setSRSAuto(boolean inAuto){mySRSAuto = inAuto;}
    /** Returns true is there is a latitude and longitude available. */
    public boolean isSRSAuto(){return mySRSAuto;}
    
    /** The bounding Box to use when generating the map. */
    /** The maximum X coordinate. */
    private double myMaxX = 0;
    /** Set the maximum X coordinate. */
    public void setMaxX(double inMaxX){myMaxX = inMaxX;}
    /** Get the maximum X coordinate. */
    public double getMaxX(){return myMaxX;}
    
    /** The minimum X coordinate. */
    private double myMinX = 0;
    /** Set the minimum X coordinate. */
    public void setMinX(double inMinX){myMinX = inMinX;}
    /** Get the minimum X coordinate. */
    public double getMinX(){return myMinX;}
    
    /** The maximum Y coordinate. */
    private double myMaxY = 0;
    /** Set the maximum Y coordinate. */
    public void setMaxY(double inMaxY){myMaxY = inMaxY;}
    /** Get the maximum Y coordinate. */
    public double getMaxY(){return myMaxY;}
    
    /** The minimum Y coordinate. */
    private double myMinY = 0;
    /** Set the minimum Y coordinate. */
    public void setMinY(double inMinY){myMinY = inMinY;}
    /** Get the minimumv Y coordinate. */
    public double getMinY(){return myMinY;}
    
    /** Set the Width of the requested result. */
    private int myWidth = 200;
    /** Set the width of the requested result. */
    public void setWidth(int inWidth){myWidth = inWidth;}
    /** Get the width of the requested result. */
    public int getWidth(){return myWidth;}
    
    /** Set the Height of the requested result. */
    private int myHeight = 200;
    /** Get the heigth of the request result. */
    public int getHeight(){return myHeight;}
    /** Set the height of the requested result. */
    public void setHeight(int inHeight){myHeight = inHeight;}
    
    /** Constant to use when requesting a PNG format. */
    public static final String FORMAT_PNG = "PNG";
    /** Constant to use when requesting a JPG format. */
    public static final String FORMAT_JPG = "JPG";
    /** Constant to use when requesting a GIF format. */
    public static final String FORMAT_GIF = "GIF";
    
    /** Get the format of the output image. */
    private String myFormat = FORMAT_PNG;
    /** Set the format of the output image. */
    public void setFormat(String inFormat){myFormat = inFormat;}
    /** Get the format of the output image. */
    public String getFormat(){return myFormat;}
    
    /** Sets the transparent value, only valid for Gif, and PDF. */
    private boolean myTransparent = false;
    /** Set the transparent value, only valid for Gif and PDF. */
    public void setTransparent(boolean inTransparent){myTransparent = inTransparent;}
    /** Get the transparent value.*/
    public boolean getTransparent(){return myTransparent;}
    
    /** Background color of the image.*/
    private Color myBackgroundColor = Color.white;
    /** Sets the background color of the image. */
    public void setBackgroundColor(Color inColor){
        if (inColor != null) myBackgroundColor = inColor;
        else myBackgroundColor = Color.white;
    }
    /** Get the background color of the image. */
    public Color getBackgroundColor(){return myBackgroundColor;}
    
    /** The url that was used to call this request. */
    private String myCalledURL = null;
    /** Set the URL that was used to call this request. */
    public void setCalledURL(String inCalledURL){myCalledURL = inCalledURL;}
    /** Get the URL that was used to call this request. */
    public String getCalledURL(){return myCalledURL;}
    
    /** For Info requests, this is the number of features to return information about. */
    private int myFeatureCount = 1;
    /** Set the number of features to return information about. */
    public void setFeatureCount(int inFeatureCount){myFeatureCount = inFeatureCount;}
    /** Get the numbe of features to return information about. */
    public int getFeatureCount(){return myFeatureCount;}
    
    /** For info requests, this is the pixel of interest in the map. */
    private int myXPoint = 0;
    /** Set the X coordinate of the pixel of interest. */
    public void setXPoint(int inXPoint){myXPoint = inXPoint;}
    /** Get the X coordinate of the pixel of interest for a getInfo request.*/
    public int getXPoint(){return myXPoint;}
    
    /** For info requests, this is the pixel of interest in the map. */
    private int myYPoint = 0;
    /** Set the Y coordinate of the pixel of interest. */
    public void setYPoint(int inYPoint){myYPoint = inYPoint;}
    /** Get the Y coordinate of the pixel of interest for a getInfo request.*/
    public int getYPoint(){return myYPoint;}
    
    /** Creates new MapRequest */
    public MapRequest(){
    }
    /** Creates new MapRequest of the given type*/
    public MapRequest(String inRequest){
        setRequest(inRequest);
    }

}
