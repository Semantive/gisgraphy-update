/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server;

/**
 * Class to hold information about a filter so that the Service can find the filter, and can modify it.
 */
public class FilterInfo {
    /** Name of the layer where this filter is to be applied. */
    private String myLayerName = null;
    /** Return the name of the layer where this filter is to be applied. */
    public String getLayerName(){return myLayerName;}
    
    /** Name of the filter to apply this value to. */
    private String myFilterName = null;
    /** Returns the name of the filter that the value is to be given to. */
    public String getFilterName(){return myFilterName;}
    
    /** The value to send to the filter. */
    private String myFilterValue = null;
    /** Return the falue that is to be applied to the filter.*/
    public String getFilterValue(){return myFilterValue;}
    
    /** Creates new FilterInfo */
    public FilterInfo(String inLayerName, String inFilterName, String inValue) {
        myLayerName = inLayerName;
        myFilterName = inFilterName;
        myFilterValue = inValue;
    }

    /** To string method for debugging purposes. */
    public String toString(){return "FilterData Layer="+myLayerName+" FilterName="+myFilterName+" Value="+myFilterValue;}
}
