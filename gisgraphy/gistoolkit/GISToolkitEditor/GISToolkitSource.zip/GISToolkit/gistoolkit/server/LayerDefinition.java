/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server;

import java.util.Vector;
import gistoolkit.features.Envelope;
import gistoolkit.datasources.*;
import gistoolkit.projection.*;
import gistoolkit.display.*;

/**
 * Holds information for a layer.
 */
public class LayerDefinition {
    
    /** Name of the layer. */
    private String myLayerName = "Poggle";
    /** Set the name of the layer.*/
    public void setLayerName(String inLayerName){myLayerName = inLayerName;}
    /** Get the name of the layer. */
    public String getLayerName(){return myLayerName;}
    
    /** Title of the layer. */
    private String myLayerTitle = "Poggle Title";
    /** Set the name of the layer.*/
    public void setLayerTitle(String inLayerTitle){myLayerTitle = inLayerTitle;}
    /** Get the name of the layer. */
    public String getLayerTitle(){return myLayerTitle;}
    
    /** The maximum distance at which to display this layer. */
    private double myMaxDisplayDistance = 180;
    /** This layer will only be drawn if the width of the view is less than this distance. */
    public void setMaxDisplayDistance(double inMaxDisplayDistance){
        myMaxDisplayDistance = inMaxDisplayDistance;
        if (myLayer != null) myLayer.setMaxDistance(myMaxDisplayDistance);
    }
    /** This layer will only be drawn if the width of the view is less than this distance. */
    public double getMaxDisplayDistance(){return myMaxDisplayDistance;}
    /** The minimum distance at which to display this layer. */
    private double myMinDisplayDistance = 0;
    /** This layer will only be drawn if the width of the view is greater than this distance. */
    public void setMinDisplayDistance(double inMinDisplayDistance){
        myMinDisplayDistance = inMinDisplayDistance;
        if (myLayer != null) myLayer.setMinDistance(myMinDisplayDistance);
    }
    /** This layer will only be drawn if the width of the view is greater than this distance. */
    public double getMinDisplayDistance(){return myMinDisplayDistance;}
    /** The maximum distance at which to label this layer. */
    private double myMaxLabelDistance = 180;
    /** This label will only be drawn if the width of the view is less than this distance. */
    public void setMaxLabelDistance(double inMaxLabelDistance){
        myMaxLabelDistance = inMaxLabelDistance;
        if (myLayer != null) myLayer.setMaxLabelDistance(myMaxLabelDistance);
    }
    /** This label will only be drawn if the width of the view is less than this distance. */
    public double getMaxLabelDistance(){return myMaxLabelDistance;}
    /** The minimum distance at which to label this layer. */
    private double myMinLabelDistance = 0;
    /** This label will only be drawn if the width of the view is greater than this distance. */
    public void setMinLabelDistance(double inMinLabelDistance){
        myMinLabelDistance = inMinLabelDistance;
        if (myLayer != null) myLayer.setMinLabelDistance(myMinLabelDistance);
    }
    /** This label will only be drawn if the width of the view is greater than this distance. */
    public double getMinLabelDistance(){return myMinLabelDistance;}
    
    /** The maximum Envelope of the layer in latitude and longitude.*/
    private Envelope myLatLonEnvelope = null;
    /** Set the maximum extends of the map in latitude and logitude. */
    public void setLatLonEnvelope(Envelope inEnvelope){myLatLonEnvelope = inEnvelope;}
    /** Get the maximum Envelope of the map in Latitude and longitude. */
    public Envelope getLatLonEnvelope(){return myLatLonEnvelope;}
    
    /** The data source from which the data will be retrieved. */
    private DataSource myDataSource = null;
    /** Set the data source to use with this layer definition. */
    public void setDataSource(DataSource inDataSource){
        myDataSource = inDataSource;
        if (inDataSource != null) myFromProjection = inDataSource.getFromProjection();
        myLayer = null;
    }
    /** Get the data source to use with this layer definition. */
    public DataSource getDataSource(){return myDataSource;}
    
    /** The From projection to use for this layer. */
    private Projection myFromProjection = null;
    /** Set the from projection to use for this layer. */
    public void setFromProjection(Projection inProjection)throws Exception{
        myFromProjection = inProjection;
        if (myLayer != null) myLayer.setFromProjection(inProjection);
        else{
            if (myDataSource != null) myDataSource.setFromProjection(myFromProjection);
        }
    }
    public Projection getFromProjection(){return myFromProjection;}
    
    /** There can be a large variety of styles to use with a given data source. */
    private Vector myStyles = new Vector();
    /** Add a given style to the list of available styles. */
    public void addStyle(Style inStyle){if (inStyle != null) myStyles.addElement(inStyle);}
    /** Remove a given style from the list of available styles. */
    public void removeStyle(Style inStyle){if (inStyle != null) myStyles.removeElement(inStyle);}
    /** Retrieve a list of the available styles for this layer. */
    public Style[] getStyles(){
        Style[] tempStyles = new Style[myStyles.size()];
        myStyles.copyInto(tempStyles);
        return tempStyles;
    }
    /** Retrieve the style with this name from the list of available styles.  Returns null if style is not found. */
    public Style getStyle(String inStyleName){
        for (int i=0; i<myStyles.size(); i++){
            Style tempStyle = (Style) myStyles.elementAt(i);
            if (inStyleName.equalsIgnoreCase(tempStyle.getStyleName())){
                return tempStyle;
            }
        }
        return null;
    }
    
    /** The projection to use with this layer. */
    private Projection myProjection = null;
    /** Set the projection to use for this layer. */
    protected void setProjection(Projection inProjection) throws Exception{
        myProjection = inProjection;
        if (myLayer != null){myLayer.setProjection(inProjection, true);}
    }
    
    /** Creates new LayerDefinition */
    public LayerDefinition() {
    }
    
    /** Creates new LayerDefinition */
    public LayerDefinition(String inName) {
        setLayerName(inName);
    }
    
    /** Do not reload the layer each time so it can do some intelligent caching. */
    private Layer myLayer = null;
    /** Returns the layer. */
    public Layer getLayer() throws Exception{
        if (myLayer == null){
            myLayer = new Layer(myDataSource);
            myLayer.setLayerName(myLayerName);
            myLayer.setMaxDistance(myMaxDisplayDistance);
            myLayer.setMinDistance(myMinDisplayDistance);
            myLayer.setMaxLabelDistance(myMaxLabelDistance);
            myLayer.setMinLabelDistance(myMinLabelDistance);
            myLayer.setProjection(myProjection, true);
            myLayer.setFromProjection(myFromProjection);
        }
        return myLayer;
    }
    
    /** Returns the layer with the given definition and style. */
    public Layer getLayer(String inStyle) throws Exception{
        getLayer();
        if (inStyle != null){
            for (int i=0; i<myStyles.size(); i++){
                Style tempStyle = (Style) myStyles.elementAt(i);
                if (inStyle.equals(tempStyle.getStyleName())){
                    myLayer.setStyle(tempStyle);
                    return myLayer;
                }
            }
        }
        else{
            if (myStyles.size() > 0){
                myLayer.setStyle((Style) myStyles.elementAt(0));
            }
        }
        return myLayer;
    }
    
}
