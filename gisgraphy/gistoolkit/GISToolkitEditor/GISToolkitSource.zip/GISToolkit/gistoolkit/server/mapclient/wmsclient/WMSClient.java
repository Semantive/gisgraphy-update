/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.wmsclient;

import java.awt.Image;
import gistoolkit.server.mapclient.*;

/**
 * Ancestor for the true clients of web services.
 */
public abstract class WMSClient extends Object {

    /** The location where the web service resides.  This is just the URL Base, the client will add the necissary parameters. */
    private String myURLBase = "";
    /** Set the location of the web service.  This should be in the form of a URL */
    public void setURLBase(String inURLBase){myURLBase = inURLBase;}
    /** Retrieve the location of the web service. */
    public String getURLBase(){return myURLBase;}
    
    /** Holds the name of the service.  This is only required for the ESRI services, the bastards*/
    private String myService = null;
    /** set the service name of the service when connecting to an ESRI service */
    public void setService(String inService){myService = inService;}
    /** Retrive the name of the service */
    public String getService(){return myService;}

    /** Creates new OGCWebServiceClient */
    public WMSClient() {
    }
    
    /** Connect to the web service.  If connection fails, then the return should be the reason.*/
    public abstract void connect() throws Exception;
    
    /** Retrieve the Available layers from the Connected Client */
    public abstract Layer[] getLayers();
    
    /** Set the layers of interest */
    public abstract void setSelectedLayers(Layer[] inLayers);
    
    /** Returns the list of selected layers. */
    public abstract Layer[] getSelectedLayers();
    
    /** Read the data source with the given extents */
    public abstract Image read(Extents inExtents) throws Exception;
    
    /** Set the width of the desired image */
    public abstract void setWidth(int inWidth);
    
    /** Set the height of the desired image */
    public abstract void setHeight(int inHeight);
    
    /** Get the Available Map Formats */
    public abstract String[] getMapFormats();
    
    /** Set the Selected Map Formats */
    public abstract void setSelectedMapFormat(String inFormat);

}
