/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.drawer;

import java.awt.*;
import java.awt.image.*;
import gistoolkit.server.mapclient.*;
import java.awt.event.*;
/**
 * Basic drawer allows subclassing by other drawers.
 */
public abstract class BasicDrawer implements Drawer, MouseListener, MouseMotionListener, KeyListener {

    /** Creates new BasicDrawer */
    public BasicDrawer() {
    }
    
    /** Component for use with the drawImage method sheesh */
    private ImagePanel myImagePanel = null;
    /** Retrieve the image panel from the drawer */
    public ImagePanel getImagePanel(){return myImagePanel;}
    /** Set the ImagePanel in the drawer so it can be updated */
    public void setImagePanel(ImagePanel inImagePanel){myImagePanel = inImagePanel;}
    
    /** Drawers can have commands to execute at a point when they have completed their work */
    private Command myCommand = null;
    /** Retrieve the Command from the Drawer */
    public Command getCommand(){return myCommand;}
    /** Set the command into the Drawer to be executed on completion */
    public void setCommand(Command inCommand){myCommand = inCommand;}
    
    /** Causes a redraw from the image panel */
    protected void draw(){
        if (myImagePanel != null){
            myImagePanel.update(myImagePanel.getGraphics());
        }
    }
    
    /** Draw the image on the screen  */
    public abstract void draw(Graphics inGraphics, Image inImage, int inWidth, int inHeight, ImageObserver inImageObserver);
    
    /** Reset the state of this draw model */
    public void reset(){}
    
    /** Mouse Methods */
    public void mouseReleased(java.awt.event.MouseEvent me) {
    }
    
    public void mouseEntered(java.awt.event.MouseEvent me) {
    }
    
    public void mouseClicked(java.awt.event.MouseEvent me) {
    }
    
    public void mousePressed(java.awt.event.MouseEvent me) {
    }
    
    public void mouseExited(java.awt.event.MouseEvent me) {
    }
    
    public void mouseDragged(java.awt.event.MouseEvent me) {
    }
    
    public void mouseMoved(java.awt.event.MouseEvent me) {
    }    
    
    /** Keyboard Messages */
    public void keyReleased(java.awt.event.KeyEvent ke) {
    }
    
    public void keyPressed(java.awt.event.KeyEvent ke) {
        // handle the escape key
        if(ke.getKeyCode() == KeyEvent.VK_ESCAPE){
            reset();
        }
    }
    
    public void keyTyped(java.awt.event.KeyEvent ke) {
    }        
}
