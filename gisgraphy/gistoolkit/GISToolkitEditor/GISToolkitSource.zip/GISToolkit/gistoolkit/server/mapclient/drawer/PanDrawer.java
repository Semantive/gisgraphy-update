/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.drawer;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

/**
 * Class to allow the user to move the image around on the screen.
 */
public class PanDrawer extends BasicDrawer{    
    
    /** Starting point of the drag */
    private Point myStartPoint = null;
    /** Retrieve the starting point of the drag in screen coordinates */
    public Point getStartPoint(){return myStartPoint;}
    
    /** Ending point of the drag */
    private Point myEndPoint = null;
    /** Retrieve the ending point of the drag in screen coordinates */
    public Point getEndPoint(){return myEndPoint;}
    
    /** Creates new PanDrawer */
    public PanDrawer() {
    }

    /** Reset the state of this draw model */
    public void reset(){
        myStartPoint = null;
        myEndPoint = null;
        draw();
    }
    
    /** Draw the image on the screen  */
    public void draw(Graphics inGraphics, Image inImage, int inWidth, int inHeight, ImageObserver inImageObserver) {
        if (inGraphics == null) return;
        if (inImage == null) return;
        if ((myStartPoint != null) && (myEndPoint != null)){
            int dx = myEndPoint.x - myStartPoint.x;
            int dy = myEndPoint.y - myStartPoint.y;
            inGraphics.clearRect(0,0, inWidth, inHeight);
            inGraphics.drawImage(inImage, dx, dy, inWidth, inHeight, inImageObserver);        
        }
        else{
            inGraphics.clearRect(0,0, getImagePanel().getWidth(), getImagePanel().getHeight());
            inGraphics.drawImage(inImage, 0,0, inWidth, inHeight, inImageObserver);
        }
    }
    
    public void mousePressed(java.awt.event.MouseEvent e) {
        myStartPoint = new java.awt.Point(e.getX(), e.getY());
        myEndPoint = myStartPoint;
    }
    /**
     * Called when the user releases the mouse button.
     */
    public void mouseDragged(MouseEvent e){
        myEndPoint = new java.awt.Point(e.getX(), e.getY());
        draw();
    }
    
    public void mouseReleased(java.awt.event.MouseEvent e) {
        myEndPoint = new java.awt.Point(e.getX(), e.getY());
        if (getCommand() != null){
            getCommand().drawexecute(this);
        }
    }
}
