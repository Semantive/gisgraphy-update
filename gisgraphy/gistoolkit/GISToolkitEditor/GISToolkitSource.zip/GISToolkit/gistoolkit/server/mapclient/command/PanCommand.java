/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.command;

import java.awt.Point;
import gistoolkit.server.mapclient.*;
import gistoolkit.server.mapclient.drawer.*;
/**
 * Used to tell the interface to draw in Pan mode, and to update the extents of the map
 * Once they do.
 */
public class PanCommand extends BasicCommand implements Runnable{
    
    
    /** Creates new PanCommand */
    public PanCommand(Client inClient) {
        super("Pan", inClient);
    }
    
    /**
     * Called when the command is executed.
     */
    public void execute() {
        PanDrawer tempDrawer = new PanDrawer();
        tempDrawer.setCommand(this);
        getClient().getImagePanel().setDrawer(tempDrawer);
        tempDrawer.setImagePanel(getClient().getImagePanel());
    }
    
    /**
     * Called when the drawer completes
     */
    public void doDrawExecute(Drawer inDrawer) {
        // update the world coordinates.
        System.out.println("Executing Pan Command");
        if (inDrawer instanceof PanDrawer){
            System.out.println("Executing Pan Command");
            Point tempStartPoint = ((PanDrawer) inDrawer).getStartPoint();
            Point tempEndPoint = ((PanDrawer) inDrawer).getEndPoint();
            
            // if neither the start or end are null, then calculate the world shift
            if ((tempStartPoint != null) && (tempEndPoint != null)){
                System.out.println("Points are not null");
                Client c = getClient();
                ImagePanel tempImagePanel = c.getImagePanel();
                Converter tempConverter = new Converter(tempImagePanel.getWidth(), tempImagePanel.getHeight(), c.getTopX(), c.getTopY(), c.getBottomX(), c.getBottomY());
                double dx = tempConverter.toWorldX(tempStartPoint.x) - tempConverter.toWorldX(tempEndPoint.x);
                double dy = tempConverter.toWorldY(tempStartPoint.y) - tempConverter.toWorldY(tempEndPoint.y);
                c.setTopX(c.getTopX()+dx);
                c.setTopY(c.getTopY()+dy);
                c.setBottomX(c.getBottomX()+dx);
                c.setBottomY(c.getBottomY()+dy);
                c.refresh();
                ((PanDrawer) inDrawer).reset();
            }
        }
    }
    
    private Thread myThread;
}
