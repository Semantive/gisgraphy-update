/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient;

/**
 * Class to convert from world coordinates to screen coordinates.
 * The individual layers will have data in their respective projections.
 * Typically, this will all be one projection.
 * The converter will then convertfrom that projection to screen coordinates.
 */
public class Converter {
    private Extents myWorldExtents;
    private Extents myScreenExtents;
    private double myXMultiplier;
    private double myYMultiplier;
    
    /**
     * Create a converter to convert from the given screen extents to the given
     * world extents, and vice versa.
     */
    public Converter(Extents inScreenExtents, Extents inWorldExtents){
        this(inScreenExtents, inWorldExtents, true);
    }
 
    /**
     * Create a converter to convert from the given screen coordinates to the given
     * world coordinates, and vice versa.
     */
    public Converter(int inScreenWidth, int inScreenHeight, double inTopX, double inTopY, double inBottomX, double inBottomY){
        this(new Extents(0, 0, inScreenWidth, inScreenHeight), new Extents(inTopX, inTopY, inBottomX, inBottomY));        
    }

    /**
     * Create a converter to convert from the given screen extents to the given
     * world extents, and vice versa.
     */
    public Converter(Extents inScreenExtents, Extents inWorldExtents, boolean inSquare){
        // save the bounds
        myWorldExtents = inWorldExtents;
        myScreenExtents = inScreenExtents;
        
        // figure out the multipliers
        myXMultiplier = (inScreenExtents.myBottomX-inScreenExtents.myTopX)/(inWorldExtents.myBottomX-inWorldExtents.myTopX);
        myYMultiplier = (inScreenExtents.myBottomY-inScreenExtents.myTopY)/(inWorldExtents.myBottomY-inWorldExtents.myTopY);
        
        if (inSquare){
            // Decide whether the xdirection or y direction is limiting.
            if (myXMultiplier < -myYMultiplier){
                myYMultiplier = -myXMultiplier;
            }
            
            // Decide wheather the xdirection or y direction is limiting.
            if (-myYMultiplier <= myXMultiplier){
                myXMultiplier = -myYMultiplier;
            }
            
            // find the world extents
            myWorldExtents = new Extents(
                toWorldX((int) inScreenExtents.getTopX()),
                toWorldY((int) inScreenExtents.getTopY()),
                toWorldX((int) inScreenExtents.getBottomX()),
                toWorldY((int) inScreenExtents.getBottomY())
            );
        }
    }
    
    
    /**
     * Convert the given world x coordinate to a corrisponding screen coordinate.
     */
    public int convertX(double inX) {
        return (int) ((inX - myWorldExtents.myTopX) * myXMultiplier);
    }
    public int convertY(double inY){
        return (int) ((inY-myWorldExtents.myTopY)*myYMultiplier);
    }
    
    /**
     * Returns a copy of the world extents used to create this converter.
     */
    public Extents getWorldExtents() {
        if (myWorldExtents == null)
            return myWorldExtents;
        else
            return (Extents) myWorldExtents.clone();
    }
    
    /**
     * Returns a copy of the screen extents used to create this converter.
     */
    public Extents getScreenExtents() {
        if (myScreenExtents == null)
            return myScreenExtents;
        else
            return (Extents) myScreenExtents.clone();
    }
    
    /**
     * Converts the given world coordinate in X to a screen pixel coordinate in X.
     */
    public int toScreenX(double inX) {
        return (int) ((inX - myWorldExtents.myTopX)*myXMultiplier);
    }
    
    /**
     * Converts the given world coordinate in Y to a screen pixel coordinate in Y.
     */
    public int toScreenY(double inY) {
        return (int) ((inY - myWorldExtents.myTopY) * myYMultiplier);
    }
    
    /**
     * Converts the given screen X pixel coordinate to a world X coordinate.
     */
    public double toWorldX(int inX) {
        return inX/myXMultiplier +myWorldExtents.myTopX;
    }
    
    /**
     * Converts the given screen Y pixel coordinate to a world Y coordinate.
     */
    public double toWorldY(int inY) {
        return inY/myYMultiplier +myWorldExtents.myTopY;
    }
    
    /** Return the width of the world */
    public double getWorldWidth(){ return myWorldExtents.getWidth();}
    /** Retrieve the height of the world */
    public double getWorldHeight(){ return myWorldExtents.getHeight();}
    /** Return the width of the screen*/
    public double getScreenWidth(){ return myScreenExtents.getWidth();}
    /** Return the height of the screen*/
    public double getScreenHeight(){ return myScreenExtents.getHeight();}
}