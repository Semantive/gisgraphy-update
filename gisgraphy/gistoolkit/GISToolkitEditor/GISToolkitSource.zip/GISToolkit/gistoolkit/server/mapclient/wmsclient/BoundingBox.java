/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.wmsclient;

/**
 * Class to hold the MinX, MaxX, MinY, MaxY data.
 */
public class BoundingBox extends Object {

    /** Creates new BoundingBox */
    public BoundingBox(double inMaxX, double inMaxY, double inMinX, double inMinY, String inSRS) {
        myMaxX = inMaxX;
        myMaxY = inMaxY;
        myMinX = inMinX;
        myMinY = inMinY;
        mySRS = inSRS;
    }

    private String mySRS = null;
    public String getSRS(){return mySRS;}
    private double myMaxX = 0.0;
    public double getMaxX(){return myMaxX;}
    private double myMaxY = 0.0;
    public double getMaxY(){return myMaxY;}
    private double myMinX = 0.0;
    public double getMinX(){return myMinX;}
    private double myMinY = 0.0;
    public double getMinY(){return myMinY;}
}
