/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.wmsclient;

import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import gistoolkit.server.UTF8Encoder;
import gistoolkit.common.*;
import gistoolkit.server.mapclient.*;
import gistoolkit.config.*;
/**
 * Client for the OGC 1.0.0 version web services.
 */
public class WMSClient100 extends WMSClient {
    /** Nice name to print out in log statements */
    private static String MY_NAME = "OGCClient 1.0.0";
    
    /** Creates new OGCWebServiceClient100 */
    public WMSClient100() {
    }
    
    /** Connect to the web service.  Throws an exception if it can not connect to the data source. */
    public void connect() throws Exception{
        // read the capabilities matrix
        // 1.0 SPECIFICATION
        String tempString = getURLBase();
        if (tempString.indexOf('?') == -1) tempString = tempString + "?";
        else tempString = tempString + "&";
        tempString = tempString + "REQUEST=capabilities&WMTVER=1.0.0";
        if (getService() != null){
            if (getService().trim().length() > 0){
                tempString = tempString + "&ServiceName="+UTF8Encoder.encode(getService());
            }
        }
        // 1.1.0 SPECIFICATION
        // String tempString = myURLBase + "?REQUEST=GetCapabilities&VERSION=1.1.0";
        
        // read the capabilities XML from the service.
        System.out.println(MY_NAME+" GetCapabilities: "+tempString);
        Node tempRoot = Configurator.getXML(tempString);
        
        // search through the XML for good data
        System.out.println(MY_NAME + " Looking for WMT_MS_Capabilities element");
        String tempName = tempRoot.getName();
        if (!tempName.equalsIgnoreCase("WMT_MS_Capabilities")){
            throw new Exception("Did not find the WMT_MS_Capabilities Root Node");
        }
        
        // Default connect parameters.
        myMapURL = getURLBase();
        myServiceURL = getURLBase();
        
        // Next look for the Service Node
        Node tempServiceNode = tempRoot.getChild("Service");
        if (tempServiceNode != null){
            Node tempNameNode = tempServiceNode.getChild("Name");
            if (tempNameNode != null) myServiceName = tempNameNode.getValue();
            Node tempTitleNode = tempServiceNode.getChild("Title");
            if (tempTitleNode != null) myTitle = tempTitleNode.getValue();
            Node tempAbstractNode = tempServiceNode.getChild("Abstract");
            if (tempAbstractNode != null) myAbstract = tempAbstractNode.getValue();
            Node tempOnlineResource = tempServiceNode.getChild("OnlineResource");
            if ((tempOnlineResource != null) && (tempOnlineResource.getValue() != null)){myServiceURL = tempOnlineResource.getValue();}
            Node tempFees = tempServiceNode.getChild("Fees");
            if (tempFees != null) myFees = tempFees.getValue();
            Node tempAccessConstraints = tempServiceNode.getChild("AccessConstraints");
            if (tempAccessConstraints != null) myAccessConstraints = tempAccessConstraints.getValue();
        }
        
        // Now identify the capabilities of this particular
        Node tempCapabilitiesNode = tempRoot.getChild("Capability");
        if (tempCapabilitiesNode != null){
            
            // Retrieve the Request node
            Node tempRequestNode = tempCapabilitiesNode.getChild("Request");
            if (tempRequestNode != null){
                
                // Read the capabilities of the map node.
                Node tempMapNode = tempRequestNode.getChild("Map");
                if (tempMapNode != null){
                    
                    // read the formats for the map
                    Node tempMapFormatNode = tempMapNode.getChild("Format");
                    if (tempMapFormatNode != null){
                        Vector tempVect = new Vector();
                        Node[] tempNodes = tempMapFormatNode.getChildren();
                        for (int i=0; i<tempNodes.length; i++){
                            tempVect.addElement(tempNodes[i].getName());
                        }
                        myMapFormats = new String[tempVect.size()];
                        tempVect.copyInto(myMapFormats);
                    }
                    
                    // Read the connect parameters of the map.
                    Node tempMapDCPNode = tempMapNode.getChild("DCPType");
                    if (tempMapDCPNode != null){
                        Node tempMapHTTPNode = tempMapDCPNode.getChild("HTTP");
                        if (tempMapHTTPNode != null){
                            Node tempGetNode = tempMapHTTPNode.getChild("Get");
                            if (tempGetNode != null){
                                tempString = tempGetNode.getAttribute("onlineResource");
                                if (tempString != null){
                                    myMapURL = tempString;
                                }
                            }
                        }
                    }
                }// end of the Map capabilities
            } // end of the Request capabilities
            
            // Determine what types of exceptions are available.
            Node tempExceptionNode = tempCapabilitiesNode.getChild("Exception");
            if (tempExceptionNode != null){
                Node tempFormatNode = tempExceptionNode.getChild("Format");
                if (tempFormatNode != null){
                    Vector tempVect = new Vector();
                    Node[] tempNodes = tempFormatNode.getChildren();
                    for (int i=0; i<tempNodes.length; i++){
                        tempVect.addElement(tempNodes[i].getName());
                    }
                    myExceptionFormats = new String[tempVect.size()];
                    tempVect.copyInto(myExceptionFormats);
                }
            }
            
            // Read the Layers from the Capabilities.
            Node tempLayerNode = tempCapabilitiesNode.getChild("Layer");
            Vector tempLayersVect = new Vector();
            if (tempLayerNode != null){
                addLayer(tempLayersVect, tempLayerNode, null);
            }
            if (tempLayersVect.size() == 0) throw new Exception("No Layer found in Capabilities ");
            myLayers = new Layer[tempLayersVect.size()];
            tempLayersVect.copyInto(myLayers);
        }
        else throw new Exception("No Capabilities Found in XML");
    }
    
    /**
     * The layers in the XML are a nested tree of layers.  This is a recursive function that walks and parses the tree
     */
    private void addLayer(Vector inLayersVect, Node inLayerNode, Layer inParent){
        // Look for a name for this Layer
        Layer tempParent = inParent;
        try{
            tempParent = new Layer(inLayerNode, inParent);
            if (tempParent.getName() != null) inLayersVect.addElement(tempParent);
        }
        catch (Exception e){
            System.out.println("Exception "+e+" Parsing Layer");
        }
        
        // Parse the remaining Layers
        Node[] tempLayers = inLayerNode.getChildren("Layer");
        for (int i=0; i<tempLayers.length; i++){
            try{
                addLayer(inLayersVect, tempLayers[i], tempParent);
            }
            catch(Exception e){
                System.out.println("Exception "+e+" Parsing Layer "+i);
            }
        }
    }
    
    /** The name of this service */
    private String myServiceName = "None";
    /** Get the service Name */
    public String getServiceName(){return myServiceName;}
    
    /** The title of this service */
    private String myTitle = "None";
    /** Get the title of the service */
    public String getTitle(){return myTitle;}
    
    /** The Abstract for this service */
    private String myAbstract = null;
    /** Get the abstract for the service */
    public String getAbstract(){return myAbstract;}
    
    /** The online resource for the actual service */
    private String myServiceURL = "";
    /** Get the Online Resource for the actual service */
    public String getServiceURL(){return myServiceURL;}
    
    /** The Fees charged to use this servuce */
    private String myFees = "";
    /** Retrieve the Fees to be charged for the use of the service */
    public String getFees(){return myFees;}
    
    /** Any Access constraints for this service */
    private String myAccessConstraints = "";
    /** Retrieve the access constraints for this servcie */
    public String getAccessConstraints(){return myAccessConstraints;}
    
    /** The URL where the map can be found */
    private String myMapURL = null;
    /** Return the URL where the map can be found */
    public String getMapURL(){return myMapURL;}
    
    /** The available formats for the map */
    private String[] myMapFormats = new String[0];
    /** Return the available formats for the map */
    public String[] getMapFormats(){return myMapFormats;}
    
    /** The selected map format */
    private String mySelectedMapFormat = "GIF";
    /** Set the selected map format */
    public void setSelectedMapFormat(String inMapFormat){mySelectedMapFormat = inMapFormat;}
    /** Retrieve the selected map format*/
    public String getSelectedMapFormat(){return mySelectedMapFormat;}
    
    /** The available formats for the exceptions */
    private String[] myExceptionFormats = new String[0];
    /** Return the available formats for exceptions */
    public String[] getExceptionFormats(){return myExceptionFormats;}
    
    /** The available Layers */
    private Layer[] myLayers = new Layer[0];
    /** Return the Available Layers */
    public Layer[] getLayers(){return myLayers;}
    
    /** The layers the user has selected */
    private Layer[] mySelectedLayers = new Layer[0];
    /** Set the selected Layers */
    public void setSelectedLayers(Layer[] inLayers){mySelectedLayers = inLayers;}
    /** Retrieve the selected layers*/
    public Layer[] getSelectedLayers(){return mySelectedLayers;}
    
    /** The width of the resulting image */
    private int myWidth = 0;
    /** Set the width of the resulting image */
    public void setWidth(int inWidth){myWidth = inWidth;}
    /** Retrieve the width of the resulting image */
    public int getWidth(){return myWidth;}
    
    /** The height of the resulting image */
    private int myHeight = 0;
    /** Set the height of the resulting image */
    public void setHeight(int inHeight){myHeight = inHeight;}
    /** Retrieve the height of the resulting image */
    public int getHeight(){return myHeight;}
    
    public Image read(Extents inExtents)throws Exception{
        // Construct the request
        String tempRequest = "Request=map";
        
        // Construct the Version
        String tempVersion = "&WMTVER=1.0.0";
        
        // The Service Name
        String tempService = "";
        if (getService() != null){
            if (getService().trim().length() > 0){
                if (myMapURL.toUpperCase().indexOf("SERVICENAME") == -1){
                    tempService = "&ServiceName="+UTF8Encoder.encode(getService());
                }
            }
        }
        
        // construct the layers
        if ((mySelectedLayers == null) || (mySelectedLayers.length == 0)) throw new Exception("No Layers Selected");
        String tempLayers = "&Layers=";
        boolean tempHasStyles = false;
        for (int i=0; i<mySelectedLayers.length; i++){
            if(i > 0) tempLayers = tempLayers + ",";
            tempLayers = tempLayers + UTF8Encoder.encode(mySelectedLayers[i].getName());
            if (mySelectedLayers[i].getSelectedStyle() != null) tempHasStyles = true;
        }
        
        // construct the styles
        String tempStyles = "";
        if (tempHasStyles){
            tempStyles = "&Styles=";
            for (int i=0; i<mySelectedLayers.length; i++){
                if(i > 0) tempStyles = tempStyles + ",";
                tempStyles = tempStyles + UTF8Encoder.encode(mySelectedLayers[i].getSelectedStyle().getName());
            }
        }
        
        // SRS  This could be a difficult one, for now it works, but I am not parsing the SRS yet.
        String tempSRS = "&SRS=";
        for (int i=0; i<mySelectedLayers.length; i++){
            if(i > 0) tempSRS = tempSRS + ",";
            tempSRS = tempSRS + UTF8Encoder.encode(mySelectedLayers[i].getSelectedSRS().trim());
        }
        
        // construct the bounding box
        double tempMinX = Math.min(inExtents.myTopX, inExtents.myBottomX);
        double tempMaxX = Math.max(inExtents.myTopX, inExtents.myBottomX);
        double tempMinY = Math.min(inExtents.myTopY, inExtents.myBottomY);
        double tempMaxY = Math.max(inExtents.myTopY, inExtents.myBottomY);
        String tempBBox = "&BBOX="+tempMinX+","+tempMinY+","+tempMaxX+","+tempMaxY;
        
        // construct the width
        String tempWidth = "&Width="+myWidth;

        // construct the height
        String tempHeight = "&Height="+myHeight;
        
        // Construct the output format
        String tempFormat = "&FORMAT=PNG";
        if (mySelectedMapFormat != null){
            tempFormat = "&FORMAT="+UTF8Encoder.encode(mySelectedMapFormat);
        }
        
        // Construct the URL.
        String tempQuestion = "?";
        if (myMapURL.indexOf(tempQuestion) != -1){
            tempQuestion = "";
        }
        String tempURLString = myMapURL + tempQuestion+tempRequest +tempService+tempVersion+tempLayers+tempStyles+tempSRS+tempBBox+tempWidth+tempHeight+tempFormat;
        URL tempURL = new URL(tempURLString);
        
        // read the data from the URL
        System.out.println("Contacting URL="+tempURLString);
        URLConnection tempURLConnection = tempURL.openConnection();
        String tempString = tempURLConnection.getContentType();
        System.out.println("Content Type = "+tempString);
        if ((tempString.equalsIgnoreCase("image/jpeg"))||(tempString.equalsIgnoreCase("image/jpg"))||(tempString.equalsIgnoreCase("image/png"))||(tempString.equalsIgnoreCase("image/gif"))){
            // Retrieve the Data
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            InputStream in = tempURLConnection.getInputStream();
            byte[] tempBuffer = new byte[1000];
            int length = in.read(tempBuffer);
            while (length != -1){
                bout.write(tempBuffer, 0, length);
                length = in.read(tempBuffer);
            }
            bout.close();
            in.close();
            return Toolkit.getDefaultToolkit().createImage(bout.toByteArray());
        }
        else {
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            InputStream in = tempURLConnection.getInputStream();
            byte[] tempBuffer = new byte[1000];
            int length= in.read(tempBuffer);
            while (length != -1){
                bout.write(tempBuffer, 0, length);
                length = in.read(tempBuffer);
            }
            bout.close();
            in.close();
            String tempError = new String(bout.toByteArray());
            throw new Exception(tempError);
        }
    }        
}
