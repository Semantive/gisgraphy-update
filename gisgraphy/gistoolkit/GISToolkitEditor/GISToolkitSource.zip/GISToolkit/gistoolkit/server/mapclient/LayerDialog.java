/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.server.mapclient.wmsclient.*;

/**
 * Presents a list of layers to the user allowing them to select which ones to display, and which style to display them in.
 */
public class LayerDialog extends JDialog implements ActionListener{
    // Vector for holding the combo boxes.
    private Vector myVectComboBoxes = new Vector();
    
    /** Vector for holding the check boxes. */
    private Vector myVectCheckboxes = new Vector();
    
    // The list of layers.
    private Layer[] myLayers = null;
    
    /** The button to press to say OK */
    private JButton myButtonOK = new JButton("OK");
    
    /** The button to press to say Cancel */
    private JButton myButtonCancel = new JButton("Cancel");
    
    /** The panel to use for displaying the controls. */
    private JPanel myPanelDisplay = new JPanel();
    
    /** Indicates whether the user clicked the OK button or not. */
    private boolean myOK = false;
    /** Returns true if the user clicked the OK button. */
    public boolean isOK(){return myOK;}
    
    /** Creates new LayerDialog */
    public LayerDialog() {
        initPanel();
    }
    
    
    /** Set up the user interface components for this dialog. */
    private void initPanel(){
        JPanel tempPanel = new JPanel();
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        
        c.weightx = 1;
        c.weighty = 1;
        c.gridwidth = 2;
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 1;
        c.gridy = 1;
        tempPanel.add(myPanelDisplay, c);
        c.weightx = 1;
        c.weighty = 0;
        c.gridy++;
        c.anchor = GridBagConstraints.EAST;
        c.fill = GridBagConstraints.NONE;
        c.gridwidth = 1;
        tempPanel.add(myButtonOK,c);
        myButtonOK.setPreferredSize(myButtonCancel.getPreferredSize());
        c.weightx = 0;
        c.gridx++;
        tempPanel.add(myButtonCancel, c);
        setContentPane(tempPanel);
        myButtonCancel.addActionListener(this);
        myButtonOK.addActionListener(this);
    }

    /** populate the panel with the controls that allow the user to select what layers are displayed. */
    public void setLayers(Layer[] inLayers, Layer[] inSelectedLayers){
        myLayers = inLayers;
        myVectCheckboxes.removeAllElements();
        myVectComboBoxes.removeAllElements();
        JPanel tempPanel = myPanelDisplay;
        tempPanel.removeAll();
        tempPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.gridx = 0;
        c.gridy = 0;
         
        // add the layers to the display.
        for (int i=0; i<inLayers.length; i++){
            
            // add the title for the user.
            c.gridx = 0;
            c.gridy++;
            c.weightx = 1;
            c.fill = GridBagConstraints.BOTH;
            tempPanel.add(new JLabel(inLayers[i].getTitle()), c);
            
            // add the visible check box to the panel.
            c.weightx = 0;
            c.gridx++;
            JCheckBox tempCheckbox = new JCheckBox("Visible", false);
            myVectCheckboxes.addElement(tempCheckbox);
            tempPanel.add(tempCheckbox, c);
            if (inSelectedLayers != null){
                for (int j=0; j<inSelectedLayers.length; j++){
                    if (inLayers[i] == inSelectedLayers[j]){
                        tempCheckbox.setSelected(true);
                        break;
                    }
                }
            }
            
            // Add the choice box to allow the user to select the style.
            c.gridx++;
            Style[] tempStyles = inLayers[i].getStyles();
            JComboBox tempComboBox = null;
            if ((tempStyles == null) || (tempStyles.length == 0)){
                tempPanel.add(new JLabel("Default"), c);
            }
            else if (tempStyles.length == 1){
                tempPanel.add(new JLabel(tempStyles[0].getName()), c);
                inLayers[i].setSelectedStyle(tempStyles[0]);
            }
            else{
                tempComboBox = new JComboBox();
                for (int j = 0; j<tempStyles.length; j++){
                    tempComboBox.addItem(tempStyles[j].getName());
                    if (inLayers[i].getSelectedStyle() == tempStyles[j]){
                        tempComboBox.setSelectedIndex(j);
                    }
                }
                tempPanel.add(tempComboBox, c);
            }
            myVectComboBoxes.addElement(tempComboBox);
        }
        
        // add a panel at the bottom to take up the space
        c.weighty = 1;
        c.gridy++;
        tempPanel.add(new JPanel(), c);
        pack();
    }
    
    /** returns the list of selected layers. */
    public Layer[] getSelectedLayers(){
        ArrayList tempListLayers = new ArrayList();
        for (int i=0; i<myVectCheckboxes.size(); i++){
            JCheckBox tempCheckbox = (JCheckBox) myVectCheckboxes.elementAt(i);
            if (tempCheckbox.isSelected()){
                tempListLayers.add(myLayers[i]);
                JComboBox tempComboBox = (JComboBox) myVectComboBoxes.elementAt(i);
                if (tempComboBox != null){
                    String tempName = (String) tempComboBox.getSelectedItem();
                    Style[] tempStyles = myLayers[i].getStyles();
                    for (int j=0; j<tempStyles.length; j++){
                        if (tempName.equalsIgnoreCase(tempStyles[j].getName())){
                            myLayers[i].setSelectedStyle(tempStyles[j]);
                            break;
                        }
                    }
                }
            }
        }
        
        Layer[] tempLayers = new Layer[tempListLayers.size()];
        tempListLayers.toArray(tempLayers);
        return tempLayers;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        if (actionEvent.getSource() == myButtonOK){
            myOK = true;
        }
        this.dispose();
    }
    
}
