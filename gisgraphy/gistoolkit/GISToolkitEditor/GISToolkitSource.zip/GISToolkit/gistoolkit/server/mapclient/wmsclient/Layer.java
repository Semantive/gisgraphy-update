/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.wmsclient;

import java.util.*;
import gistoolkit.common.*;
/**
 * Represents an available layer in a web service.
 */
public class Layer extends Object {
    
    /** The name of the layer */
    private String myName = null;
    /** Return the name of the layer */
    public String getName(){return myName;}
    
    /** The title of the layer */
    private String myTitle = "";
    /** Return the title of the layer */
    public String getTitle(){return myTitle;}
    
    /** The abstract of the layer */
    private String myAbstract = "";
    /** Return the abstract of the layer */
    public String getAbstract(){return myAbstract;}
    
    /** The keywords of the layer */
    private String myKeywords = "";
    /** Return the keywords of the layer */
    public String getKeywords(){return myKeywords;}
    
    /** The SRS of this data */
    private String[] myAvailableSRS = {"EPSG:4326"};
    /** Return the SRS of this layer */
    public String[] getAvailableSRS(){return myAvailableSRS;}
    
    /** The selected SRS */
    private String mySelectedSRS = "EPSG:4326";
    /** Return the selected SRS */
    public String getSelectedSRS(){return mySelectedSRS;}
    /** Set the selected STS */
    public void setSelectedSRS(String inSRS) throws Exception{
        if (inSRS == null) throw new Exception("Selected SRS can not be NULL");
        for (int i=0; i<myAvailableSRS.length; i++){
            if (inSRS.equalsIgnoreCase(myAvailableSRS[i])){
                mySelectedSRS = myAvailableSRS[i];
                return;
            }
        }
        throw new Exception("SRS "+inSRS+" Is not available for Layer "+myTitle+"("+myName+")");
    }
    
    /** The bounding box values in Lat Long (EPSG:4326). */
    private BoundingBox myBoundingBoxLatLong = null;
    /** return the bounding box in Lat Long */
    public BoundingBox getBoundingBoxLatLong(){return myBoundingBoxLatLong;}
    
    /** The Selected Style for the Layer */
    private Style mySelectedStyle = null;
    /** Return the selected style for this layer */
    public Style getSelectedStyle(){return mySelectedStyle;}
    /** Set the selected style for this layer */
    public void setSelectedStyle(Style inStyle){mySelectedStyle = inStyle;}
    
    
    /** The bounding Box values in Other SRS*/
    private BoundingBox[] myBoundingBoxSRS = new BoundingBox[0];
    /** Retrieve the bounding box for the given SRS.  If the bounding box does not exist, then null is returned */
    private BoundingBox getBoundingBox(String inSRS){
        if (inSRS == null) return null;
        if ("EPSG:4326".equalsIgnoreCase(inSRS)) return myBoundingBoxLatLong;
        for (int i=0; i<myBoundingBoxSRS.length; i++){
            if (myBoundingBoxSRS[i].getSRS().equalsIgnoreCase(inSRS)) return myBoundingBoxSRS[i];
        }
        return null;
    }
    /** Retireve all the bounding boxes for this layer except EPSG:4326*/
    public BoundingBox[] getBoundingBoxes(){
        return myBoundingBoxSRS;
    }
    /** Add a SRS Bounding box to the list */
    private void add(BoundingBox inBox){
        if (inBox == null) return;
        Vector tempVect = new Vector();
        for (int i=0; i<myBoundingBoxSRS.length; i++){
            if (myBoundingBoxSRS[i].getSRS().equals(inBox.getSRS())){
                myBoundingBoxSRS[i] = inBox;
                return;
            }
            tempVect.addElement(myBoundingBoxSRS[i]);
        }
        tempVect.addElement(inBox);
        myBoundingBoxSRS = new BoundingBox[tempVect.size()];
        tempVect.copyInto(myBoundingBoxSRS);
    }
    
    
    
    /** The DataURL of this data */
    private String myDataURL = null;
    /** Return the DataURL of the layer */
    public String getDataURL(){return myDataURL;}
    
    /** The Available Styles */
    private Style[] myStyles = null;
    /** return the styles available for this layer */
    public Style[] getStyles(){return myStyles;}
    
    
    /** Creates new Capability */
    public Layer() {
    }
    
    /** Create the layer and populate it with the node */
    public Layer(Node inNode) throws Exception{
        setNode(inNode, null);
    }
    
    /** Create the layer and populate it with the node */
    public Layer(Node inNode, Layer inParent) throws Exception{
        setNode(inNode, inParent);
    }
    
    /** Populate the object with the items from the node */
    private void setNode(Node inNode, Layer inParent) throws Exception{
        if (inNode == null) throw new Exception("Error populating layer, Node is null");
        
        // The name of the layer
        String tempString;
        Node tempNameNode = inNode.getChild("Name");
        if (tempNameNode != null){
            tempString = tempNameNode.getValue();
            if (tempString != null){
                myName = tempString;
            }
        }
        
        // The title of the layer
        Node tempTitleNode = inNode.getChild("Title");
        if (tempTitleNode != null){
            tempString = tempTitleNode.getValue();
            if (tempString != null){
                myTitle = tempString;
            }
        }
        
        /** The Abstract of the layer */
        Node tempAbstractNode = inNode.getChild("Abstract");
        if (tempAbstractNode != null){
            tempString = tempAbstractNode.getValue();
            if (tempString != null){
                myAbstract = tempString;
            }
        }
        
        /** The Keywords */
        Node tempKeywordNode = inNode.getChild("Keywords");
        if (tempKeywordNode != null){
            tempString = tempKeywordNode.getValue();
            if (tempString != null){
                myKeywords = tempString;
            }
        }
        
        /** The SRS */
        Node tempSRSNode = inNode.getChild("SRS");
        if (tempSRSNode != null){
            tempString = tempSRSNode.getValue();
            if (tempString != null){
                StringTokenizer st = new StringTokenizer(tempString);
                Vector tempVectSRS = new Vector();
                while (st.hasMoreElements()){
                    tempString = st.nextToken(" ").trim();
                    if (tempString.length() > 0) tempVectSRS.addElement(tempString);
                }
                myAvailableSRS = new String[tempVectSRS.size()];
                tempVectSRS.copyInto(myAvailableSRS);
            }
        }
        else if (inParent!= null){
            myAvailableSRS = inParent.getAvailableSRS();
        }
        else throw new Exception("Error parsing Layer, no valid Spatial Reference System (SRS) detected");
        
        /** the Valid Bounding Box in Lat Long (EPSG:4326)*/
        Node tempLatLonBoundingBoxNode = inNode.getChild("LatLonBoundingBox");
        if (tempLatLonBoundingBoxNode != null){
            String tempName = null;
            String tempValue = null;
            try{
                tempName = "MinX";
                tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                double tempMinX = Double.parseDouble(tempValue);
                tempName = "MaxX";
                tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                double tempMaxX = Double.parseDouble(tempValue);
                tempName = "MinY";
                tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                double tempMinY = Double.parseDouble(tempValue);
                tempName = "MaxY";
                tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                double tempMaxY = Double.parseDouble(tempValue);
                myBoundingBoxLatLong = new BoundingBox(tempMaxX, tempMaxY, tempMinX, tempMinY, "EPSG:4326");
            }
            catch (Exception e){
                throw new Exception("Error in Layer "+myName+" Reading "+tempName+" Value="+tempValue);
            }
        }
        else if(inParent != null){
            myBoundingBoxLatLong = inParent.getBoundingBoxLatLong();
        }
        else if (myName != null) throw new Exception("Error in Layer, no Valid Bounding Box Found");
        
        // Additional Bounding Boxes in the respective SRSs
        if (inParent != null){
            if (inParent.getBoundingBoxes() != null){
                myBoundingBoxSRS = inParent.getBoundingBoxes();
            }
        }
        Node[] tempNodes = inNode.getChildren("BoundingBox");
        for (int i=0; i<tempNodes.length; i++){
            tempString = tempNodes[i].getAttribute("SRS");
            if (tempString != null){
                String tempSRS = tempString.trim();
                
                // The Bounding Parameters
                String tempName = null;
                String tempValue = null;
                try{
                    tempName = "MinX";
                    tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                    double tempMinX = Double.parseDouble(tempValue);
                    tempName = "MaxX";
                    tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                    double tempMaxX = Double.parseDouble(tempValue);
                    tempName = "MinY";
                    tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                    double tempMinY = Double.parseDouble(tempValue);
                    tempName = "MaxY";
                    tempValue = tempLatLonBoundingBoxNode.getAttribute(tempName);
                    double tempMaxY = Double.parseDouble(tempValue);
                    BoundingBox tempBox = new BoundingBox(tempMaxX, tempMaxY, tempMinX, tempMinY, tempSRS);
                    add(tempBox);
                }
                catch (Exception e){
                    System.out.println("Error in Layer "+myName+" Reading "+tempName+" Value="+tempValue);
                }
            }
        }
        
        /** the Data URL */
        Node tempDataURLNode = inNode.getChild("DataURL");
        if (tempDataURLNode != null){
            tempString = tempDataURLNode.getValue();
            if (tempString != null) {
                myDataURL = tempString.trim();
            }
        }
        
        /** The Available Styles It is OK for there to be no styles, or styles with no names.*/
        tempNodes = inNode.getChildren("Style");
        Vector tempStyleVect = new Vector();
        for (int i=0; i<tempNodes.length; i++){
            
            /** The name of the Style*/
            Node tempStyleNameNode = tempNodes[i].getChild("Name");
            String tempName = "Default";
            if (tempStyleNameNode != null){
                tempString = tempStyleNameNode.getValue();
                if (tempString != null) tempName = tempString;
            }
            
            /** The Title of the Style*/
            Node tempStyleTitleNode = tempNodes[i].getChild("Title");
            String tempTitle = null;
            if (tempStyleTitleNode != null){
                tempTitle = tempStyleTitleNode.getValue();
            }
            
            /** The Style URL */
            Node tempStyleURLNode = tempNodes[i].getChild("StyleURL");
            String tempStyleURL = null;
            if (tempStyleURLNode != null){
                tempStyleURL = tempStyleURLNode.getValue();
            }
            
            // Create the Style
            Style tempStyle = new Style(tempName, tempTitle, tempStyleURL);
            tempStyleVect.addElement(tempStyle);
        }
        
        myStyles = new Style[tempStyleVect.size()];
        tempStyleVect.copyInto(myStyles);
        if ((myStyles.length == 0) && (inParent != null)){
            myStyles = inParent.getStyles();
        }
    }
    
    public String toString(){
        if (myTitle == null) return myName;
        return myTitle + "("+myName+")";
    }
}
