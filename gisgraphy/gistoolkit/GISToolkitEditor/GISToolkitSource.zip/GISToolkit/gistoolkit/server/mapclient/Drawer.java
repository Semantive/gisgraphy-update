/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.*;
/**
 * Interface to allow drawers to modify the picture that is displayed to the user.
 * @author  ithaqua
 */
public interface Drawer {
    /** Set the image panel in the drawer, so it can be affected */
    public void setImagePanel(ImagePanel inImagePanel);
    
    /** Draw the image on the screen */
    public void draw(Graphics inGraphics, Image inImage, int inWidth, int inHeight, ImageObserver inImageObserver);
}
