/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient;

/**
 * Represents a rectangular bounding box.  Typically it is used for the minimum
 * bounding rectangle for a particular geographic feature.
 */
public class Extents {
    public double myTopX;
    public double getTopX(){return myTopX;}
    public double myTopY;
    public double getTopY(){return myTopY;}
    public double myBottomX;
    public double getBottomX(){return myBottomX;}
    public double myBottomY;
    public double getBottomY(){return myBottomY;}
    
    /**
     * Create a new Extents with null values.
     */
    public Extents() {
        super();
    }
    
    /**
     * Create a new Extents with the given values.  The bottomX is the maximum X, and the Top X is the minimum X.
     */
    public Extents(double inTopX, double inTopY, double inBottomX, double inBottomY) {
        myTopX = inTopX;
        myTopY = inTopY;
        myBottomX = inBottomX;
        myBottomY = inBottomY;
    }
    
    /**
     * Create a copy of the bounds.
     * Creation date: (4/13/2001 4:53:50 PM)
     * @return features.Bounds
     */
    public Object clone() {
        return new Extents(myTopX, myTopY, myBottomX, myBottomY);
    }
            
    /**
     * The to string method for debugging.
     * Creation date: (4/13/2001 5:22:03 PM)
     * @return java.lang.String
     */
    public String toString() {
        return "TopX="+myTopX+" TopY="+myTopY+" BottomX="+ myBottomX+" BottomY="+myBottomY;
    }
    
    /**
     * Determines if the Extents sent in is within the current Extents.
     * Compares with equality, such that if the Extents sent in is the same as the current Extents,
     * then the result will be true.
     */
    public boolean contains(Extents inExtents) {
        if (inExtents == null)
            return false;
        
        // check the sides.
        if (inExtents.myTopX < myTopX)
            return false;
        if (inExtents.myTopY > myTopY)
            return false;
        if (inExtents.myBottomX > myBottomX)
            return false;
        if (inExtents.myBottomY < myBottomY)
            return false;
        return true;
    }
    
    /**
     * Returns the width of this extents
     */
    public double getWidth(){
        return Math.abs(myBottomX-myTopX);
    }

    /**
     * Returns the height of this extents
     */
    public double getHeight(){
        return Math.abs(myTopY-myBottomY);
    }
    
    /**
     * Translate the extents the given distance.
     */
    public void translate(double inXDistance, double inYDistance){
        myTopX = myTopX + inXDistance;
        myBottomX = myBottomX + inXDistance;
        myTopY = myTopY + inYDistance;
        myBottomY = myBottomY + inYDistance;
    }
       
}