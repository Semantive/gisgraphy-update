/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.command;

import java.io.*;
import javax.swing.*;
import gistoolkit.server.mapclient.*;
/**
 * A basic command to be sub classed for specific commands.
 */
public abstract class BasicCommand implements Command, Runnable{
    /** Holds a reference to this command's name */
    private String myCommandName = "";
    /** Used to retrieve the name of this command.*/
    public String getCommandName() {return myCommandName;}
    /** Used to set the name of the command. */
    public void setCommandName(String inCommandName){myCommandName = inCommandName;}
    
    /** Holds a reference to the Client so the command can affect it. */
    private Client myClient = null;
    /** Called before the execute command.*/
    public void setClient(Client inClient) { myClient = inClient;}
    /** Retrieve a reference to the client so it can be manipulated */
    public Client getClient(){return myClient;}
    
    /** Creates new BasicCommand */
    public BasicCommand(String inName) {
        super();
        setCommandName(inName);
    }
     
    /** Creates new BasicCommand */
    public BasicCommand(String inName, Client inClient) {
        super();
        setCommandName(inName);
        myClient = inClient;
    }
    /**
     * Show the exception to the user.
     */
    public void showException(Exception inException){
        String tempString = inException.getMessage();
        if (inException instanceof NullPointerException){
            try{
                ByteArrayOutputStream bout = new ByteArrayOutputStream();
                PrintStream ps = new PrintStream(bout);
                inException.printStackTrace(ps);
                ps.close();
                bout.close();
                tempString = new String(bout.toByteArray());
                tempString = "Null Pointer Exception\n"+tempString;
            }
            catch (Exception e){
                showError(e.getMessage());
            }
        }
        showError(tempString);
    }
    
    /**
     * Show the error to the user.
     */
    public void showError(String inString){
        if (inString == null) return;
        if (myClient instanceof java.awt.Component){
            JOptionPane.showMessageDialog( (java.awt.Component) getClient(), inString, "Error ", JOptionPane.ERROR_MESSAGE);               
        }
        else {
            System.out.println(inString);
        }
    }
    /**
     * Called when the command is executed.
     */
    public abstract void execute();
    
    /**
     * Called when the drawer completes
     */
    public void drawexecute(Drawer inDrawer){
        System.out.println("Executing");
        myDrawer = inDrawer;
        myThread = new Thread(this);
        myThread.start();
        System.out.println("Finished Starting Thread");
    }    
    
    /** Allows the execution of results within another thread */
    private Thread myThread = null;

    /** Stores the drawer that is sent in */
    private Drawer myDrawer = null;
    
    /** Run the draw execute command */
    public void run(){
        System.out.println("Running");
        doDrawExecute(myDrawer);
    }
    
    /** execute the drawe command. */
    public void doDrawExecute(Drawer InDrawer){}
}
