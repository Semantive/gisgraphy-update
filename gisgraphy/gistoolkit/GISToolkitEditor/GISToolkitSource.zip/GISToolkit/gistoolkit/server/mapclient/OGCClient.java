/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import gistoolkit.server.mapclient.images.*;
import gistoolkit.server.mapclient.command.*;
import gistoolkit.server.mapclient.wmsclient.*;

/**
 * The actual client part of the client.
 */
public class OGCClient extends JPanel implements Client, ComponentListener{
    // The Logo Panel
    private ImagePanel myLogoPanel;
    /** Set the logo to use in this applet. */
    public void setLogoImage(Image inImage){if (inImage != null) myLogoPanel.setImage(inImage);}
    
    // The ImagePanel
    private ImagePanel myImagePanel;
    /** Returns a reference to the image panel so the commands can access them. */
    public ImagePanel getImagePanel(){return myImagePanel;}
    
    /** The horrizontal location of the upper left hand corner in world coordinates.*/
    double myTopX = -126.57427796586376;
    /**Sets the horrizontal location of the upper left hand corner in world coordinates.*/
    public void setTopX(double inTopX){myTopX = inTopX;}
    /**Retrieves the horrizontal location of the upper left hand corner in world coordinates */
    public double getTopX(){return myTopX;}
    /** The vertical location of the upper left hand corner in world coordinates.*/
    double myTopY = 64.50671413250694;
    /**Sets the vertical location of the upper left hand corner in world coordinates.*/
    public void setTopY(double inTopY){myTopY = inTopY;}
    /**Retrieves the vertical location of the upper left hand corner in world coordinates */
    public double getTopY(){return myTopY;}
    /** The horrizontal location of the lower right hand corner in world coordinates.*/
    double myBottomX = -64.33109861795347;
    /**Sets the horrizontal location of the lower right hand corner in world coordinates.*/
    public void setBottomX(double inBottomX){myBottomX = inBottomX;}
    /**Retrieves the horrizontal location of the lower right hand corner in world coordinates */
    public double getBottomX(){return myBottomX;}
    /** The vertical location of the lower right hand corner in world coordinates.*/
    double myBottomY = 13.412;
    /**Sets the vertical location of the lower right hand corner in world coordinates.*/
    public void setBottomY(double inBottomY){myBottomY = inBottomY;}
    /**Retrieves the vertical location of the lower right hand corner in world coordinates */
    public double getBottomY(){return myBottomY;}
    
    /** The color to use when drawing highlights. */
    private Color myHighlightColor = new Color(0,255,0);
    /** Set the color to use when drawing highlights. */
    public void setHighlightColor(Color inColor){myHighlightColor = inColor;}
    /** The color to use when drawing shadows. */
    private Color myShadowColor = new Color(0, 50, 0);
    /** Set the color to use when drawing shadows. */
    public void setShadowColor(Color inColor){myShadowColor = inColor;}
    
    // Button Group to group the tools radio buttons
    private ButtonGroup myButtonGroup = new ButtonGroup();
    
    /** The client for access ing the web service.*/
    public WMSClient myClient = null;
    /** set the url used for connecting to the web service. */
    public void setWebServiceURL(String inURL){
        myClient.setURLBase(inURL);
    }
    
    
    /** Creates new OGCClient */
    public OGCClient() {
        setBackground(new Color(70,200,70));
        myClient = new WMSClient100();
        addComponentListener(this);
    }
    
    /** Initialize this applet with the controls needed for the accessing a map server. */
    public void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0;
        c.weighty = 0;
        c.gridwidth = 2;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.WEST;
        
        // There is the logo in the upper left hand corner of the screen.
        myLogoPanel = new ImagePanel();
        add(myLogoPanel, c);
        ImageSource tempImageSource = new ImageSource();
        myLogoPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, myHighlightColor, myShadowColor));
        myLogoPanel.setBackground(getBackground());
        myLogoPanel.setImage(tempImageSource.getImage("g.png"));
        
        // There is the image in the lower left hand corner of the screen.
        c.gridy++;
        c.gridx++;
        c.weightx = 1;
        c.weighty = 1;
        c.gridwidth = 1;
        c.fill = GridBagConstraints.BOTH;
        myImagePanel = new ImagePanel();
        myImagePanel.setBackground(getBackground());
        myImagePanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, myHighlightColor, myShadowColor));
        add(myImagePanel, c);
        
        // add a panel for the Buttons.
        JPanel tempButtonPanel = new JPanel(new GridBagLayout());
        tempButtonPanel.setBackground(getBackground());
        c.weightx = 0;
        c.weighty = 0;
        c.gridx = 0;
        add(tempButtonPanel, c);
        GridBagConstraints tempPanelConstraints = new GridBagConstraints();
        tempPanelConstraints.gridy = 0;
        tempPanelConstraints.weightx = 0;
        tempPanelConstraints.weighty = 0;
        tempPanelConstraints.fill = GridBagConstraints.BOTH;
        
        // the ZoomIn Button.
        tempPanelConstraints.gridy = 0;
        CommandRadioButton tempCommandRadioButton = new CommandRadioButton(new ZoomInCommand(this));
        tempButtonPanel.add(tempCommandRadioButton, tempPanelConstraints);
        tempCommandRadioButton.setIcon(tempImageSource.getIcon("ZoomInInactive.png"));
        tempCommandRadioButton.setSelectedIcon(tempImageSource.getIcon("ZoomInActive.png"));
        tempCommandRadioButton.setBackground(getBackground());
        tempCommandRadioButton.setBorder(null);
        myButtonGroup.add(tempCommandRadioButton);
        
        // the ZoomOut Button.
        tempPanelConstraints.gridy++;
        tempCommandRadioButton = new CommandRadioButton(new ZoomOutCommand(this));
        tempButtonPanel.add(tempCommandRadioButton, tempPanelConstraints);
        tempCommandRadioButton.setIcon(tempImageSource.getIcon("ZoomOutInactive.png"));
        tempCommandRadioButton.setSelectedIcon(tempImageSource.getIcon("ZoomOutActive.png"));
        tempCommandRadioButton.setBackground(getBackground());
        tempCommandRadioButton.setBorder(null);
        myButtonGroup.add(tempCommandRadioButton);
        
        // the Pan Button.
        tempPanelConstraints.gridy++;
        tempCommandRadioButton = new CommandRadioButton(new PanCommand(this));
        tempButtonPanel.add(tempCommandRadioButton, tempPanelConstraints);
        tempCommandRadioButton.setIcon(tempImageSource.getIcon("PanInactive.png"));
        tempCommandRadioButton.setSelectedIcon(tempImageSource.getIcon("PanActive.png"));
        tempCommandRadioButton.setBackground(getBackground());
        tempCommandRadioButton.setBorder(null);
        myButtonGroup.add(tempCommandRadioButton);
        
        // the Pallet Button.
        tempPanelConstraints.gridy++;
        CommandButton tempCommandButton = new CommandButton(new PalletCommand(this));
        tempButtonPanel.add(tempCommandButton, tempPanelConstraints);
        tempCommandButton.setIcon(tempImageSource.getIcon("PalletInactive.png"));
        tempCommandButton.setRolloverIcon(tempImageSource.getIcon("PalletActive.png"));
        tempCommandButton.setBackground(getBackground());
        tempCommandButton.setBorder(null);
        
        // fill up the remaining space.
        tempPanelConstraints.gridy++;
        tempPanelConstraints.weighty = 1;
        JPanel tempSpacePanel = new JPanel();
        tempSpacePanel.setBackground(getBackground());
        tempButtonPanel.add(tempSpacePanel, tempPanelConstraints);
    }
    
    /** List the layer dialog. */
    private LayerDialog myLayerDialog = new LayerDialog();
    /** Show the layer Dialog */
    public void showLayerDialog(){
        myLayerDialog.setLayers(myClient.getLayers(), myClient.getSelectedLayers());
        myLayerDialog.setModal(true);
        myLayerDialog.setLocationRelativeTo(this);
        myLayerDialog.show();
        if (myLayerDialog.isOK()){
            myClient.setSelectedLayers(myLayerDialog.getSelectedLayers());
            myClient.setSelectedMapFormat("PNG");
            refresh();
        }
    }
        
    /** Connect to the web service. */
    public void connect(){
        try{
            myClient.connect();
            myClient.setHeight(300);
            myClient.setWidth(300);
            showLayerDialog();
        }
        catch (Exception e){
            System.out.println(e);
            e.printStackTrace(System.out);
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /** Causes the client to requery the data source for a new image. */
    public void refresh(){
        try{
            if ((myImagePanel.getHeight() > 1) && (myImagePanel.getWidth() > 1)){
                myClient.setHeight(myImagePanel.getHeight());
                myClient.setWidth(myImagePanel.getWidth());
                Converter tempConverter = new Converter(
                    new Extents(0,0,myImagePanel.getWidth(), myImagePanel.getHeight()),
                    new Extents(myTopX, myTopY, myBottomX, myBottomY)
                );
                myImagePanel.setImage(myClient.read(tempConverter.getWorldExtents()));
            }
        }
        catch (Exception e){
            System.out.println(e);
            e.printStackTrace(System.out);
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void componentResized(java.awt.event.ComponentEvent componentEvent) {
    }
    
    public void componentMoved(java.awt.event.ComponentEvent componentEvent) {
    }
    
    public void componentShown(java.awt.event.ComponentEvent componentEvent) {
        refresh();
    }
    
    public void componentHidden(java.awt.event.ComponentEvent componentEvent) {
    }
    
}
