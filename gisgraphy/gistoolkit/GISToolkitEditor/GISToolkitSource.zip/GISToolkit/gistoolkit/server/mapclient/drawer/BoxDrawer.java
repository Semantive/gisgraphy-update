/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.drawer;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

/**
 * Draws a box on the screen.
 */
public class BoxDrawer extends BasicDrawer {
    
    /** The color to draw the box */
    private Color myColor = Color.red;
    /** Retrieves the color the box will be drawn */
    public Color getBoxColor(){return myColor;}
    /** Set the color to draw the box */
    public void setBoxColor(Color inColor){myColor = inColor;}
    
    /** Starting point of the drag */
    private Point myStartPoint = null;
    /** Retrieve the starting point of the drag in screen coordinates */
    public Point getStartPoint(){return myStartPoint;}
    
    /** Ending point of the drag */
    private Point myEndPoint = null;
    /** Retrieve the ending point of the drag in screen coordinates */
    public Point getEndPoint(){return myEndPoint;}
    
    /** Creates new BoxDrawer */
    public BoxDrawer() {
    }
    
    /** Draw the image on the screen  */
    public void draw(Graphics inGraphics, Image inImage, int inWidth, int inHeight, ImageObserver inImageObserver) {
        if (inGraphics == null) return;
        if (inImage == null) return;
        if ((myStartPoint != null) && (myEndPoint != null)){
            inGraphics.drawImage(inImage, 0, 0, inWidth, inHeight, getImagePanel());
            
            // order the points
            int tempminx = Math.min(myStartPoint.x, myEndPoint.x);
            int tempminy = Math.min(myStartPoint.y, myEndPoint.y);
            int tempmaxx = Math.max(myStartPoint.x, myEndPoint.x);
            int tempmaxy = Math.max(myStartPoint.y, myEndPoint.y);
            
            // save the color
            Color tempColor = inGraphics.getColor();
            inGraphics.setColor(myColor);
            
            // draw the box
            inGraphics.drawRect(tempminx, tempminy, tempmaxx-tempminx, tempmaxy-tempminy);
            
            // restore the color.
            inGraphics.setColor(tempColor);
        }
        else{
            inGraphics.drawImage(inImage, 0,0, inWidth, inHeight, getImagePanel());
        }
    }
    
    /** Reset the state of this draw model */
    public void reset(){
        myStartPoint = null;
        myEndPoint = null;
        draw();
    }
    
    /**
     * Called when the user releases the mouse button.
     */
    public void mouseDragged(MouseEvent e){
        myEndPoint = new java.awt.Point(e.getX(), e.getY());
        draw();
    }
    
    /**
     * Called when the user releases the mouse butotn.
     */
    public void mousePressed(MouseEvent e){
        
        myStartPoint = new java.awt.Point(e.getX(), e.getY());
        myEndPoint = myStartPoint;
    }
    
    /**
     * Called when the user releases the mouse butotn.
     */
    public void mouseReleased(MouseEvent e){
        if (getCommand() != null){
            getCommand().drawexecute(this);
            draw();
        }
    }
    
    /** Draw the image on the screen   */
    public void draw(Graphics inGraphics, Image inImage, ImageObserver inImageObserver) {
    }
    
}
