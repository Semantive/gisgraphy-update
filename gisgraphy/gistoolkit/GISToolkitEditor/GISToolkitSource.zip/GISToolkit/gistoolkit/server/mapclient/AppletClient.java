/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient;

import java.net.*;
import java.awt.*;
import javax.swing.*;

/**
 * A generic client for a web map service.
 */
public class AppletClient extends JApplet{
    /** Place to get the banner image. */
    private static String myBannerPageImageFileName = null;
    /** set the banner page image file name. */
    public void setBannerPageImageFileName(String inFileName){myBannerPageImageFileName = inFileName;}
    /** Get the banner page image file name. */
    public String getBannerPageImageFileName(){return myBannerPageImageFileName;}
    
    /** the currently accessable OGCClient. */
    private OGCClient myClient = null;
    
    /** Creates new AppletClient */
    public AppletClient() {
    }
    
    /** Initialize this applet with the controls needed for the accessing a map server. */
    public void init(){
        System.out.println("Initializing");
        OGCClient tempClient = new OGCClient();
        myClient = tempClient;
        tempClient.initPanel();
        setContentPane(tempClient);
        
        // look for the LOGOIMAGE parameter.
        String tempStringLogoImage = getParameter("LOGOIMAGE");
        Image tempLogoImage = null;
        if (tempStringLogoImage != null){
            try{
                URL tempURLLogoImage = new URL(tempStringLogoImage);
                tempLogoImage = Toolkit.getDefaultToolkit().getImage(tempURLLogoImage);
                if (tempLogoImage != null) tempClient.setLogoImage(tempLogoImage);
            }
            catch (Exception e){
                System.out.println("Error Parsing LOGOIMAGE Value="+tempStringLogoImage+" Must be an image file.");
            }
        }
        
        // look for the BAKCGROUNDCOLOR parameter.
        String tempStringColor = getParameter("BACKGROUNDCOLOR");
        if (tempStringColor != null){
            try{
                int tempInt = Integer.parseInt(tempStringColor, 16);
                Color tempColor = new Color(tempInt);
                tempClient.setBackground(tempColor);
            }
            catch (Exception e){
                System.out.println("Error Parsing BACKGROUNDCOLOR Value="+tempStringColor+" Must be a hexidecimal value of the form RRGGBB as in \"FFAABB\".");
            }
        }
        
        // look for the HIGHLIGHTCOLOR parameter.
        tempStringColor = getParameter("HIGHLIGHTCOLOR");
        if (tempStringColor != null){
            try{
                int tempInt = Integer.parseInt(tempStringColor, 16);
                Color tempColor = new Color(tempInt);
                tempClient.setHighlightColor(tempColor);
            }
            catch (Exception e){
                System.out.println("Error Parsing HIGHLIGHTCOLOR Value="+tempStringColor+" Must be a hexidecimal value of the form RRGGBB as in \"FFAABB\".");
            }
        }
        // look for the SHADOWCOLOR color parameter.
        tempStringColor = getParameter("SHADOWCOLOR");
        if (tempStringColor != null){
            try{
                int tempInt = Integer.parseInt(tempStringColor, 16);
                Color tempColor = new Color(tempInt);
                tempClient.setShadowColor(tempColor);
            }
            catch (Exception e){
                System.out.println("Error Parsing SHADOWCOLOR Value="+tempStringColor+" Must be a hexidecimal value of the form RRGGBB as in \"FFAABB\".");
            }
        }
        
        // look for the web service parameter
        String tempWebServiceURL = getParameter("WEBSERVICE");
        if (tempWebServiceURL == null){
            // ask the user for the url of the web service.
            boolean tempKeepAsking = true;
            tempWebServiceURL = JOptionPane.showInputDialog(this, "URL of the OGC Web Map Service?", "Web Map Service", JOptionPane.QUESTION_MESSAGE);
            while((tempKeepAsking)&&(tempWebServiceURL != null)){
                
                try{
                    URL tempURL = new URL(tempWebServiceURL);
                    break;
                }
                catch (MalformedURLException e){
                    tempWebServiceURL = JOptionPane.showInputDialog(this, "Bad URL: "+e.getMessage(), "Web Map Service", JOptionPane.QUESTION_MESSAGE);
                }
            }
        }
        if (tempWebServiceURL != null){
            tempClient.setWebServiceURL(tempWebServiceURL);
            tempClient.connect();
            myWaitThread.start();
        }
    }
    
    /** Thread for waiting 5 seconds and then refreshing the map on startup. */
    private class MyWaitThread extends Thread{
        public void run(){
            try{
                Thread.sleep(1000);
            }
            catch (InterruptedException e){
            }
            if (myClient != null){
                myClient.refresh();
                System.out.println("Refreshing the client.");
            }
        }
    }
    private MyWaitThread myWaitThread = new MyWaitThread();
}
