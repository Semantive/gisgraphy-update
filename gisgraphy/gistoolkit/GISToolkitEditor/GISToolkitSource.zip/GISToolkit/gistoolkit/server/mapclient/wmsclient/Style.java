/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.wmsclient;

/**
 * Holds information about the styles available for a web service.
 */
public class Style extends java.lang.Object {

    /** The name of the style */
    private String myName = null;
    /** Retrieve the name of the style */
    public String getName(){return myName;}
    
    /** The title of the Style */
    private String myTitle = null;
    /** Return the title of the style */
    public String getTitle(){return myTitle;}
    
    /** The URL of additional information about the Style */
    private String myStyleURL = null;
    /** Return the URL of additional information about the Style */
    public String getStyleURL(){return myStyleURL;}
    
    /** Creates new Style */
    public Style(String inName, String inTitle, String inStyleURL) {
        myName = inName;
        myTitle = inTitle;
        myStyleURL = inStyleURL;
    }
    
    /** returns the title of the style */
    public String toString(){
        return myTitle+"("+myName+")";
    }
}
