/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.command;

import java.awt.*;
import gistoolkit.server.mapclient.*;
import gistoolkit.server.mapclient.drawer.*;
/**
 * Tells the image panel to zoom in.
 */
public class ZoomInCommand extends BasicCommand{

    /** Creates new ZoomInCommand */
    public ZoomInCommand(Client inClient) {
        super("Zoom In", inClient);
    }
    
    /**
     * Called when the command is executed.
     */
    public void execute() {
        BoxDrawer tempDrawer = new BoxDrawer();
        tempDrawer.setCommand(this);
        getClient().getImagePanel().setDrawer(tempDrawer);
        tempDrawer.setImagePanel(getClient().getImagePanel());
    }
    
    /**
     * Called when the drawer completes
     */
    public void doDrawExecute(Drawer inDrawer) {
        // update the world coordinates.
        if (inDrawer instanceof BoxDrawer){
            Point tempStartPoint = ((BoxDrawer) inDrawer).getStartPoint();
            Point tempEndPoint = ((BoxDrawer) inDrawer).getEndPoint();
            Client c = getClient();
            ImagePanel tempImagePanel = c.getImagePanel();
            
            // if neither the start or end are null, then calculate the world zoom
            if ((tempStartPoint != null) && (tempEndPoint != null)){
                if ((Math.abs(tempStartPoint.x - tempEndPoint.x) > 6) && (Math.abs(tempStartPoint.y-tempEndPoint.y) > 6)){
                    Converter tempConverter = new Converter(tempImagePanel.getWidth(), tempImagePanel.getHeight(), c.getTopX(), c.getTopY(), c.getBottomX(), c.getBottomY());

                    double tx = tempConverter.toWorldX(tempStartPoint.x);
                    double ty = tempConverter.toWorldY(tempStartPoint.y);
                    double bx = tempConverter.toWorldX(tempEndPoint.x);
                    double by = tempConverter.toWorldY(tempEndPoint.y);

                    c.setTopX(Math.min(tx,bx));
                    c.setBottomX(Math.max(tx,bx));
                    c.setTopY(Math.max(ty,by));
                    c.setBottomY(Math.min(ty,by));
                    c.refresh();
                }
                else{
                    // convert the point to world coordinates
                    Converter tempConverter = new Converter(tempImagePanel.getWidth(), tempImagePanel.getHeight(), c.getTopX(), c.getTopY(), c.getBottomX(), c.getBottomY());
                    double cx = tempConverter.toWorldX(tempStartPoint.x);
                    double cy = tempConverter.toWorldY(tempStartPoint.y);

                    // center the map around this point and zoom in
                    double dx = c.getBottomX()-c.getTopX();
                    double dy = c.getTopY()-c.getBottomY();
                    c.setTopX(cx-dx/4);
                    c.setBottomX(cx+dx/4);
                    c.setTopY(cy+dy/4);
                    c.setBottomY(cy-dy/4);
                    c.refresh();
                }
                ((BoxDrawer) inDrawer).reset();
            }
        }
    }
}
