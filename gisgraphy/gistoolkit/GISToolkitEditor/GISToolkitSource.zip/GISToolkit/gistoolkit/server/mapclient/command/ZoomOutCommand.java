/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package gistoolkit.server.mapclient.command;

import java.awt.*;
import gistoolkit.server.mapclient.*;
import gistoolkit.server.mapclient.drawer.*;
/**
 * Class to handle zooming out.
 */
public class ZoomOutCommand extends BasicCommand {

    /** Creates new ZoomOutCommand */
    public ZoomOutCommand(Client inClient) {
        super("Zoom Out", inClient);
    }
        
    /**
     * Called when the command is executed.
     */
    public void execute() {
        BoxDrawer tempDrawer = new BoxDrawer();
        tempDrawer.setCommand(this);
        getClient().getImagePanel().setDrawer(tempDrawer);
        tempDrawer.setImagePanel(getClient().getImagePanel());
    }
    
    /**
     * Called when the drawer completes
     */
    public void doDrawExecute(Drawer inDrawer) {
        // update the world coordinates.
        if (inDrawer instanceof BoxDrawer){
            Point tempStartPoint = ((BoxDrawer) inDrawer).getStartPoint();
            Point tempEndPoint = ((BoxDrawer) inDrawer).getEndPoint();
            Client c = getClient();
            ImagePanel tempImagePanel = c.getImagePanel();
            
            // if neither the start or end are null, then calculate the world zoom
            if ((tempStartPoint != null) && (tempEndPoint != null)){
                if ((Math.abs(tempStartPoint.x - tempEndPoint.x) > 6) && (Math.abs(tempStartPoint.y-tempEndPoint.y) > 6)){
                    Converter tempConverter = new Converter(tempImagePanel.getWidth(), tempImagePanel.getHeight(), c.getTopX(), c.getTopY(), c.getBottomX(), c.getBottomY());

                    double tx = tempConverter.toWorldX(tempStartPoint.x);
                    double ty = tempConverter.toWorldY(tempStartPoint.y);
                    double bx = tempConverter.toWorldX(tempEndPoint.x);
                    double by = tempConverter.toWorldY(tempEndPoint.y);
                    
                    // coordinates of the drawn square.
                    double stx = Math.min(tx,bx);
                    double sty = Math.max(ty,by);
                    double sbx = Math.max(tx,bx);
                    double sby = Math.min(ty,by);
                    
                    // calculate the width of the drawn square
                    double dsx = stx-sbx;
                    double dsy = sty-sby;
                    
                    // calculate the center of the drawn square
                    double csx = ((stx-sbx)/2+sbx);
                    double csy = ((sty-sby)/2+sby);

                    // coordinates of the world
                    double wtx = c.getTopX();
                    double wty = c.getTopY();
                    double wbx = c.getBottomX();
                    double wby = c.getBottomY();
                    
                    // calculate the width of the world
                    double dwx = wtx - wbx;
                    double dwy = wty - wby;
                    
                    // calculate the center of the current world
                    double cwx = ((dwx)/2+wbx);
                    double cwy = ((wty-wby)/2+wby);                    
                                        
                    // Calculate the width and height in world coordinates of the new viewable region
                    double dnx = ((dwx)*(dwx))/(dsx);
                    double dny = ((dwy)*(dwy))/(dsy);
                                        
                    // calculate the left and top edges of the new world square
                    double lnx = cwx-dnx*((csx-wtx)/(dwx));
                    double tny = cwy-dny*((csy-wty)/(dwy));

                    // set the sides of the world.
                    c.setTopX(lnx);
                    c.setBottomX(lnx-dnx);
                    c.setTopY(tny);
                    c.setBottomY(tny-dny);
                    c.refresh();
                }
                else{
                    // convert the point to world coordinates
                    Converter tempConverter = new Converter(tempImagePanel.getWidth(), tempImagePanel.getHeight(), c.getTopX(), c.getTopY(), c.getBottomX(), c.getBottomY());
                    double cx = tempConverter.toWorldX(tempStartPoint.x);
                    double cy = tempConverter.toWorldY(tempStartPoint.y);

                    // center the map around this point and zoom in
                    double dx = c.getBottomX()-c.getTopX();
                    double dy = c.getTopY()-c.getBottomY();
                    c.setTopX(cx-dx);
                    c.setBottomX(cx+dx);
                    c.setTopY(cy+dy);
                    c.setBottomY(cy-dy);
                    c.refresh();
                }
                ((BoxDrawer) inDrawer).reset();                
            }
        }
    }
}
