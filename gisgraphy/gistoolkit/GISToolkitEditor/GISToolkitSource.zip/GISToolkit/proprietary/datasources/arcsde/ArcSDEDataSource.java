/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package proprietary.datasources.arcsde;

import java.util.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;
import com.esri.sde.sdk.client.*;
/**
 * Retrieves data from an ArcSDEDataSource.
 * @author  ithaqua
 * @version
 */
public class ArcSDEDataSource extends SimpleDBDataSource {
    
    /** Creates new ArcSDEDataSource */
    public ArcSDEDataSource() {
        setName("ARCSDE Datasource");
    }
    
    /** The computer name of the server where the SDE processes is running */
    private String myServername = "Localhost";
    /** Set the name of the server where the SDE processes is running */
    public void setServername(String inServername){myServername = inServername;}
    /** Retrieve the name of the server where the SDE process is running */
    public String getServername(){return myServername;}
    
    /** The port number on which the server is listening */
    private int myPortNumber = 5151; // the default for the SDE services.
    /** Set the port number where the ARCSDE service is listening */
    public void setPortNumber(int inPortNumber){myPortNumber = inPortNumber;}
    /** Retrieve the port number where the ARCSDE service is listening */
    public int getPortNumber(){return myPortNumber;}
    
    /** The name of the database to connect with, this parameter is optional*/
    private String myDatabaseName = "SDE";
    /** Set the name of the database with which to connect.*/
    public void setDatabaseName(String inDatabaseName){myDatabaseName = inDatabaseName;}
    /** Retrieve the name of the database with which to connect */
    public String getDatabaseName(){return myDatabaseName;}
    
    /** The table name this datasource is to draw it's data from */
    private String myTableName = "SDE";
    /** Set the name of the table where the data for this data source is stored */
    public void setTableName(String inTableName){myTableName = inTableName;}
    /** Retrieve the name of the table where the data for this data source is stored */
    public String getTableName(){return myTableName;}
    
    /** The username of the user to verify for connection to the database.  This information is for security purposes only. */
    private String myUsername = "SDE";
    /** Set the username to use when verifying the connection to the database */
    public void setUsername(String inUsername){myUsername = inUsername;}
    /** Retrieve the username to use when connecting to the SDE database */
    public String getUsername(){return myUsername;}
    
    /** The password to use to verify the connection to the database.  This information is used for security purposes only.*/
    private String myPassword = "SDE";
    /** Set the password of the user to verify for connection to the database */
    public void setPassword(String inPassword){myPassword = inPassword;}
    /** Retrieve the password of the user to use for verification when connecting to the database */
    public String getPassword(){return myPassword;}
    
    /** The ESRI envelope method is broken as far as I can tell, if you can get it to work, feel free */
    private double myMinX = Double.MAX_VALUE;
    /** Set the minimum X value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public void setMinX(double inMinX){myMinX = inMinX;}
    /** Get the minimum X value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public double getMinX(){return myMinX;}
    /** The ESRI envelope method is broken as far as I can tell, if you can get it to work, feel free */
    private double myMaxX = Double.MIN_VALUE;
    /** Set the maximum X value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public void setMaxX(double inMaxX){myMaxX = inMaxX;}
    /** Get the maximum X value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public double getMaxX(){return myMaxX;}
    /** The ESRI envelope method is broken as far as I can tell, if you can get it to work, feel free */
    private double myMinY = Double.MAX_VALUE;
    /** Set the minimum Y value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public void setMinY(double inMinY){myMinY = inMinY;}
    /** Get the minimum X value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public double getMinY(){return myMinY;}
    /** The ESRI envelope method is broken as far as I can tell, if you can get it to work, feel free */
    private double myMaxY = Double.MIN_VALUE;
    /** Set the maximum X value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public void setMaxY(double inMaxY){myMaxY = inMaxY;}
    /** Get the maximum Y value to be sent to the database.  This is to avoid the problems with the ESRI envelope methods */
    public double getMaxY(){return myMaxY;}
    
    /** Connect to the datasource to ensure that it is operational */
    public void connect() throws Exception{
        // connect to the database
        System.out.println("ARCSDEDatasource Connecting to the ArcSDE Server...");
        SeConnection conn = new SeConnection( myServername, myPortNumber, myDatabaseName, myUsername, myPassword );
//        System.out.println("ARCSDEDatasource Connection Successful! \n");
        Vector layerList = conn.getLayers();
        myTableName = myTableName.toUpperCase();
        for(int i=0;i<layerList.size(); i++) {
            SeLayer tmpLayer = (SeLayer) layerList.elementAt(i);
            if(tmpLayer.getQualifiedName().equals(myTableName))
                break;
            if(tmpLayer.getName().equals(myTableName)) {
                myTableName = tmpLayer.getQualifiedName();
                break;
            }
        }
        setName(myTableName);
    }
    
    /**Returns the bounding rectangle of all the shapes in the Data Source.*/
    public Envelope readEnvelope() throws Exception{
        return new Envelope(myMinX, myMaxY, myMaxX, myMinY);
    }
        
    /**
     * Reads all the objects from the shape file, and populates the layer with them.
     */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception {
        try{
            // connect to the SDE datasource
            System.out.println("ARCSDEDatasource.readShapes: Connecting to the ArcSDE Server...");
            SeConnection conn = new SeConnection( myServername, myPortNumber, myDatabaseName, myUsername, myPassword );
            System.out.println("ARCSDEDatasource Connection Successful! \n");
            
            // get the description of the table
            SeTable tempTable = new SeTable(conn, myTableName);
            SeColumnDefinition[] tempColumnDefs = tempTable.describe();
            String[] tempColumnNames = new String[tempColumnDefs.length];
            String tempSpatialColumnName = "Shape";
            //   Store the names of all the table's columns in the
            //   String array cols. This array specifies the columns
            //   to be retrieved from the database.
            for( int i = 0 ; i < tempColumnNames.length ; i++ ) {
                tempColumnNames[i] = tempColumnDefs[i].getName();
                if (tempColumnDefs[i].getType() == SeColumnDefinition.TYPE_SHAPE){
                    tempSpatialColumnName = tempColumnNames[i];
                }
            }
            SeLayer tempLayer = new SeLayer(conn, myTableName, tempSpatialColumnName);
            
            // query the data from the database.
            SeSqlConstruct tempSQLConstruct = new SeSqlConstruct(myTableName);
            String tempFilterSQL = getFilterSQL();
            if ((tempFilterSQL != null) && (tempFilterSQL.length() > 0)){
                tempSQLConstruct.setWhere(getFilterSQL());
            }
            SeQuery tempQuery = new SeQuery( conn, tempColumnNames, tempSQLConstruct );
            tempQuery.prepareQuery();
            
            // construct the bounds.
            if (inEnvelope != null){
                Point tempTopLeft = new Point(inEnvelope.getMinX(), inEnvelope.getMaxY());
                Point tempTopRight = new Point(inEnvelope.getMaxX(), inEnvelope.getMaxY());
                Point tempBottomLeft = new Point(inEnvelope.getMinX(), inEnvelope.getMinY());
                Point tempBottomRight = new Point(inEnvelope.getMaxX(), inEnvelope.getMinY());

                // ensure that the points are not out of bounds.
                SeExtent tempEnvelope = tempLayer.getCoordRef().getXYEnvelope();
                /*
                checkPoint(tempTopLeft, tempEnvelope);
                checkPoint(tempTopRight, tempEnvelope);
                checkPoint(tempBottomLeft, tempEnvelope);
                checkPoint(tempBottomRight, tempEnvelope);
                */
                
                // convert the points to SePoints
                SDEPoint[] tempSDEPoints = new SDEPoint[5];
                tempSDEPoints[0] = new SDEPoint(tempTopLeft.getX(), tempTopLeft.getY());
                tempSDEPoints[1] = new SDEPoint(tempTopRight.getX(), tempTopRight.getY());
                tempSDEPoints[2] = new SDEPoint(tempBottomRight.getX(), tempBottomRight.getY());
                tempSDEPoints[3] = new SDEPoint(tempBottomLeft.getX(), tempBottomRight.getY());
                tempSDEPoints[4] = new SDEPoint(tempTopLeft.getX(), tempTopLeft.getY());
                
                // create the filter for the query.
                SeShape shape = new SeShape(tempLayer.getCoordRef());
                SeExtent extent = new SeExtent( inEnvelope.getMinX(),inEnvelope.getMinY(),inEnvelope.getMaxX(),inEnvelope.getMaxY());
                //shape.generateRectangle(extent);
                
                int[] tempOffsets = new int[1];
                tempOffsets[0] = 0;
                shape.generatePolygon(5,1,tempOffsets, tempSDEPoints);
                SeShape[] shapes = new SeShape[1];
                shapes[0] = shape;
                SeShapeFilter filters[] = new SeShapeFilter[shapes.length];
                SeShapeFilter filter = null;
                for( int i = 0 ; i < shapes.length ; i++ ) {
                    filter = new SeShapeFilter( myTableName, tempSpatialColumnName, shapes[i], SeFilter.METHOD_AI_OR_ET);
                    filters[i] = filter;
                }
                
                // set the spatial constraints if there are any.
                tempQuery.setSpatialConstraints(SeQuery.SE_OPTIMIZE, false, filters);
            }
            
            // execute the query.
            tempQuery.execute();
            
            // retrieve the information
            SeRow tempRow = null;
            SeColumnDefinition colDef = new SeColumnDefinition();
            
            // Fetch the first row that matches the query.
            tempRow = tempQuery.fetch();
            if( tempRow == null ) {
                System.out.println("ARCSDEDatasource  No rows fetched");
                return new GISDataset(tempColumnNames);
            }

            int max = tempRow.getNumColumns();
            System.out.println("ARCSDEDatasource "+max+" columns fetched");
            
            // read the column name information
            String[] tempAttributeNames = null;
            AttributeType[] tempAttributeTypes = null;
            {
                Vector tempColumnNameVect = new Vector();
                Vector tempAttributeTypeVect = new Vector();
                for( int i=0; i<max; i++){
                    colDef = tempRow.getColumnDef(i);
                    if (colDef.getType() != SeColumnDefinition.TYPE_SHAPE){
                        AttributeType tempAttributeType = null;
                        int tempSize = colDef.getSize();
                        if (tempSize == 0) tempSize = -1;
                        switch( colDef.getType() ) {
                            case SeColumnDefinition.TYPE_SMALLINT:
                                tempAttributeType = new AttributeType(AttributeType.INTEGER, tempSize);
                                break;
                            case SeColumnDefinition.TYPE_DATE:
                                tempAttributeType = new AttributeType(AttributeType.TIMESTAMP, tempSize);
                                break;
                            case SeColumnDefinition.TYPE_INTEGER:
                                tempAttributeType = new AttributeType(AttributeType.INTEGER, tempSize);
                                break;
                            case SeColumnDefinition.TYPE_FLOAT:
                                tempAttributeType = new AttributeType(AttributeType.FLOAT, tempSize);
                                break;
                            case SeColumnDefinition.TYPE_DOUBLE:
                                tempAttributeType = new AttributeType(AttributeType.FLOAT, tempSize);
                                break;
                            case SeColumnDefinition.TYPE_STRING:
                                tempAttributeType = new AttributeType(AttributeType.STRING, tempSize);
                                break;
                        } // End switch
                        tempColumnNameVect.addElement(colDef.getName());
                        tempAttributeTypeVect.addElement(tempAttributeType);
                    }
                }
                tempAttributeNames = new String[tempColumnNameVect.size()];
                tempColumnNameVect.copyInto(tempAttributeNames);
                tempAttributeTypes = new AttributeType[tempAttributeTypeVect.size()];
                tempAttributeTypeVect.copyInto(tempAttributeTypes);
            }
            
            // loop through all the rows, reading the attribute data
            GISDataset tempDataset = new GISDataset(tempAttributeNames,tempAttributeTypes);
            while( tempRow != null ) {
                
                // read the non spatial information
                Object tempAttributes[] = new Object[tempAttributeNames.length];
                Shape tempShape = null;
                for( int i=0 ; i < tempAttributes.length ; i++ ) {
                    colDef = tempRow.getColumnDef(i);
                    int type = colDef.getType();
                    // don't try to retrieve the value if the indicator is NULL
                    if ( tempRow.getIndicator((short)i) != SeRow.SE_IS_NULL_VALUE) {
                        switch( type ) {
                            case SeColumnDefinition.TYPE_SMALLINT:
                                tempAttributes[i] = tempRow.getShort(i);
                                break;
                            case SeColumnDefinition.TYPE_DATE:
                                tempAttributes[i] = tempRow.getDate(i);
                                break;
                            case SeColumnDefinition.TYPE_INTEGER:
                                tempAttributes[i] = tempRow.getInteger(i);
                                break;
                            case SeColumnDefinition.TYPE_FLOAT:
                                tempAttributes[i] = tempRow.getFloat(i);
                                break;
                            case SeColumnDefinition.TYPE_DOUBLE:
                                tempAttributes[i] = tempRow.getDouble(i);
                                break;
                            case SeColumnDefinition.TYPE_STRING:
                                tempAttributes[i] = tempRow.getString(i);
                                break;
                            case SeColumnDefinition.TYPE_SHAPE:
                                // retrieve the shape
                                SeShape spVal = (SeShape)tempRow.getShape(i);
                                tempShape = parseShape(spVal);
                                break;
                        } // End switch
                    }
                }
                // create the record
                tempDataset.add(tempAttributes, tempShape);
                fireRead(tempDataset.getRecord(tempDataset.size()-1));
                
                // Fetch the next row that matches the query.
                tempRow = tempQuery.fetch();
            } // End while
            tempQuery.close();
            return tempDataset;
        }
        catch ( SeException e ) {
            System.out.println(e.getSeError().getErrDesc() );
            System.out.println(e);
            e.printStackTrace();
        }
        return new GISDataset();
    }
            
    /**
     * Initialize the data source from the properties.
     */
    public void load(Properties inProperties) {
    }
        
    
    /** Parse the shape from the ESRI representation into the internal representation */
    private Shape parseShape(SeShape inSeShape) throws Exception{
        if (inSeShape == null) return null;
        SeShape shape = inSeShape;
        Shape tempShape = null;
        double points[][][] = inSeShape.getAllCoords();
        int numParts = inSeShape.getNumParts();
        
        // Retrieve the shape type.
        int type = -1;
        type = inSeShape.getType();
        switch( type ) {
            case SeShape.TYPE_LINE:
                // this is a line, create a line
                if (numParts > 0){
                    Point[] tempPoints = new Point[points[0][0].length/2];
                    for (int i=0; i<tempPoints.length; i++){
                        tempPoints[i] = new Point(points[0][0][(i*2)], points[0][0][(i*2)+1]);
                    }
                    tempShape = new LineString(tempPoints);
                }
                break;
            case SeShape.TYPE_MULTI_LINE:
                // this is a multi line
                if (numParts > 0){
                    LineString[] tempLineStrings = new LineString[numParts];
                    for (int i=0; i<numParts; i++){
                        
                        Point[] tempPoints = new Point[points[i][0].length/2];
                        for (int j=0; j<tempPoints.length; j++){
                            tempPoints[j] = new Point(points[i][0][(j*2)], points[i][0][(j*2)+1]);
                        }
                        tempLineStrings[i] = new LineString(tempPoints);
                    }
                    tempShape = new MultiLineString(tempLineStrings);
                }
                break;
            case SeShape.TYPE_MULTI_POINT:
                if (numParts > 0){
                    Point[] tempPoints = new Point[points[0][0].length/2];
                    for (int i=0; i<points[0][0].length; i=i+2){
                        tempPoints[i] = new Point(points[0][0][i], points[0][0][i+1]);
                    }
                    tempShape = new MultiPoint(tempPoints);
                }
                break;
            case SeShape.TYPE_MULTI_POLYGON:
                // this is a multi line
                if (numParts > 0){
                    Polygon[] tempPolygons = new Polygon[numParts];
                    for (int i=0; i<numParts; i++){
                        int numSubParts  = shape.getNumSubParts(i+1);
                        LinearRing tempPosShape = null;
                        Vector tempHoleVect = new Vector();
                        for (int j=0; j<numSubParts; j++){
                            int numCoords = shape.getNumPoints(i+1, j+1);
                            Point[] tempPoints = new Point[numCoords];
                            for (int k=0; k<numCoords; k++){
                                tempPoints[k] = new Point(points[i][j][k*2], points[i][j][(k*2+1)] );
                            }
                            if (j==0) tempPosShape = new LinearRing(tempPoints);
                            else tempHoleVect.addElement(new LinearRing(tempPoints));
                        }
                        LinearRing[] tempHoles = new LinearRing[tempHoleVect.size()];
                        tempHoleVect.copyInto(tempHoles);
                        tempPolygons[i] = new Polygon(tempPosShape, tempHoles);
                    }
                    tempShape = new MultiPolygon(tempPolygons);
                }
                break;
            case SeShape.TYPE_MULTI_SIMPLE_LINE:
                // this is a multi line
                if (numParts > 0){
                    Vector tempVectLineStrings = new Vector();
                    for (int i=0; i<numParts; i++){
                        int numSubParts  = shape.getNumSubParts(i+1);
                        
                        for (int j=0; j<numSubParts; j++){
                            int numCoords = shape.getNumPoints(i+1, j+1);
                            Point[] tempPoints = new Point[numCoords];
                            for (int k=0; k<numCoords; k++){
                                tempPoints[k] = new Point(points[i][j][k*2], points[i][j][(k*2+1)] );
                            }
                            tempVectLineStrings.addElement(new LineString(tempPoints));
                        }
                    }
                    LineString[] tempLineStrings = new LineString[tempVectLineStrings.size()];
                    tempVectLineStrings.copyInto(tempLineStrings);
                    tempShape = new MultiLineString(tempLineStrings);
                }
                break;
            case SeShape.TYPE_NIL:
                tempShape = null;
                break;
            case SeShape.TYPE_POINT:
                if (numParts > 0){
                    tempShape = new Point(points[0][0][0], points[0][0][1]);
                }
                break;
            case SeShape.TYPE_POLYGON:
                if (numParts > 0){
                    Polygon tempPolygon = new Polygon();
                    LinearRing tempPosShape = null;
                    Vector tempHoleVect = new Vector();
                    for (int i=0; i<points[0].length; i++){
                        Point[] tempPoints = new Point[points[0][i].length/2];
                        for (int j=0; j<points[0][i].length/2; j++){
                            tempPoints[j] = new Point(points[0][i][j*2], points[0][i][j*2+1]);
                        }
                        if (tempPosShape == null) tempPosShape = new LinearRing(tempPoints);
                        else{
                            tempHoleVect.addElement(new LinearRing(tempPoints));
                        }
                    }
                    
                    LinearRing[] tempHoles = new LinearRing[tempHoleVect.size()];
                    tempHoleVect.copyInto(tempHoles);
                    tempShape = new Polygon(tempPosShape, tempHoles);
                }
                break;
            case SeShape.TYPE_SIMPLE_LINE:
                if (numParts > 0){
                    Point[] tempPoints = new Point[points[0][0].length/2];
                    for (int i=0; i<tempPoints.length; i++){
                        tempPoints[i] = new Point(points[0][0][i*2], points[0][0][i*2+1]);
                    }
                    tempShape = new LineString(tempPoints);
                }
                break;
        }
        return tempShape;
    }
    
    /** check the point to ensure that it does not violate the Envelope */
    private void checkPoint(Point inPoint, SeExtent inSeEnvelope){
        System.out.println("X="+inPoint.getX()+" Y="+inPoint.getY());
        System.out.println("MinX="+myMinX+" MaxX="+myMaxX+" MinY="+myMinY+" MaxY="+myMaxY);
        if (myMinX > inPoint.getX()) inPoint.setX(myMinX);
        if (myMaxX < inPoint.getX()) inPoint.setX(myMaxX);
        if (myMinY > inPoint.getY()) inPoint.setY(myMinY);
        if (myMaxY < inPoint.getY()) inPoint.setY(myMaxY);
        //if (inSeEnvelope.getMinX() > inPoint.getX()) inPoint.setX(inSeEnvelope.getMinX());
        //if (inSeEnvelope.getMaxX() < inPoint.getX()) inPoint.setX(inSeEnvelope.getMaxX());
        //if (inSeEnvelope.getMinY() > inPoint.getY()) inPoint.setY(inSeEnvelope.getMinY());
        //if (inSeEnvelope.getMaxY() < inPoint.getY()) inPoint.setY(inSeEnvelope.getMaxY());
    }
        
    private static final String MAX_X = "MaxX";
    private static final String MIN_X = "MinX";
    private static final String MAX_Y = "MaxY";
    private static final String MIN_Y = "MinY";
    private static final String SERVER_NAME = "Servername";
    private static final String PORT_NUMBER = "PortNumber";
    private static final String USERNAME = "Username";
    private static final String PASSWORD = "Password";
    private static final String DATABASE_NAME = "DatabaseName";
    private static final String TABLE_NAME = "TableName";

    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("ARCSDEDataSource");        
        
        // the bounding box.
        tempRoot.addAttribute(MAX_X, ""+myMaxX);
        tempRoot.addAttribute(MAX_Y, ""+myMaxY);
        tempRoot.addAttribute(MIN_X, ""+myMinX);
        tempRoot.addAttribute(MIN_Y, ""+myMinY);
        
        // connection parameters
        tempRoot.addAttribute(SERVER_NAME, getServername());
        tempRoot.addAttribute(PORT_NUMBER, ""+getPortNumber());
        tempRoot.addAttribute(USERNAME, getUsername());
        tempRoot.addAttribute(PASSWORD, getPassword());
        tempRoot.addAttribute(DATABASE_NAME, getDatabaseName());
        tempRoot.addAttribute(TABLE_NAME, getTableName());
        
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        if (inNode == null) throw new Exception("Can not set up ArcSDEDataSource configuration information is null");
        super.setNode(inNode);
        String tempName = null;
        String tempValue = null;
        try{
            // bounding box
            tempName = MAX_X;
            tempValue = inNode.getAttribute(tempName);
            myMaxX = Double.parseDouble(tempValue);
            tempName = MAX_Y;
            tempValue = inNode.getAttribute(tempName);
            myMaxY = Double.parseDouble(tempValue);
            tempName = MIN_X;
            tempValue = inNode.getAttribute(tempName);
            myMinX = Double.parseDouble(tempValue);
            tempName = MIN_Y;
            tempValue = inNode.getAttribute(tempName);
            myMinY = Double.parseDouble(tempValue);
            
            // connection parameters
            tempName = SERVER_NAME;
            tempValue = inNode.getAttribute(tempName);
            myServername = tempValue;
            tempName = PORT_NUMBER;
            tempValue = inNode.getAttribute(tempName);
            myPortNumber = Integer.parseInt(tempValue);
            tempName = USERNAME;
            tempValue = inNode.getAttribute(tempName);
            myUsername = tempValue;
            tempName = PASSWORD;
            tempValue = inNode.getAttribute(tempName);
            myPassword = tempValue;
            tempName = DATABASE_NAME;
            tempValue = inNode.getAttribute(tempName);
            myDatabaseName = tempValue;
            tempName = TABLE_NAME;
            tempValue = inNode.getAttribute(tempName);
            myTableName = tempValue;
        }
        catch (Exception e){
            throw new Exception ("Can not read value for "+tempName+" to configure "+getName()+ " Arc SDE Datasource");
        }
        connect();
    }    
    public static void main(String[] arg) {
        try {
            ArcSDEDataSource sdeDS = new ArcSDEDataSource();
            sdeDS.setServername("Kurdy");
            sdeDS.setPortNumber(5151);
            sdeDS.setUsername("pch");
            sdeDS.setPassword("pch1");
            sdeDS.setTableName("res_routier");
            sdeDS.connect();
            sdeDS.readDataset(new Envelope(80000,80000,71000,71000));
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        System.out.println("...finished");
    }
    
    /** Get the style to use with this datasource.  */
    public gistoolkit.display.Style getStyle() {
        return null;
    }
}
