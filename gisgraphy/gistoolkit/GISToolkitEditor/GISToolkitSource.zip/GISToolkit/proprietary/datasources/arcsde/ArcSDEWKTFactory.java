/*
 * WKTFactory.java
 *
 * Created on January 9, 2002, 8:52 PM
 */
package proprietary.datasources.arcsde;
import java.util.*;
//import gistoolkit.features.*;
import com.esri.sde.sdk.client.*;
/**
 * Class for converting Well Known Text(WKT) representations of a shape into their Shape counterparts.
 * @author  schullto
 */
public class ArcSDEWKTFactory {
    /** Creates new WKTFactory */
    public ArcSDEWKTFactory() {
    }
    /** Retrieve the shape from the text string */
    public static SeShape parseShape(SeCoordinateReference coordRef,String inWKT) throws Exception{
        if (inWKT == null) return null;
        if (inWKT.startsWith("POINT")) return parsePoint(coordRef,inWKT);
        if (inWKT.startsWith("LINESTRING")) return parseLineString(coordRef,inWKT);
        if (inWKT.startsWith("POLYGON")) return parsePolygon(coordRef,inWKT);
        if (inWKT.startsWith("MULTIPOINT")) return parseMultiPoint(coordRef,inWKT);
        if (inWKT.startsWith("MULTILINESTRING")) return parseMultiLineString(coordRef,inWKT);
        if (inWKT.startsWith("MULTIPOLYGON")) return parseMultiPolygon(coordRef,inWKT);
        throw new Exception("Geometry Type not recognized for "+inWKT);
    }
    /** Convert the Well Know Text (WKT) representation of a point into a Point. */
    public static SeShape parsePoint(SeCoordinateReference coordRef,String inWKT) throws Exception{
        // find the X coordinate
        int tempStartIndex = inWKT.indexOf('(');
        if (tempStartIndex == -1) throw new Exception("Can Not find Start of X coordinate in Point "+inWKT);
        int tempEndIndex = inWKT.indexOf(')',tempStartIndex);
        if (tempEndIndex == -1) throw new Exception("Can Not find End of X coordinate in Point "+inWKT);
        // return the point
        SDEPoint tempPoint = parsePoint(inWKT, tempStartIndex+1, tempEndIndex-1);
        SeShape retShape = new SeShape(coordRef);
        retShape.generatePoint(1, new SDEPoint[]{tempPoint});
        return retShape;
    }
    /** Convert the Well Know Text (WKT) representation of a line string into a LineString. */
    public static SeShape parseLineString(SeCoordinateReference coordRef,String inWKT) throws Exception{
        // find the first Parenthesis
        int tempStartIndex = inWKT.indexOf('(');
        if (tempStartIndex == -1) throw new Exception("Can not find start of LineString in "+inWKT);
        int tempEndIndex = inWKT.indexOf(')',tempStartIndex);
        if (tempEndIndex == -1) throw new Exception("Can not find end of LineString in "+inWKT);
        // get the points from the middle part
        SDEPoint[] tempPoints = parsePoints(inWKT, tempStartIndex+1, tempEndIndex-1);
        SeShape retShape = new SeShape(coordRef);
        retShape.generateSimpleLine(tempPoints.length,1,new int[] {0},tempPoints);
        return retShape;
    }
    /** Convert the Well Know Text (WKT) representation of a polygon into a Polygon. */
    public static SeShape parsePolygon(SeCoordinateReference coordRef,String inWKT) throws Exception{
        // find the first parenthisis
        int tempStartIndex = inWKT.indexOf('(');
        if (tempStartIndex == -1) throw new Exception("Can not find start of Polygon in "+inWKT);
        // find the last parenthisis
        int tempEndIndex = inWKT.lastIndexOf(')');
        if (tempEndIndex == -1) throw new Exception("Can not find end of Polygon in "+inWKT);
        // parse the groups of points between the parenthesis
        SDEPoint[][] tempPointArray = parsePointGroups(inWKT, tempStartIndex+1, tempEndIndex-1);
        int[] partsIndexes = new int[tempPointArray.length];
        Vector pointList = new Vector();
        for(int i=0; i<tempPointArray.length;i++) {
            partsIndexes[i] = pointList.size();
            for(int j=0;j<tempPointArray[i].length;j++) {
                pointList.addElement(tempPointArray[i][j]);
            }
            SDEPoint firstPoint = tempPointArray[i][0];
            SDEPoint lastPoint = tempPointArray[i][tempPointArray[i].length-1];
            if((firstPoint.getX()==lastPoint.getX())&&(firstPoint.getY()==lastPoint.getY())) {
            }else{
                pointList.addElement(firstPoint);
            }
        }
        SDEPoint[] pointArray = new SDEPoint[pointList.size()];
        for(int i=0;i<pointList.size();i++) {
            pointArray[i] = (SDEPoint)pointList.elementAt(i);
        }
        SeShape retShape = new SeShape(coordRef);
        retShape.generatePolygon(pointArray.length,partsIndexes.length,partsIndexes,pointArray);
        return retShape.asPolygon();
    }
    /** Convert the Well Known Text (WKT) representation of a multi point into a MultiPoint. */
    public static SeShape parseMultiPoint(SeCoordinateReference coordRef,String inWKT) throws Exception{
        // find the first Parenthesis
        int tempStartIndex = inWKT.indexOf('(');
        if (tempStartIndex == -1) throw new Exception("Can not find start of MultiPoint in "+inWKT);
        int tempEndIndex = inWKT.indexOf(')',tempStartIndex);
        if (tempEndIndex == -1) throw new Exception("Can not find end of MultiPoint in "+inWKT);
        // get the points from the middle part
        SDEPoint[] tempPoints = parsePoints(inWKT, tempStartIndex+1, tempEndIndex-1);
        SeShape retShape = new SeShape(coordRef);
        retShape.generatePoint(tempPoints.length, tempPoints);
        return retShape;
    }
    /** Convert the Well Known Text (WKT) representaion of a multi line string into a MultiLineString. */
    public static SeShape parseMultiLineString(SeCoordinateReference coordRef,String inWKT) throws Exception{
        // find the first parenthisis
        int tempStartIndex = inWKT.indexOf('(');
        if (tempStartIndex == -1) throw new Exception("Can not find start of MultiLineString in "+inWKT);
        // find the last parenthisis
        int tempEndIndex = inWKT.lastIndexOf(')');
        if (tempEndIndex == -1) throw new Exception("Can not find end of MultiLineString in "+inWKT);
        // parse the groups of points between the parenthesis
        SDEPoint[][] tempPointArray = parsePointGroups(inWKT, tempStartIndex+1, tempEndIndex-1);

        int[] partsIndexes = new int[tempPointArray.length];
        Vector pointList = new Vector();
        for(int i=0; i<tempPointArray.length;i++) {
            partsIndexes[i] = pointList.size();
            for(int j=0;j<tempPointArray[i].length;j++) {
                pointList.addElement(tempPointArray[i][j]);
            }
        }
        SDEPoint[] pointArray = new SDEPoint[pointList.size()];
        for(int i=0;i<pointList.size();i++) {
            pointArray[i] = (SDEPoint)pointList.elementAt(i);
        }
        SeShape retShape = new SeShape(coordRef);
        retShape.generateLine(pointArray.length,partsIndexes.length,partsIndexes,pointArray);
        return retShape;
    }
    /** Convert the Well Known Text (WKT) representation of  multi polygon into a MultiPolygon. */
    public static SeShape parseMultiPolygon(SeCoordinateReference coordRef,String inWKT) throws Exception {
        // find the first parenthisis
        int tempStartIndex = inWKT.indexOf('(');
        if (tempStartIndex == -1) throw new Exception("Can not find start of MultiPolygon in "+ inWKT);
        // find the matching parenthisis
        int tempEndIndex = getMatchingParenthesis(inWKT, tempStartIndex + 1);
        if (tempEndIndex == -1) throw new Exception("Can not find end of MultiPolygon in "+inWKT);
        // find the Polygons
        ArrayList tempPolygonList = new ArrayList();
        int tempPolygonStartIndex = inWKT.indexOf('(', tempStartIndex + 1);
        int tempPolygonEndIndex = getMatchingParenthesis(inWKT, tempPolygonStartIndex + 1);

        Vector partsList = new Vector();
        Vector pointList = new Vector();
        while (tempPolygonStartIndex != -1){
            // parse the groups of points between the parenthesis
            SDEPoint[][] tempPointArray = parsePointGroups(inWKT, tempPolygonStartIndex+1, tempPolygonEndIndex-1);
            // create the polygon
            for(int i=0; i<tempPointArray.length;i++) {
                partsList.addElement(new Integer(pointList.size()));
                for(int j=0;j<tempPointArray[i].length;j++) {
                    pointList.addElement(tempPointArray[i][j]);
                }
                SDEPoint firstPoint = tempPointArray[i][0];
                SDEPoint lastPoint = tempPointArray[i][tempPointArray[i].length-1];
                if((firstPoint.getX()==lastPoint.getX())&&(firstPoint.getY()==lastPoint.getY())) {
                }else{
                    pointList.addElement(firstPoint);
                }
            }
            // calculate the next value of the start and end indexes.
            tempPolygonStartIndex = inWKT.indexOf('(', tempPolygonEndIndex + 1);
            tempPolygonEndIndex = getMatchingParenthesis(inWKT, tempPolygonStartIndex + 1);
        }
        // create the multipolygon
        int[] partIndexes = new int[partsList.size()];
        for(int i=0;i<partsList.size();i++) {
            partIndexes[i] = ((Integer)partsList.elementAt(i)).intValue();
        }
        SDEPoint[] pointArray = new SDEPoint[pointList.size()];
        for(int i=0;i<pointList.size();i++) {
            pointArray[i] = (SDEPoint)pointList.elementAt(i);
        }
        SeShape retShape = new SeShape(coordRef);
        retShape.generatePolygon(pointArray.length,partIndexes.length,partIndexes,pointArray);
        return retShape.asPolygon();
    }
    /** parse a point from a space separated set of numbers.  An example of input may be "1.2 2.3 3.4". */
    protected static SDEPoint parsePoint(String inWKT, int inStartIndex, int inEndIndex) throws Exception{
        // find the X coordinate
        int tempStartIndex = inStartIndex;
        int tempEndIndex = inWKT.indexOf(' ',tempStartIndex);
        if ((tempEndIndex == -1) || (tempEndIndex > inEndIndex)) throw new Exception("Can Not find End of X coordinate in Point "+inWKT+ " Between "+inStartIndex+" and "+inEndIndex);
        double x = Double.parseDouble(inWKT.substring(tempStartIndex, tempEndIndex+1));
        // find the Y Coordinate
        tempStartIndex = tempEndIndex + 1;
        if (tempStartIndex > inEndIndex) throw new Exception("Can Not find Start of Y coordinate in Point "+inWKT);
        tempEndIndex = inWKT.indexOf(' ',tempStartIndex);
        if ((tempEndIndex == -1) || (tempEndIndex > inEndIndex)) tempEndIndex = inEndIndex;
        double y = Double.parseDouble(inWKT.substring(tempStartIndex, tempEndIndex+1));
        // could find a z coordinate in the future.
        return new SDEPoint(x,y);
    }
    /** parse a set of points from a space separated coma delimited set of numbers.  An example of input may be "1.2 2.3 3.4, 100 200.2, 25 35 45". */
    protected static SDEPoint[] parsePoints(String inWKT, int inStartIndex, int inEndIndex) throws Exception{
        // loop through the set separating out the commas
        ArrayList tempArrayList = new ArrayList();
        int tempStartIndex = inStartIndex;
        while ((tempStartIndex != -1) && (tempStartIndex < inEndIndex)){
            int tempEndIndex = inWKT.indexOf(',',tempStartIndex);
            if ((tempEndIndex == -1) || (tempEndIndex > inEndIndex)) tempEndIndex = inEndIndex;
            else tempEndIndex = tempEndIndex -1;
            tempArrayList.add(parsePoint(inWKT, tempStartIndex, tempEndIndex));
            tempStartIndex = tempEndIndex + 2; // to step over the comma
        }
        SDEPoint[] tempPoints = new SDEPoint[tempArrayList.size()];
        tempArrayList.toArray(tempPoints);
        return tempPoints;
    }
    /**
     * Parse muliple sets of points from a space separated comma delimited, and parenthetically grouped set of numbers.
     * An example of the type of string that should be sent in is the following. (1.2 2.3 3.4, 1.3 3.4 4.5, 1.4 2.5 3.6),(9.8 8.7,3.4 4.3,1.2 1.3, 1.5 2.3)
     */
    protected static SDEPoint[][] parsePointGroups(String inWKT, int inStartIndex, int inEndIndex) throws Exception{
        int tempStartIndex = inWKT.indexOf('(', inStartIndex);
        if ((tempStartIndex == -1) || (tempStartIndex > inEndIndex)) return new SDEPoint[0][0];
        int tempEndIndex = inWKT.indexOf(')', tempStartIndex);
        if (tempEndIndex > inEndIndex) tempEndIndex = inEndIndex;
        else tempEndIndex = tempEndIndex -1;
        ArrayList tempArrayList = new ArrayList();
        while ((tempStartIndex != -1) && (tempStartIndex < inEndIndex)){
            tempArrayList.add(parsePoints(inWKT, tempStartIndex+1, tempEndIndex));
            tempStartIndex = inWKT.indexOf('(', tempEndIndex);
            tempEndIndex = inWKT.indexOf(')', tempStartIndex);
            if (tempEndIndex > inEndIndex) tempEndIndex = inEndIndex;
            else tempEndIndex = tempEndIndex -1;
        }
        // convert the points to an array
        SDEPoint[][] tempPointArray = new SDEPoint[tempArrayList.size()][0];
        for (int i=0; i<tempArrayList.size(); i++){
            tempPointArray[i] = (SDEPoint[]) tempArrayList.get(i);
        }
        return tempPointArray;
    }
    /** Given a string and a starting position.  Find the matching parenthesis for the position sent in. */
    private static int getMatchingParenthesis(String inWKT, int inStartLocation){
        int numOpen = 0;
        for (int i=inStartLocation; i<inWKT.length(); i++){
            if (inWKT.charAt(i) == '(') numOpen++;
            else {
                if (inWKT.charAt(i) == ')'){
                    if (numOpen == 0) return i;
                    else numOpen--;
                }
            }
        }
        return -1;
    }
    /** Test the Parser */
    public static void main(String [] inArgs){
        try{
            SeCoordinateReference coordRef = new SeCoordinateReference();
            
            // parse a point
            System.out.println("Point 1");
            SeShape tempPoints = parsePoint(coordRef,"POINT(1 2 3)");
            writePoints(tempPoints);
            // parse a point
            System.out.println("Point 2");
            SeShape tempPoints2 = parsePoint(coordRef,"POINT(1.234 12.34 123.4)");
            writePoints(tempPoints2);
            // parse a LineString
            System.out.println("LineString 1");
            SeShape tempLineString = parseLineString(coordRef,"LINESTRING(0 0,1 1,1 2)");
            writePoints(tempLineString);
            // parse a LineString
            System.out.println("LineString 2");
            tempLineString = parseLineString(coordRef,"LINESTRING(1.234 1.234 123.4,12.34 12.34 123.4,123.4 123.4)");
            writePoints(tempLineString);
            // parse a Polygon
            System.out.println("Polygon 1");
            SeShape tempPolygon = parsePolygon(coordRef,"POLYGON((0 0 0,4 0 0,4 4 0,0 4 0,0 0 0),(1 1 0,2 1 0,2 2 0,1 2 0,1 1 0))");
            writePoints(tempPolygon);
            // parse a Polygon
            System.out.println("Polygon 2");
            tempPolygon = parsePolygon(coordRef,"POLYGON((1.2345 1.2345,12.345 12.345 0,123.45 123.45 0,1234.5 1234.5 0,12345 12345,1.2345 1.2345),(1.2345 1.2345 0,12.345 12.345,123.45 123.45 0,1234.5 1234.5 0,12345 12345 0,1.2345 1.2345))");
            writePoints(tempPolygon);
            // parse a Polygon
            System.out.println("Polygon 3");
            tempPolygon = parsePolygon(coordRef,"POLYGON((1.2345 1.2345,12.345 12.345 0,123.45 123.45 0,1234.5 1234.5 0,12345 12345),(1.2345 1.2345 0,12.345 12.345,123.45 123.45 0,1234.5 1234.5 0,12345 12345 0))");
            writePoints(tempPolygon);
            // parse a MultiPoint
            System.out.println("MultiPoint 1");
            SeShape tempMultiPoint = parseMultiPoint(coordRef,"MULTIPOINT(0 0 0,1 2 1)");
            writePoints(tempMultiPoint);
            // parse a MultiPoint
            System.out.println("MultiPoint 2");
            tempMultiPoint = parseMultiPoint(coordRef,"MULTIPOINT(12.34 12.34 0,43.21 43.21)");
            writePoints(tempMultiPoint);
            // parse a MultiLineString
            System.out.println("MultiLineString 1");
            SeShape tempMultiLineString = parseMultiLineString(coordRef,"MULTILINESTRING((0 0 0,1 1 0,1 2 1),(2 3 1,3 2 1,5 4 1))");
            writePoints(tempMultiLineString);
            // parse a MultiLineString
            System.out.println("MultiLineString 2");
            tempMultiLineString = parseMultiLineString(coordRef,"MULTILINESTRING((1.2345 1.2345 0,12.345 12.345 0,123.45 123.45),(1234.5 1234.5 1,5432.1 5432.1 1,543.21 543.21))");
            writePoints(tempMultiLineString);
            // parse a MultiPolygon
            System.out.println("MultiPolygon 1");
            SeShape tempMultiPolygon = parseMultiPolygon(coordRef,"MULTIPOLYGON(((0 0 0,4 0 0,4 4 0,0 4 0,0 0 0),(1 1 0,2 1 0,2 2 0,1 2 0,1 1 0)),((10 10 0,10 20 0,20 20 0,20 10 0,10 10 0)))");
            writePoints(tempMultiPolygon);
           
/*
            SeShape tmpShape = parseShape(coordRef,"LINESTRING(72438.66212917473 108531.86941555724 72374.27393794601 108538.39880151939 72298.81295589669 108541.1019279926 72213.32861206651 108546.29725304403 72140.56298820503 108574.0003797262 72065.42235319232 108624.39878897523 71980.10985899233 108657.20350024078 71867.04734419234 108677.50037206509 71784.21923291759 108707.79725344648 71704.1332790133 108768.20348790559 71616.34421754106 108808.6019349651 71573.78173459292 108841.29722708906 71528.96924357349 108911.70347110525 71471.60983484794 108989.70349828302 71449.31296111223 109042.50036564219 71459.8910921512 109122.79724744149 71495.89112655674 109245.89880269582 71511.43797607857 109316.203490591 71476.45359761847 109351.39879694613 71360.53173802103 109319.00035753228 71267.29734533749 109294.00035732333 71216.78174866148 109261.39880566744 71171.53172317846 109266.5003902508 71131.34425138155 109274.20349781879 71171.88328545936 109319.29725760999 71225.00049985516 109366.89879991772 71321.0317121124 109434.6019174607 71356.4770246274 109472.20349757894 71354.35983528901 109532.50036026404 71314.53174142598 109597.79725141148 71274.53175056519 109635.60194377179 71231.70358278364 109625.60193421468 71198.7817314587 109593.00038255879 71166.04736106991 109585.60194335389 71138.54734662978 109613.2972543831 71123.89110260586 109681.10192804708 71126.92234440107 109761.5003659674 71142.35986951651 109814.20349285853 71102.15671904606 109821.7972286525 71074.6411206676 109844.50037423993 71057.25048755857 109879.601940127 71017.13330927081 109897.2972415991 70974.39111367194 109902.39882618247 70951.89108032658 109925.00036828127 70929.35983173692 109940.20347117518 70876.47703956265 109932.70347584925 70843.8911192127 109950.39882468895 70851.60985808661 109975.50038101892 70912.38328613255 110038.20351746713 70975.46924747355 110070.70351300201 70981.95140794473 110051.73208118636 71002.01134706502 110024.02900187178 71042.04629521002 110015.70139994765 71135.75261123021 110016.01175242197 71214.72239515508 109996.71845780671 71311.29241379137 109957.32363532382 71358.20579969694 109956.86227496059 71395.02391981435 109987.00038016768 71423.03427270966 110002.37950104)");
            writePoints(tmpShape);
 */
            System.out.println("Finished...");
        }
        catch (Exception e){
            System.out.println(""+e);
        }
    }
    // getAllCoords returns a three dimensional array of double values.
    public static void writePoints(SeShape shape) {
        try {
            System.out.println(shape);
            double[][][] points = shape.getAllCoords();
            // Display the X and Y values
            for( int partNo = 0 ; partNo < points.length ; partNo++, System.out.println("") ) 
                for( int subPartNo = 0 ; subPartNo < points[partNo].length ; subPartNo++, System.out.println("") ) 
                    for( int pointNo = 0 ; pointNo < points[partNo][subPartNo].length ; pointNo+=2) 
                        System.out.println("X: " + points[partNo][subPartNo][pointNo] + "\tY: " + points[partNo][subPartNo][(pointNo+1)] );
        }catch(Exception ex) {
            ex.printStackTrace();
        }
    }
}
