/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package proprietary.datasources.arcsde;

import java.awt.*;
import javax.swing.*;
import gistoolkit.display.GISDisplay;
import gistoolkit.datasources.*;
import gistoolkit.application.*;
import gistoolkit.application.layers.*;
/**
 * Allows entry of parameters relative to the ARCSDE DataSource.
 * @author  ithaqua
 */
public class ArcSDEDataSourcePanel extends JPanel implements DataSourcePanel {
    
    /** Creates new ArcSDEDataSourcePanel */
    public ArcSDEDataSourcePanel() {
        initPanel();
    }
    
    /** Allows the user to enter a value for the server name. */
    private JTextField myTextFieldServername = new JTextField("Localhost");
    /** Set the name of the server where the SDE process is running */
    public void setServername(String inServername){myTextFieldServername.setText(inServername);}
    /** Retrieve the name of the server where the SDE process is running*/
    public String getServername(){return myTextFieldServername.getText();}
    
    /** Allows the user to enter avalue for the port number */
    private JTextField myTextFieldPortnumber = new JTextField("5151"); // 5151 is the default for SDE
    /** Set the port number on which the SDE server is listening for incoming requests.  The SDE default for version 8.1 is 5151. */
    public void setPortNumber(String inPortNumber){myTextFieldPortnumber.setText(inPortNumber);}
    /** Retrieve the port number on which the SDE server is listening for incoming requests.  The SDE default for version 8.1 is 5151.*/
    public int getPortNumber(){return Integer.parseInt(myTextFieldPortnumber.getText());}
    
    /** Allows the user to enter a value for the database name */
    private JTextField myTextFieldDatabasename = new JTextField("SDE");
    /** Set the database name of the database that SDE will access to service this request */
    public void setDatbasename(String inDatabasename){myTextFieldDatabasename.setText(inDatabasename);}
    /** Retrieve the database name of the database that SDE will access to service this request */
    public String getDatabasename(){return myTextFieldDatabasename.getText();}
    
    /** Allows the user to enter a value for the table name */
    private JTextField myTextFieldTablename = new JTextField("SDE");
    /** Set the tablename where the data for this datasource resides */
    public void setTablename(String inTablename){myTextFieldTablename.setText(inTablename);}
    /** Retrieve the tablename where the data for this datasource resides */
    public String getTablename(){return myTextFieldTablename.getText();}
    
    /** Allows the user to enter a value for the Username for security reasons in accessing the database */
    private JTextField myTextFieldUsername = new JTextField("SDE");
    /** Set the username used when accessing the database */
    public void setUsername(String inUsername){myTextFieldUsername.setText(inUsername);}
    /** Return the username for accessing the database */
    public String getUsername(){return myTextFieldUsername.getText();}
    
    /** Allows the user to enter a password for accessing the database for security reasons */
    private JPasswordField myPasswordField = new JPasswordField("");
    /** Set the password corresponding to the username used when authenticating access to the database */
    public void setPassword(String inPassword){myPasswordField.setText(inPassword);}
    /** Retrieve the password corresponding to the username used when authenticating access to the database */
    public String getPassword(){return new String(myPasswordField.getPassword());}
    
    /** Allows the user to enter the minimum X value */
    private JTextField myTextFieldMinX = new JTextField();
    /** Allows the user to enter the maximum X value */
    private JTextField myTextFieldMaxX = new JTextField();
    /** Allows the user to enter the Minimum Y value */
    private JTextField myTextFieldMinY = new JTextField();
    /** Allows the user to enter the Maximum Y value */
    private JTextField myTextFieldMaxY = new JTextField();
    
    /**
     * Return the full configured data source.
     */
    public DataSource getDataSource() throws Exception {
        ArcSDEDataSource tempDataSource = new ArcSDEDataSource();
        tempDataSource.setServername(getServername());
        tempDataSource.setPortNumber(getPortNumber());
        tempDataSource.setDatabaseName(getDatabasename());
        tempDataSource.setTableName(getTablename());
        tempDataSource.setUsername(getUsername());
        tempDataSource.setPassword(getPassword());
        tempDataSource.setMinX(Double.parseDouble(myTextFieldMinX.getText()));
        tempDataSource.setMaxX(Double.parseDouble(myTextFieldMaxX.getText()));
        tempDataSource.setMinY(Double.parseDouble(myTextFieldMinY.getText()));
        tempDataSource.setMaxY(Double.parseDouble(myTextFieldMaxY.getText()));
        tempDataSource.connect();
        return tempDataSource;
    }
    
    /** Sets up the user interface elements of this panel. */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        
        // the Server name
        c.gridx = 0;
        c.gridy = 0;
        add(new JLabel("Server Name"), c);
        c.gridy++;
        add(myTextFieldServername, c);
        myTextFieldServername.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceServername", myTextFieldServername.getText()));

        // the server port
        c.gridy++;
        add(new JLabel("Port Number"), c);
        c.gridy++;
        add(myTextFieldPortnumber, c);
        myTextFieldPortnumber.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourcePortNumber", myTextFieldPortnumber.getText()));
        
        // the Databasename
        c.gridy++;
        add(new JLabel("Database Name"), c);
        c.gridy++;
        add(myTextFieldDatabasename, c);
        myTextFieldDatabasename.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceDatabaseName", myTextFieldDatabasename.getText()));
        
        // the table name
        c.gridy++;
        add(new JLabel("Table Name"), c);
        c.gridy++;
        add(myTextFieldTablename, c);
        myTextFieldTablename.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceTableName", myTextFieldTablename.getText()));
       
        // the Username
        c.gridy++;
        add(new JLabel("Username"), c);
        c.gridy++;
        add(myTextFieldUsername, c);
        myTextFieldUsername.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceUsername", myTextFieldUsername.getText()));
        
        // the Password
        c.gridy++;
        add(new JLabel("Password"), c);
        c.gridy++;
        add(myPasswordField, c);
        myPasswordField.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourcePassword"));
        
        // the minimum X value
        c.gridy++;
        add(new JLabel("Minimum X"), c);
        c.gridy++;
        add(myTextFieldMinX, c);
        myTextFieldMinX.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceMinX"));
        
        // the maximum X value
        c.gridy++;
        add(new JLabel("Maximum X"), c);
        c.gridy++;
        add(myTextFieldMaxX, c);
        myTextFieldMaxX.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceMaxX"));
        
        // the minimum Y value
        c.gridy++;
        add(new JLabel("Minimum Y"), c);
        c.gridy++;
        add(myTextFieldMinY, c);
        myTextFieldMinY.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceMinY"));
        
        // the maximum Y value
        c.gridy++;
        add(new JLabel("Maximum Y"), c);
        c.gridy++;
        add(myTextFieldMaxY, c);
        myTextFieldMaxY.setText(System.getProperty(Constants.getApplicationName()+".ArcSDEDataSourceMaxY"));
        
        // Some space at the bottom
        c.gridy++;
        c.weighty = 1;
        add(new JLabel(""), c);
    }
    
    /**
     * Sets the GISDisplay in case the panel should need it.
     */
    public void setGISDisplay(GISDisplay inDisplay) {
    }
    
}
