/*
 * ArcSDEDataSource.java
 *
 * Created on August 6, 2001, 9:26 AM
 */
package proprietary.datasources.arcsde;
import java.util.*;
import gistoolkit.common.*;
import gistoolkit.features.*;
import com.esri.sde.sdk.client.*;
/** Retrieves data from an ArcSDEDataSource.
 * @author tomluxj
 * @version 0.1
 */
public class UpdateableArcSDEDataSource extends ArcSDEDataSource {
    /** Creates new ArcSDEDataSource */
    public UpdateableArcSDEDataSource() {
        setName("UpdateableArcSDEDataSource");
    }
    private static SeConnection getConnection(String srvName, int portNbr, String dbName, String user, String passwd ) {
        SeConnection tmpConn = null;
        try{
            tmpConn = new SeConnection(srvName, portNbr, dbName, user, passwd);
        }catch ( SeException e ) {
            e.printStackTrace();
            tmpConn = null;
        }
        return tmpConn;
    }
    private String getPrimaryKeyField(String tblName) throws Exception{
//        System.out.println("Trying to get PrimaryKey: "+tblName);
        SeConnection conn = getConnection(getServername(), getPortNumber(), getDatabaseName(), getUsername(), getPassword() );
        SeTable tempTable = new SeTable(conn, tblName);
        SeSqlConstruct sqlConstruct = new SeSqlConstruct("SDE.TABLE_REGISTRY");
        sqlConstruct.setWhere("TABLE_NAME = '"+tempTable.getName()+"'");
        SeQuery theQuery = new SeQuery(conn,new String[]{"ROWID_COLUMN"},sqlConstruct);
        theQuery.prepareQuery();
        theQuery.execute();
        SeRow row = theQuery.fetch();
        conn.close();
        if(row != null){
            String retString = row.getString(0)+"";
            return retString;
        }
        throw new Exception("no primary key found for table: "+tempTable.getName());
    }    
    /** Returns true.
     * @return always true
     */    
    public boolean isUpdateable() {return true;}
    /** */
    private SeShape parseSeShape(SeCoordinateReference coordRef, Shape inShape) throws Exception{
        if (inShape == null) return null;
        Shape shape = inShape;
        SeShape tempShape = null;
        double points[][][] = null;//inShape.getAllCoords();
        int numParts = 0;//inShape.getNumParts();
        // Retrieve the shape type.
        String type = inShape.getShapeType();
        String wktShape = inShape.getWKT();
//        System.out.println(wktShape);
        tempShape = new SeShape(coordRef);
        return tempShape;
    }
    /** Inserts the given record into the datasource.
     * @param inRecord Record to insert
     * @throws Exception
     */
    public void doInsert(Record inRecord) throws Exception {
        System.out.println("UpdatetabelArcSDE_DataSource.doInsert");
        SeConnection conn = getConnection(getServername(), getPortNumber(), getDatabaseName(), getUsername(), getPassword() );
        
        SeTable tempTable = new SeTable(conn, getTableName());
        SeColumnDefinition[] tempColumnDefs = tempTable.describe();
        String tempSpatialColumnName = "Shape";
        for(int i=0; i<tempColumnDefs.length; i++) {
            if(tempColumnDefs[i].getType() == SeColumnDefinition.TYPE_SHAPE) {
                tempSpatialColumnName = tempColumnDefs[i].getName();
            }
        }
        String[] tempColumnNames = new String[] {tempSpatialColumnName};
        SeLayer theLayer = new SeLayer(conn,getTableName(),tempSpatialColumnName);
        Shape tempShapeValue = inRecord.getShape();

        SeInsert theInsert = new SeInsert(conn);
        theInsert.intoTable(getTableName(),tempColumnNames);
        theInsert.setWriteMode(true);
        SeRow theRow = theInsert.getRowToSet();
        
        String shapeWKT = tempShapeValue.getWKT().toUpperCase();
        SeShape tmpShape = ArcSDEWKTFactory.parseShape(theLayer.getCoordRef(),shapeWKT);
        theRow.setShape(0,tmpShape);
        try {
            theInsert.execute();
//            System.out.println("insert executed, trying to close: "+ new Date());
            theInsert.flushBufferedWrites();
//            System.out.println("222insert executed, trying to close: "+ new Date());
            theInsert.close();
//            System.out.println("insert.closed!! "+ new Date());
        }catch(SeException seEx) {
            System.out.println(seEx.getSeError().getErrDesc());
            System.out.println(seEx.getSeError().getExtErrMsg());
            seEx.printStackTrace();
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        fireInsert(inRecord);
        setCache(null, null);
        conn.close();
        System.out.println("doInsert finished");
    }
    /** Update the data source with the changed record. By default this is a read only data source, so this method does nothing.
     * @param inRecord Record to update
     * @throws Exception
     */
    public void doUpdate(Record inRecord) throws Exception {
        // connect to the SDE datasource
        System.out.println("UpdatetabelArcSDE_DataSource.doUpdate");
//        System.out.println("updateableARCSDEDatasource Connecting to the ArcSDE Server...");
//        SeConnection conn = new SeConnection( myServername, myPortNumber, myDatabaseName, myUsername, myPassword );
        SeConnection conn = getConnection(getServername(), getPortNumber(), getDatabaseName(), getUsername(), getPassword() );
        
//        System.out.println("updateableARCSDEDatasource Connection Successful! \n");
        // get the description of the table
        SeTable tempTable = new SeTable(conn, getTableName());
        SeColumnDefinition[] tempColumnDefs = tempTable.describe();
        String tempSpatialColumnName = "Shape1";
        //   Store the names of all the table's columns in the
        //   String array cols. This array specifies the columns
        //   to be retrieved from the database.
        Object[] tempAttributeValuesOrig = inRecord.getAttributes();
        AttributeType[] tempAttributeTypeOrig = inRecord.getAttributeTypes();
        String[] tempColumnNamesOrig = new String[tempColumnDefs.length];
        int colIndex = 0;
        for(int i=0; i<tempColumnDefs.length; i++) {
//            System.out.println(tempColumnNamesOrig[i]);
            if(tempColumnDefs[i].getType() == SeColumnDefinition.TYPE_SHAPE) {
//                System.out.println("Shape found");
                tempSpatialColumnName = tempColumnDefs[i].getName();
                tempColumnNamesOrig[colIndex++] = tempColumnDefs[i].getName();
            }else{
                tempColumnNamesOrig[colIndex++] = tempColumnDefs[i].getName();
            }
        }
        //        System.out.println("Shape field is names : "+tempSpatialColumnName);
        /*eliminating thge ObjectID*/
        String[] tempColumnNames = new String[tempColumnNamesOrig.length-1];
        Object[] tempAttributeValues = new Object[tempAttributeValuesOrig.length-1];
        AttributeType[] tempAttributeType = new AttributeType[tempAttributeTypeOrig.length-1];
        for(int i=1;i<tempColumnNamesOrig.length;i++) tempColumnNames[i-1] = tempColumnNamesOrig[i];
        for(int i=1;i<tempAttributeValuesOrig.length;i++) tempAttributeValues[i-1] = tempAttributeValuesOrig[i];
        for(int i=1;i<tempAttributeTypeOrig.length;i++) tempAttributeType[i-1] = tempAttributeTypeOrig[i];

        SeLayer theLayer = new SeLayer(conn,getTableName(),tempSpatialColumnName);
        Shape tempShapeValue = inRecord.getShape();

        SeObjectId theObjectId = new SeObjectId(new Long(tempAttributeValuesOrig[0]+"").longValue());
        SeUpdate theUpdate = new SeUpdate(conn);
//        System.out.println("## "+theObjectId.longValue());
//        System.out.println(tempAttributeValues.length+"<>"+tempColumnNames.length+"<>"+tempAttributeType.length);
      
        for(int i=0;i<tempColumnNames.length-1;i++) {
//            System.out.println(i+" > "+tempColumnNames[i]+"="+tempAttributeValues[i]+">"+tempAttributeType[i].getType());
        }
//        System.out.println("UpdtArcSdeSoruce.doUpdate("+theObjectId.longValue()+","+getTableName()+","+tempColumnNames.length+")");

        SeRow theRow = theUpdate.singleRow(theObjectId, getTableName(), tempColumnNames);
        for(int i=0;i<tempColumnNames.length;i++) {
//            System.out.println(i+">"+tempColumnNames[i]+"="+tempAttributeValues[i]+":"+tempColumnDefs[i+1].getName());
            switch(tempColumnDefs[i+1].getType()) {
                case SeColumnDefinition.TYPE_SHAPE:
                    String shapeWKT = tempShapeValue.getWKT().toUpperCase();
                    SeShape tmpShape = ArcSDEWKTFactory.parseShape(theLayer.getCoordRef(),shapeWKT);
                    theRow.setShape(i,tmpShape);
                    break;
                case SeColumnDefinition.TYPE_BLOB:
                    break;
                case SeColumnDefinition.TYPE_DATE:
                    if(tempAttributeValues[i] == null)
                        theRow.setDate(i,new Date());
                    else
//                        theRow.setDate(i,new Date(tempAttributeValues[i]+""));
                        theRow.setDate(i,new Date());
                    break;
                case SeColumnDefinition.TYPE_DOUBLE:
                    if((tempAttributeValues[i] == null)||(tempAttributeValues[i]+"").equals(""))
                        theRow.setDouble(i,new Double(0));
                    else
                        theRow.setDouble(i,new Double(tempAttributeValues[i]+""));
                    break;
                case SeColumnDefinition.TYPE_FLOAT:
                    if((tempAttributeValues[i] == null)||(tempAttributeValues[i]+"").equals(""))
                        theRow.setFloat(i,new Float(0));
                    else
                        theRow.setFloat(i,new Float(tempAttributeValues[i]+""));
                    break;
                case SeColumnDefinition.TYPE_INTEGER:
                    if((tempAttributeValues[i] == null)||(tempAttributeValues[i]+"").equals(""))
                        theRow.setInteger(i,new Integer(0));
                    else
                        theRow.setInteger(i,new Integer(tempAttributeValues[i]+""));
                    break;
                case SeColumnDefinition.TYPE_SMALLINT:
                    if((tempAttributeValues[i] == null)||(tempAttributeValues[i]+"").equals(""))
                        theRow.setShort(i,new Short((short)0));
                    else
                        theRow.setShort(i,new Short(tempAttributeValues[i]+""));
                    break;
                case SeColumnDefinition.TYPE_STRING:
                    if(tempAttributeValues[i] == null)
                        theRow.setString(i,"");
                    else
                        theRow.setString(i,tempAttributeValues[i]+"");
                    break;
            } // swicth column type
        } // for each column
        theUpdate.execute();
        theUpdate.close();
        conn.close();
//        System.out.println("cleaned up");
        fireUpdate(inRecord);
        setCache(null, null);
//        System.out.println("doUpdate finished");
    }
    /** Delete this record from the database. By default this is a read only data source, so this method does nothing.
     * @param inRecord
     * @throws Exception  */
    public void doDelete(Record inRecord) throws Exception {
        System.out.println("UpdatetabelArcSDE_DataSource.doDelete");
        SeConnection conn = getConnection(getServername(), getPortNumber(), getDatabaseName(), getUsername(), getPassword() );
        
        String[] attriName = inRecord.getAttributeNames();
        Object[] attriValues = inRecord.getAttributes();
        int idIndex = -1;
        String pkFieldName = getPrimaryKeyField(getTableName()).toUpperCase();
        for(int i=0; i<attriName.length;i++) {
            if(attriName[i].toUpperCase().equals(pkFieldName)) {
                idIndex = i;
                break;
            }
        }
        if(idIndex >= 0) {
            SeDelete theDelete = new SeDelete(conn);
            String queryStr = pkFieldName+" = "+attriValues[idIndex];
//            System.out.println("deleting row where: "+queryStr);
            theDelete.fromTable(getTableName(),queryStr);
            theDelete.close();
//            conn.close();
            fireDelete(inRecord);
            setCache(null, null);
        }
        conn.close();
    }
    /** Commit all changes since the last commit. This is a read only data source by default, so this method does nothing.
     * @throws Exception  */
    public void commit() throws Exception {
        System.out.println("UpdateableArcSDESource.doCommit not yet implemented!!");
/*        // Retrieve the connection to the database
        Connection tempConnection = connect();
        //Is there a transaction active.
        if (myInTransaction){
            // commit the transaction
            String tempQuery = "COMMIT";
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.execute(tempQuery);
            tempStatement.close();
            myInTransaction = false;
        }
        fireCommit();
        setCache(null, null);
 */   }
    /** Rollback any changes to this datasource since the last commit.
     * @throws Exception
     */
    public void rollback() throws Exception {
        System.out.println("UpdateableArcSDESource.rollback not yet implemented!!");
/*        // Retrieve the connection to the database
        Connection tempConnection = connect();
        //Is there a transaction active.
        if (myInTransaction){
            // commit the transaction
            String tempQuery = "ROLLBACK";
            Statement tempStatement = tempConnection.createStatement();
            tempStatement.execute(tempQuery);
            tempStatement.close();
            myInTransaction = false;
        }
        fireRollBack();
        setCache(null, null);
 */   }
    
        /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tmpNode = super.getNode();
        tmpNode.setName("UpdateableArcSDEDataSource");
        return tmpNode;
    }
    
        /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        if (inNode == null) throw new Exception("Can not set up UpdateableArcSDEDataSource configuration information is null");
        super.setNode(inNode);
    }    

}
