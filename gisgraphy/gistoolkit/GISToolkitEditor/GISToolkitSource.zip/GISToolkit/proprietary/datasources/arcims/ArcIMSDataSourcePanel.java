/*
 
 * OGCWebServiceDataSourcePanel.java
 
 *
 
 * Created on September 5, 2001, 2:49 PM
 
 */

package proprietary.datasources.arcims;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.GISDisplay;
import gistoolkit.application.layers.DataSourcePanel;
import gistoolkit.datasources.DataSource;
import gistoolkit.datasources.webservice.Layer;

/**
 *
 * Panel to display the relevent bits about a particular ArcIMS-OGC Web Service.
 *
 * @author  tomluxj
 *
 */

public class ArcIMSDataSourcePanel extends JPanel implements DataSourcePanel, ActionListener{
    /** Text field for entering the Basic Text Information */
    private JTextField myTextFieldURL = new JTextField("http://gis2.pch.etat.lu/servlet/com.esri.wms.Esrimap");
    //"http://heineken.gsfc.nasa.gov:8910/cgi-bin/dib/WGISS");
    /** A tag for the service */
    private JComboBox myComboBoxService = new JComboBox(new String[] {"raster_ortho","raster_tc"});
    /** Button for attempting to connect with the WEb Server */
    private JButton myButtonConnect = new JButton("Connect");
    /** Data Source for connecting */
    ArcIMSDataSource myDataSource = null;

    /** Creates new OGCWebServiceDataSourcePanel */
    public ArcIMSDataSourcePanel() {
        initPanel();
    }
    
    /** Initialize the Panel */
    private void initPanel(){
        setLayout(new BorderLayout());
        JPanel tempTopPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0;
        c.weighty = 0;
        // Label
        c.gridx = 0;
        c.gridy = 0;
        tempTopPanel.add(new JLabel("URL :"), c);
        c.gridx++;
        c.weightx = 1;
        tempTopPanel.add(myTextFieldURL, c);
        c.weightx = 0;
        // The Service
        c.gridx = 0;
        c.gridy++;
        tempTopPanel.add(new JLabel("Service"), c);
        c.gridx++;
        c.weightx = 1;
        tempTopPanel.add(myComboBoxService, c);
        c.weightx = 0;
        c.gridx++;
        c.weightx = 0;
        // the Connect button
        c.gridy++;
        c.gridx=0;
        c.gridwidth = 2;
        c.fill = GridBagConstraints.VERTICAL;
        tempTopPanel.add(myButtonConnect, c);
        add(tempTopPanel, BorderLayout.NORTH);
        myButtonConnect.addActionListener(this);
    }
    
    public void actionPerformed(java.awt.event.ActionEvent p1) {
        if (p1.getSource() == myButtonConnect){
            myDataSource = new ArcIMSDataSource();
            myDataSource.setURLBase(myTextFieldURL.getText());
            myDataSource.setService(myComboBoxService.getSelectedItem()+"");
            try {
                myDataSource.connect();
            } catch (Exception e){
                JOptionPane.showMessageDialog(this, e.getMessage(), "Error Connecting", JOptionPane.ERROR_MESSAGE);
            }
            initSubPanel(myDataSource);
        }
        if (p1.getSource() == myButtonAdd){
            Object[] tempItems = myListAvailableLayers.getSelectedValues();
            DefaultListModel tempModel = (DefaultListModel) myListSelectedLayers.getModel();
            for (int i=0; i<tempItems.length; i++){
                tempModel.addElement(tempItems[i]);
            }
            tempModel = (DefaultListModel) myListAvailableLayers.getModel();
            for (int i=0; i<tempItems.length; i++){
                tempModel.removeElement(tempItems[i]);
            }
        }
        if (p1.getSource() == myButtonUP){
            int tempIndex = myListSelectedLayers.getSelectedIndex();
            if (tempIndex > 0){
                Object tempItem = myListSelectedLayers.getSelectedValue();
                DefaultListModel tempModel = (DefaultListModel) myListSelectedLayers.getModel();
                tempModel.removeElement(tempItem);
                tempModel.insertElementAt(tempItem, tempIndex-1);
                myListSelectedLayers.setSelectedIndex(tempIndex-1);
            }
        }
        if (p1.getSource() == myButtonDown){
            int tempIndex = myListSelectedLayers.getSelectedIndex();
            DefaultListModel tempModel = (DefaultListModel) myListSelectedLayers.getModel();
            if (tempIndex < tempModel.getSize()-1){
                Object tempItem = myListSelectedLayers.getSelectedValue();
                tempModel.removeElement(tempItem);
                tempModel.insertElementAt(tempItem, tempIndex+1);
                myListSelectedLayers.setSelectedIndex(tempIndex+1);
            }
        }
        if (p1.getSource() == myButtonDelete){
            int tempIndex = myListSelectedLayers.getSelectedIndex();
            if (tempIndex >= 0){
                DefaultListModel tempModel = (DefaultListModel) myListSelectedLayers.getModel();
                Object tempObject = tempModel.getElementAt(tempIndex);
                tempModel.removeElementAt(tempIndex);
                tempModel = (DefaultListModel) myListAvailableLayers.getModel();
                tempModel.addElement(tempObject);
            }
        }
        if (p1.getSource() == myComboFormat){
            myDataSource.setSelectedMapFormat((String) myComboFormat.getSelectedItem());
        }
    }
    
    /** List box for allowing the users to select items from the list */
    private JList myListAvailableLayers = new JList();
    /** List box to show the user the layers they have selected */
    private JList myListSelectedLayers = new JList();
    /** Allow the user to move Buttons over from the Available list */
    private JButton myButtonAdd = new JButton("Add ->");
    /** Allow the user to move the layers up or down in the list */
    private JButton myButtonUP = new JButton("Up");
    /** Allow the user to move the layers up or down in the list */
    private JButton myButtonDown = new JButton("Down");
    /** Allow the user to delete the layers in the list */
    private JButton myButtonDelete = new JButton("Delete");
    /** Allow the user to select the type of data */
    private JComboBox myComboFormat = new JComboBox();
    /** Sub panel to be displayed when data is available */
    private JPanel mySubPanel = null;
    /** Allows the flipping of the cards */
    private CardLayout myCardLayout = new CardLayout();

    /** Allow the user to select amungst the available layers */
    private void initSubPanel(ArcIMSDataSource inDS){
        if (mySubPanel == null){
            // Select Styles Panel
            mySubPanel = getLayersPanel();
            add(mySubPanel, BorderLayout.CENTER);
            validate();
        }
        // populate the Lists with the Available Layers.
        Layer[] tempLayers = inDS.getAvailableLayers();
        DefaultListModel tempAvailableListModel = new DefaultListModel();
        for (int i=0; i<tempLayers.length; i++){
            tempAvailableListModel.addElement(tempLayers[i]);
        }
        myListAvailableLayers.setModel(tempAvailableListModel);
        DefaultListModel tempSelectedListModel = new DefaultListModel();
        if (tempAvailableListModel.getSize() == 1){
            tempSelectedListModel.addElement(tempLayers[0]);
            myListAvailableLayers.setSelectedIndex(0);
        }
        myListSelectedLayers.setModel(tempSelectedListModel);
        // Populate the combo box with the available formats
        myComboFormat.removeAllItems();
        String[] tempFormats = myDataSource.getAvailableMapFormats();
        for (int i=0; i<tempFormats.length; i++){
            myComboFormat.addItem(tempFormats[i]);
        }
    }
    
    /** Return the panel for allowing the user to select the layers */
    private JPanel getLayersPanel(){
        // Select Layers Panel
        JPanel tempPanel = new JPanel(new GridBagLayout());
        tempPanel.setName("FirstPanel");
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        c.fill = GridBagConstraints.BOTH;
        // The Available Layers
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.weighty = 1;
        tempPanel.add(new JScrollPane(myListAvailableLayers), c);
        // The Buttons
        c.gridx++;
        c.weighty = 0;
        c.weightx = 0;
        JPanel tempButtonPanel = new JPanel(new GridLayout(0,1,2,2));
        tempButtonPanel.add(myButtonAdd);
        myButtonAdd.addActionListener(this);
        tempButtonPanel.add(myButtonUP);
        myButtonUP.addActionListener(this);
        tempButtonPanel.add(myButtonDown);
        myButtonDown.addActionListener(this);
        tempPanel.add(tempButtonPanel, c);
        tempButtonPanel.add(myButtonDelete);
        myButtonDelete.addActionListener(this);
        tempPanel.add(tempButtonPanel, c);
        // The Selected Layers
        c.gridx++;
        c.weightx = 1;
        c.weighty = 1;
        tempPanel.add(new JScrollPane(myListSelectedLayers), c);
        c.gridwidth = 1;
        // Tye type Choice
        c.gridx = 0;
        c.gridy++;
        c.fill = GridBagConstraints.HORIZONTAL;
        tempPanel.add(myComboFormat, c);
        myComboFormat.addActionListener(this);
        return tempPanel;
    }
    
    /**
     *
     * Return the fully configured datasource.
     *
     */
    public DataSource getDataSource() throws Exception {
        // Retrieve the selected Layers
        DefaultListModel tempModel = (DefaultListModel) myListSelectedLayers.getModel();
        Layer[] tempSelectedLayers = new Layer[tempModel.size()];
        for (int i=0; i<tempSelectedLayers.length; i++){
            Layer tempLayer = (Layer) tempModel.getElementAt(i);
            tempSelectedLayers[i] = tempLayer;
            if (tempLayer.getSelectedStyle() == null){
                if (tempLayer.getStyles() != null){
                    if (tempLayer.getStyles().length > 0){
                        tempLayer.setSelectedStyle(tempLayer.getStyles()[0]);
                    }
                }
            }
        }
        if (tempSelectedLayers.length == 0) throw new Exception("No layers selected");
        myDataSource.setLayers(tempSelectedLayers);
        return myDataSource;
    }
    
    /**
     *
     * Sets the GISDisplay in case the panel should need it.
     *
     */
    public void setGISDisplay(GISDisplay inDisplay) {
    }

    public static void main(String[] arg) {
        ArcIMSDataSourcePanel dataSource = new ArcIMSDataSourcePanel();
        JFrame myFrame = new JFrame("UpdateableArcSDEDataSourcePanel");
        myFrame.getContentPane().add(dataSource);
        myFrame.setSize(400,400);
        myFrame.setVisible(true);
    }
}