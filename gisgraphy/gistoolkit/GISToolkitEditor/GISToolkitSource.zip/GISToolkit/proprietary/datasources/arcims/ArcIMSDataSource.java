/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package proprietary.datasources.arcims;

import gistoolkit.common.*;
import gistoolkit.features.*;
import gistoolkit.datasources.*;
import gistoolkit.datasources.webservice.*;
/**
 * Data source for reading images from an OGC WebMapService.
 */
public class ArcIMSDataSource extends SimpleDataSource implements RasterDatasource {
    
    /** Holds the base URL for reading information from this datasource */
    private String myURLBase = "";
    /** Set the base URL for reading information from this datasource */
    public void setURLBase(String inURLBase){myURLBase = inURLBase;}
    /** Retrieve the base URL for reading information from this datasource */
    public String getURLBase(){return myURLBase;}

    /** Holds a String representation from the selected layers (need for XML) */
    private String mySelLayersString = "";
    /** Retrive the selected layer of the service */
    public String getSelLayersString(){return mySelLayersString;}
    
    /** Holds the name of the service.  This is only required for the ESRI services, the bastards*/
    private String myService = null;
    /** set the service name of the service when connecting to an ESRI service */
    public void setService(String inService){myService = inService;}
    /** Retrive the name of the service */
    public String getService(){return myService;}
    
    /** Used Format */
    private String myFormat = null;
    /** The client to use for connecting with the web service */
    private ArcIMSClient myArcIMSClient = null;
    
    /** Creates new OGCWebServiceDataSource */
    public ArcIMSDataSource() {
        setCached(false);
    }
        
    /** The name of this data source */
    private String myName = "ArcIMS_DataSource";
    /**Sets an identifier string for the datasource.*/
    public void setName(String inName) { myName = inName;}
    /**Returns the identifier string for the datasource.*/
    public String getName() {return myName;}
    
    /** The list of layers in the order they are to be drawn */
    private Layer[] myLayers = new Layer[0];
    /** Retrieve the list of layers */
    public Layer[] getLayers(){return myLayers;}
    /** Set the list of layers */
    public void setLayers(Layer[] inLayers){myLayers = inLayers;}
                
    /**
     * Determines if this datasource is updateable.
     */
    public boolean isUpdateable() {
        return false;
    }
    
    /** Connect to the data source */
    public void connect() throws Exception{
        // Attempt to connect with the 1.1 client
        
        // Attempt to connect with the 1.0 client
        ArcIMSClient tempClient = new ArcIMSClient();
        tempClient.setURLBase(getURLBase());
        tempClient.setService(getService());
        tempClient.setSelLayersString(getSelLayersString());
        tempClient.setSelectedMapFormat(myFormat);
        try{
            tempClient.connect();
            myArcIMSClient = tempClient;
        }
        catch (Exception e){
            System.out.println(""+e);
            throw e;
        }
        myName = "ArcIMS_"+getService();
    }
        
    private static final String DATASOURCE_NAME = "DataSourceName";
    private static final String URLBASE = "URLBase";
    private static final String SELECTEDLAYERS = "SelectedLayers";
    private static final String SERVICE = "Service";
    private static final String FORMAT = "Format";
    
    /** Get the configuration information for this data source  */
    public Node getNode() {
        Node tempRoot = super.getNode();
        tempRoot.setName("ArcIMSDataSource");
        tempRoot.addAttribute(DATASOURCE_NAME, myName);
        tempRoot.addAttribute(URLBASE, myURLBase);
        tempRoot.addAttribute(SERVICE, myService);
        tempRoot.addAttribute(FORMAT, myFormat);
        String tmpSelectLayers = new String();
        Layer[] selLayers = myArcIMSClient.getSelectedLayers();
        for(int i=0; i<selLayers.length;i++) {
            tmpSelectLayers += selLayers[i].getName()+"; ";
        }
        if(tmpSelectLayers.length()>0)
            tmpSelectLayers.substring(0,tmpSelectLayers.length());
        
        tempRoot.addAttribute(SELECTEDLAYERS, tmpSelectLayers);
        return tempRoot;
    }
    
    /** Set the configuration information for this data source  */
    public void setNode(Node inNode) throws Exception {
        if (inNode == null) throw new Exception("Error reading configuration information for ArcIMSDataSource");
        super.setNode(inNode);
        String tempString = inNode.getAttribute(DATASOURCE_NAME);
        if (tempString != null) myName = tempString;
        tempString = inNode.getAttribute(URLBASE);
        if (tempString != null)myURLBase = tempString;
        tempString = inNode.getAttribute(SELECTEDLAYERS);
        if (tempString != null)mySelLayersString = tempString;
        tempString = inNode.getAttribute(SERVICE);
        if (tempString != null)myService = tempString;
        tempString = inNode.getAttribute(FORMAT);
        if (tempString != null)myFormat = tempString;
        connect();
    }
    
    /** Retrieve the available layers */
    public Layer[] getAvailableLayers(){
        return myArcIMSClient.getLayers();
    }
    
    /**
     * Set the width of the image to retrieve.
     * The data source can use this information to generate the appropriate rastor shapes.
     * Several shapes may be generated or just one that cover this area.  This is just a
     * suggestion.
     */
    public void setImageWidth(int inWidth) {
        myArcIMSClient.setWidth(inWidth);
    }
    
    /**
     * Set the height of the image to retrieve.
     * The data source can use this information to generate the appropriate rastor shapes.
     * Several shapes may be generated or just one that cover this area.  This is just a
     * suggestion.
     */
    public void setImageHeight(int inHeight) {
        myArcIMSClient.setHeight(inHeight);
    }
    
    /** Retrieve the available map formats */
    public String[] getAvailableMapFormats(){
        if (myArcIMSClient != null) return myArcIMSClient.getMapFormats();
        return new String[0];
    }
    
    /** Set the Selected map format */
    public void setSelectedMapFormat(String inFormat){
        myFormat = inFormat;
        if (myArcIMSClient != null) myArcIMSClient.setSelectedMapFormat(inFormat);
    }
        
    /** Returns the bounding rectangle of all the shapes in the Data Source. */
    public Envelope readEnvelope() throws Exception {
        return null;
    }
    
    /** This method should return the shapes from the data source  */
    protected GISDataset readShapes(Envelope inEnvelope) throws Exception {
        // send the request to the server
        myArcIMSClient.setSelectedLayers(myLayers);
        GISDataset tempDataset = myArcIMSClient.read(inEnvelope);
        return tempDataset;
    }
    public gistoolkit.display.Style getStyle() {
        return null;
    }

}
