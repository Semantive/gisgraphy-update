/*
 *    GISToolkit - Geographical Information System Toolkit
 *    (C) 2002, Ithaqua Enterprises Inc.
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; 
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    
 */

package proprietary.datasources.ermapper;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gistoolkit.display.GISDisplay;
import gistoolkit.datasources.*;
import gistoolkit.application.*;
import gistoolkit.application.layers.*;

/**
 * Panel for collecting the information required for creating an Earth Resource Mapping data source.
 * Creation date: (5/1/2001 11:05:59 AM)
 */
public class ERMapperDataSourcePanel extends JPanel implements ActionListener, DataSourcePanel{
    
    /**
     * Text field to allow the user to type the location directly.
     */
    private JTextField myTextFieldLocation;
    
    /**
     * Button for looking up a location.
     */
    private JButton myButtonLocation;
    
    /**
     * Reference to the Datasource.
     */
    private DataSource myDatasource = null;
    
    /**
     * Construct a new Earth Resource Mapping panel.
     */
    public ERMapperDataSourcePanel() {
        super();
        initPanel();
    }
    
    /**
     * Construct a new Earth Resource Mapping panel.
     * @param layout java.awt.LayoutManager
     */
    public ERMapperDataSourcePanel(java.awt.LayoutManager layout) {
        super(layout);
        initPanel();
    }
    
    /**
     * Construct a new Earth Resource Mapping panel.
     * @param layout java.awt.LayoutManager
     * @param isDoubleBuffered boolean
     */
    public ERMapperDataSourcePanel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
        super(layout, isDoubleBuffered);
        initPanel();
    }
    
    /**
     * Construct a new Earth Resource Mapping panel.
     * @param isDoubleBuffered boolean
     */
    public ERMapperDataSourcePanel(boolean isDoubleBuffered) {
        super(isDoubleBuffered);
        initPanel();
    }
    
    /**
     * Handle events coming from the button.
     */
    public void actionPerformed(ActionEvent inAE){
        if (myChooser == null){
            myChooser = new JFileChooser();
        }
        String tempString = myTextFieldLocation.getText();
        if ((tempString != null) && (tempString.length() >0)){
            File tempFile = new File(tempString);
            if (tempFile.exists()){
                if (tempFile.isDirectory()){
                    myChooser.setCurrentDirectory(tempFile);
                }
                if (tempFile.isFile()){
                    myChooser.setSelectedFile(tempFile);
                }
            }
        }
        
        
        // Note: source for ExtensionFileFilter can be found in the SwingSet demo
        //		ExtensionFileFilter filter = new ExtensionFileFilter();
        //		filter.addExtension("jpg");
        //		filter.addExtension("gif");
        //		filter.setDescription("JPG & GIF Images");
        //		chooser.setFileFilter(filter);
        int returnVal = myChooser.showOpenDialog(this);
        
        if(returnVal == JFileChooser.APPROVE_OPTION) {                
                
            myTextFieldLocation.setText(myChooser.getSelectedFile().getAbsolutePath());
        }
    }
    
    /**
     * Returns the fully configured datasource.
     */
    public DataSource getDataSource() throws Exception{
        ERMapperDatasource tempDatasource = new ERMapperDatasource(myTextFieldLocation.getText());
        return tempDatasource;
    }
    
    /**
     * Set up the GUI components for requesting the information from the user.
     */
    private void initPanel(){
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2,2,2,2);
        
        // create the type in box for the filename
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        JLabel tempLabelFile = new JLabel("File");
        add(tempLabelFile, c);
        
        c.gridx++;
        c.weightx = 1;
        myTextFieldLocation = new JTextField();
        add(myTextFieldLocation, c);
        myTextFieldLocation.setText(System.getProperty(Constants.getApplicationName()+".ERMapperDataSourceFile", myTextFieldLocation.getText()));
        
        c.gridx++;
        c.weightx = 0;
        myButtonLocation = new JButton("File");
        add(myButtonLocation, c);
        
        // add some space at the bottom
        c.gridx = 0;
        c.gridy++;
        c.weighty = 1;
        add(new JPanel(), c);
        
        // listen to the button
        myButtonLocation.addActionListener(this);
                
    }
    
    /**
     * Sets the GISDisplay in case the panel should need it.
     */
    public void setGISDisplay(GISDisplay inDisplay) {
    }
    
    /**
     * Save the file chooser for future reference
     */
    private static JFileChooser myChooser = new JFileChooser();
}